# Route 53 SME —— 硬数字与关键事实单一源（Canonical Facts）

> **本文件是全体系硬数字/边界结论的唯一权威源。** 任何 topic 正文、题库、总纲与本表冲突时，以本表为准；发现冲突就地改齐本表，不要在别处另立数字。
> 采集/复核日期：2026-09-20。每行分级：
> - **[官方现行]** = AWS 官方文档现行结论，可回溯官方 URL；
> - **[内部经验]** = 内部运营/case 经验值，非公开产品契约；
> - **[待验证]** = 需回官方文档或再抽查核对的结论。
>
> 本表已并入 DESIGN-REVIEW（Codex/Claude）与 exam/codex-review-findings.md 三处订正。

---

## 1. 控制面 API 限流（Rate Limiting）

| 事实 | 权威值 | 分级 |
|---|---|---|
| 公共 Route 53 API 账号桶（一般 API 调用） | 持续 **10 RPS**，突发上限 **50** | [官方现行] |
| DNS changes（ChangeResourceRecordSets 等变更类） | 持续 **100 次/秒**，突发上限 **1500** | [官方现行] |
| Route 53 **Resolver** API | 单独计量，约 **5 RPS**（不与上面两桶混用） | [官方现行] |
| 旧文里的「统一 5 RPS」「token bucket 容量 40 补 5/s」 | **已过时/错误**，勿再用 | [官方现行] |

> 说明：超限返回 `Throttling`/`PriorRequestNotComplete`，客户端应指数退避重试。5 RPS 只属 Resolver API，不是公共 Route 53 API 的账号桶。

---

## 2. 健康检查（Health Checks）

| 事实 | 权威值 | 分级 |
|---|---|---|
| Endpoint HC 请求间隔 | 仅 **10s 或 30s**；默认 30s；**创建后不可改** | [官方现行] |
| FailureThreshold（连续失败阈值） | **1–10 次**，默认 **3** | [官方现行] |
| 18% checker 规则 | >**18%** 的全球 checker 判健康才算健康；**仅** Endpoint HC 适用，Calculated/CloudWatch 不适用 | [官方现行] |
| HTTP(S) 响应时间 | **4s** 内建连 + 建连后 **2s** 内收 2xx/3xx | [官方现行] |
| TCP 响应时间 | **10s** 内建连 | [官方现行] |
| 字符串匹配（string match） | 搜索串区分大小写，须完整位于 body 前 **5120 bytes**；状态码后 2s 内收 body | [官方现行] |
| HC 类型 | Endpoint / Calculated / CloudWatch / **Recovery Control（ARC）** 四类（旧「只有三类」已过时） | [官方现行] |
| HTTPS 证书 | HC **不校验证书**；开 SNI 把 FQDN 放进 TLS ClientHello，首次证书名不匹配会重试且省略 SNI | [官方现行] |
| Calculated HC | 按健康子检查数与 HealthThreshold 比较（父上限 255 子检查） | [官方现行] |
| CloudWatch HC | 读 alarm **数据流**而非强制 alarm state；字段 `InsufficientDataHealthStatus`；**不支持跨账号 alarm** | [官方现行] |
| 新建 HC 默认状态 | 视为**健康** | [官方现行] |

---

## 3. 配额（Quotas / Limits）

| 事实 | 权威值 | 分级 |
|---|---|---|
| 每账号 Hosted Zone | 默认 **500**（可提额） | [官方现行] |
| 每 zone 记录数 | **10000**（超出收费，可提额） | [官方现行] |
| 单 RRset 值上限 | **400** 值 | [官方现行] |
| Geoproximity（同名同类型记录数） | 上限 **30**；其他路由策略同名同类型上限 **100** | [官方现行] |
| 每 PHZ 关联 VPC | **300**（超此规模建议改用 Profiles） | [官方现行] |
| 每 zone KSK 数 | 上限 **2** | [官方现行] |
| Resolver Endpoint 每 endpoint ENI | ≤ **6** | [官方现行] |
| 配额管理入口 | 走 **us-east-1**（Route 53 为全球服务，但配额/DNSSEC 管理在 us-east-1） | [官方现行] |
| 「1024 PPS/ENI 不可调」 | 属 EC2 ENI 的 DNS 查询包速率上限，非 Route 53 API 配额；诊断触顶用 Interface Analyzer | [待验证] |

---

## 4. DNSSEC

| 事实 | 权威值 | 分级 |
|---|---|---|
| KSK 密钥 | 用户提供的 **KMS 非对称 CMK**，算法 **ECC_NIST_P256**，**必须位于 us-east-1**；用户轮换；每 zone ≤2 | [官方现行] |
| ZSK | Route 53 自动管理与轮换（pre-publish，双 ZSK 并存正常） | [官方现行] |
| KSK 签名对象 | KSK 签署包含 KSK/ZSK 的**整个 DNSKEY RRset**；ZSK 签署其余 RRset（不是「KSK 签署 ZSK」） | [官方现行] |
| DS 记录 | 是子区 DNSKEY 的**摘要+算法元数据**，位于父区；**不含完整公钥** | [官方现行] |
| 签名 zone 的 TTL | 签名 zone 记录的**最大有效 TTL 为一周**；原 TTL < 一周的记录**不受影响**（不是「TTL 强制一周」） | [官方现行] |
| RRSIG | 对同名同类型的**整个 RRset**签名；inception/expiration 独立于 TTL 控制签名有效期 | [官方现行] |
| DNSSEC 性质 | 只提供**来源认证与完整性**，**不加密**（无机密性）；验证通常由**递归解析器**完成，非权威服务器 | [官方现行] |
| island of trust | 有 DNSKEY 但父区无 DS；禁用顺序=先解信任链（删父区 DS）→删 KSK→删 zone | [官方现行] |
| PHZ | **不支持** DNSSEC signing | [官方现行] |
| NSEC3 | 仅提高区域枚举成本，不保证阻止离线破解 | [官方现行] |

---

## 5. 路由策略（Routing Policies）

| 事实 | 权威值 | 分级 |
|---|---|---|
| Simple | 返回 RRset **全部值**并随机排序；**不是**「最多返回 8 个值」（8 值上限属 Multivalue）；单 RRset 配额 400 | [官方现行] |
| Multivalue | 正常最多返回 **8 条健康**记录；全部不健康时 fail-open 返回最多 8 条不健康记录 | [官方现行] |
| Weighted | 权重上限 **255**；权重 **0** 仅在所有非零权重记录不健康时才考虑，且零权重记录本身仍受 HC 影响（不是自动兜底） | [官方现行] |
| Geoproximity bias | 有效范围 **-99 ~ 99**（含 0）；0=无偏移，正值扩大区域，负值缩小 | [官方现行] |
| Geoproximity 创建方式 | **2024 起**支持普通记录/API/CLI/SDK 创建；**仅地图可视化**仍限 Traffic Flow（不是「必须用 Traffic Flow」） | [官方现行] |
| Latency | 记录须指定一个 AWS Region；**可**指向 AWS 外资源（对外部资源延迟可能不准）；非实时测量 | [官方现行] |
| Failover | Primary 无 HC 视为始终健康，不会切 Secondary；要有效故障转移，Primary 需 HC 或 ETH；Alias Primary 可用 EvaluateTargetHealth | [官方现行] |
| Geolocation | default 兜底、最小区优先 | [官方现行] |
| IP-based 掩码 | 普通条目 IPv4 /1–/24、IPv6 /1–/48；默认位置 * 可表示 /0（::/0）；PHZ 不支持 | [官方现行] |
| EDNS0 / ECS | VPC .2 resolver 支持 EDNS0，不支持 ECS；GeoIP 库 MaxMind（不披露细节） | [内部经验] |

---

## 6. 变更传播（Change Propagation）

| 事实 | 权威值 | 分级 |
|---|---|---|
| ChangeResourceRecordSets 状态机 | 返回后状态 `PENDING` → 全球生效后 `INSYNC` | [官方现行] |
| 确认全球已生效 | 轮询 **GetChange**，状态变为 **INSYNC** 即表示所有 Route 53 权威 DNS 服务器已同步该变更 | [官方现行] |
| 幂等/重试 | 变更是幂等的；并发未完成变更会触发 `PriorRequestNotComplete` | [官方现行] |

---

## 7. ARC（Application Recovery Controller）关键数字

| 事实 | 权威值 | 分级 |
|---|---|---|
| Zonal Shift / Autoshift | 最长 **72h**；fail-open 不移流量 | [官方现行] |
| Routing Control cluster | **5 个区域**数据面端点，≥3/5 quorum（后端复制一致性；客户端只调用一个端点） | [官方现行] |
| 控制平面位置 | 控制平面在 **us-west-2**；ARC 指标在 us-west-2 | [官方现行] |
| Recovery Control HC | 必须**显式创建** RECOVERY_CONTROL health check 并关联 RoutingControlArn（不自动对应） | [官方现行] |

---

## 变更来源对照

- 控制面限流 10/50、DNS changes 100/1500、Resolver 另算：exam/codex-review-findings.md「Topic 12」+ DESIGN-REVIEW（M7 单一事实源缺位）。
- 健康检查 10/30s、阈值 1–10 默 3、18%、4s/2s/10s、5120B：codex-review-findings.md「Topic 04」。
- DNSSEC KMS us-east-1 / 签名最大 TTL 一周：codex-review-findings.md「Topic 07」+「Topic 08」。
- 路由策略 Simple 全部值 / Multivalue≤8 / weight255 权重0 / bias -99..99 / geoproximity 2024：codex-review-findings.md「Topic 03」+「Topic 02」。
- GetChange=INSYNC、配额：00-knowledge-framework.md 驱动表 + 官方 DNSLimitations.html。

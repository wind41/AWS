# Route 53 SME 备考 —— 主知识框架（Master Syllabus / 驱动表）

> **硬数字以 `00b-canonical-facts.md` 为准。** 本总纲、各 topic 正文与题库中的任何硬数字/边界结论若与 `00b-canonical-facts.md` 冲突，一律以 `00b` 为权威单一源。

> **一句话学习目标**：以 15 个真实 case 为锚、以 AWS 官方文档为纲，掌握 Route 53 从公私 Hosted Zone、记录/Alias、8 种路由策略、健康检查、Resolver/混合 DNS、DNS Firewall、DNSSEC、域名生命周期、Profiles、ARC 到配额/限流与故障排查纪律的 SME 级深度与边界结论，能在考试与真实 case 中条件反射地给出正确答案和排查路径。

## 如何用这套材料备考 SME

1. **先读本框架**：看总览 mindmap 建立全局地图，再看「知识域驱动表」了解每个 topic 覆盖什么、绑定哪个真实 case、能做什么实验、对应哪条高频考点。
2. **按驱动表逐 topic 精读**（核心 `01-*.md` ~ `13-*.md`，及扩充的 `00a`、`03b`、`14`~`23`，共 25 个 topic）：每个 topic 文件套用第 4 节的统一模板——概念先行，真实 case 讲故事，动手实验固化，考点/易错点应试，最后一张该域 mermaid 逻辑导图收口。
3. **背边界数字**：内部研究「考点速记」+ 外部「SME 高频考点」两份速记表里的硬限制（1024 PPS、weight 255、18% checker、TTL 强制 1 周……）是高频必考，单独刷。
4. **按第 5 节路线推进**：先打基础域（Hosted Zone / 记录 Alias / 路由策略），再攻高频重灾区（Resolver 优先级 / 健康检查 / DNSSEC），最后补生命周期与治理域。
5. **来源可回溯**：每个 topic 的来源锚点列在驱动表，内部 wiki 需 Midway，外部为 AWS 官方 URL；不确定的边界结论回到锚点核对。

---

## 总览 Mermaid Mindmap

```mermaid
mindmap
  root((Route 53))
    Hosted Zones
      Public HZ
      Private HZ / VPC 关联
      Split-horizon / 重叠命名空间最长匹配
      合并 vs 分离 / 委派
    记录与 Alias
      A AAAA CNAME MX TXT SRV CAA NS SOA DS
      Alias vs CNAME
      Zone apex 只能 Alias
      TTL / Simple RRSET 返回全部值随机排序
    路由策略 8 种
      Simple
      Weighted 上限255 / 权重0
      Latency
      Failover / 主备
      Geolocation / default
      Geoproximity / bias -99..99 / 上限30 / 2024起支持普通记录
      Multivalue 最多8
      IP-based / CIDR / PHZ不支持
      EDNS0 ECS
    健康检查
      Endpoint HTTP HTTPS TCP
      Calculated 父255子
      CloudWatch alarm-based
      18% checker / fail-open
      Evaluate Target Health
      Unwanted HC abuse
    Resolver 与混合DNS
      VPC+2 / .2 resolver
      Inbound / Outbound Endpoint
      Forward Rule 优先 PHZ
      dot 全局 rule / RAM共享
      ENI QPS / NAT 出公网
    DNS Firewall
      出站按域名 / 防exfiltration
      rule group priority 从小到大
      ALLOW BLOCK ALERT
      Domain redirection / Advanced DGA 隧道
      Global Resolver / DNS View
    DNSSEC
      KSK 用户 KMS 非对称 CMK / ECC_NIST_P256 / 必须us-east-1
      ZSK R53 自动轮换
      信任链 DS / island of trust
      签名zone最大有效TTL一周 原TTL<一周不受影响 / PHZ不支持
    域名注册与生命周期
      Registrar-Registry-WHOIS
      TLD 特性 jp pay
      账号关闭 clientHold
      跨账号转移 / 转移锁
    Route53 Profiles
      跨账号统一分发
      local优先Profile / 最具体胜
      1 VPC 1 Profile
    ARC 应用恢复控制
      Zonal Shift 最长72h
      Autoshift
      Routing Control 开关 / 5区cluster
      Readiness Check / 指标在us-west-2
    服务集成
      ELB CloudFront S3 API GW GA
      ACM DNS 验证
    配额与限流
      1024 PPS 不可调
      每zone 10000记录
      公共API账号桶 持续10RPS/突发50
      DNS changes 持续100/s/突发1500
      Resolver API 约5RPS 另算
    故障排查纪律
      证据分级
      单点 vs 全局
      必要非充分
      dig / SERVFAIL / NXDOMAIN / NODATA
```

---

## 知识域驱动表（Wave 3 逐 topic 撰写清单）

> 编号 = 最终 topic 文件序号（`NN-<slug>.md`）。核心 01–13 由 inventory 的 A–J 与 external 的 15 节合并而来；后续扩充了 00a（协议底座横切）、03b（路由×HC 交互深度专题）、14–23（技术原理深挖 / 可观测性 / 成本 / 差异诊断 / Traffic Flow / IAM 治理 / Resolver 高级 / Cloud Map / 迁移 / 企业跨区跨账号）。**当前共 25 个 topic 文件**：00a、01–13、03b，及 14–23。
> case ID 取自 `r53-case-inventory.md`；实验主题取自 inventory 第 3b 节 + lab 素材；SME 考点编号 = external `r53-external-research.md` 第 15 节速记编号（A1–F35）。

| 序号 | 知识域名称 | 覆盖的知识点 | 绑定的真实 case（case ID） | 可做的实验（实验主题） | 关联 SME 高频考点编号 | 内部+外部来源锚点 |
|---|---|---|---|---|---|---|
| 01 | Hosted Zones（Public / Private / Split-horizon） | Public vs PHZ；PHZ 需 enableDnsHostnames/Support；VPC 关联、跨账号关联(VpcAssociationAuthorization)；split-view；重叠命名空间最长匹配；PHZ 支持/不支持的路由策略与健康检查；子域 PHZ 合并 vs 分离；apex NS+SOA | 178118102100384（合并 vs 分离，★）、178239640400861（PHZ 只经 VPC DNS）、178782060900806（跨区/跨账号关联、同名 PHZ 冲突） | 子域 PHZ 零停机合并进父域（降 TTL → 建全记录 → 切委派 → 删旧 zone）；`dig @169.254.169.253` 直验 VPC DNS 命中 PHZ | B11, E27（Profile 最具体）, 外部第2节最长匹配 | 内部 §1 + QA-3982；外部 hosted-zone-private-considerations.html / AboutHZWorkingWith.html |
| 02 | 记录类型与 Alias | 支持的记录类型(A/AAAA/CNAME/MX/TXT/SRV/CAA/NS/SOA/DS/CAA…)；Alias vs CNAME 五维差异；CNAME 不能位于 apex（Alias 可以）；Alias 免费/ETH/不能设 TTL；CNAME 不能与他类型共存；Simple RRSET 返回全部值随机排序（8 值上限属 MVA 非 Simple，单 RRset 配额 400 值）；ALIAS 链受支持（末端为合格 AWS 资源仍免费；同 zone 目标通常同类型，zone apex 不能最终指向 CNAME） | 178602594200640（Alias 指向 NLB 场景引出，★配合 topic 05） | 建 apex A-Alias 指向 ELB 并开 Evaluate Target Health，对比同目标 CNAME 的 dig 往返差异 | A1, A2, A3, A4, A5 | 内部 §2 + R53PublicDNS；外部 ResourceRecordTypes.html / resource-record-sets-choosing-alias-non-alias.html |
| 03 | 路由策略（8 种） | Simple/Weighted/Latency/Failover/Geolocation/Geoproximity/Multivalue/IP-based；weight 上限 255、权重 0 行为；geolocation default 兜底、最小区优先；geoproximity bias -99..99（含 0）、2024 起支持普通记录/API/CLI/SDK（仅地图可视化限 Traffic Flow）、上限 30；latency 非实时；multivalue 最多 8；IP-based CIDR 匹配规则、PHZ 不支持；EDNS0/ECS（.2 支持 EDNS0 不支持 ECS）；GeoIP 库(MaxMind 不披露) | 178246722300140（Geolocation/GeoIP/EDNS0，★）、178782060900806（failover 设计） | 加权路由按权重直查权威 NS 并发 ~10K 次统计实际分配比例；用 `dig TXT o-o.myaddr.google.com` 检测 resolver 是否支持 ECS | B6, B7, B8, B9, B10, B11, B12 | 内部 §3 + kyoheibb + TSR53DNSService；外部 routing-policy*.html / routing-policy-edns0.html |
| 04 | 健康检查（Health Check / HaaS） | 三类 HC（Endpoint/Calculated/CloudWatch alarm-based）；18% checker 判定；HTTP 4s+2s、TCP 10s、string match 5120 字节；HTTPS 不校验证书；新 HC 默认健康；calculated 父 255 子；CloudWatch HC 监控数据流非状态；InsufficientDataHealthState 三态；Evaluate Target Health 二选一；fail-open；HC 源 IP prefix list；Unwanted HC abuse 流程 | P460958645（CALCULATED HC 卡 Unhealthy，★）、V2254930641（Unwanted HC abuse，★） | CloudWatch alarm-based HC + `UpdateHealthCheck` 触发重评估观察状态同步；识别 HC User-Agent/prefix list 并演练 abuse outbound 流程（只读理解，禁用需 2PR） | C13, C14, C15, C16, C17, C18, C19 | 内部 §4 + TSR53HealthCheckService + TSOA runbook；外部 health-checks-creating-values.html / dns-failover-determining-health-of-endpoints.html / dns-failover-types.html |
| 05 | Resolver 与混合 DNS（解析优先级） | VPC+2/.2 resolver；Inbound(on-prem→AWS)/Outbound(AWS→on-prem) 方向；conditional forwarding rule；dot(.) 全局 rule；**Forward Rule 优先 PHZ 优先公网**；RAM 跨账号共享 rule；每 endpoint ≤6 ENI、~10K QPS/ENI、经 NLB/SG 降至 ~1.5–1.7K；outbound 出公网需 NAT；多 ENI + NACL 双向放行；VPC DNS 不过 SG/NACL；resolv.conf fallback 到公共 DNS 致 PHZ NXDOMAIN | 178602594200640（Forward Rule > PHZ > 公网，★核心）、178767531400698（多 ENI + NACL，★核心）、178239640400861（resolv.conf fallback）、178782060900806（rule regional 优先 PHZ） | 差分诊断：`nslookup`/`dig` UDP vs TCP(`+tcp`)、SRV 区分出站/入站/路由/目标故障；`kubectl exec` 看 Pod `/etc/resolv.conf` 与 CoreDNS dnsPolicy | D20, D21, D22, D23, D24 | 内部 §5 + QA-385/QA-1466 + Learn108；外部 resolver.html / resolver-availability-scaling.html + re:Post forwarding-rule-and-phz |
| 06 | DNS Firewall / Global Resolver | 出站按域名过滤、防 exfiltration；rule group 关联 VPC、priority 数字从小到大；rule 组内 priority；ALLOW/BLOCK/ALERT（含 domain list 才能 ALLOW，Advanced 只 BLOCK/ALERT）；BLOCK 响应 NXDOMAIN/NODATA/OVERRIDE；Domain redirection 检查整条链；DGA/DNS tunneling 高级检测；与 Network Firewall 区别；Firewall Manager 集中管理；Global Resolver + DNS View + Access Source/Token；OCSF query log；托管列表不公开 | （教学素材，无 Support case） repost_article_dns_firewall / repost_draft_global_resolver_dns_firewall(+lab) / dns_firewall_diagram.drawio | ★完整 lab：建 Global Resolver → DNS View → Access Source → Query Logging → 自定义/托管/DGA 规则 → `dig` 验证 → CloudWatch Logs Insights 查 OCSF `firewall_rule_id`（ALERT 命中 action=Allowed 只能靠日志区分） | E25, E26, 内部 §5 DNS Firewall QA-497(allowlist CNAME 未列被 BLOCK) | 内部 §5 DNS Firewall 段 + inventory §4 架构图；外部 resolver-dns-firewall.html / resolver-dns-firewall-overview.html |
| 07 | DNSSEC | signing 让 resolver 验真；KSK=用户 KMS 非对称 CMK(ECC_NIST_P256)、用户轮换、每 zone ≤2；ZSK=R53 自动 pre-publish 轮换(7–30 天，双 ZSK 并存正常)；信任链需父 zone 支持 DS；island of trust(有 DNSKEY 无父 DS)；禁用需先解信任链、可跳删 DS；签名 zone 记录最大有效 TTL 一周（原 TTL<一周不受影响）；PHZ 不支持；不支持 multi-vendor/vanity NS；负缓存；Resolver DNSSEC validation ≠ signing | 178970323600938（stale delegation SERVFAIL + DNSSEC 禁用/island of trust，★核心） | 启用 DNSSEC signing → 观察 DNSKEY 出现新 ZSK（正常）；按正确顺序禁用（解信任链→删 KSK→删 zone），复现/绕过 island of trust | E28, E29 | 内部 §6 + QA-2638/QA-325/QA-347 + R253；外部 dns-configuring-dnssec.html / resolver-dnssec-validation.html |
| 08 | DNS 安全 / dangling delegation / subdomain takeover | dangling DNS delegation → subdomain takeover；NS hold(StopZoneSniping) 机制与失效排查；Scenario 1–5；删 zone 正确顺序（先删 NS 记录/先解委派）；DNSSEC 作为防护；共享责任；abuse 报告入口 | 178715620200407（subdomain takeover / NS hold，★核心） | 复现 Scenario 1：删 child zone 但不同步删父域委派 → 用他账号"抢注"同名验证 NS hold 是否拦截（受控实验/概念演练） | E28（DNSSEC 防护）, F 排查纪律 | 内部 §1/§12 + inventory 知识域 F；外部 welcome-dns-service.html（委派链） |
| 09 | 域名注册 / TLD 特性 / 生命周期 | Registrar(Amazon Registrar/Gandi)→Registry→WHOIS；R53 Domains 全球/仅 us-east-1/仅商业分区；并非所有 TLD 支持注册（不支持不影响建 zone）；.jp/.pay 特性；账号关闭域名流水线(通知→suspend→~30 天删)、clientHold；跨账号转移须源账号发起、重开自动 unsuspend；转移锁(.jp 2025/10 起不支持)；WHOIS/RDAP 数据策略隐去 | 178238086600080（.jp 到期日机制，★）、178636929200282（账号关闭/clientHold/跨账号转移，★）、178791950000232（不支持的 .pay/LRP/PFR） | 用 `get-contact-reachability-status` 观察 reachability；核对控制台到期日 vs registry WHOIS 到期日的 .jp 月末更新差异（只读核对，非破坏性） | F33 | 内部 §7 + Networking TFC；外部 welcome-domain-registration.html |
| 10 | Route 53 Profiles | 跨账号/多 VPC 统一分发 DNS 配置（RAM，同 Region）；可关联 PHZ/Resolver rules/DNS Firewall rule groups/Interface endpoints/query logging；改 Profile 传播全关联 VPC；**1 VPC 只能 1 Profile**；优先级：local VPC 优先于 Profile，冲突取最具体；>300 VPC-PHZ 关联建议改用；避免与 endpoints 形成 DNS loop | （无独立 Support case，178782060900806 提及作为跨区多 VPC 治理选项） | 建 Profile 关联 PHZ + Resolver rule，跨账号 RAM 共享；构造 local vs Profile 同名冲突验证「最具体胜/local 优先」优先级表 | E27 | 内部 §8 + kyoheibb Profile 段；外部 profiles.html |
| 11 | Application Recovery Controller (ARC) | 2024/08 起独立服务（R53 SME 仍 POC）；Multi-AZ：Zonal Shift/Autoshift 最长 72h、fail-open 不移流量；Multi-Region：Routing Control(开关/5 区 cluster/safety rules)+Readiness Check(每分钟审计)；可配任何支持 HC 的路由策略；指标在 us-west-2；ARC 非必须（failover 记录/手改 simple/固定子域+改 apex Alias 也可切换） | （无独立 Support case，QA-3396/QA-2811 内部先例） | 演练 Zonal Shift 移走某 AZ（设过期时间）；用 routing control 开关做多 Region failover，验证 safety rule 阻止同时关两区 | E30 | 内部 §9 + R253/PeRC + QA-3396/QA-2811；外部 r53recovery routing-control.html / best-practices |
| 12 | 服务集成 + 配额与限流 | Alias 指向 ELB/CloudFront/S3/API GW/GA/VPC endpoint；apex 必 A-Alias；ACM DNS 验证 CNAME；CloudFront resolver identity 间歇 NODATA；**1024 PPS/ENI 不可调**；每 zone 10,000 记录(超收费)；value/record 400；geoproximity 同名同类型仅 30、其他 100；每 PHZ 300 VPC；KSK/zone 2；公共 Route 53 API 账号桶持续 10 RPS/突发 50、DNS changes 持续 100/s/突发 1500、Resolver API 约 5 RPS 另算；配额管理在 us-east-1 | 178602958500732（ip-ranges.json ROUTE53 分类/SNS 变更，★）、178602594200640（Alias→NLB 集成） | 从 ip-ranges.json 用 `jq` 提取 ROUTE53 权威 NS CIDR 并订阅 SNS `AmazonIpSpaceChanged`；用 Interface Analyzer/amzlogs 判断实例是否触顶 1024 PPS | F31, F32, F35, 内部 §11 边界数字 | 内部 §10/§11 + CWR-Route53 + ip-ranges 案例；外部 DNSLimitations.html / route53/pricing |
| 13 | 通用故障排查纪律（横切） | 证据分级(DIRECTLY_OBSERVED/DOCUMENTED_FACT/INFERENCE/UNKNOWN)；单点失败 vs 全局；必要非充分条件；故障签名 SERVFAIL/NXDOMAIN/NODATA/REFUSED；`dig` 用法(+short/+trace/+tcp/CNAME 类型)；标准排查树(whois/NS/HZ/CloudTrail)；内部工具(Info Search Tool/Customer Info Search/Dexter/K2)；LSE 先看 lse.amazon.com | 178222843600312（突然全部解析失败排查树，★）、178970323600938/178767531400698/178239640400861（证据纪律范例） | 对一个真实域构造 SERVFAIL/NXDOMAIN/NODATA 场景并用 dig 逐层定位；练标准排查树（whois→NS→HZ→CloudTrail 逐层收敛） | F 全组 + 各域交叉 | 内部 §12 + TSR53DNSService/TSOA runbook；外部 各故障签名散见于对应域官方页 |
| 00a | DNS 协议基础（横切底座 / RFC 级协议原理） | 迭代 vs 递归解析（stub/recursive/authoritative 三角色，R53=权威非递归）；delegation 与 glue；bailiwick 与 in/out-of-bailiwick glue(RFC 9471)；UDP 截断/TC 位/TCP fallback；EDNS0(RFC 6891)；NXDOMAIN vs NODATA；负缓存与 SOA MINIMUM(RFC 2308)；TTL 语义；DNS 报文头标志(AA/RD/RA/AD/CD，AD≠AA) | （无独立 case/方法论域，为 01/05/07/13/14 的协议底座） | `dig +trace`（看迭代过程）vs `dig @8.8.8.8`（递归结果、AA=0）对比；`dig +tcp`/TC 位/EDNS0 大包；构造 NXDOMAIN vs NODATA 对比 SOA MINIMUM 负缓存 | 外部第2节最长匹配 + F 排查纪律（贯穿 A/D/E 各域协议根） | 外部 RFC 1034/1035/2308/6891/9471；配套 topic 14 权威侧机制底座 |
| 03b | 路由策略 × 健康检查 × Failover 交互（深度专题） | 各路由策略绑 HC 后的完整行为；三层判读框架（是否参与评估→健康判定→策略选取+fail-open）；weighted+HC 含 0-weight 与全挂 fail-open；latency 先延迟后健康；geolocation/IP-based「无匹配」vs「全挂」两条失败路径（唯二不 fail-open）；MVA 全挂返回最多 8 条不健康；simple 不能绑 HC；核心心法「宁可返回可能坏的答案也不返回空」 | 178602594200640、178782060900806（failover 设计交互，承 topic 03/04） | 对每策略构造「全挂」与「无匹配」两场景，dig 验证 fail-open vs no answer；weighted 全不健康观察 0-weight 是否独占兜底 | B6–B12 + C13–C19（03×04 交叉） | 内部 topics/03 + topics/04；exam/codex-review-findings topic 03 第3/4/5/8项、topic 04 全部 |
| 14 | 技术原理深挖（底层机制 / 报文·数据面·信任链） | 递归解析完整路径与 R53 权威定位；权威 anycast/全球 NS 基础设施与四组委派 NS 选择机制；VPC Resolver 数据面架构/EDNS0 client subnet/缓存与负缓存/serve-stale；health checker 全球分布/18% 共识/数据面传播延迟；DNSSEC 验证链密码学；RD/AA/AD 标志层次(AA≠AD)；GetChange=INSYNC 为传播完成权威确认 | （无独立 case，为 01/04/05/07/03b 的机制底座） | `dig +short NS` vs 控制台四条 awsdns 对比；观察冷缓存迭代路径；核对 INSYNC 与下游 TTL 缓存的生效时差 | B/C/D/E 各域机制根 + 外部架构博客 | 外部 route-53-concepts.html + A Case Study in Global Fault Isolation 博客；配套 topic 00a |
| 15 | 可观测性（CloudWatch 指标 + Query Logging + CloudTrail） | 三条独立数据面（指标=趋势/告警、query logging=逐条取证、CloudTrail=谁改配置，不可互替）；Public DNS query logging 只投 CloudWatch Logs+日志组必须 us-east-1+缓存命中不产日志(采样)；Resolver query logging 三目标(CWL/S3/Firehose)+srcids 依路径可变+缓存不产日志；CloudWatch 指标命名空间与「全球服务指标只在 us-east-1」；DNSSECInternalFailure 必设告警；健康检查指标(HealthCheckPercentageHealthy 仅 Endpoint、ChildHealthCheckHealthyCount 仅 Calculated、SSLHandshakeTime 仅 HTTPS) | （无独立 case/方法论域，两方评审标为必补高频盲区） | 建 public/resolver query logging，制造缓存命中验证「缓存不产日志」；CloudWatch Logs Insights 查 ServFail/timeout 率；对 DNSSEC 指标设告警 | 内部 §7/§9/§5/§11 边界 + F 排查纪律 | 外部 Route 53 DG（Public/Resolver query logging、Monitoring hosted zones/health checks/Resolver、CloudTrail）；内部 §5/§7/§9/§11 |
| 16 | 成本 / 计费模型 | 两大收费类（按月固定费 vs 按查询量费）；hosted zone 月费(前25个$0.50，不按天 prorate，12h 宽限但查询照收)；PHZ 查询免费；DNS query 按路由策略分档(standard<latency<geo/geoproximity<IP-based)；NXDOMAIN/类型不匹配也收费；Alias 指向 AWS 资源查询免费(省钱手段)；Traffic policy record $50/月常驻隐形费；Resolver endpoint ENI 小时费；DNS Firewall Advanced/Profiles 小时费；用量类型代码(DNS-Queries/LBR-Queries/Geo-Queries/Cidr-Queries) | 178602958500732（承 topic 12，账单/用量类型） | 从账单区分「新增常驻资源」vs「查询量涨」；核对 Alias→AWS 资源免 query 费；估算 simple 换 geoproximity 单价约+75% | F31/F32/F35 + 内部 §11 边界数字 | 外部 route53/pricing + TLD 价目表 PDF + CloudWatch/KMS/S3 定价；配套 topic 12 |
| 17 | 反例库 / 差异诊断（同症状异根因对照库） | 「症状≠根因」方法论（承 topic 13 纪律落到具体症状）；SERVFAIL 5 根因(DNSSEC/stale 委派/上游超时/限流 conntrack/空 zone)及一句话判别顺序；解析不一致 5 根因(split-view/优先级命中/latency-geo 按 resolver IP/TTL 负缓存/多值加权)；间歇超时根因(多 ENI 某路径阻断/限流/1024 PPS 偷额度/转发目标间歇不响应)；每根因配判别特征+下一步验证命令；同症状可同时多根因(必要非充分) | 178222843600312、178970323600938、178767531400698、178239640400861（各症状范例，承 topic 13） | 按症状类别跑判别流程：`dig +cd`(分 DNSSEC)→`+trace`(分委派)→查 forward rule→查限流指标→核记录；VPC内外双查分 split-view | F 全组 + 各域交叉（差异诊断收口） | 内部 topics/13 纪律 + 各域 case；外部各故障签名对应域页 |
| 18 | Traffic Flow / Policy Record（编排层与可视化） | Traffic Flow 是编排层非第9种策略；三核心对象(traffic policy 免费/version≤1000/policy record=API 里 policy instance $50月费)；可视化编辑器嵌套多策略；geoproximity 地图仅可视化限 Traffic Flow(记录本身2024起可直建)；单向性(只能编排→生成，不能反向导入)；更新/回滚靠版本(UpdateTrafficPolicyInstance 异步需轮询 state+受 TTL 影响)；仅 public HZ、PHZ 不支持；配额(policy 50/账户、record 5/账户默认小需提额) | （无独立 case/方法论域，承 topic 03 路由策略编排） | 可视化建 latency→weighted 嵌套树生成 policy record；新建 version 后选择性更新+回滚验证异步 state；alias 指向 policy record 降本验证 | B 路由策略组 + 内部 §3 Traffic Flow | 外部 traffic-flow.html + DNSLimitations.html + route53/pricing；内部 §3(kyoheibb+TSR53DNSService)；配套 topic 03/16 |
| 19 | IAM / KMS / RAM / SCP 治理（跨账号权限与责任边界） | 权限四件套分层(IAM 主体+记录级/KMS DNSSEC 私钥授权/RAM 跨账号分发/SCP 组织护栏)；hosted zone 支持资源级 ARN，List/Get 逐 action 判断(单 zone 读支持 ARN，账户级枚举 ListHostedZones 必须 Resource:*)；三个记录级条件键(NormalizedRecordNames/RecordTypes/Actions 可「可改不可删」)；KMS key policy 必须授权 dnssec-route53.amazonaws.com(DescribeKey/GetPublicKey/Sign+CreateGrant)；SourceAccount/SourceArn 防 confused deputy；partition 边界(aws/aws-cn/aws-us-gov 不跨)；Profile 专属条件键 | （无独立 case/方法论域，承 topic 07/10/23 治理） | 写「可改 A 记录数据但不能删任何记录」的记录级 IAM 策略；配 DNSSEC KSK 的 KMS key policy + SourceArn；ExternalDNS 拆 ChangeRRSets(zone ARN)+ListHostedZones(*)两 Statement | E27/E28/E29 + 内部治理段 | 外部 Service Authorization Reference(Route53) + DNSSEC key policy 文档；内部 §7/§8/§10；配套 topic 07/10/23 |
| 20 | Resolver 高级能力（delegation / DoH / IPv6-DNS64 / Outposts / HA） | 承 topic 05 只写高级：endpoint 第三方向 INBOUND_DELEGATION(NS 委派+迭代 vs default inbound 转发)；inbound/outbound delegation 把「每子域一条 forward rule」折叠成一条委派(无额外费)；autodefined/system 规则与 `.`(dot) forward rule 交互(内部名默认不转发、SYSTEM 规则反向挖洞)；DoH/DoH-FIPS+SNI；dual-stack/IPv6-only endpoint；DNS64+NAT64；Resolver on Outposts；outbound endpoint HA 与容量规划(≤6 ENI、~10K QPS/ENI) | 178767531400698、178602594200640（承 topic 05 混合 DNS） | 建 INBOUND_DELEGATION 端点+on-prem 父区 NS 委派验证迭代解析；outbound delegation rule 覆盖多子域 vs 逐条 forward rule；SYSTEM 规则让子域就地解析 | D20–D24（承 topic 05） | 外部 CreateResolverEndpoint API + What's New(DoH/IPv6/delegation) + Outposts/scaling DG + hybrid DNS 博客；配套 topic 05/12 |
| 21 | Cloud Map / 服务发现 + ExternalDNS（容器动态命名） | R53 作动态服务发现底座；Cloud Map 三层模型(namespace/service/instance)；三种 namespace(Public DNS 建 public HZ/Private DNS 建 PHZ/HTTP 不建 HZ 只能 DiscoverInstances)；DNS discovery vs API discovery 两条腿(HTTP 只能 API，最易踩坑)；记录类型(A/AAAA/SRV/CNAME 创建后不可改，改类型须删服务重建)；路由策略(MULTIVALUE 最多8健康实例/WEIGHTED 随机等权、alias 场景必用 WEIGHTED)；custom health(UpdateInstanceCustomHealthStatus+30s) vs R53 HC；ECS 服务发现 task 注册注销/Service Connect vs Service Discovery；EKS ExternalDNS(TXT registry/owner-id/domain-filter/IRSA/限流) | （无独立 case/方法论域，承 topic 01/03/04/12） | Cloud Map create-private-dns-namespace→create-service→register-instance 全链；`dig service.namespace` 验 DNS discovery；HTTP namespace 验证只能 DiscoverInstances；EKS ExternalDNS IAM+OIDC+IRSA+Helm | 内部 topic 01/03/04/12 交叉 | 外部 Cloud Map API(DnsConfig/HealthCheckCustomConfig/CreateHttpNamespace)+DG + ECS DG/repost + EKS ExternalDNS repost；配套 topic 01/03/04/12 |
| 22 | DNS 迁移与批量变更剧本 | 注册(registrar)与解析(DNS hosting)是两件独立事(可只迁其一)；迁入编排三路径(手工/zone file 导入/导入后改造)；zone file 导入硬规则(RFC 格式、$GENERATE/$INCLUDE 失败、忽略 SOA+同名 NS、单次≤1000 条、已存在记录整份失败、尾点 FQDN 语义、只能控制台)；ChangeResourceRecordSets 原子性(整批事务、一条失败零落地)、CREATE/DELETE(值须完全一致)/UPSERT(整体替换、幂等首选)；硬上限(1000 ResourceRecord/batch、32000 字符，UPSERT 加倍)；NS 切换四阶段(降 TTL→并行验证→改注册商 NS→监控 INSYNC 非 PENDING)与回滚 | （无独立 case/运维执行域，承 topic 09/02/03/12） | zone file 导入排错(尾点/$GENERATE/幂等)；用 UPSERT 写可重跑批量脚本验证原子性；NS 切换四阶段 dry-run + GetChange 轮询 INSYNC | F 排查纪律 + 内部 §7 生命周期交叉 | 外部 migrate-dns-domain-in-use.html + import zone file/repost + ChangeResourceRecordSets + DNSLimitations.html；配套 topic 09 |
| 23 | 企业级跨区/跨账号 DNS 架构综合选型 | 三层集中式 DNS 要素(PHZ 管谁应答/Resolver 管往哪转/Profile 管怎么批量下发，叠加非替代)；hub-spoke 集中式 Resolver(一套共享 endpoint 服务全组织，TGW/peering+RAM 共享 rule)；跨账号 PHZ 两条路(VpcAssociationAuthorization 逐 PHZ vs Profiles 免授权规模化)；混合云双向条件转发(inbound←on-prem/outbound→on-prem，Forward Rule>PHZ 铁律致「PHZ 加记录不生效」)；多区域 failover(DNS 层负责切、数据面负责通)；所有集中式资源都是 Regional 跨区逐区建；Profiles vs 逐 VPC 关联 vs Resolver rule 三选一判据 | （无独立 case/架构综合域，收口 topic 01/05/10/19 碎片） | 用 Organizations 场景推演 hub-spoke Resolver + Profile 下发；对比逐 PHZ 授权 vs Profile 共享的运维量；构造同名 PHZ+forward rule 验证「PHZ 不生效」根因 | E27（Profile 最具体）+ D 域 + 各治理交叉 | 内部 topic 01/05/10/19 收敛；外部 Profiles/Resolver/RAM 官方页；配套 topic 01/05/10/19 |

---

## 每个 topic 文件的统一模板

> Wave 3 逐 topic 撰写时严格套用以下 5 段结构，产出 `NN-<slug>.md`。每段的写作要求见括注。

```markdown
# NN. <知识域名称>

## 1. 概念（Concept）
- 该域的 SME 级核心概念：定义、组件、工作原理、边界数字。
- 用 external + internal 研究里的权威结论，标来源锚点。
- 边界数字/硬限制单独加粗或列表，便于背记。

## 2. 真实案例说明（Real Case）
- 引用驱动表绑定的 case ID，一句话症状 → 根因 → 知识点落点。
- 讲清"为什么这个概念在真实故障里长这样"，把抽象概念钉到具体故事。
- 多个 case 时先讲 ★核心教学 case，再补充。

## 3. 实验步骤（Hands-on Lab）
- 套用驱动表「可做的实验」主题，写可复现分步命令（含预期输出、清理步骤）。
- 只读/受控/破坏性要标注；禁用/abuse 类只做概念演练，不执行需 2PR 的操作。
- 尽量给 dig/nslookup/jq/aws cli 的确切命令与判读方法。

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）
- 逐条列驱动表「关联 SME 高频考点编号」对应的速记点（A1..F35）。
- 每条写"考点结论 + 常见错误认知"，正误对照。
- 补该域特有的 internal 边界数字速记。

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）
- 一张该域的 mermaid 图（flowchart 表决策/优先级链，或 mindmap 表知识结构）。
- 纯 mermaid 语法，可 git 版本化。
- 例：解析优先级链、健康检查判定流程、DNSSEC 信任链、路由策略选择树。
```

---

## 备考路线（先学哪几个域 / 高频必考）

**第一梯队 —— 基础地基（先学，其它域都依赖）**
- **01 Hosted Zones**、**02 记录与 Alias**、**03 路由策略**。这三域是 Route 53 的骨架，考试占比最大，Alias vs CNAME、8 种路由策略的场景信号词是必考。

**第二梯队 —— 高频重灾区（错误率最高，重点攻）**
- **05 Resolver 与混合 DNS**：`Forward Rule > PHZ > 公网` 优先级、Inbound/Outbound 方向、多 ENI+NACL——真实 case 最集中，考试最爱考优先级链。
- **04 健康检查**：18% checker、HTTPS 不校验证书、Evaluate Target Health 二选一、fail-open——陷阱题密集。
- **07 DNSSEC**：KSK/ZSK 责任划分、TTL 强制 1 周、PHZ 不支持、signing≠validation——细节多易混。
- **06 DNS Firewall**：priority 从小到大、ALLOW 需 domain list、Domain redirection——出站/域名层概念。

**第三梯队 —— 生命周期与治理（补全，考点相对集中）**
- **09 域名注册/TLD/生命周期**、**10 Profiles**、**11 ARC**、**08 DNS 安全/takeover**。

**贯穿全程 —— 速记与纪律**
- **12 配额与限流** 的边界数字（1024 PPS 不可调、每 zone 10000 记录、geoproximity 30、KSK/zone 2、PHZ 300 VPC）+ **13 故障排查纪律**（证据分级、dig 判读、SERVFAIL/NXDOMAIN/NODATA 签名）从第一天起就穿插刷，考试反复出现。

**高频必考清单（务必条件反射）**：Alias 只能建 apex / Alias 免费 + ETH；weight≤255、权重 0 行为；geolocation default、geoproximity bias±99 + 上限 30 + 需 Traffic Flow；multivalue≤8；simple 无 HC；IP-based PHZ 不支持；18% checker；HTTPS 不验证书；Forward Rule 优先 PHZ；重叠命名空间最长匹配；KSK=用户 KMS（非对称 ECC_NIST_P256、必须 us-east-1）/ZSK=R53、DS 在父区且不含完整公钥、签名 zone 记录最大有效 TTL 一周（原 TTL<一周不受影响）；1024 PPS 不可调；公共 API 账号桶持续 10 RPS/突发 50、DNS changes 100/s（突发 1500）、Resolver API 约 5 RPS 另算；GetChange=INSYNC 表示全球已同步；ARC 指标在 us-west-2 / Zonal Shift 72h（Zonal Shift 最长 72h、Autoshift、Readiness Check——详见 topic 11）；R53 全球服务但配额/DNSSEC 管理走 us-east-1。

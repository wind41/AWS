# 10. Route 53 Profiles（跨账号 / 跨 VPC 集中式 DNS 治理）

> 驱动表定位：治理规模化梯队。核心价值 = 把一组 DNS 配置**打包分发**到多个 VPC，解决「逐 VPC 手工配置」在几十上百个 VPC 时的运维爆炸。无绑定真实 case（用典型多-VPC 企业治理场景推演）。SME 高频考点：Profile 是**打包分发**非取代 PHZ、**每 VPC 只能 1 个 Profile**、**最具体匹配优先（仅同名冲突时 local 优先）**、**跨账号靠 RAM 共享**、**Profile/资源/VPC 必须同 Region**。

---

## 1. 概念（Concept）

### 1.1 Route 53 Profile 是什么

- **Profile = 一组 DNS 配置的可复用「打包容器」**。把以下资源装进一个 Profile，然后把这个 Profile **一次性关联到多个 VPC**：
  1. **Private Hosted Zones（PHZ）**
  2. **Resolver rules**（转发规则 / 系统规则）
  3. **DNS Firewall rule groups**（含优先级与 fail-open/fail-closed 等行为设置）
  4. **Resolver query logging 配置**
  5. **Interface VPC endpoints**（可作为 Profile 资源随之下发）
  6. **VPC 级 DNS 设置**：如 DNSSEC validation、反向 DNS（reverse DNS）、DNS Firewall failure mode 等设置项也可通过 Profile 统一下发。
- 目的：把「本该逐 VPC 重复配置」的 DNS 治理策略，变成**建一次 Profile → 关联到 N 个 VPC**，实现**集中式、规模化**的 DNS 治理。（对应 case 178782060900806 引出的 >300 VPC-PHZ 关联的治理选项）

### 1.2 核心心智模型：打包分发，不是取代

- **关键考点①**：Profile 是**分发机制**，不是新的 DNS 资源类型。PHZ 还是 PHZ、Resolver rule 还是 Resolver rule —— Profile 只是把它们**成组、批量、集中**地关联到多个 VPC。
- 因此："用了 Profile 就不用 PHZ 了" 是**错误**认知。你仍然先创建 PHZ / Resolver rule / Firewall rule group，再把它们**放进** Profile 分发。

### 1.3 每 VPC 只能关联一个 Profile

- **关键考点②**：**1 个 VPC 同时只能关联 1 个 Profile**。想给一个 VPC 下发多组策略，必须把这些策略**合并进同一个 Profile**，不能叠加多个 Profile。
- 反过来：**1 个 Profile 可以关联到很多 VPC**（这正是它规模化的意义）；跨账号时这些 VPC 可以分属不同账号（见 §1.5）。

### 1.4 优先级：最具体匹配优先；仅同名冲突时 local 优先

- **关键考点③（对应 topic 01 的 E27）**：VPC 本地（local）配置与 Profile 下发的配置共存时，解析**首先遵循 DNS 的最具体匹配（most-specific-match）原则**——命名空间更具体（更长/更精确匹配查询名）的那条胜出，无论它来自 local 还是 Profile。
  - **只有当 local 与 Profile 存在"相同域名/相同命名空间"的冲突时，才由 local 优先**（就近覆盖）。
- 心智模型：**先看谁更具体；只有同名平手时才 local > Profile**。不要笼统记成"local 永远压过 Profile"——若 Profile 下发的是更具体的域名，仍是 Profile 命中。

### 1.5 跨账号：靠 RAM（Resource Access Manager）共享

- **关键考点④**：Profile 本身是一个可被 **AWS RAM 共享**的资源。跨账号治理的路径是：
  1. 中心账号创建 Profile 并装入配置；
  2. 通过 **RAM** 把该 Profile **共享**给成员账号（或整个 Organization / OU）；
  3. 成员账号接受共享后，把 Profile **关联到自己账号内的 VPC**。
- 由此实现**集中定义、跨账号统一下发**。这也**免去了逐个 PHZ 做 `VpcAssociationAuthorization` 跨账号授权**的繁琐（呼应 topic 01：跨账号关联 PHZ 需授权，或改用 Profiles 免此步）。
- **RAM 权限不局限于只读**：RAM 共享 Profile 时可选用允许成员账号"关联/管理"的权限集，不一定只授予只读——按治理需要选择权限即可（不要默认"RAM 共享的 Profile 只能被成员账号只读查看"）。

### 1.5b 同 Region 边界（硬约束）

- **Profile、被打包的资源、以及被关联的 VPC 必须处于同一 Region**：Profile 是区域性资源，不能跨 Region 关联 VPC 或跨 Region 打包资源。跨 Region 治理需在每个 Region 各自建立 Profile。
- **Organizations 共享可自动接受**：通过 Organizations 范围共享时，成员账号的接受可自动化；但 RAM 授予的权限集按所选 permission 决定，不必只读。

### 1.6 与「逐 VPC 配置」的对比（治理规模化）

| 维度 | 逐 VPC 手工配置 | Route 53 Profiles |
|---|---|---|
| 配置动作 | 每个 VPC 逐条关联 PHZ / Resolver rule / Firewall group | 建一次 Profile，批量关联多个 VPC |
| 跨账号 | 每个 PHZ 逐个 `VpcAssociationAuthorization` | 一次 RAM 共享，成员账号自助关联 |
| 一致性 | 靠人工/脚本保证，易漂移 | 集中定义，天然一致 |
| 变更传播 | 改动需遍历所有 VPC | 改 Profile，自动作用于所有关联 VPC |
| 规模上限痛点 | 每 PHZ 300 VPC、几十上百 VPC 运维爆炸 | 为规模化治理而生 |
| 覆盖内容 | 单类资源逐个处理 | PHZ + Resolver rules + DNS Firewall + query logging + Interface VPC endpoints 及 VPC 级设置一起打包 |

---

## 2. 案例说明（典型多-VPC 企业治理场景）

> 无真实 case；用典型企业多账号/多 VPC 集中式 DNS 治理场景推演。

### 场景 —— 「一次定义、全组织下发」的企业内网 DNS 治理

- **背景**：某企业用 AWS Organizations 管理 40+ 账号、上百个 VPC。安全与网络团队在**中心网络账号**统一管理：
  - 一个内网 PHZ `corp.internal`（所有工作负载访问内部服务）；
  - 一条 Resolver forward rule：把 `onprem.example.com` 转发到本地数据中心 DNS（走 Direct Connect / VPN）；
  - 一个 DNS Firewall rule group：拦截已知恶意域名；
  - Resolver query logging：把所有 VPC 的 DNS 查询集中投递到中心日志。
- **痛点（逐 VPC 配置时）**：每上线一个新 VPC / 新账号，网络团队都要重复：关联 PHZ（跨账号还要授权）、关联 Resolver rule、关联 Firewall group、配置 query logging —— 上百个 VPC 时极易漏配、不一致、审计困难。
- **用 Profile 后的解法**：
  1. 中心账号把上述配置（含可选的 Interface VPC endpoints 与 VPC 级 DNS 设置）**装进一个 Profile** `corp-dns-baseline`；
  2. 通过 **RAM** 把该 Profile 共享给整个 Organization；
  3. 各成员账号把 Profile **关联到本账号的每个 VPC**（一步到位，打包的配置全部生效；须与 Profile 同 Region）；
  4. **例外覆盖**：某个测试 VPC 需要一个只对它可见的临时 PHZ `sandbox.corp.internal`（与 Profile 基线**同名冲突**），直接在该 VPC **本地关联**这个 PHZ —— 因**同名冲突时 local 优先于 Profile**，测试 VPC 就近命中本地 PHZ，其余 VPC 仍走 Profile 下发的基线。
- **知识点落点**：
  1. Profile 把**多类 DNS 配置一起打包**（PHZ / Resolver rules / DNS Firewall / query logging / Interface VPC endpoints 及相关 VPC 级设置），而非只搬 PHZ（考点①的正例）；
  2. 每个 VPC 关联的是**这一个** `corp-dns-baseline` Profile，不能再叠加第二个 Profile（考点②）；
  3. 测试 VPC 的本地同名 PHZ 覆盖 Profile 基线，体现**同名冲突时 local 优先**（考点③；无同名冲突时按最具体匹配）；
  4. 跨 40+ 账号的下发靠**一次 RAM 共享**，免去逐 PHZ 授权（考点④）；前提是各资源与 VPC 同 Region。

---

## 3. 实验步骤（Hands-on Lab）

> 演示：建 Profile → 装入 PHZ + Resolver rule → 关联多个 VPC → RAM 跨账号共享 → 验证解析。所有步骤为受控/非破坏性演示，在测试资源上做。命令以 `aws route53profiles` 与 `aws ram` 为主。

### Lab：从零搭建并分发一个 DNS 治理 Profile

前置：已有一个测试 PHZ（`corp.internal`，zone id `<PHZ_ID>`）与一条 Resolver rule（`<RESOLVER_RULE_ID>`）；两个测试 VPC `<VPC_A>`、`<VPC_B>`（可跨账号）。

```bash
# 1) 创建 Profile
aws route53profiles create-profile --name corp-dns-baseline
#   记下返回的 Profile Id：<PROFILE_ID>

# 2) 把 PHZ 装进 Profile（ResourceArn 为该 PHZ 的 ARN）
aws route53profiles associate-resource-to-profile \
  --profile-id <PROFILE_ID> \
  --name attach-corp-internal \
  --resource-arn arn:aws:route53:::hostedzone/<PHZ_ID>

# 3) 把 Resolver rule 装进 Profile
aws route53profiles associate-resource-to-profile \
  --profile-id <PROFILE_ID> \
  --name attach-onprem-forward \
  --resource-arn arn:aws:route53resolver:<region>:<acct>:resolver-rule/<RESOLVER_RULE_ID>
#   （DNS Firewall rule group、query logging 配置同理，各用一次 associate-resource-to-profile）

# 4) 把 Profile 关联到本账号的多个 VPC
aws route53profiles associate-profile \
  --profile-id <PROFILE_ID> --name assoc-vpc-a --resource-id <VPC_A>
aws route53profiles associate-profile \
  --profile-id <PROFILE_ID> --name assoc-vpc-b --resource-id <VPC_B>
#   注意：若某 VPC 已关联了另一个 Profile，此步会失败（每 VPC 只能 1 个 Profile）

# 5) 跨账号：用 RAM 把 Profile 共享给成员账号（或 Organization）
aws ram create-resource-share \
  --name corp-dns-baseline-share \
  --resource-arns arn:aws:route53profiles:<region>:<acct>:profile/<PROFILE_ID> \
  --principals <MEMBER_ACCOUNT_ID>
#   成员账号接受共享后，在自己账号内执行第 4 步把 Profile 关联到本账号 VPC

# 6) 验证解析（在关联了 Profile 的 VPC 内的 EC2 上）
dig @169.254.169.253 service.corp.internal +short   # 命中 Profile 下发的 PHZ → 返回私有 IP
dig @169.254.169.253 host.onprem.example.com +short  # 命中 Profile 下发的 forward rule → 转发本地 DNS 应答
```

**预期与判读**：
- 第 4 步对已有 Profile 的 VPC 会报错 —— 直接印证**每 VPC 只能 1 个 Profile**。
- 第 6 步在**任何**关联了该 Profile 的 VPC 上都得到一致结果 —— 证明"建一次、多 VPC 生效"的分发效果。
- **同名冲突 local 优先验证**：在其中一个 VPC 上**本地**再关联一个**同名**但不同记录的 PHZ，重复第 6 步该记录，会看到返回的是**本地 PHZ** 的值而非 Profile 的值 —— 印证**同名冲突时 local 优先**（非同名时仍按最具体匹配）。

**清理**：先 `disassociate-profile`（解绑各 VPC）→ `disassociate-resource-from-profile`（卸下 PHZ/rule）→ 删除 RAM share → `delete-profile`。测试 PHZ / Resolver rule 按各自 topic 的清理方式删除。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **①Profile 是打包分发，不是取代 PHZ**：Profile 只是把 PHZ / Resolver rule / DNS Firewall group / query logging **成组批量关联**到多 VPC。PHZ 等资源仍需先单独创建。
  - 常见错误认知：以为"改用 Profile 后就不需要 PHZ 了"。
- **②每 VPC 只能关联一个 Profile**：一个 VPC 同时最多绑 1 个 Profile；要下发多组策略必须**合并进同一个 Profile**，不能叠加。反向 1 个 Profile 可关联到很多 VPC。
  - 常见错误认知：以为可以给一个 VPC 叠加多个 Profile 分层下发。
- **③最具体匹配优先；仅同名冲突时 local 优先（E27）**：local 与 Profile 共存时，先按 DNS **最具体匹配**决定命中方（更具体者胜，无论来源）；**只有当两者是相同域名/命名空间冲突时，才由 local 优先**（就近覆盖）。
  - 常见错误认知：笼统记成"local 永远压过 Profile"——若 Profile 下发的域名更具体，仍是 Profile 命中。
- **④跨账号靠 RAM 共享**：Profile 通过 **AWS RAM** 共享给成员账号 / Organization，成员账号接受后关联到自身 VPC。这**免去逐 PHZ 的 `VpcAssociationAuthorization`** 跨账号授权。
  - 常见错误认知：以为跨账号用 Profile 仍要对每个 PHZ 单独授权。
- **RAM 权限不必只读**：RAM 共享 Profile 时按所选 permission 集授予权限，可允许成员账号关联/管理，不一定只读。
  - 常见错误认知：以为 RAM 共享的 Profile 成员账号只能只读查看。
- **同 Region 边界（硬约束）**：Profile、被打包的资源、被关联的 VPC 必须处于**同一 Region**；跨 Region 治理需每个 Region 各建 Profile。Organizations 范围共享可自动接受。
  - 常见错误认知：以为一个 Profile 能跨 Region 关联 VPC 或打包异地资源。
- **打包的资源类型要记全**：PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging 配置、**Interface VPC endpoints**，以及 **DNSSEC validation / 反向 DNS / DNS Firewall failure mode 等 VPC 级设置** —— 都能进 Profile，不要只记"四类"。
- **治理规模化定位**：当 PHZ-VPC 关联逼近 **每 PHZ 300 VPC** 上限、或几十上百 VPC 逐个配置不可维护时，Profiles 是标准治理方案（呼应 case 178782060900806）。
- **变更传播**：改 Profile 内的配置会作用于**所有**关联该 Profile 的 VPC —— 集中一致是优点，但也意味着一次误改的**爆炸半径覆盖全部关联 VPC**，变更需谨慎评审。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

Profile 从中心账号定义、经 RAM 跨账号分发、到 VPC 内解析时与 local 配置的优先级决策链：

```mermaid
flowchart TD
    subgraph HUB["中心网络账号"]
      P["Route 53 Profile<br/>corp-dns-baseline"]
      P --> R1["PHZ (corp.internal)"]
      P --> R2["Resolver rules"]
      P --> R3["DNS Firewall rule groups"]
      P --> R4["Resolver query logging 配置"]
      P --> R5["Interface VPC endpoints /<br/>VPC级设置(DNSSEC校验·反向DNS·<br/>Firewall failure mode)"]
    end

    P -->|"AWS RAM 共享<br/>(跨账号 / Organization·同Region)"| SHARE(("RAM Resource Share"))
    SHARE --> MA["成员账号接受共享"]
    MA -->|"associate-profile<br/>(每 VPC 只能 1 个 Profile)"| V1["VPC-1"]
    MA --> V2["VPC-2"]
    MA --> V3["VPC-N ..."]

    V1 --> Q["VPC 内 DNS 查询<br/>(经 VPC+2 / .2 Resolver)"]
    Q --> MATCH{"local 与 Profile 配置<br/>按最具体匹配比较"}
    MATCH -- "更具体者胜(不论来源)" --> WINSPEC["用更具体的<br/>local 或 Profile 配置应答"]
    MATCH -- "同名/同命名空间冲突" --> USELOCAL["local 优先<br/>(就近覆盖 Profile)"]
    MATCH -- "均无匹配" --> PUB["转公网递归"]

    classDef warn fill:#fde,stroke:#b36;
    class USELOCAL,SHARE warn;
```

> 图注：两个核心决策点 —— **RAM 共享**是跨账号分发的唯一途径（免逐 PHZ 授权，且资源/VPC 须同 Region）；VPC 内解析时**先按最具体匹配决定命中方，仅同名冲突时 local 优先**，均无匹配才转公网。每个 VPC 只挂一个 Profile，一个 Profile 可覆盖 N 个（跨账号）VPC。

# Topic 20：Resolver 高级能力（delegation / DoH / IPv6-DNS64 / Outposts / HA 容量规划）

> Route 53 SME · P2 进阶层。本 topic 是 **topic 05（Resolver 与混合 DNS 基础：解析优先级链、Inbound/Outbound、`.` 规则、每 ENI QPS）** 与 **topic 12（配额）** 的**进阶延伸**——只写 05 没覆盖的新/高级能力：**Resolver endpoint delegation（inbound/outbound 委派）、autodefined/system 规则与转发规则的交互、DoH 与 DoH-FIPS、IPv6/dual-stack endpoint、DNS64+NAT64、Resolver on Outposts、outbound endpoint 高可用与容量规划**。05 的基础不重复；遇到解析优先级/方向/NACL 排障请回看 05。
>
> 来源锚点：
> - 官方 API 参考 `CreateResolverEndpoint`（Direction / Protocols / ResolverEndpointType / Dns64Enabled / OutpostArn / Ipv6InternetAccessEnabled 字段）。
> - AWS What's New：DoH（2023-12）、DoH+SNI（2024-10）、dual-stack/IPv6-only endpoint（2023-09）、Resolver endpoint DNS delegation for PHZ（2025-06；GovCloud 2026-04）。
> - AWS 博客：Streamline hybrid DNS management using Route 53 Resolver endpoints delegation（2025-08）；How to achieve DNS high availability with Route 53 Resolver endpoints（2024-07）。
> - DeveloperGuide：Route 53 on Outposts、resolver-overview-forward-network-to-vpc、best-practices-resolver-endpoint-scaling。
> - VPC UserGuide：nat-gateway-nat64-dns64。

---

## 1. 概念（Concept）

### 1.1 Endpoint 三种方向 —— 新增 `INBOUND_DELEGATION`（★进阶重点）
`CreateResolverEndpoint` 的 `Direction` 现有**三个**合法值（05 只讲了前两个）：

| Direction | 含义 |
|---|---|
| `INBOUND` | on-prem → AWS：把 on-prem 查询转发到本 VPC 的 Resolver，解析 PHZ / AWS 内部名（默认 inbound 端点，转发到 IP） |
| `OUTBOUND` | AWS → on-prem：把 VPC 查询转发到本地/其他网络 DNS |
| `INBOUND_DELEGATION` | **委派**：把某子域的**权威**从 on-prem 委派给 Route 53 Resolver——on-prem 通过标准 DNS **NS 记录委派 + 迭代查询**把子域交给 R53，而不是逐条建 conditional forwarding rule |

- **default inbound vs delegation inbound 的本质区别**：default inbound 端点是"on-prem 把查询**转发（forward）**给它"；delegation inbound 端点是"on-prem 的父区用 **NS 记录把子域委派（delegate）**给它，走标准迭代解析链"。
- 这解决了此前的限制：**Route 53 Resolver 端点原先不支持对私有、不可公网解析域名的迭代查询**，无法把 R53 纳入统一私有命名空间的委派链；现在可以了。
- 来源：官方 API `CreateResolverEndpoint` Direction 枚举；What's New 2025-06。

### 1.2 Inbound / Outbound Delegation（委派）机制 —— 减少 1:1 转发规则
delegation 的价值是**把"每个子域一条 forwarding rule"折叠成"一条委派"**：

- **Inbound delegation（on-prem → AWS 委派子域给 R53 PHZ）**：
  1. AWS 侧建 `aws.healthtech.example.com` 的 **PHZ** 并关联到 VPC，建 A 记录。
  2. 建 **inbound delegation 端点**（`Direction=INBOUND_DELEGATION`），记下端点 IP。
  3. on-prem 父区（`healthtech.example.com`）加 **NS 记录**把 `aws.healthtech.example.com` 委派给端点，并把 NS 主机名的 A 记录指向端点 IP（充当 glue）。
  4. on-prem resolver 迭代解析时按 NS 引荐（referral）走到 R53 端点拿权威应答。

- **Outbound delegation（AWS PHZ 把子域委派给 on-prem）**：
  1. VPC 有 outbound 端点。
  2. 在 PHZ（如 parent `example.com` 或 `healthtech.example.com`）里为子域建 **NS 记录**指向 on-prem 权威 DNS 的 FQDN。
  3. 建 **delegation rule**（`FORWARD` 之外的新 rule 类型）关联到 VPC。
  4. glue 处理：若 on-prem DNS 的 FQDN **在被委派的域内（in-zone）**，在 PHZ 里加它的 A 记录做 glue；若 **out-of-domain**，则单独建一条 forwarding rule 指向该 DNS 的 IP。
  - **关键收益**：`sales.healthtech...`、`hr.healthtech...`、`training.healthtech...` 等一堆子域，用 conditional forwarding 要**每个子域一条 forward rule**；用 outbound delegation **一条 `healthtech.example.com` delegation rule 就全覆盖**。

- **父+子域都在 on-prem** 时也支持：outbound 端点上建**两条**——`example.com` 的 **Forward Rule**（指父区 on-prem DNS）+ `example.com` 的 **Delegation Rule**；R53 收到 `drugs.healthtech.example.com` 查询后先按 forward rule 转给父区，父区回引荐，R53 顺委派链一路走到正确的 on-prem DNS。
- **计费**：delegation 已含在 Resolver endpoint 的**小时费 + 查询费**里，**无额外费用**。
- 来源：博客 Streamline hybrid DNS management（2025-08）。

### 1.3 autodefined / system 规则 与 forwarding rule 的交互（★易错，衔接 topic 05 优先级链）
- **autodefined rules（自动定义规则）**：VPC Resolver 为一批 **AWS 内部域名**自动内建的解析规则——如 `amazonaws.com` 的部分子域、`ec2.internal` / `<region>.compute.internal`、反向 DNS（`in-addr.arpa` / `ip6.arpa`）等；这些名字**默认不被 `.`(dot) forward rule 转发出去**，以免破坏内部功能。
- **`.`(dot) FORWARD 规则并非真的转发"全部"**：它覆盖除更具体规则（PHZ、autodefined 内部名）以外的所有域名；要连内部名也强制转发，需把该 VPC 的 `enableDnsHostnames` 关掉，或为这些内部域名单独建规则（05 已述，此处强调交互）。
- **System 规则可反向"挖洞"（打破 forward rule 的子域继承）**：Forward Rule 默认作用于该域名及其所有子域；给某子域建一条 **System 规则（RuleType=SYSTEM）**，可让该子域**不被转发**、改由 VPC Resolver 本地解析（例：`example.com` 建 FORWARD、`acme.example.com` 建 SYSTEM → acme 子域本地解析）。
- **优先级仍遵循 topic 05 铁律**：先比"最具体域名匹配"，再比类型（同层级：Forward Rule > PHZ > autodefined/内部 > 默认 Recursive `Internet Resolver`）。delegation rule 参与的是**迭代/引荐**路径，与"某域名到底命中哪条 rule"仍走同一套 most-specific-match 判定。
- 来源：DeveloperGuide resolver-rules 系列 + topic 05 交叉锚点。

### 1.4 DoH 与 DoH-FIPS（加密 DNS，考点新增）
- **DoH（DNS over HTTPS）**：2023-12 起 Resolver 端点支持，**inbound 与 outbound 都可用**；用 HTTP/HTTP2 over TLS 加密 DNS 查询数据。
- **协议组合规则（★背记，来自官方 API `Protocols` 字段）**：
  - `Protocols` 数组 **1–2 个**，合法值 `Do53 | DoH | DoH-FIPS`。
  - **default inbound 端点**可用：`Do53`、`DoH`、`DoH-FIPS`（单用），或 `Do53+DoH`、`Do53+DoH-FIPS`（组合）；空 = `Do53`。
  - **delegation inbound 端点**：**只能用 `Do53`**（不支持 DoH/DoH-FIPS）。
  - **outbound 端点**：`Do53`、`DoH`（单用）或 `Do53+DoH`（组合）；空 = `Do53`。**outbound 不支持 `DoH-FIPS`**。
  - ⚠️ **`DoH-FIPS` 仅适用于 default inbound 端点**——这是最容易考错的一条。
- **DoH + SNI（2024-10）**：outbound 端点向要求 SNI 做 TLS 校验的 DoH 目标发查询时，可指定 SNI 目标服务器主机名。
- **每 ENI QPS 影响**：DoH 的**每网络接口 QPS 显著低于 Do53（UDP）的 ~10K**（DoH 走 TLS/HTTP2 有握手与连接开销）——高 QPS 场景要为 DoH 预留更多 ENI（见 §1.7 容量规划）。
- 来源：What's New 2023-12 / 2024-10；官方 API `Protocols` 字段。

### 1.5 IPv6 / dual-stack endpoint（2023-09）
- `ResolverEndpointType` 三值：**`IPV4` | `IPV6` | `DUALSTACK`**；dual-stack = 同时经 IPv4 与 IPv6 解析，应用到端点所有 IP。
- **IPv6-only VPC / dual-stack VPC** 可用 IPv6 端点，让 IPv6 客户端不经 IPv4 也能解析。
- `IpAddresses` 里每条可同时给 `Ip`（IPv4）与 `Ipv6`；`Ipv6InternetAccessEnabled=true` 时 outbound 端点 ENI 可经 internet gateway 向**公网 IPv6 目标**转发查询（要用 SG/NACL/egress-only IGW 保护 ENI，注意 connection tracking 影响吞吐）。
- 来源：What's New 2023-09；官方 API `ResolverEndpointType` / `Ipv6InternetAccessEnabled`。

### 1.6 DNS64 + NAT64（让 IPv6-only 资源访问 IPv4-only 服务）
- **DNS64 是 VPC 子网级功能，不是在 Resolver 端点上开**：在**子网**上启用 DNS64（`aws ec2 modify-subnet-attribute --enable-dns64` 或 VPC 控制台改子网设置），启用后作用于该子网内所有 AWS 资源。此时该子网内资源查询走 **VPC 默认 Resolver（`.2` / IPv6 的 `fd00:ec2::253`）**，Resolver 为 IPv4-only 服务**合成 AAAA（IPv6）记录**——把 IPv4 地址加上 **`64:ff9b::/96`** 前缀（RFC 6052）。IPv6-only 客户端据此拿到 IPv6 地址去访问 IPv4-only 服务。
  - ⚠️ **勘误**：这条 IPv6-only→IPv4-only 的 DNS64 能力**由子网属性驱动**，不要说成"在 inbound Resolver 端点上 `Dns64Enabled=true`"。`CreateResolverEndpoint`/`UpdateResolverEndpoint` 确有 `Dns64Enabled` 字段（用于 inbound 端点场景的 DNS64 合成），但客户最常见的"IPv6-only 子网访问 IPv4 服务"的标准做法是**子网级 DNS64 + NAT64**，二者不要混为一谈。
- **必须与 NAT64 配对**：DNS64 只在 DNS 层合成地址，真正的 IPv6↔IPv4 报文转换由 **NAT Gateway 的 NAT64** 在网络层完成——需在子网路由表里加 **`64:ff9b::/96` 指向 NAT Gateway** 的路由（NAT64 在现有/新建 NAT GW 上自动可用）。
- **场景**：IPv6-only 子网里的资源要访问同 VPC/别 VPC/on-prem/公网的 IPv4-only 资源。
- 来源：VPC UserGuide nat-gateway-nat64-dns64（`64:ff9b::/96`、子网启用 DNS64、NAT GW 做 NAT64）；官方 API `Dns64Enabled` 字段（inbound 端点场景）。

### 1.7 Outbound endpoint 高可用与容量规划（★数字必背，衔接 topic 05 §1.5）
- **每个 endpoint IP（ENI）≤ ~10,000 QPS（over UDP/Do53）**；DoH 每 ENI 显著更低。
- **加了限制性 Security Group → connection tracking → 每 ENI 降到低至 ~1,500 QPS**（约 6 倍下降）；要么加 ENI，要么按 untracked-connections 规则配 SG 规避 connection tracking。
- **≤ 6 IP/endpoint（可经 Service Quotas 提额）**；加 IP **线性扩** QPS。
- **可用容量规划公式（备维护/故障降容）**：最佳情况 QPS = **`(n − 1) × 10,000`**（n = endpoint IP 数，扣 1 个 IP 应对单 AZ/单 ENI 故障）。例：6 IP → `(6−1)×10,000 = 50,000` QPS。
- **监控阈值**：监控 CloudWatch `InboundQueryVolume` / `OutboundQueryVolume` / `OutBoundQueryAggregateVolume`（含 per-IP）；**任一 IP 的峰值 QPS 超过其容量 50% 就应加一个 ENI**。
- **多 AZ 冗余**：跨 2 个 AZ 至少 2 个 endpoint IP；**3+ AZ 的 Region 关键应用建议 3 个 IP 跨 3 AZ**。Resolver **自动把查询复制/分发到多个 outbound ENI**——单 AZ 故障时（FIS 实证）活跃 AZ 的 ENI 继续发查询、**应用无 DNS 超时**。
- **Resolver rule 目标冗余**：每条 outbound rule 应配**多于一个**目标 DNS IP（**≤ 6 个**）。
- **子网规划**：Resolver 端点建议用独立 `/28` 或 `/27` 子网 + 独立路由表；跨 VPC 用 TGW / VPC peering。
- **VPC Resolver（.2）本身高可用**，无需自己规划冗余；DHCP option set 用 `AmazonProvidedDNS`。
- **发现不冗余端点**：Trusted Advisor 的 "Route 53 Resolver Endpoint Availability Zone Redundancy" 检查（可跨 Organizations 账号）。
- 来源：博客 How to achieve DNS HA（2024-07）+ best-practices-resolver-endpoint-scaling。

### 1.8 Resolver on Outposts（本地 DNS 解析）
- **Route 53 Resolver on Outposts**：在 **AWS Outposts Rack** 上建 Resolver 端点，让 Outposts 本地资源就近做 DNS 解析、并在与 Region 断连时保持本地可用性。
- **DNS 记录仍存在 Region、不落地 Outposts**——本地只做解析/缓存，记录管理仍集中在 Region（设计上"就近解析 + 集中管理"）。
- **建端点约束**：`OutpostArn` + `PreferredInstanceType` 必须**同时**指定（给了一个就必须给另一个）；用 `CreateOutpostResolver` / Resolver on Outposts 流程建。
- ⚠️ **LNI 不兼容**：启用了 **Local Network Interface (LNI)** 的 Outposts 子网**不能**放 Resolver 端点 ENI；若在含 Resolver 端点 ENI 的子网上启用 LNI，这些 ENI 会**停止工作**。
- Outposts 上 inbound 端点转发外部查询给 Outposts 上的 Resolver；outbound 端点把查询转给 on-prem 自管 DNS。
- 来源：DeveloperGuide Route 53 on Outposts；官方 API `OutpostArn` / `PreferredInstanceType` + LNI 兼容性说明。

---

## 2. 真实案例说明（Real Case）

> 本 topic 为进阶能力层，绑定 case 以"能力选型/排障判断"为主（基础混合 DNS case 见 topic 05 的 178602594200640 / 178767531400698）。

### 场景 A（选型）：一堆子域的转发规则爆炸 → 改用 outbound delegation
- **诉求**：客户 hybrid，PHZ 里 parent `healthtech.example.com` 在 R53，但 `sales.` / `hr.` / `training.` / `drugs.` 等十几个子域权威 DNS 还在 on-prem，要 VPC 内资源都能解析。
- **旧做法痛点**：每个子域一条 conditional forwarding rule → 规则数随子域线性增长、维护困难、易漏配。
- **正解**：建 outbound 端点 + **一条 `healthtech.example.com` delegation rule** + 在 PHZ 里给子域建 NS 记录指向 on-prem DNS FQDN；in-zone 的 DNS FQDN 用 PHZ 里的 A 记录做 glue，out-of-domain 的补一条 forwarding rule。**一条委派覆盖全部子域**。
- **SME 判断点**：看到"子域多、权威分散在 on-prem、还在不断新增"就该推 delegation 而非继续堆 forward rule；delegation **无额外费用**，不必担心成本。

### 场景 B（排障判断）：DoH-FIPS 建端点报参数错误
- **症状**：客户想给一个 **outbound** 端点或 **delegation inbound** 端点启用 `DoH-FIPS`，API 返回 `InvalidParameterException`（FieldName=Protocols）。
- **根因**：**`DoH-FIPS` 仅适用于 default inbound 端点**；outbound 只支持 `Do53`/`DoH`，delegation inbound 只支持 `Do53`。
- **正解**：改到 default inbound 端点用 DoH-FIPS；outbound 要加密改用 `DoH`（+ 必要时 SNI）。
- **SME 判断点**：协议组合与端点类型强绑定，别记成"DoH-FIPS 到处能用"。

### 场景 C（排障判断）：Outposts 上 Resolver 端点 ENI 突然全部失效
- **症状**：Outposts 上原本正常的 Resolver 端点，某次子网变更后 ENI 全部停止响应。
- **根因**：在含 Resolver 端点 ENI 的 Outposts 子网上**启用了 LNI（Local Network Interface）**，二者不兼容。
- **正解**：把 Resolver 端点 ENI 迁到未启用 LNI 的子网。
- **SME 判断点**：Outposts + Resolver 端点排障先查子网是否开了 LNI。

### 场景 D（容量规划）：高 QPS 场景每 ENI 只跑到 ~1.5K
- **症状**：客户抱怨 outbound 端点吞吐远低于预期（~1.5K/ENI 而非 ~10K）。
- **根因**：端点 ENI 挂了限制性 Security Group，触发 connection tracking，每 ENI 有效 QPS 降到低至 ~1,500（约 6 倍）。
- **正解**：加 ENI，或按 untracked-connections 规则配 SG 规避 connection tracking；并按 `(n−1)×10,000` 规划可用容量、监控 per-IP QPS 超 50% 就加 ENI。

---

## 3. 实验步骤（Hands-on Lab）

> 受控实验，涉及 endpoint / rule / NAT GW 会产生小额费用，实验后清理。

### Lab A：建 dual-stack outbound 端点 + 观察协议约束
```bash
# dual-stack outbound（每子网给 IPv4+IPv6），协议 Do53+DoH
aws route53resolver create-resolver-endpoint \
  --creator-request-id lab-$(date +%s) \
  --name lab-out-dualstack \
  --direction OUTBOUND \
  --resolver-endpoint-type DUALSTACK \
  --protocols Do53 DoH \
  --security-group-ids sg-xxxx \
  --ip-addresses SubnetId=subnet-aaa SubnetId=subnet-bbb
# 反例（预期报错 InvalidParameterException / Protocols）：outbound 用 DoH-FIPS
aws route53resolver create-resolver-endpoint \
  --creator-request-id lab-err-$(date +%s) --name lab-err \
  --direction OUTBOUND --protocols DoH-FIPS \
  --security-group-ids sg-xxxx \
  --ip-addresses SubnetId=subnet-aaa SubnetId=subnet-bbb
# → 现场验证「DoH-FIPS 仅 default inbound」
```

### Lab B：inbound delegation 端点（on-prem 委派子域给 R53 PHZ）
```bash
# 1) 建 PHZ aws.healthtech.example.com 并关联 VPC，建 A 记录 app1
# 2) 建 inbound delegation 端点（只能 Do53）
aws route53resolver create-resolver-endpoint \
  --creator-request-id lab-del-$(date +%s) \
  --name lab-inbound-delegation \
  --direction INBOUND_DELEGATION \
  --protocols Do53 \
  --security-group-ids sg-xxxx \
  --ip-addresses SubnetId=subnet-aaa SubnetId=subnet-bbb
# 3) 记下端点 IP；on-prem 父区 healthtech.example.com 加 NS 委派 aws 子域，
#    并把 NS 主机名 A 记录指向端点 IP（glue）。
# 4) 从 on-prem 迭代解析 app1.aws.healthtech.example.com，确认走委派链到 R53
```

### Lab C：DNS64 + NAT64（IPv6-only → IPv4-only）
```bash
# 前提：一个 IPv6-only 子网 + 一个带 NAT64 的 NAT Gateway
# DNS64 在【子网】上开（不是在 Resolver 端点上）
aws ec2 modify-subnet-attribute --subnet-id subnet-ipv6only --enable-dns64
# 在该子网路由表加 64:ff9b::/96 指向 NAT Gateway
aws ec2 create-route --route-table-id rtb-xxxx \
  --destination-ipv6-cidr-block 64:ff9b::/96 --nat-gateway-id nat-xxxx
# 从 IPv6-only 客户端查一个 IPv4-only 名字，预期拿到 64:ff9b::/96 前缀的合成 AAAA
dig AAAA ipv4-only-service.example.com   # 走 VPC 默认 Resolver(.2 / fd00:ec2::253)
# 访问该 AAAA，报文经 NAT GW NAT64 转成 IPv4 到达目标
```

### Lab D：outbound HA 容量验证（多 AZ + FIS）
```bash
# 建 3 IP 跨 3 AZ 的 outbound 端点；rule 配 2 个目标 DNS IP
# 用 FIS AZ power-failure 场景断一个 AZ，持续 dig 观察无超时
# CloudWatch 看 per-IP OutboundQueryVolume，超 50% 容量则加 ENI
# 容量公式：(n-1)*10000，6 IP → 50000 QPS
```

### 清理
```bash
aws route53resolver delete-resolver-endpoint --resolver-endpoint-id rslvr-xxxx
# 删除临时 PHZ / NAT GW / FIS 模板
```

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **E1 三种 Direction**：`INBOUND` / `OUTBOUND` / **`INBOUND_DELEGATION`**。
  - ❌ 常见错误：以为只有 inbound/outbound 两种；delegation 是**委派（NS + 迭代）**不是 forward。

- **E2 delegation 减少 1:1 转发规则（★）**：一堆子域权威在 on-prem 时，**一条 delegation rule** 覆盖全部子域，胜过"每子域一条 forward rule"。
  - ✅ delegation **无额外费用**（含在端点小时+查询费里）。
  - ❌ 常见错误：把 delegation 当成"另一种转发"——它走标准 NS 委派/迭代链；out-of-domain 的 NS 主机名要补 forwarding rule 或 in-zone glue A 记录。

- **E3 协议组合强绑端点类型（★最易错）**：
  - **DoH-FIPS 仅 default inbound**；outbound 仅 `Do53`/`DoH`；delegation inbound 仅 `Do53`；`Protocols` 数组 1–2 项，值 `Do53|DoH|DoH-FIPS`，空=Do53。
  - ❌ 常见错误：outbound 或 delegation inbound 上配 DoH-FIPS → `InvalidParameterException`。
  - DoH 每 ENI QPS 显著低于 Do53 ~10K，高 QPS 要多留 ENI。

- **E4 ResolverEndpointType**：`IPV4` / `IPV6` / `DUALSTACK`；dual-stack = 同时 v4/v6，应用到所有 IP。
  - `Ipv6InternetAccessEnabled` 让 outbound 经 IGW 转发公网 IPv6 目标（注意 SG/NACL + connection tracking）。

- **E5 DNS64（子网级功能）**：在 **IPv6-only 子网上启用 DNS64**（`modify-subnet-attribute --enable-dns64`），VPC 默认 Resolver 为 IPv4-only 服务合成 AAAA，前缀 **`64:ff9b::/96`**，**必须配 NAT64（子网路由表加 `64:ff9b::/96` 指向 NAT GW）**才能真正通信。
  - ❌ 常见错误：把它说成"在 inbound Resolver 端点上开 `Dns64Enabled`"——标准做法是**子网级 DNS64**；也别忘了网络层要 NAT64。

- **E6 容量/HA 数字（★背记）**：
  - 每 IP(ENI) ~10K QPS（Do53/UDP）；限制性 SG → connection tracking → 低至 ~1.5K；≤6 IP/endpoint（可提额）；线性扩。
  - **可用容量公式 `(n−1)×10,000`**（6 IP → 50K）；per-IP 峰值超容量 **50%** 就加 ENI；监控 `InboundQueryVolume`/`OutboundQueryVolume`/`OutBoundQueryAggregateVolume`。
  - 多 AZ：≥2 IP 跨 2 AZ，3+ AZ Region 关键应用 3 IP 跨 3 AZ；Resolver 自动复制查询到多 ENI，单 AZ 故障不断。
  - 每条 outbound rule ≤6 目标 DNS IP，冗余至少 2 个。
  - ⚠️ 别与 **1024 PPS/ENI 不可调**（实例侧 VPC+2 link-local 限制，topic 12/05）混淆——那是**实例侧**，这是**endpoint 侧**。

- **E7 Outposts**：`OutpostArn` + `PreferredInstanceType` 必须**同时**给；DNS 记录仍在 Region、本地只解析/缓存；**LNI 子网与 Resolver 端点 ENI 不兼容**（开 LNI 会让端点 ENI 停摆）。

- **E8 autodefined/system 交互**：`.` FORWARD 不转 AWS 内部名（autodefined）；给子域建 **SYSTEM 规则**可让它不被上层 FORWARD 转发、本地解析；优先级仍是"最具体优先，同层级 Forward>PHZ>内部>默认递归"（详见 topic 05）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

### 5.1 Endpoint 方向 × 协议 × 类型 能力矩阵
```mermaid
flowchart TD
    EP[Resolver Endpoint] --> DIR{Direction}
    DIR --> IN[INBOUND default<br/>on-prem→AWS forward]
    DIR --> OUT[OUTBOUND<br/>AWS→on-prem]
    DIR --> DEL[INBOUND_DELEGATION<br/>NS委派+迭代]

    IN --> INP[协议: Do53 / DoH / DoH-FIPS<br/>可组合 Do53+DoH 或 Do53+DoH-FIPS]
    OUT --> OUTP[协议: Do53 / DoH<br/>❌ 无 DoH-FIPS]
    DEL --> DELP[协议: 仅 Do53]

    EP --> TYPE[Type: IPV4 / IPV6 / DUALSTACK]
    SUBNET[IPv6-only 子网] --> DNS64[子网启用 DNS64<br/>VPC Resolver 合成 AAAA 64:ff9b::/96<br/>需配 NAT64: 路由 64:ff9b::/96→NAT GW]
    style DELP fill:#fff4d6
    style OUTP fill:#ffe0e0
    style DNS64 fill:#e0f0ff
```

### 5.2 Outbound delegation 折叠多子域转发规则
```mermaid
flowchart LR
    subgraph OLD[旧: conditional forwarding]
      R1[fwd sales.healthtech...]
      R2[fwd hr.healthtech...]
      R3[fwd training.healthtech...]
      R4[fwd drugs.healthtech...]
    end
    subgraph NEW[新: outbound delegation]
      D1[一条 delegation rule<br/>healthtech.example.com]
      NS[PHZ 内 NS 记录指向 on-prem DNS FQDN<br/>+ in-zone glue A / out-of-domain forward rule]
    end
    OLD -.规则随子域线性增长.-> PAIN[[维护困难/易漏]]
    NEW -.一条覆盖全部子域.-> WIN[[无额外费用 / 走标准迭代委派链]]
    style NEW fill:#e0ffe0
    style OLD fill:#ffe0e0
```

### 5.3 Outbound endpoint 高可用与容量规划
```mermaid
flowchart TD
    APP[VPC 应用] --> RES[VPC Resolver .2<br/>复制查询到多 ENI]
    RES --> AZ1[ENI@AZ-a ~10K QPS]
    RES --> AZ2[ENI@AZ-b ~10K QPS]
    RES --> AZ3[ENI@AZ-c ~10K QPS]
    AZ1 & AZ2 & AZ3 --> TGT[on-prem DNS<br/>rule 配≥2 目标IP]
    AZ2 -. FIS 断 AZ-b .-> DOWN[该 ENI 停]
    DOWN -.其余 AZ 继续.-> NOTO[[应用无 DNS 超时]]
    CAP[[容量: n-1 ×10K<br/>6IP→50K<br/>限制性SG→~1.5K<br/>per-IP>50%容量→加ENI]]
    style NOTO fill:#e0ffe0
    style CAP fill:#fff4d6
```

---

## 来源（Sources）

- 官方 API 参考：`CreateResolverEndpoint`（Direction=INBOUND|OUTBOUND|INBOUND_DELEGATION；Protocols=Do53|DoH|DoH-FIPS 及组合规则；ResolverEndpointType=IPV4|IPV6|DUALSTACK；Dns64Enabled；OutpostArn+PreferredInstanceType；Ipv6InternetAccessEnabled；IpAddresses 最少 2 项、LNI 子网不兼容）—— docs.aws.amazon.com/Route53/latest/APIReference/API_route53resolver_CreateResolverEndpoint.html
- AWS What's New：Resolver endpoints support DoH（2023-12）；DoH with SNI validation（2024-10）；dual-stack & IPv6-only Resolver endpoints（2023-09）；Resolver endpoints DNS delegation for private hosted zones（2025-06；GovCloud 2026-04）
- AWS 博客（Networking & Content Delivery）：Streamline hybrid DNS management using Amazon Route 53 Resolver endpoints delegation（2025-08）；How to achieve DNS high availability with Route 53 Resolver endpoints（2024-07，含 `(n−1)×10,000` 公式、per-IP 50% 阈值、connection tracking ~1.5K、多 AZ FIS 验证）
- DeveloperGuide：What is Amazon Route 53 on Outposts（outpost-resolver.html，记录存 Region 不落地）；How DNS resolvers on your network forward DNS queries to Resolver endpoints（default vs delegation inbound）；best-practices-resolver-endpoint-scaling
- VPC UserGuide：NAT gateway NAT64 & DNS64（nat-gateway-nat64-dns64.html，`64:ff9b::/96`）
- 交叉锚点：topic 05（解析优先级链 / Inbound-Outbound / `.` 规则 / 每 ENI QPS 基础）、topic 12（配额与 1024 PPS 区分）

# 23. 企业级跨区 / 跨账号 DNS 架构综合选型（Hub-Spoke Resolver · 跨账号 PHZ · 混合云 · 多区 failover · 决策树）

> 驱动表定位：架构综合 / 选型收口梯队。核心价值 = 把散落在 topic 01（PHZ 跨账号关联）、05（Resolver / 混合 DNS / RAM 共享）、10（Profiles 打包分发）、19（IAM/RAM/SCP 跨账号治理）里的碎片，收敛成一张**「多 VPC / 多账号 / 多区域该怎么建集中式 DNS、什么时候用哪种机制」的选型全景**。无绑定单一 case（用典型企业 Organizations 场景推演，锚各碎片的真实 case 结论）。SME 高频考点：**Profiles vs 逐 VPC 关联 vs Resolver rule 三选一的判据**、**hub-spoke 集中式 Resolver（共享 inbound/outbound endpoint）省钱省运维**、**跨账号 PHZ 关联 `VpcAssociationAuthorization` vs 用 Profiles 免授权**、**混合云条件转发的双向对接（inbound←on-prem、outbound→on-prem）**、**多区域 failover 的 DNS 层与数据面职责边界**、**所有集中式资源都是 Regional、跨区要逐区建**。

---

## 1. 概念（Concept）

### 1.0 先厘清：三层「集中式 DNS」要素，别混

企业级 DNS 架构问题几乎都能拆成三层，每层用不同机制、有不同跨账号 / 跨区行为：

| 层 | 要素 | 集中式机制 | 跨账号靠 | 跨区行为 |
|---|---|---|---|---|
| **名字空间**（谁来应答内部名） | Private Hosted Zone（PHZ） | 集中账号建 PHZ，关联到多账号 VPC | `VpcAssociationAuthorization`，或改用 Profiles 免授权 | PHZ 可跨区关联 VPC；同名冲突 / 最具体匹配（topic 01） |
| **转发 / 混合**（内部名往哪转、on-prem 怎么互通） | Resolver endpoint（inbound/outbound）+ Resolver rule | hub-spoke：一套共享 endpoint 服务全组织 | Resolver rule 经 RAM 共享（同 Region） | endpoint/rule 都是 **Regional**，每区一套 |
| **分发 / 治理**（把上面两层一次性下发到 N 个 VPC） | Route 53 Profiles | 建一次 Profile，批量关联多 VPC | Profile 直接 RAM 共享给账号 / OU / Org | Profile / 资源 / VPC 必须同 Region，每区建一个 Profile |

> 记忆锚：**PHZ 管「谁应答」、Resolver 管「往哪转」、Profile 管「怎么批量下发」**。三者不是替代关系，是叠加：Profile 里装的正是 PHZ + Resolver rule（topic 10 §1.1）。

### 1.1 集中式 Resolver：Hub-Spoke（共享 inbound/outbound endpoint）

- **痛点**：Resolver endpoint 按 ENI 小时 + 查询量计费，且每个 endpoint 要占 2+ 个子网 ENI。**若每个 VPC 各建一套 inbound/outbound endpoint，成本与运维随 VPC 数线性爆炸**。
- **Hub-Spoke 解法**：在一个**中心（hub / 网络）VPC / 账号**里建**一套** inbound + outbound endpoint，spoke VPC 通过 **TGW（Transit Gateway）/ VPC peering** 把 DNS 查询送到 hub，由 hub 的 endpoint 统一对 on-prem 转发（outbound）、统一接收 on-prem 查询（inbound）。
- **落地要件**：
  1. spoke VPC 上的 **Resolver forward rule** 指向 hub 的转发目标（或指向 hub 内一台转发器 / hub 的 outbound endpoint 目标 IP）；
  2. rule 用 **RAM 共享**给各 spoke 账号（同 Region），**父账号 outbound endpoint 随 rule 一起共享，无需为每账号重建 endpoint**（topic 05 §1.3 D24）；
  3. hub 与 spoke 之间要有 **TGW/peering 网络可达 + 双向放行 DNS**（出站 UDP/TCP 53、入站 UDP/TCP ephemeral；endpoint 每个 ENI 子网 NACL 都要放行——topic 05 case 二的教训）。
- **收益**：一套 endpoint 服务全组织，避免每 VPC 重复建 endpoint。容量按 **每个 endpoint IP（ENI）约 10,000 QPS** 计——**若被连接跟踪（restrictive SG 规则、或经 NLB 路由）拖住，单 IP 上限可低至 ~1,500 QPS**；要更高吞吐就**给 endpoint 加 IP/ENI**（每加一个 ENI 增加成本），而非按"固定 6 ENI≈60K"想当然。**用 Profiles 把这条共享 rule 一次性下发到所有 spoke VPC**，就把「hub-spoke 转发」与「规模化分发」合并成一步。

### 1.2 跨账号 PHZ 共享：两条路，选一条

集中账号的内部 PHZ（如 `corp.internal`）要让别账号的 VPC 能解析，有两条路径：

- **路径 A — 逐 PHZ `VpcAssociationAuthorization`（topic 01 §1.2）**：
  1. VPC 属主账号先 `create-vpc-association-authorization` 授权；
  2. PHZ 属主账号再 `associate-vpc-with-hosted-zone` 关联；
  3. 可**跨账号、跨区**关联。**适合 PHZ 数量少、VPC 数量少**的场景。
  - 坑：解除授权 ≠ 解除关联；每个 PHZ × 每个 VPC 都要走一遍，数量一多运维爆炸；每 PHZ 上限 **300 VPC**（topic 01）。
- **路径 B — Route 53 Profiles（topic 10）**：把 PHZ 装进 Profile，**RAM 一次共享**给账号 / OU / 整个 Org，成员账号接受后关联到自己 VPC，**免去逐 PHZ 的 `VpcAssociationAuthorization`**。**适合几十上百 VPC、多账号规模化**。
  - 硬约束：Profile / 资源 / VPC 必须**同 Region**；每 VPC 只能 1 个 Profile。

### 1.3 混合云互通：on-prem AD DNS ↔ AWS（双向条件转发）

企业普遍有 on-prem Active Directory DNS，与 AWS 双向互通靠一对方向相反的转发（topic 05 §1.2）：

- **AWS → on-prem（outbound）**：在 hub VPC 建 **outbound endpoint** + 一条 **conditional forward rule**（如 `corp.example.com.` → on-prem AD DNS IP），把内部域名查询经 DX/VPN 转发到 on-prem。
- **on-prem → AWS（inbound）**：在 hub VPC 建 **inbound endpoint**（拿到一组私有 IP），在 **on-prem AD DNS 上配置条件转发器**，把 AWS 侧域名（如 `awscloud.internal`、PHZ 域名）指向这些 inbound endpoint IP。
- **关键边界**：
  - outbound endpoint 是**私有 IP**，要转发到公网 DNS 需经 **NAT Gateway**；
  - **同域名同层级时 Forward Rule 优先于 PHZ**（topic 05 §1.4 铁律）——若既建了 `corp.example.com` 的 PHZ 又建了同名 forward rule，查询会被**转发到 on-prem 而非命中 PHZ**，这是混合云最常见的「PHZ 加了记录不生效」根因（topic 05 case 178602594200640）；
  - 要让某子域**不**转发、就地解析，为该子域建一条更具体的 **System 规则**（反向覆盖）。

### 1.4 多区域 failover：DNS 层负责「切」，数据面负责「通」

多区域高可用要分清 **DNS 层** 与 **数据面 / 网络层** 各自职责：

- **DNS 层（Route 53 记录 + 健康检查）**：
  - **Failover 路由策略** + 健康检查：primary 区健康检查失败 → 自动把流量切到 secondary 区（**public zone** 用于面向 internet 的多区 failover）。
  - **Latency / Geoproximity** 路由：把用户就近导向最近健康的区域。
  - **PHZ 内多区 failover**：PHZ 支持 failover / latency / weighted / multivalue + 健康检查（但 **PHZ 不支持 IP-based，也不支持 DNSSEC**——topic 01 §1.4）。
  - ⚠️ **健康检查看的是端点可达性**，DNS 切换受 **TTL** 影响：TTL 越大，客户端缓存越久，切换越慢——多区 failover 记录应用**较短 TTL**（如 60s）。
- **数据面 / 网络层**：跨区的 PHZ 关联、Resolver endpoint（每区一套）、TGW 跨区 peering 才是「切过去之后真的能通」的前提。**DNS 把名字解析到 secondary 区的 IP，但那条网络路径 / 那套 PHZ / endpoint 必须在 secondary 区已经建好**。
- **ARC（Application Recovery Controller，topic 11）**：当「按健康检查自动切」不够可控时，用 ARC routing control 做**人工 / 编排式的确定性区域切换**（防止脑裂 / 抖动）。DR 演练与受控切换选 ARC，而非纯健康检查自动切。
- **Regional 铁律**：Resolver endpoint / rule / Profile 全是 **Regional**；多区架构必须**每个 Region 各建一套** endpoint + Profile，并各自共享。Public DNS / Domains 才是 global（us-east-1）。

### 1.5 治理落地：IAM / RAM / SCP 收口（topic 19）

集中式架构的权限边界一并收口（细节见 topic 19）：

- **IAM 细粒度**：业务账号用 `ChangeResourceRecordSets` 绑具体 PHZ ARN + 三条件键（记录名 / 类型 / 动作，如「可改 A 不可删」）；`ListHostedZones` 单独 `Resource:"*"`。
- **RAM**：Resolver rule 走 `put-resolver-rule-policy` + RAM 接受；Profile 直接 RAM 共享。**共享 ≠ 生效，必须目标账号关联到 VPC**。
- **SCP**：组织根 Deny 危险动作（`DeleteHostedZone` / `DisableHostedZoneDNSSEC` / `DeleteResolverRule` …），仅中心 DNSAdmin 例外。
- **责任边界**：Profile / rule 定义留在中心账号改；成员账号只在授权动作集内关联，改 Profile 内配置的爆炸半径 = 所有关联 VPC。

---

## 2. 案例说明（典型企业 Organizations 综合场景）

> 无绑定单一 case；用「中心网络账号 + 多业务账号 + on-prem AD + 双区 DR」的组织级场景推演，把各碎片的真实 case 结论收进一张图。

**背景**：某企业 AWS Organizations 下 50+ 账号、200+ VPC，两个业务区域 `us-east-1`（primary）/ `us-west-2`（DR）；有 on-prem 数据中心跑 AD DNS（`corp.example.com`），经 Direct Connect 接入；要求：全组织能解析内部 PHZ `svc.internal`，内部名与 on-prem 双向互通，公网业务多区 failover，且核心 DNS 资源谁都不能误删。

**架构落法（逐层锚考点）**：

1. **名字空间层（PHZ）**：中心网络账号建 PHZ `svc.internal`。因 VPC 达 200+、跨 50 账号，**不走逐 PHZ `VpcAssociationAuthorization`（路径 A 会运维爆炸），改用 Profiles（路径 B）**：把 `svc.internal` PHZ 装进 Profile。（§1.2；topic 01 / 10）

2. **转发 / 混合层（hub-spoke Resolver）**：中心账号在**每个区**（us-east-1、us-west-2）各建**一套** inbound + outbound endpoint（Regional，必须逐区建）。
   - **outbound**：建 `corp.example.com.` forward rule → on-prem AD DNS IP（经 DX）；
   - **inbound**：在 on-prem AD DNS 上把 `svc.internal` 条件转发到 inbound endpoint 的私有 IP；
   - forward rule 经 **RAM 共享**给全组织（每区一次），outbound endpoint 随 rule 共享，spoke 账号不必各建 endpoint。（§1.1 / §1.3；topic 05 D24）

3. **分发层（Profiles 一次下发）**：把 PHZ `svc.internal` + `corp.example.com` forward rule 一起装进**每区一个** Profile（`corp-dns-baseline-use1` / `-usw2`），**RAM 共享给整个 Org**，成员账号把 Profile 关联到本区各 VPC。一步下发名字空间 + 混合转发，免逐 PHZ 授权。（§1.0 / §1.2；topic 10）

4. **多区 failover 层**：公网业务域 `app.example.com`（public zone）用 **failover 路由 + 健康检查**，primary=us-east-1 ALB、secondary=us-west-2 ALB，TTL=60s；两区的 `svc.internal` PHZ 与 endpoint 均已就位，切换后数据面可通。DR 演练用 **ARC routing control** 做确定性切换。（§1.4；topic 11）

5. **治理层**：业务账号 IAM 只授「改自己子域 A/AAAA、不可删」；组织根挂 SCP Deny 危险删除动作，仅中心 DNSAdmin 例外；Profile / rule 改动评审在中心账号。（§1.5；topic 19）

**知识点落点**：
- 200+ VPC / 50 账号 → **选 Profiles 而非逐 VPC**（§1.2 判据）；
- 一套 endpoint 服务全组织 → **hub-spoke 省成本**（§1.1）；
- 混合云 `corp.example.com` 同名 PHZ + forward rule 冲突 → **Forward Rule 优先**，别在 PHZ 加记录指望覆盖（§1.3；case 178602594200640）；
- endpoint / Profile 是 **Regional**，双区各建一套（§1.4 铁律）；
- 误删护栏靠 **SCP + 内建顺序防呆**（§1.5；topic 19）。

---

## 3. 实验步骤（Hands-on Lab）

> 演示：搭一个「中心账号 Profile 装 PHZ + forward rule → RAM 共享 → 成员账号关联 VPC」的最小集中式架构，并验证混合转发优先级与多区 failover 记录。所有步骤为受控 / 非破坏性演示，在测试资源上做；endpoint / rule 会产生小额费用，实验后清理。

### Lab A：hub-spoke 集中式 Resolver + Profile 一次下发

前置：中心账号一个 hub 测试 VPC（2 私有子网跨 2 AZ）；一个测试 PHZ `svc.internal`（zone `<PHZ_ID>`）；一个成员测试账号的 spoke VPC `<SPOKE_VPC>`。

```bash
# 1) 中心账号：建 outbound endpoint（hub 集中转发）
aws route53resolver create-resolver-endpoint \
  --creator-request-id hub-out-$(date +%s) --name hub-outbound --direction OUTBOUND \
  --security-group-ids <SG> --ip-addresses SubnetId=<SUBNET_A> SubnetId=<SUBNET_B>

# 2) 建 forward rule：corp.example.com → on-prem AD DNS（测试可指向一台 dnsmasq）
aws route53resolver create-resolver-rule \
  --creator-request-id hub-fwd-$(date +%s) --name fwd-corp --rule-type FORWARD \
  --domain-name corp.example.com. --resolver-endpoint-id <OUTBOUND_EP_ID> \
  --target-ips Ip=<ONPREM_DNS_IP>,Port=53

# 3) 建 Profile，把 PHZ + forward rule 一起装进去
aws route53profiles create-profile --name corp-dns-baseline
aws route53profiles associate-resource-to-profile --profile-id <PROFILE_ID> \
  --name attach-phz --resource-arn arn:aws:route53:::hostedzone/<PHZ_ID>
aws route53profiles associate-resource-to-profile --profile-id <PROFILE_ID> \
  --name attach-fwd --resource-arn arn:aws:route53resolver:<region>:<acct>:resolver-rule/<RULE_ID>

# 4) RAM 把 Profile 共享给成员账号（或整个 Org）
aws ram create-resource-share --name corp-dns-share \
  --resource-arns arn:aws:route53profiles:<region>:<acct>:profile/<PROFILE_ID> \
  --principals <MEMBER_ACCOUNT_ID>

# 5) 成员账号接受共享，把 Profile 关联到 spoke VPC
aws ram get-resource-share-invitations --region <region>
aws ram accept-resource-share-invitation --resource-share-invitation-arn <INV_ARN> --region <region>
aws route53profiles associate-profile --profile-id <PROFILE_ID> --name assoc-spoke --resource-id <SPOKE_VPC>
```

**验证（在 spoke VPC 内的 EC2 上）**：
```bash
dig @169.254.169.253 host.svc.internal +short      # 命中 Profile 下发的 PHZ → 私有 IP
dig @169.254.169.253 x.corp.example.com +short      # 命中 Profile 下发的 forward rule → 转发 on-prem
```
一步下发即在所有关联 VPC 生效 —— 印证「建一次、多 VPC / 多账号生效」，且免逐 PHZ 授权。

### Lab B：验证混合云同名冲突 —— Forward Rule 优先于 PHZ

```bash
# 在同一 VPC 既有 corp.example.com 的 PHZ(一条 A 记录) 又有同名 forward rule 时：
dig @169.254.169.253 svc.corp.example.com +short
# 预期：返回的是 forward rule 目标(on-prem)的应答，而非 PHZ 里的 A 记录
# → 现场印证「同域名同层级 Forward Rule > PHZ」(topic 05 case 178602594200640)
# 要让某子域就地解析: 为该子域建一条更具体的 System 规则(反向覆盖)
```

### Lab C：多区 failover 记录（public zone）

```bash
# primary(us-east-1) + secondary(us-west-2)，各带健康检查，TTL 短
aws route53 change-resource-record-sets --hosted-zone-id <PUBLIC_ZONE_ID> --change-batch '{
  "Changes":[
    {"Action":"UPSERT","ResourceRecordSet":{"Name":"app.example.com","Type":"A","SetIdentifier":"primary","Failover":"PRIMARY","TTL":60,"ResourceRecords":[{"Value":"<PRIMARY_IP>"}],"HealthCheckId":"<HC_PRIMARY>"}},
    {"Action":"UPSERT","ResourceRecordSet":{"Name":"app.example.com","Type":"A","SetIdentifier":"secondary","Failover":"SECONDARY","TTL":60,"ResourceRecords":[{"Value":"<SECONDARY_IP>"}],"HealthCheckId":"<HC_SECONDARY>"}}
  ]}'
# 判读: primary 健康检查失败后, 解析在(约 TTL 后)切到 secondary。
# 前提: secondary 区的 PHZ/endpoint/网络路径已就位, 否则"切过去也不通"。
```

**清理**：`disassociate-profile` → `disassociate-resource-from-profile` → 删 RAM share → `delete-profile`；`delete-resolver-rule` / `delete-resolver-endpoint`；删测试 failover 记录与健康检查。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **①选型判据：Profiles vs 逐 VPC 关联 vs Resolver rule**（本 topic 核心）——三者不是替代而是分工，选错会运维爆炸或功能错位：
  - **要「批量下发一组 DNS 配置到很多 VPC / 多账号」→ Profiles**（几十上百 VPC、跨 Org 的规模化治理；免逐 PHZ 授权）。
  - **要「让别账号 VPC 解析我的 PHZ」且 PHZ/VPC 数量少 → 逐 VPC `VpcAssociationAuthorization`**（简单、无 Profile 的同 Region / 单 Profile 约束）。
  - **要「把某域名的查询转发到别处（on-prem / 企业 DNS）」→ Resolver forward rule**（+ outbound endpoint，经 RAM 跨账号共享）。
  - 常见错误认知：以为「用了 Profile 就不要 PHZ / Resolver rule」——Profile 只是**打包分发**，装的正是 PHZ + rule（topic 10 §1.1）。
- **②hub-spoke 集中式 Resolver 省成本**：一套 inbound/outbound endpoint 服务全组织，forward rule 经 RAM 共享、**父账号 endpoint 随 rule 共享，无需每账号重建 endpoint**（D24）。
  - 常见错误认知：以为跨账号共享 rule 还要每账号单独建 outbound endpoint。
- **③跨账号 PHZ 两条路要选对**：逐 PHZ `VpcAssociationAuthorization`（少量、可跨区）vs Profiles RAM 共享（规模化、免授权但 Profile/资源/VPC 同 Region、每 VPC 1 Profile）。每 PHZ **300 VPC** 上限逼近时改 Profiles（topic 01 / 10）。
  - 常见错误认知：200+ VPC 还逐个 `VpcAssociationAuthorization`。
- **④混合云同名冲突：Forward Rule > PHZ（同域名同层级）**：既有 PHZ 又有同名 forward rule 时查询被**转发出去**，PHZ 加记录不生效；就地解析要建更具体的 **System 规则**反向覆盖（topic 05 case 178602594200640）。先比最具体匹配、再比类型。
  - 常见错误认知：在 PHZ 里加条记录就能覆盖 forward rule（方案不可行）。
- **⑤混合云双向要各配一头**：AWS→on-prem 用 **outbound endpoint + forward rule**；on-prem→AWS 用 **inbound endpoint + on-prem 侧条件转发器**指向 inbound IP。outbound 是私有 IP，出公网需 **NAT Gateway**；endpoint 每个 ENI 子网 NACL 都要双向放行 DNS（topic 05 case 178767531400698）。
  - 常见错误认知：只配一个方向就以为双向通；方向记反（In=别人进来查我 / Out=我出去查别人）。
- **⑥多区域 failover：DNS 层「切」、数据面「通」是两回事**：failover 路由 + 健康检查负责把名字切到健康区，但 **secondary 区的 PHZ / endpoint / 网络路径必须已就位**才真能通；TTL 越大切换越慢（多区记录用短 TTL）。受控 / 演练式切换用 **ARC routing control**（topic 11），非纯健康检查自动切。
  - 常见错误认知：以为配了 failover 记录就等于多区高可用，忽略数据面与 secondary 区资源就位。
- **⑦Regional 铁律**：Resolver endpoint / rule / Profile 全是 **Regional**，多区必须**逐区各建一套**并各自 RAM 共享；跨区关联 VPC 只对 **PHZ** 成立（endpoint/Profile 不行）。Public DNS / Domains 才是 global（us-east-1）。
  - 常见错误认知：以为一个 Profile / endpoint 能跨区服务所有 VPC。
- **⑧治理收口（topic 19）**：IAM 记录级细粒度（可改不可删）、RAM 共享后须目标账号关联 VPC 才生效、SCP Deny 危险删除、Profile 改动爆炸半径 = 全部关联 VPC。
  - 常见错误认知：以为 RAM 共享完就自动生效；在成员账号里查为什么改不了 Profile 内配置（应在中心账号改）。

---

## 5. 该域 Mermaid 逻辑导图 / 选型决策树（Decision Tree）

### 5.1 选型决策树（★本 topic 核心）

从「你要解决什么 DNS 需求」出发，导到该用哪套机制：

```mermaid
flowchart TD
    START(["企业级 DNS 需求"]) --> Q1{"需求类型?"}

    Q1 -->|"内部名解析<br/>(PHZ 应答)"| Q2{"要覆盖多少<br/>VPC / 账号?"}
    Q1 -->|"某域名转发到<br/>on-prem / 企业 DNS"| FWD["Resolver forward rule<br/>+ outbound endpoint<br/>(RAM 跨账号共享, 同Region)"]
    Q1 -->|"on-prem 要查 AWS 内部名"| INB["inbound endpoint<br/>+ on-prem 侧条件转发器<br/>指向 inbound 私有IP"]
    Q1 -->|"公网业务多区高可用"| FO["public zone failover 路由<br/>+ 健康检查 (短TTL)<br/>+ 数据面/secondary区就位<br/>(受控切换用 ARC)"]

    Q2 -->|"少量 PHZ / 少量 VPC"| VAA["逐 VPC 关联<br/>VpcAssociationAuthorization<br/>(可跨区/跨账号, 无 1-Profile 约束)"]
    Q2 -->|"几十上百 VPC / 多账号 / Org"| Q3{"要把 PHZ + Resolver rule<br/>+ Firewall 等一起批量下发?"}

    Q3 -->|"是"| PROF["Route 53 Profiles<br/>建一次→RAM共享→成员账号关联VPC<br/>免逐PHZ授权; 每VPC 1个; 同Region"]
    Q3 -->|"否, 只共享单条 rule"| FWD

    FWD --> HUB{"多账号都要转发?"}
    HUB -->|"是"| HUBSPOKE["hub-spoke: 中心账号一套 endpoint<br/>rule 经 RAM 共享<br/>(endpoint 随 rule 共享, 省成本)"]
    HUB -->|"否"| SINGLE["单 VPC 建 endpoint + rule"]

    PROF --> REG{"多区域?"}
    HUBSPOKE --> REG
    VAA --> REG2{"PHZ 需跨区?"}
    REG -->|"是"| PERREGION["每 Region 各建一套<br/>endpoint / Profile 并各自 RAM 共享<br/>(Regional 铁律)"]
    REG -->|"否"| DONE1["单区落地"]
    REG2 -->|"是"| PHZXREGION["PHZ 可跨区关联 VPC<br/>(endpoint/Profile 不能跨区)"]
    REG2 -->|"否"| DONE2["单区落地"]

    classDef warn fill:#fde,stroke:#b36;
    classDef pick fill:#e0f0ff,stroke:#369;
    class PROF,HUBSPOKE,VAA,FWD,INB,FO pick;
    class PERREGION,PHZXREGION,FO warn;
```

> 图注：三大分叉 —— **规模决定 Profiles vs 逐 VPC 关联**（几十上百 VPC/多账号 → Profiles，少量 → `VpcAssociationAuthorization`）；**转发需求走 Resolver rule**（多账号则 hub-spoke 共享 endpoint 省成本）；**多区必逐区建 endpoint/Profile**（只有 PHZ 能跨区关联 VPC）。混合云是 outbound（AWS→on-prem）+ inbound（on-prem→AWS）两头各配一次。

### 5.2 综合架构全景（hub-spoke + 跨账号 Profile + 混合云 + 多区）

```mermaid
flowchart TB
    subgraph ONPREM["on-prem 数据中心"]
      AD["AD DNS<br/>corp.example.com"]
    end

    subgraph HUB["中心网络账号 (每 Region 一套)"]
      OUT["outbound endpoint"]
      IN["inbound endpoint"]
      PHZ["PHZ svc.internal"]
      RULE["forward rule<br/>corp.example.com→on-prem"]
      PROF["Profile corp-dns-baseline<br/>(装 PHZ + rule)"]
      PROF --> PHZ
      PROF --> RULE
      RULE --> OUT
    end

    AD -->|"条件转发 svc.internal<br/>→ inbound 私有IP"| IN --> PHZ
    OUT -->|"corp.example.com<br/>经 DX/VPN"| AD

    PROF -->|"RAM 共享 (Org/OU, 每Region)"| RAMS(("RAM Share"))
    RAMS --> M1["成员账号A: 关联到 spoke VPC"]
    RAMS --> M2["成员账号B: 关联到 spoke VPC"]
    M1 --> SV1["spoke VPC<br/>(VPC+2 解析: PHZ + forward)"]
    M2 --> SV2["spoke VPC"]

    subgraph DR["多区 failover"]
      PUB["public zone app.example.com<br/>failover + 健康检查 (短TTL)"]
      PUB -->|"primary 健康"| R1["us-east-1 ALB"]
      PUB -->|"primary 失败→切"| R2["us-west-2 ALB<br/>(该区 PHZ/endpoint 须就位)"]
      ARC["ARC routing control<br/>确定性/演练切换"] -.-> PUB
    end

    classDef warn fill:#fde,stroke:#b36;
    class RAMS,RULE,R2 warn;
```

> 图注：**hub 一套 endpoint** 对 on-prem 双向互通（out=转发、in=接收）；**Profile 经 RAM 把 PHZ+rule 一次下发**到全组织 spoke VPC；**同名 `corp.example.com` 走 forward rule（优先于 PHZ）转 on-prem**；多区 failover 由 public zone + 健康检查驱动，但 **secondary 区资源须就位**，受控切换交给 ARC。所有 endpoint/Profile **Regional，逐区各建**。

---

## 来源（Sources）

- 本 topic 为聚合型，主要收敛自本知识库既有碎片并锚其真实 case：
  - topic 01 Hosted Zones（PHZ 跨账号 `VpcAssociationAuthorization`、最具体匹配、300 VPC 上限；case 178118102100384 / 178239640400861 / 178782060900806）
  - topic 05 Resolver 与混合 DNS（inbound/outbound 方向、forward rule > PHZ、`.` rule、RAM 跨账号 D24、NACL 双向放行；case 178602594200640 / 178767531400698）
  - topic 10 Route 53 Profiles（打包分发、每 VPC 1 Profile、RAM 共享免逐 PHZ 授权、同 Region 边界；case 178782060900806）
  - topic 11 ARC（Application Recovery Controller，确定性区域切换）
  - topic 19 IAM/KMS/RAM/SCP 治理（记录级条件键、RAM 共享后须关联 VPC、SCP 防误删）
- AWS 官方文档：
  - Centralized DNS management of hybrid cloud with Amazon Route 53 and AWS Transit Gateway（hub-spoke 集中式 Resolver）：<https://aws.amazon.com/blogs/networking-and-content-delivery/centralized-dns-management-of-hybrid-cloud-with-amazon-route-53-and-aws-transit-gateway/>
  - Using Amazon Route 53 Profiles for scalable multi-account AWS environments：<https://aws.amazon.com/blogs/networking-and-content-delivery/using-amazon-route-53-profiles-for-scalable-multi-account-aws-environments/>
  - Resolving DNS queries between VPCs and your network（inbound/outbound endpoint + forward rule）：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver.html>
  - How do I configure and manage cross-account access for Amazon Route 53 resources?：<https://repost.aws/knowledge-center/route-53-cross-account-resources>
  - Configuring DNS failover（failover 路由 + 健康检查）：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-failover-configuring.html>
  - Working with private hosted zones（PHZ 跨账号 / 跨区关联、最具体匹配）：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zones-private.html>
  - Amazon Route 53 FAQs（Resolver + RAM 集成、共享后须关联 VPC）：<https://aws.amazon.com/route53/faqs/>
  - Amazon Application Recovery Controller（ARC）routing control：<https://docs.aws.amazon.com/r53recovery/latest/dg/routing-control.html>

# Topic 00a — DNS 协议基础（SME 底座）

> **定位**：这是所有其他 topic 的**协议底座**。R53 是 DNS 生态里的一个权威实现，客户追问"为什么改了记录没生效""为什么 dig 有时走 TCP""SERVFAIL 到底断在哪""NXDOMAIN 和空答案区别在哪"时，答案都落在**协议层**——先懂 DNS 报文/委派/缓存的原生语义，再谈 R53 特性才不会张冠李戴。本专题只讲**RFC 级的协议原理**，不讲 R53 配置。
> **九大基础块**：(1) 迭代 vs 递归解析；(2) delegation（委派）与 glue；(3) bailiwick 与 in/out-of-bailiwick glue（RFC 9471）；(4) UDP 截断 / TC 位 / TCP fallback；(5) EDNS0（RFC 6891）；(6) NXDOMAIN vs NODATA；(7) 负缓存与 SOA MINIMUM（RFC 2308）；(8) TTL 语义；(9) DNS 报文头标志（AA/RD/RA/AD/CD，**AD≠AA**）。
> **配套 topic**：14（技术原理深挖，讲 R53 权威侧 anycast/委派机制的机制底座）、01（Hosted Zone）、07（DNSSEC，AD 位的密码学来源）、05（Resolver/递归数据面）、13（排障纪律）。

---

## 一、迭代 vs 递归解析（三种角色，别混）

DNS 里有三种角色，SME 最常被客户问混：

| 角色 | 谁 | 做什么 | 查询里怎么体现 |
|---|---|---|---|
| **Stub resolver（存根解析器）** | 终端 OS（glibc / EC2 内核）| 只把查询丢给配置的递归解析器，自己**不迭代** | 发出 **RD=1** 的查询 |
| **Recursive resolver（递归解析器）** | ISP / 企业 / 8.8.8.8 / **VPC Resolver** | 替客户端"跑完全程"：从根开始**迭代**问下去，缓存结果 | 对上游权威做迭代时通常发 **RD=0**；自己缓存（RD 只表是否请求递归，不据此判定角色——见第九块）|
| **Authoritative server（权威服务器）** | zone 所有者侧（**Route 53 就在这一层**）| 只回答"我负责的 zone"，**从不迭代、从不缓存别人的数据** | 应答置 **AA=1** |

- **递归（recursive）**：客户端说"请你替我把答案查全，直接给我最终结果"。递归解析器承担这份工作。
- **迭代（iterative）**：递归解析器逐跳去问——**根 → TLD → 权威**，每一跳只拿到"下一跳该问谁"的委派（referral），直到某台权威给出带 **AA=1** 的最终答案。
- **核心心法**：R53（托管 zone 那侧）是**权威**，不是递归；它收到 RD=1 也**不会**替你递归，只按权威身份对"它负责的 zone"作答。VPC Resolver 才是递归层。

```mermaid
sequenceDiagram
    participant C as Stub Resolver (客户端)
    participant R as Recursive Resolver (递归/VPC Resolver)
    participant Root as 根 (.)
    participant TLD as .com 权威 (Verisign)
    participant A as Route 53 权威 (awsdns)

    C->>R: www.example.com A?  (RD=1 递归请求)
    R->>Root: www.example.com A?  (RD=0 迭代)
    Root-->>R: referral: 去问 .com (返回 .com NS)
    R->>TLD: www.example.com A?  (RD=0 迭代)
    TLD-->>R: referral: 去问 example.com (返回委派 NS + glue?)
    R->>A: www.example.com A?  (RD=0 迭代)
    A-->>R: 权威答案 A=203.0.113.10 (AA=1)
    R-->>C: A=203.0.113.10 (缓存 TTL 秒, RA=1)
```

> **SME 排障锚点**：客户 `dig +trace` 看到的是**迭代过程**（模拟递归解析器逐跳）；客户 `dig @8.8.8.8` 看到的是**递归结果**（RD=1，答案可能来自缓存，AA=0）。两者不一样是正常的，不是 R53 出错。

---

## 二、delegation（委派）与 glue

- **delegation（委派）** = 父 zone 用 **NS 记录**把某个子域名的权威"下放"给一组名字服务器。例：`.com` 里存 `example.com. NS ns-xxx.awsdns-yy.net.`，这就是把 `example.com` 委派给 R53。委派**只靠 NS 记录的名字**完成。
- **glue（黏合记录）** = 委派时**在父 zone 的 additional section 里附带的 NS 名字的 A/AAAA 地址**。为什么需要它？看下一块的 bailiwick 死循环。
- **delegation set**：一个 R53 hosted zone 拿到的**四条委派 NS 名字**（`awsdns-*`，横跨 .com/.net/.org/.co.uk 四个 TLD——机制详见 topic 14 第二块）。客户在**域名注册商侧**必须把这四条 NS 填成"父级委派"，否则解析链断在 TLD 那一跳。

> **SME 排障锚点**：客户"域名解析全线不通、连 SOA 都拿不到"——第一步查**注册商侧的 NS 委派**是否等于 hosted zone 的四条 `awsdns` NS。委派没配对 = 全世界都找不到这台权威。

---

## 三、bailiwick 与 in/out-of-bailiwick glue（RFC 9471，硬考点）

**bailiwick（管辖范围）** 指"某台权威服务器的名字是否落在它自己被委派的域之内"。这决定了 glue 是**必需**还是**可选**。

### 3.1 in-bailiwick（in-domain）NS —— glue 是**必需**

- NS 名字**落在被委派域内部**，例：`example.com` 的 NS 是 `ns1.example.com`。
- 死循环问题：要解析 `ns1.example.com` 的地址，就得先找到 `example.com` 的权威——可 `example.com` 的权威**正是** `ns1.example.com`。鸡生蛋。
- **解法：父 zone（`.com`）必须附带 glue**，即在 referral 里直接给出 `ns1.example.com A 192.0.2.1`，打破循环。
- **RFC 9471 的硬要求（更新 RFC 1034）**：权威服务器生成 referral 时，**MUST** 包含所有 in-domain NS 的可用 glue；若**报文太大放不下**，**MUST 置 TC=1** 告知客户端"答案被截断，请改用 TCP 重取"（见第四块）。

### 3.2 out-of-bailiwick / sibling NS —— glue 只是**优化，非必需**

- NS 名字**落在被委派域之外**。两种情况：
  - **out-of-bailiwick（域外）**：NS 在完全另一棵子树，例：`example.com` 用 `ns.provider.net`。
  - **sibling（同父兄弟域）**：NS 在同一父级下的另一个被委派子域，例：`foo.test` 用 `ns1.bar.test`（`bar.test` 与 `foo.test` 都是 `test` 的子域）。
- 这些情况**不需要**父级 glue：解析器可以**独立**沿 `.net`/`bar.test` 各自的链路解析出 NS 地址，不依赖这条委派附带的 glue。
- **RFC 9471**：sibling glue 权威 **SHOULD** 附带（作为优化，省一次往返）；若 in-domain glue 塞满后 sibling glue 放不下，权威 **MAY**（但不强制）置 TC=1。
- **例外——cyclic sibling（循环兄弟依赖）**：`bar.test` 用 `ns1.foo.test`，同时 `foo.test` 用 `ns2.bar.test`，互相指向对方。此时**只有**父级 `test` 附带 glue 才能打破循环。RFC 9471 指出这种情况极罕见（2021 年 ICANN CZDS 全量数据里约 2.09 亿委派中仅 222 个）。

### 3.3 与 Route 53 的关系（考点落点）

- R53 的 `awsdns-*` NS 属于 **out-of-bailiwick**（对客户的 `example.com` 而言，NS 名字在 `.net/.org/.co.uk` 等别的树上）。所以客户 zone 的委派**不依赖** `.com` 附带 `awsdns` 的 glue——解析器能独立解析出 `awsdns` 地址。这是 R53 委派设计能横跨四个 TLD 的前提（topic 14 第二块）。
- **常见误区**：客户以为"R53 没给我 glue 所以解析不了"。对 out-of-bailiwick 的 awsdns NS，**本就不需要** child 侧 glue。真正会因缺 glue 断链的是 **in-bailiwick 自建 NS** 场景（客户用 `ns1.example.com` 却没在注册商侧配 glue）。

---

## 四、UDP 截断 / TC 位 / TCP fallback

- **DNS 传输默认走 UDP/53**（一来一回、无连接、低开销）。传统 UDP 无 EDNS0 时上限 **512 字节**。
- **TC（TrunCation）位**：当权威要回的答案**超过所选传输能容纳的大小**时，它把能放的放进去，并置 **TC=1** 表示"答案不完整"。
- **改用另一种 transport**：客户端看到 **TC=1**，**SHOULD 用另一种能承载更大响应的 transport 重发同一查询**——经典场景下即改用 **TCP/53**（RFC 1035 起 DNS 客户端/服务端必须支持 TCP），TCP 报文上限 **65535 字节**，足以承载完整答案。
- **触发 TC 的典型场景**：
  - 大量记录的应答（很多 A / 很多 MX / 很多 TXT）。
  - **DNSSEC 签名记录**（RRSIG/DNSKEY 体积大，最容易撑爆 UDP）——topic 07。
  - **in-domain glue 放不下**（RFC 9471 要求此时 MUST 置 TC=1）。
- **RFC 9471 的运维影响提示**：新要求可能让"UDP 置 TC 的比例"上升，进而**增加落到 TCP 的查询量**——网络中间设备（防火墙/SG）**必须同时放行 UDP/53 和 TCP/53**，只放 UDP 会导致大应答场景（DNSSEC、多记录）间歇性 SERVFAIL。

> **SME 排障锚点**：客户"平时好好的，加了 DNSSEC / 记录变多后偶发解析失败"——查中间链路是否**阻断了 TCP/53**。这是"UDP 通、TCP 不通"经典故障。

---

## 五、EDNS0（RFC 6891）

- **EDNS0（Extension Mechanisms for DNS）** 用一条伪记录 **OPT** 扩展 DNS，无需改协议头。
- 最重要的字段：**requestor's UDP payload size**——客户端用它**声明"我这条 UDP 链路最多能接收多大的响应"**，常见值 **1232 / 4096**（DNS Flag Day 2020 推荐 **1232** 以规避 IP 分片黑洞）。它是**接收方能力的上报值，不是一个硬截断阈值**：实际能走多大 UDP 还同时受**服务端自身的 payload 上限、路径 MTU、双方取较小值**等影响。它把 UDP 上限从古老的 512 提升到 1232~4096，**减少不必要的 TCP fallback**。
- 还承载：**DO 位**（DNSSEC OK，表示客户端要 DNSSEC 记录，topic 07）、扩展 RCODE、以及 **EDNS Client Subnet（ECS）** 等选项（把客户端网段带给权威做地理定位，topic 14）。
- **与第四块的关系**：EDNS0 声明的 payload size 决定"多大之内还能走 UDP"；超过它，才置 TC=1 走 TCP。所以 EDNS0 是"UDP 能撑多大"的旋钮，TC/TCP 是"撑不下时的兜底"。

> **SME 排障锚点**：`dig` 输出里出现 `; EDNS: version: 0; udp: 1232` 就是 EDNS0 在起作用；**DO 位只有在显式 `+dnssec` 时才置位**（届时才会看到 `flags: do`），普通 EDNS 查询不带 DO。若中间设备**丢弃带 OPT 的包**（老旧防火墙），会退化到 512 甚至完全失败。

---

## 六、NXDOMAIN vs NODATA（RFC 2308，别混）

两者都是"负答案"，但语义**完全不同**：

| | **NXDOMAIN**（Name Error）| **NODATA** |
|---|---|---|
| 含义 | **这个域名不存在**（任何类型都没有）| **域名存在，但没有你问的那个类型**的记录 |
| RCODE | `NXDOMAIN`（Name Error，RCODE=3）| **`NOERROR`（RCODE=0）** + answer 段为空 |
| 怎么判定 | 直接看 RCODE | **无专用 RCODE，必须从应答内容"算"出来**：RCODE=NOERROR 且 answer 空、authority 段有 SOA |
| 例子 | 查 `nonexistent.example.com A` → 整个名字不存在 | 查 `example.com AAAA`，但该名只有 A、没有 AAAA |

- **关键陷阱**：NODATA **没有**独立的返回码，它是 `NOERROR + 空 answer` 的组合，必须由解析器**算法推断**。客户"我明明查到了 NOERROR 为什么没数据"——那就是 NODATA，说明**该类型**没记录，不代表域名不存在。
- **权威侧硬要求（RFC 2308 §3）**：权威在回 NXDOMAIN 或 NODATA 时**MUST 在 authority 段放入该 zone 的 SOA 记录**——这是负答案能被缓存的前提（见第七块）。RFC 2308 还建议权威只发 TYPE 2 形态（authority 段只含 SOA、不含 NS），以免老解析器把它误当 referral。

---

## 七、负缓存与 SOA MINIMUM（RFC 2308）

- **负缓存（negative caching）** = 缓存"某记录/某域名不存在"这一事实。RFC 2308 把它从"可选"升级为"**只要解析器缓存正答案，就必须也缓存负答案**"。
- **负答案的 TTL 来自哪里？** 负答案的 answer 段是空的，没有普通记录可挂 TTL——所以 TTL **由 authority 段那条 SOA 记录承载**。
- **SOA MINIMUM 字段的现代含义（RFC 2308 §4，硬考点）**：SOA 的最后一个字段（MINIMUM）历史上被赋过三种含义，RFC 2308 明确它的**唯一现代含义 = 负答案的缓存 TTL**。
  - 具体规则（§5）：负答案的缓存时长 = **min(SOA.MINIMUM, SOA 记录自身的 TTL)**。
  - 另两种旧含义（"zone 内所有 RR 的最小 TTL""无显式 TTL 记录的默认 TTL"）已废弃/被 `$TTL` 指令取代。
- **实践值**：RFC 2308 建议负缓存 TTL 取 **1~3 小时**较合理，超过 1 天会出问题。
- **SERVFAIL / 死服务器的负缓存上限（§7）**：server failure 和 unreachable server 的负缓存 **MUST NOT 超过 5 分钟**，且按 `<query name, type, class, server IP>` 元组缓存。

> **SME 排障锚点**：客户"我刚创建了记录，为什么还是查不到（NXDOMAIN）"——很可能**创建前**的那次查询已被下游解析器**负缓存**，卡在负缓存窗口内。R53 默认 SOA 的 **MINIMUM 字段 = 86400 秒**，而 **SOA 记录自身的 TTL 默认 = 900 秒**，按 RFC 2308 §5 有效负缓存 = **min(86400, 900) = 900 秒**（起决定作用的是较小的 SOA TTL，不是 MINIMUM 字段）。让客户等负缓存过期，或换未缓存过的解析器验证。R53 权威侧改动传播很快（`GetChange` 返回 `INSYNC` 即完成），卡的是**下游负缓存**。

---

## 八、TTL 语义

- **TTL（Time To Live）** = 权威授权"这条答案可以被缓存多少秒"。**倒计时归零即失效**，必须重新查权威。
- **谁在倒计时**：递归解析器（主缓存层）持有答案时倒扣 TTL；它把答案转给下游时，会带**剩余 TTL**（不是重置为原值）。所以链路上每一跳看到的 TTL 只减不增。
- **正 TTL vs 负 TTL**：普通记录的 TTL 是记录自身字段；**负答案的 TTL 来自 SOA MINIMUM**（第七块）——两者是不同来源，别混。
- **"改记录多久生效"取决于链路上任一缓存层旧记录的剩余 TTL**，不只是最近那一跳。降 TTL 要**提前**做（比如迁移前 24h 把 TTL 从 3600 降到 60），因为降 TTL 本身也要等旧的高 TTL 过期才生效。
- **TTL=0**：表示"不要缓存"，每次都回权威。R53 alias 到 AWS 资源时有其特殊 TTL 行为（继承目标，topic 02）。

> **SME 排障锚点**：迁移/切换类 case 的第一问永远是"**旧记录 TTL 是多少、你提前多久降的**"。没提前降 TTL 就切换 = 全网按旧的高 TTL 继续解析到旧目标。

---

## 九、DNS 报文头标志（AA/RD/RA/AD/CD，AD≠AA）

DNS 报文头有一组 1-bit 标志，SME 必须能逐位读懂 `dig` 输出里的 `flags:` 段：

| 标志 | 全称 | 谁置位 | 含义 | 常见误区 |
|---|---|---|---|---|
| **QR** | Query/Response | 服务器 | 0=查询，1=应答 | — |
| **AA** | Authoritative Answer | **权威服务器** | =1 表示"**该答案来自对此 zone 有权威的服务器**（原话，非缓存转述）" | **AA=1 只表来源权威，不提供任何密码学真实性**——防不了路径伪造 |
| **RD** | Recursion Desired | 客户端 | =1"请你替我递归查全" | **RD 只表达是否请求递归，不标识角色**：stub→recursive 通常带 RD=1；recursive→权威做迭代时通常 RD=0；但 forwarder（转发器）转发给上游递归时也可带 RD=1，别用 RD 反推角色 |
| **RA** | Recursion Available | 递归解析器 | =1"我支持递归" | 权威服务器通常 RA=0（它不递归）|
| **AD** | Authentic Data | **验证型递归解析器** | =1 表示"**该答案经 DNSSEC 验证通过、密码学可信**"（RFC 4035）| **AD≠AA**：AD 是"密码学验证过"，AA 是"来源权威"，两个完全不同层次 |
| **CD** | Checking Disabled | 客户端 | =1"**请求递归器不要为我做 DNSSEC 验证**，把未验证数据也返给我" | 用于调试：客户端想自己验签，让解析器别拦。**注意：CD=1 只是"请求"不验证，最终仍受递归器实现、本地策略以及已有 BAD cache（先前验证失败的缓存）影响，不保证一定返回未经任何拦截的原始数据** |

- **AA≠AD（最高频考点）**：
  - **AA=1**：答案来自权威服务器本身（不是缓存）。只说明"来源正确"，**不能防篡改**——路径上的中间人仍可伪造 AA=1 的假答案。
  - **AD=1**：递归解析器**做了 DNSSEC 验证并通过**，答案密码学可信（RFC 4035）。这才是"authenticated"。
  - 关系：R53 权威应答带 AA=1；只有当 zone 启用 DNSSEC 且递归解析器开启验证、验签成功，客户端拿到的应答才会带 AD=1。DNSSEC 报 **SERVFAIL** 常见于验证失败（验证型解析器拒绝返回不可信数据）——topic 07。
- **CD 位排障用法**：客户报"DNSSEC SERVFAIL"时，用 `dig +cd`（置 CD=1，**请求解析器不做验证**）对比：若 `+cd` 能拿到数据而默认 SERVFAIL，则**问题大概率出在 DNSSEC 验证链**（DS/DNSKEY/RRSIG 不匹配），而非记录本身缺失。（CD=1 是请求不验证，个别实现/本地策略仍可能不完全服从，但作为定位手法足够。）这是 DNSSEC 断链定位的关键手法。

---

## dig 实验（把上面九块都验一遍）

```bash
# 1. 迭代过程：看逐跳委派（根→TLD→权威），观察每跳 referral
dig +trace www.example.com A

# 2. delegation / glue：向父级(.com 权威)问委派，看 authority(NS) + additional(glue) 段
dig @a.gtld-servers.net example.com NS +norec

# 3. bailiwick：out-of-bailiwick 的 awsdns NS 通常不带 child 侧 glue；
#    自建 in-bailiwick NS(ns1.example.com) 才必须有 glue
dig example.com NS +norec        # 看返回的 NS 名字落在域内还是域外

# 4. TC 位 / TCP fallback：强制小 UDP 缓冲触发截断，观察 flags 出现 tc
dig +dnssec +bufsize=512 +ignore example.com DNSKEY   # 看 ";; flags: ... tc"
dig +tcp example.com DNSKEY                            # 改 TCP 拿完整答案

# 5. EDNS0：看 OPT 伪记录与协商的 udp payload size；DO 位只有 +dnssec 才置
dig example.com A                # 普通查询: "; EDNS: version: 0; udp: 1232"（无 do）
dig example.com A +dnssec        # 显式请求 DNSSEC: 才出现 "flags: do"

# 6. NXDOMAIN vs NODATA：对比状态码
dig nonexistent-xyz.example.com A   # status: NXDOMAIN
dig example.com AAAA                # status: NOERROR + 空 ANSWER = NODATA(该类型无记录)

# 7. 负缓存 / SOA MINIMUM：看 SOA 最后一个字段(负答案 TTL)
dig example.com SOA +short          # 末尾数字即 minimum = 负缓存 TTL

# 8. TTL 语义：连查两次看剩余 TTL 递减(经缓存解析器时)
dig @8.8.8.8 example.com A +noall +answer   # 记 TTL，稍后再查看它变小

# 9. 报文头标志：读 flags 段
dig @8.8.8.8 example.com A          # 递归结果: flags 常见 qr rd ra (无 aa)
dig @ns-xxx.awsdns-yy.net example.com A +norec   # 权威直答: flags 含 aa
dig example.com A +dnssec           # DNSSEC 验证通过时 flags 含 ad
dig example.com A +cd               # 置 CD=1 关闭验证, 用于 SERVFAIL 定位
```

---

## SME 考点速记

1. **迭代 vs 递归**：递归解析器替客户端"跑全程"（RD=1 请求它）；它对上游权威做**迭代**（RD=0），逐跳拿 referral。R53 是**权威**不是递归，收到 RD=1 也不递归。
2. **delegation 靠 NS 名字，glue 是父级附带的 NS 地址**。委派没在注册商侧配对 = 全网找不到权威。
3. **bailiwick（RFC 9471）**：in-domain NS 的 glue **MUST** 有（否则死循环），放不下时权威 **MUST 置 TC=1**；sibling/out-of-bailiwick glue 仅 **SHOULD**（优化）。R53 的 awsdns 是 out-of-bailiwick，不依赖 child 侧 glue。
4. **TC 位 → TCP fallback**：UDP 装不下就置 TC=1，客户端改 TCP/53 重取（上限 65535）。中间链路**必须同时放行 UDP/53 + TCP/53**，否则 DNSSEC/大应答间歇失败。
5. **EDNS0（RFC 6891）**：OPT 伪记录声明 UDP payload size（1232/4096），承载 DO 位/ECS。是"UDP 能撑多大"的旋钮。
6. **NXDOMAIN（域名不存在，RCODE=3）vs NODATA（域名在、该类型无记录，RCODE=NOERROR+空 answer）**。NODATA 无专用 RCODE，靠算法推断。
7. **负缓存 TTL = min(SOA.MINIMUM, SOA 自身 TTL)（RFC 2308）**。SOA MINIMUM 的现代唯一含义就是负答案缓存时长；R53 默认 **MINIMUM=86400 秒、SOA 记录 TTL=900 秒 → 有效负缓存 = min(86400,900)=900 秒**（较小的 SOA TTL 起决定作用）。SERVFAIL/死服务器负缓存 **≤5 分钟**。
8. **TTL 语义**：只减不增，链路每跳带剩余 TTL；"改记录多久生效"取决于**任一缓存层旧记录的剩余 TTL**；迁移要**提前降 TTL**。
9. **AA≠AD（最高频）**：AA=1 只表"来源权威"（防不了伪造）；AD=1 表"DNSSEC 验证通过、密码学可信"（RFC 4035）。CD=1 关掉解析器侧验证，是 DNSSEC SERVFAIL 定位的关键手法（`dig +cd`）。

---

## 来源

- [RFC 1034 — Domain Names: Concepts and Facilities](https://www.rfc-editor.org/rfc/rfc1034.html)（迭代/递归、委派、glue、报文头基础；被 RFC 2308 / 9471 更新）
- [RFC 1035 — Domain Names: Implementation and Specification](https://www.rfc-editor.org/rfc/rfc1035.html)（报文格式、TC 位、UDP 512 上限、TCP/53、SOA 字段）
- [RFC 2308 — Negative Caching of DNS Queries (DNS NCACHE)](https://www.rfc-editor.org/rfc/rfc2308.html)（NXDOMAIN vs NODATA 定义、负缓存必需化、**SOA MINIMUM = 负答案 TTL**、SERVFAIL/死服务器负缓存 ≤5 分钟）
- [RFC 6891 — Extension Mechanisms for DNS (EDNS(0))](https://www.rfc-editor.org/rfc/rfc6891.html)（OPT 伪记录、requestor UDP payload size、扩展 RCODE/标志）
- [RFC 9471 — DNS Glue Requirements in Referral Responses](https://www.rfc-editor.org/rfc/rfc9471.html)（更新 RFC 1034；in-domain glue MUST + 放不下 MUST 置 TC=1；sibling glue SHOULD；cyclic sibling；EDNS0 UDP 1232-4096 / TCP 65535）
- [RFC 4035 — Protocol Modifications for the DNS Security Extensions](https://www.rfc-editor.org/rfc/rfc4035.html)（**AD（Authentic Data）位**由验证型解析器在 DNSSEC 验证通过后置位；CD 位关闭验证）
- [RFC 8499 — DNS Terminology](https://www.rfc-editor.org/rfc/rfc8499.html)（bailiwick / in-domain / sibling 等术语权威定义）
- [DNS Flag Day 2020](https://dnsflagday.net/2020/)（推荐 EDNS0 UDP payload size 1232 以规避 IP 分片）
- [Amazon Route 53 concepts](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/route-53-concepts.html)（R53 作为权威、hosted zone / NS 委派 / SOA / GetChange INSYNC）
- 配套内部 topic：14-technical-deep-principles（R53 权威侧 anycast/四组委派机制底座）、07-dnssec（AD 位密码学来源与 SERVFAIL 定位）、05-resolver-hybrid-dns（VPC Resolver 递归数据面）。

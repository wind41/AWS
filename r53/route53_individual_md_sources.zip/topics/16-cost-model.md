# 16. Route 53 成本 / 计费模型专题

> 来源（官方定价页，权威）：
> - Amazon Route 53 Pricing — https://aws.amazon.com/route53/pricing/
> - Route 53 域名注册 TLD 价目表（PDF）— https://d32ze2gidvkk54.cloudfront.net/Amazon_Route_53_Domain_Registration_Pricing_20140731.pdf
> - CloudWatch 定价（query logging 落此账单）— https://aws.amazon.com/cloudwatch/pricing/
> - KMS 定价（DNSSEC 签名落此账单）— https://aws.amazon.com/kms/pricing/
> - S3 定价（Resolver query log 目标 / 控制台 LIST 调用）— https://aws.amazon.com/s3/pricing/
>
> 价格为标准 AWS 商业区，US East (N. Virginia) 参考值；GovCloud 单列更贵。价格随时间可能调整，客户账单以官方页面当期值为准——本专题重点是**计费"结构"与陷阱**，不是背死数字。

---

## 一、核心心智模型：Route 53 按什么收费

Route 53 没有前期费用、没有查询量承诺，纯按用量走。收费点分成两大类：

1. **按月固定费**（有没有流量都在扣）：hosted zone 月费、health check 月费、Traffic Flow policy record 月费、Resolver endpoint 的 ENI 小时费、DNS Firewall Advanced 的小时费、Route 53 Profiles 小时费。
2. **按查询量费**（用多少扣多少，通常 prorated）：各种路由策略的 DNS query、Resolver endpoint 过境 query、DNS Firewall 检查的 query。

> **SME 第一考点**：区分"常驻固定费"和"按量费"。客户账单突然升高，先问是"多了一个常驻资源"（endpoint / health check / policy record）还是"查询量涨了"。**常驻费用是成本优化和账单意外的最大来源**（见第七节陷阱）。

---

## 二、Authoritative DNS（权威解析）

### 2.1 Hosted Zone 月费

| 项 | 价格 |
|---|---|
| 前 25 个 hosted zone | **$0.50 / zone / 月** |
| 第 26 个起（超出部分） | **$0.10 / zone / 月** |
| 每个 zone 前 10,000 条记录 | 免费 |
| 超过 10,000 条的每条记录 | $0.0015 / 记录 / 月 |

关键计费规则：
- **月费不按天 prorate**。zone 在创建当刻收一次，之后每月 1 号再收。月中删掉不退。
- **12 小时宽限**：创建后 12 小时内删除的 hosted zone 不收 zone 月费——但**这期间 public zone 上的查询照样按量收费**。（做测试/演示要记住这条。）
- **Private hosted zone 的查询完全免费**（zone 月费照收，query 不收）。
- 超过 500 个 zone 或单 zone 超 10,000 记录需要 contact us 提额。

### 2.2 DNS Query 计费（按路由策略分档）

除了指向 AWS 资源的 Alias A/AAAA（见 2.3），**每个被 Route 53 应答的 public zone 查询都收费**，包括不支持的记录类型、记录名匹配但类型不匹配、以及查询不存在的记录（NXDOMAIN）。查询费 **prorated**。

商业区价格（每百万查询；前 10 亿 / 超 10 亿两档）：

| 路由类型 | 前 10 亿 query/月 | 超 10 亿 query/月 |
|---|---|---|
| **Standard**（simple/weighted/failover/multivalue） | $0.40 / 百万 | $0.20 / 百万 |
| **Latency-Based Routing (LBR)** | $0.60 / 百万 | $0.30 / 百万 |
| **Geolocation / Geoproximity** | $0.70 / 百万 | $0.35 / 百万 |
| **IP-Based Routing** | $0.80 / 百万 | $0.40 / 百万 |

> **SME 考点**：查询单价随路由策略**越"智能"越贵**（standard < latency < geo/geoproximity < IP-based）。同样的流量，把 simple 换成 geoproximity 单查询贵约 75%。账单里对应的 usage 类型分别是 `DNS-Queries` / `LBR-Queries` / `Geo-Queries` / `Cidr-Queries`（Alias 版前缀 `Intra-AWS-`）。

IP-Based Routing 额外：前 1,000 个 IP(CIDR) block 存储免费，超出每个 $0.0015/月（prorated hourly）。

### 2.3 Alias 指向 AWS 资源 = 查询免费（重点省钱手段）

Alias A/AAAA 记录**指向下列 AWS 资源时，查询不收费**：
- Elastic Load Balancer（ELB/ALB/NLB）
- CloudFront distribution
- Elastic Beanstalk 环境
- API Gateway
- VPC endpoint
- S3 bucket（配置为 website endpoint）
- App Runner、AppSync、OpenSearch、Lightsail、Global Accelerator

免费成立的两个条件（都要满足）：
1. 查询的域名+记录类型（如 A）匹配到一条 alias 记录；
2. alias target 是上面这类 AWS 资源，而**不是同 zone 里的另一条普通（非 alias）记录**。

链式 alias（a → b → ELB）整条链都免费。但 alias 指向的是同 zone 的一条非 alias 记录时，按 standard 收费。

> **SME 考点（最常考）**：CNAME vs Alias 的成本差。
> - CNAME 指向 AWS 资源：**按 standard query 收费**，且 CNAME 不能用在 zone apex（根域）。
> - Alias 指向支持列表里的 AWS 资源：**查询免费**，且可用于 zone apex。
> 结论：把指向 ELB/CloudFront/S3-website 的记录用 **Alias 而非 CNAME**，既支持根域又省查询费。这是"零改架构直接降本"的标准答案。

### 2.4 Traffic Flow — policy record 月费

- **$50.00 / policy record / 月**（按月 prorate）。
- 当你把一个 Traffic Flow 策略与某个具体域名（如 www.example.com）关联，就产生一条 policy record。
- **没关联到域名的 traffic policy 不收费**。

> **SME 考点**：$50/月/record 是 Route 53 里单价最高的"隐形常驻费"之一。一个客户建了几十条 policy record，光这一项就上千刀/月。问账单意外时必查。策略本身（未关联）不花钱，钱花在"关联出来的 record"。

### 2.5 权威 DNS Query Logging

- Route 53 **对 query log 本身不收费**。
- 但日志写入 **CloudWatch Logs（固定在 us-east-1）**，产生 CloudWatch 的**数据摄入 + 存储 + 分析**费用。
- 成本取决于日志条目大小 × 查询量。高 QPS 域名开 query logging，CloudWatch 账单可能远超 Route 53 本体。

### 2.6 DNSSEC

- 启用 DNSSEC 签名（public zone）或 DNSSEC 验证（Resolver）**Route 53 不收费**。
- 但签名需要 **KMS** 存私钥 + 每次签名调用 → 产生 KMS 费用。
- 省钱技巧：**多个 public zone 可共用同一把 KMS 客户托管密钥**，减少 KMS 密钥数量。

---

## 三、Health Check（DNS 故障转移）

### 免费额度（关键）
- 新老客户对**同账户内 / 关联到同账户的 AWS endpoint**，最多 **50 个 health check 免费**。
- ELB 资源、S3 website bucket 的 health check 由 AWS 自动提供，**永远免费、不占这 50 个额度**。

### 收费表

| | AWS Endpoint | 非 AWS Endpoint（外部/公网 IP/on-prem） |
|---|---|---|
| 基础 health check（含 calculated、metric-based） | $0.50 / check / 月 | **$0.75 / check / 月** |
| 可选功能（HTTPS、字符串匹配、快速探测间隔、延迟测量）**每项** | $1.00 / 项 / 月 | **$2.00 / 项 / 月** |

- 月费按天 prorate。超 200 个需 contact us。

> **SME 考点（高频陷阱）**：
> 1. **"可选功能是按项叠加收费"**。一个监控外部 endpoint 且同时开了 HTTPS + string matching + fast interval + latency 的 health check，成本 = $0.75（基础）+ 4 × $2.00 = **$8.75/月**，不是 $0.75。客户以为 health check 很便宜，是因为没算这些附加项。
> 2. **AWS vs 非 AWS 单价差 50%**（基础）到 100%（可选项）。监控 on-prem/第三方 endpoint 明显更贵。
> 3. 优化：能用免费的 ELB/S3-website 自带 health check 就不要另建；把附加功能砍到实际需要的；用 **calculated health check**（父检点聚合多个子检点）而不是给每个子检点都堆满可选功能。

---

## 四、Route 53 Resolver（混合云 DNS）

### 4.1 Resolver Endpoint（inbound / outbound）

- **$0.125 / ENI / 小时**。一个 endpoint 至少 2 个 IP = 2 个 ENI，所以**最小成本 = 2 × $0.125 × 24 × 30 ≈ $180/月**，只要 endpoint 存在就一直扣，跟有没有查询无关。
- 一个 outbound endpoint 可被同区多账户的多个 VPC 复用。

### 4.2 过境查询（Recursive query to/from on-prem）

- 只有**穿过 endpoint（inbound 或 outbound）的查询才收费**；在 Resolver 本地解析（VPC 内 .2 resolver）的查询**不收费**。
- $0.40 / 百万（前 10 亿/月），$0.20 / 百万（超 10 亿）。

### 4.3 Resolver Query Log
- Route 53 对 VPC Resolver query log 不收费；日志按目标（CloudWatch / S3 / Kinesis Data Firehose）产生对应服务的费用。

> **SME 考点（最经典的"常驻费用"陷阱）**：
> - Resolver endpoint 是**按 ENI 小时常驻计费**，最低约 $180/月/endpoint，**空闲也扣**。客户在多个区/多个 VPC 各建 endpoint，很快堆到几千刀/月。
> - 优化：**尽量复用一个 outbound endpoint 给多 VPC**（RAM 共享 / Transit Gateway 集中），而不是每 VPC 一套；不再用的 endpoint 及时删；只对真正需要跨 on-prem 解析的 VPC 建 endpoint，VPC 内部解析走免费的本地 resolver。
> - **VPC 内 .2 resolver 解析免费**——不要为纯 VPC 内解析建 endpoint。

---

## 五、Resolver DNS Firewall

### Foundational
- **DNS query 检查费**：$0.60 / 百万（前 10 亿），$0.40 / 百万（超 10 亿）。对有 firewall rule group 关联的 VPC 发出的查询、以及经 inbound endpoint 进入这类 VPC 的查询收费；**CNAME 跟随产生的查询也收费**。
- **自定义域名列表**：每个存在自定义 domain list 里的域名 $0.0005/月（prorated hourly）。
- **托管域名列表（Managed Domain List）**：不收域名存储费，只收被检查的 query 费。

### Advanced
- 含一条或多条 Advanced 规则的 rule group，**每 VPC 关联 $0.16 / 小时**（按月聚合、prorated hourly）≈ $115.20/月/VPC 关联（满月）。用于 DGA、DNS Tunneling 等高级防护。

> **SME 考点**：DNS Firewall 是"按查询检查量 + Advanced 按小时"双重结构。Advanced 是又一个**常驻小时费**（$0.16/h/VPC 关联）。高 QPS VPC 开 Foundational，query 费可能很大（例：10 亿查询 = $600/月）。

---

## 六、其他常驻/固定费

### 6.1 Global Resolver（较新）
- 30 天免费试用（前两区 + DNS filtering + 至多 10 亿查询）。
- 区域小时费：前两区打包 **$5.00/小时**（不含 DNS filtering $4.50/h）；每多一区 $1.50/h（不含 filtering $0.75/h）。
- 查询量费：超首 10 亿查询/部署/月后 $1.50/百万。
- **这是重量级常驻费**（前两区就 $5/h ≈ $3,600/月），SME 要提醒客户仅在有全球递归解析需求时启用。

### 6.2 Route 53 Profiles
- **$0.75 / 小时 / 账户**（含前 100 个 Profile-VPC 关联，覆盖该账户该区所有 Profile）。
- 超过 100 个关联：$0.0014 / 关联 / 小时 / 区。
- 例：3 个 Profile 共 90 个 VPC 关联 → 前 100 内 → $0.75×720 = **$540/月**。
- 又一个**按小时常驻费**（≈$540/月起）。

### 6.3 Domain 注册
- 按 TLD 定价、**按年**注册（价目见 TLD PDF）。不提供批量折扣。
- 默认每账户 20 个域名注册上限，可 contact us 提额。
- **不能用 Promotional Credit 抵域名注册费**。
- 与 hosted zone 是**两笔独立费用**：注册域名（年费给注册局）≠ 托管解析（hosted zone 月费）。可以只注册不建 zone，也可以在 Route 53 建 zone 托管一个在别处注册的域名。

---

## 七、SME 高频考点汇总：成本优化 + 陷阱

**陷阱（账单意外的常见根因）：**
1. **常驻资源忘了删/复用**——Resolver endpoint（≈$180/月/个）、Traffic Flow policy record（$50/月/条）、DNS Firewall Advanced（$115/月/VPC）、Profiles（$540/月起）、Global Resolver（$3,600/月起）。这些**空闲也扣**，是账单意外的头号来源。
2. **Health check 可选功能按项叠加**——外部 endpoint 堆满附加项可到 $8.75/月/check，远超"$0.75"的直觉。
3. **hosted zone 月费不 prorate + 每月 1 号计费**——月中反复建删 zone 每次都收整月；只有 12 小时内删除才免 zone 费（但 query 仍收）。
4. **Query logging / DNSSEC "Route 53 免费"是误导**——真正的钱在下游 CloudWatch / KMS / S3 账单里。
5. **NXDOMAIN 和类型不匹配的查询也收费**——被打的不存在域名、只建了 A 没建 AAAA（浏览器双查）都在花钱。
6. **CNAME 指向 AWS 资源仍按 query 收费**，而等价的 Alias 免费。

**成本优化标准答案：**
1. 指向 AWS 资源（ELB/CloudFront/S3-website/API GW 等）一律用 **Alias 而非 CNAME** → 查询免费 + 支持根域。
2. **VPC 内解析走免费本地 .2 resolver**；只对真正跨 on-prem 的场景建 Resolver endpoint，并**跨 VPC/账户复用一套 outbound endpoint**（RAM 共享）。
3. Health check：优先用 ELB/S3-website 的**免费自带检查**；用 50 个 AWS endpoint 免费额度；砍掉不必要的可选功能；用 **calculated health check** 聚合。
4. 定期清理未使用的 **policy record、闲置 endpoint、闲置 Firewall Advanced 关联、闲置 Profiles**。
5. 路由策略按需选——不需要 geo/IP-based 就用 standard，单查询更便宜。
6. DNSSEC 多 zone **共用一把 KMS 密钥**降 KMS 成本。
7. Private hosted zone 查询免费——内部服务发现优先放 private zone。

**易混点速记：**
- Zone 月费 = 常驻按月（不 prorate）；Query 费 = 按量（prorate）。
- Alias 指 AWS 资源 = 免费；CNAME / Alias 指普通记录 = 收费。
- Resolver：本地解析免费；过 endpoint 才收 query，且 endpoint 有 ENI 小时常驻费。
- "Route 53 不收费" 的功能（query log / DNSSEC）钱在 CloudWatch / KMS。

# 04. 健康检查（Health Check / HaaS）

> 来源锚点：外部 `r53-external-research.md` 第 6 节 + 第 15 节速记 C13–C19；内部 `r53-internal-research.md` §4 + TSR53HealthCheckService + MR-TSOA Troubleshooting Runbook。
> 绑定真实 case：**P460958645**（CALCULATED/CloudWatch HC 卡 Unhealthy，★）、**V2254930641**（Unwanted HC abuse，★）。

---

## 1. 概念（Concept）

Route 53 健康检查（HaaS = Health check as a Service）由全球分布的 health checker 组成，用来判断某个 endpoint/资源是否健康，并驱动 failover / multivalue / weighted 等路由策略是否返回某条记录。

### 四类健康检查（考点核心，必须条件反射区分）

1. **Endpoint（端点检查）**
   - 监控一个 IP 或域名 + 端口，协议为 **HTTP / HTTPS / TCP**，可选 **string matching（字符串匹配）**。
   - 由**全球分布的 health checker** 各自独立探测目标端点，无相互协调。
   - **不能对 local / private / 不可路由 / multicast IP 段建 endpoint 检查**（内部 ALB / 非公网资源无法用，建议 EC2 用 EIP 固定公网 IP，或改用 CloudWatch/Calculated HC）。
   - **探测间隔仅 10s（快速，附加费）或 30s（标准），默认 30s，且创建后不可修改**（要改间隔只能删掉重建）。
   - **FailureThreshold（失败阈值）= 连续多少次探测结果一致才翻转健康状态，取值 1–10，默认 3。**

2. **Calculated（计算/组合检查）**
   - 一个父检查监控多个子检查，**1 父最多管 255 子**，配置一个 **HealthThreshold（健康阈值）**。
   - 父检查的健康判定 = **当前处于健康的子检查数量 ≥ HealthThreshold 则父健康**（不是"某个 alarm 状态"，而是对子检查计数）。
   - 用于把多个独立探测聚合成一个总体健康判断。

3. **CloudWatch alarm-based（基于告警的检查）**
   - 监控某个 CloudWatch Alarm 的**数据流（metric data stream）而非 alarm 的最终 state**。映射：`OK → 健康`、`ALARM → 不健康`、`INSUFFICIENT_DATA → 按 InsufficientDataHealthStatus 配置`。
   - 用于监控无法直接 endpoint 探测的资源（如内部 ALB、自定义业务指标）。
   - **配置字段名是 `InsufficientDataHealthStatus`，三态**：`Unhealthy`（默认，数据不足即判不健康）、`Healthy`（数据不足仍健康）、`LastKnownStatus`（保持上次已知状态）。
   - **不支持跨账号 alarm**——被引用的 CloudWatch alarm 必须与健康检查在**同一 AWS 账号**内。

4. **ARC Recovery Control（`RECOVERY_CONTROL` 类型）**
   - 关联一个 **Application Recovery Controller（ARC）routing control**，随 routing control 的 On/Off 状态判定健康，用于 ARC 主导的故障转移编排。
   - 是官方文档列出的第四类健康检查类型，早期"只有三类"的说法已过时。

### 判定机制 / 阈值参数（★背记 — 陷阱题密集）

- Endpoint HC 由全球多地 health checker 探测，**互不协调**；探测间隔 **10s（快速，附加费）或 30s（标准），默认 30s，创建后不可改**。
- **聚合规则（18% 规则）**：**> 18% 的全球 checker 报健康 → 判健康；≤ 18% → 判不健康**。设 18% 门槛是为了防止某处网络隔离导致的误判。
  - ⚠️ **18% 规则仅适用于由全球 checker 探测的 Endpoint 健康检查**；Calculated（按子检查计数 vs HealthThreshold）与 CloudWatch alarm-based（按 alarm 数据流）**不适用 18% 规则**。
- **响应时间阈值（仅 Endpoint HC）**：
  - **HTTP / HTTPS**：需 **4s 内**建立 TCP 连接 + 连接建立后 **2s 内**回 2xx/3xx 状态码。
  - **TCP**：需 **10s 内**建立连接。
  - **string matching**：在收到状态码后需再 **2s 内**收到响应 body，且匹配串必须落在 body 的**前 5,120 字节**内。
  - **字符串匹配区分大小写（case-sensitive）**，须完整落在前 5,120 字节内才算命中。
- **HTTPS 健康检查不校验证书**——证书过期/无效**不会**导致检查失败。（高频陷阱题）
- **新建健康检查在数据足够前默认视为健康**（若开启 invert 反转，则默认不健康）。

### 与 failover 绑定（考点）

- **Active-passive（主备）= failover 路由策略**；**Active-active = 除 failover 外任意策略**（所有同名同类型同策略记录都活跃，除非被判不健康）。
- **绑定方式二选一（易错点）**：
  - 记录指向**可建 alias 的 AWS 资源**（ELB/CloudFront 等）→ **不要**再建独立健康检查，而是把 alias 记录的 **Evaluate Target Health (ETH) 设 Yes**。
  - 记录指向**不能建 alias 的资源** → 才关联独立健康检查。
- **Failover Primary 必须关联 HC**（否则无法创建 failover 策略）。
- **fail-open 行为（内部 runbook 明确的坑）**：
  - 单条 failover 记录：**Primary + Secondary 的 HC 都 unhealthy → R53 返回 Primary**（fail open 到 primary），此行为**不可配置**。
  - 整个 Hosted Zone 视角：**该 zone 所有 HC 都 unhealthy → R53 fail open**（当作全部通过来应答）。
- **多资源主/备记录**：只要至少一个关联资源健康，该 failover 记录即视为健康。

### 健康检查器源 IP（运维/防火墙相关）

- 2023/09 起以 **AWS managed prefix list** 形式提供，IP 由 AWS 自动更新；该 prefix list 消耗名额 weight = 25。
- 防火墙放行时**不能只放自己 region 的 CIDR**——健康检查器来自多个 region。
- 探测请求携带 **User-Agent: `Amazon-Route53-Health-Check-Service`**（见 case V2254930641 证据）。

### Unwanted HC abuse（滥用）流程

- 任意账户都可创建一个指向**不属于自己**的 IP/域名的 endpoint HC，导致受害方持续收到探测请求。
- 处理是 **Support Ops 专属权限**（`Only Support Ops can address - Permission / Tooling restriction`）。
- 标准流程：确认 HC → 联系 offending account → 等待 **7 天** → 无回复则用 **Mechanic `controlapi disable-health-check`** 强制禁用（需 **2PR / Consensus Review**）。**禁用 ≠ 删除**：记录仍存在但 `Disabled=true`，不再发探测。

---

## 2. 真实案例说明（Real Case）

### ★ P460958645 — CloudWatch alarm-based HC 卡在 Unhealthy 约 53 分钟

- **症状**：关联的 CloudWatch Alarm（`pg-uat-euc1-wallstreetsuite-ec2-app-2-alarm`）已在 06:26 UTC 转为 **OK**，但 Route 53 HC（`9e5ef064-...`）仍停留在 **Unhealthy** 约 53 分钟，直到客户 07:16–07:18 手动执行 `UpdateHealthCheck` 才在 07:19 恢复 Healthy。
- **根因落点**：这是一个 **CloudWatch alarm 类型 HC**。失败消息明确是 "CloudWatch didn't have enough data to determine the state of the alarm"，即 alarm 一度进入 `INSUFFICIENT_DATA`，而 HC 的 `InsufficientDataHealthStatus` 为默认 **Unhealthy** → 数据不足即判不健康。正常情况下 R53 对 CW alarm 状态变化的响应应在 **1–2 分钟内**，本例 53 分钟属异常，怀疑 HC control plane 轮询 CloudWatch 时出现暂时性状态同步延迟。
- **知识点钉法**：① CloudWatch HC 监控的是 alarm **数据流**、三态里 INSUFFICIENT_DATA 走 `InsufficientDataHealthStatus`；② 默认 Unhealthy 是"数据不足即判死"的陷阱，改 `LastKnownStatus` 可缓解；③ **`UpdateHealthCheck` 会触发 HC 重新评估**，可作紧急恢复手段。

### ★ V2254930641 — Unwanted Health Check abuse（滥用）

- **症状**：受害账户 `611757617007` 的 ALB（`app/prd01-iotube-web-alb/...`，域名 `goodgearjapan.com`，IP `54.168.27.241`）持续收到来自 Route 53 Health Check Service 的探测。
- **根因**：另一个账户 `035745015862` 创建了一个 **HTTP 类型 endpoint HC**（ID `28e27f8c-...`，端口 80，间隔 30s，失败阈值 3），把目标指向了**不属于它的 IP**。ALB access log 里 `User-Agent: Amazon-Route53-Health-Check-Service (ref 28e27f8c-...)` 是决定性证据。
- **处理落点**：走标准 Unwanted HC abuse 流程——Route 53 Information Search 确认 HC → 向 offending / victim 双方发 outbound case → 等 7 天无回复 → 用 Mechanic `controlapi disable-health-check`（Namespace `haas-support`、us-east-1、2PR + Review ID）禁用，最终状态 `Disabled=true`。
- **知识点钉法**：① 探测源 User-Agent 与 `ref=<HC ID>` 是识别 HC abuse 的关键；② 禁用是 Support Ops 专属、需 2PR、禁用非删除。

---

## 3. 实验步骤（Hands-on Lab）

> 主题取自驱动表：CloudWatch alarm-based HC + `UpdateHealthCheck` 触发重评估观察状态同步；识别 HC User-Agent/prefix list 并演练 abuse outbound 流程（**只读理解，禁用需 2PR，不执行**）。

### Lab A：CloudWatch alarm-based HC 状态同步（复现 P460958645 现象，非破坏性）

```bash
# 1. 先建一个 CloudWatch Alarm（示例：监控某 EC2 StatusCheckFailed）
aws cloudwatch put-metric-alarm \
  --alarm-name r53-lab-hc-alarm \
  --namespace AWS/EC2 --metric-name StatusCheckFailed \
  --dimensions Name=InstanceId,Value=<i-xxxx> \
  --statistic Maximum --period 60 --evaluation-periods 1 \
  --threshold 1 --comparison-operator GreaterThanOrEqualToThreshold \
  --region eu-central-1

# 2. 建 CloudWatch alarm-based 健康检查，注意 InsufficientDataHealthState
aws route53 create-health-check \
  --caller-reference r53-lab-$(date +%s) \
  --health-check-config '{
    "Type":"CLOUDWATCH_METRIC",
    "AlarmIdentifier":{"Region":"eu-central-1","Name":"r53-lab-hc-alarm"},
    "InsufficientDataHealthState":"Unhealthy"
  }'
# 预期：新建 HC 在拿到足够数据前默认 Healthy；alarm 进 INSUFFICIENT_DATA 时按上面配置判 Unhealthy

# 3. 查 HC 当前状态与最近失败原因
aws route53 get-health-check-status --health-check-id <HC_ID>
#   观察各 checker region 的 StatusReport（会写明 "CloudWatch didn't have enough data ..." 等）

# 4. 复现"触发重新评估"：改任一无害字段（如 Inverted 再改回）触发 UpdateHealthCheck
aws route53 update-health-check --health-check-id <HC_ID> --inverted
aws route53 update-health-check --health-check-id <HC_ID> --no-inverted
#   预期：UpdateHealthCheck 触发 HC 重新评估，状态在 1–2 分钟内同步（对照 case 的 53 分钟异常）

# 5. 对比把 InsufficientDataHealthState 改成 LastKnownStatus 的缓解效果
aws route53 update-health-check --health-check-id <HC_ID> \
  --insufficient-data-health-status LastKnownStatus

# 清理
aws route53 delete-health-check --health-check-id <HC_ID>
aws cloudwatch delete-alarms --alarm-names r53-lab-hc-alarm --region eu-central-1
```

判读要点：`get-health-check-status` 返回多个 region checker 的 `StatusReport`；用 **18% 规则**理解"少数 checker 报健康也可能判健康"。

### Lab B：识别 HC 探测源与 abuse 流程（只读演练，禁用步骤不执行）

```bash
# 1. 在被探测资源（如 ALB）的 access log 里识别 R53 HC 探测
#    关键特征：User-Agent 含 Amazon-Route53-Health-Check-Service (ref <HC_ID>; report http://amzn.to/1vsZADi)
grep 'Amazon-Route53-Health-Check-Service' alb_access.log

# 2. 用 HC 源 IP prefix list 核对来源（健康检查器多 region，勿只放本 region CIDR）
aws ec2 get-managed-prefix-list-entries \
  --prefix-list-id <route53-healthchecks-pl-id> --region us-east-1

# 3.（内部工具，只读）用 Route 53 Information Search 按 HC ID 查 owner/配置：
#    https://route53-information-search.amazon.com/customersearch?searchFieldType=Any&searchFieldValue=<HC_ID>
```

> **禁用属破坏性且 Support-Ops 专属**：Mechanic `controlapi disable-health-check`（Namespace `haas-support`）**需 2PR / Consensus Review**，本 lab **只做概念演练，不执行**。禁用是 `Disabled=true`（非删除）。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

逐条对应外部第 15 节速记 **C13–C19**（附常见错误认知正误对照）：

- **C13**：**Active-passive = failover 策略；active-active = 除 failover 外任意策略**。
  - ✗ 错误认知：以为"主备"就是一定要用某个专门的"active-passive 策略"名——它就是 failover 策略本身。
- **C14**：指向可建 alias 的 AWS 资源做 failover 时，用 **Evaluate Target Health = Yes**，**不要**再单独建健康检查。
  - ✗ 错误认知：给指向 ELB 的 alias 记录又额外挂一个 endpoint HC——多余且可能冲突，应改用 ETH。
- **C15**：**> 18% 的全球 checker 报健康才算健康；≤ 18% 判不健康**；**此规则仅适用于 Endpoint 健康检查**。
  - ✗ 错误认知：以为"多数（>50%）checker 健康才算健康"——门槛是 18%，用于防网络隔离误判；也别把 18% 套到 Calculated（按子检查数 vs HealthThreshold）或 CloudWatch（按 alarm 数据流）上。
- **C16**：**HTTP/HTTPS：4s 建连 + 2s 回 2xx/3xx；TCP：10s 建连；string match 收到状态码后 2s 内收 body，匹配串须落在 body 前 5,120 字节内且区分大小写**。
  - ✗ 错误认知：把 4s / 2s / 10s / 5120B 混记，或以为字符串可在整个 body 任意位置匹配、以为大小写不敏感。
- **C17**：**HTTPS 健康检查不校验证书**（证书过期/无效不导致失败）。
  - ✗ 错误认知：以为证书过期会让 HTTPS HC 变红——不会，这是经典陷阱题。
- **C18**：**Calculated：1 父最多 255 子，按健康子检查数 ≥ HealthThreshold 判健康**；**CloudWatch alarm HC 监控 alarm 的数据流而非直接 alarm 状态，字段 `InsufficientDataHealthStatus`，且不支持跨账号 alarm**；**新检查在数据足够前默认健康（除非 invert）**。
  - ✗ 错误认知：以为 CloudWatch HC 读的是 alarm 的 state 字段——实际读数据流；以为新建 HC 一开始是 unhealthy；以为能引用别的账号的 alarm。
- **C19**：**不能对 private / 不可路由 / multicast IP 建 endpoint 健康检查**。
  - ✗ 错误认知：想给内部 ALB 直接建 endpoint HC——建不了/状态异常，应改用 CloudWatch alarm-based 或 calculated HC（配合 EIP 固定 IP）。

### 该域特有内部边界数字速记（internal §4 / TSOA runbook）

- **InsufficientDataHealthStatus 三态**：Unhealthy（默认，坑）/ Healthy / LastKnownStatus。P460958645 的缓解就是改 LastKnownStatus。CloudWatch HC 读 alarm 数据流、不支持跨账号 alarm。
- **`UpdateHealthCheck` 会触发 HC 重新评估**——紧急恢复手段。
- **Endpoint HC 间隔仅 10s/30s，默认 30s，创建后不可改**；**FailureThreshold 连续 1–10 次，默认 3**。
- **Calculated：按健康子检查数 vs HealthThreshold**；四类 HC = Endpoint / Calculated / CloudWatch / ARC Recovery Control。
- **Failover fail-open**：单条 Primary+Secondary 都不健康 → 返回 Primary（不可配置）；整 zone HC 全不健康 → fail open。
- **Failover Primary 必须有 HC**，否则建不了 failover。
- **HC 器源 IP = AWS managed prefix list（weight 25）**，多 region，防火墙别只放本 region。
- **Unwanted HC abuse**：Support Ops 专属，联系 offending → 等 7 天 → Mechanic 禁用（2PR），禁用非删除。
- **PHZ 支持的 HC**：仅可与 failover / multivalue / weighted / latency / geolocation / geoproximity 记录关联；**simple 记录不能关联 HC**。
- 探测间隔 **10s（快速，附加费）/ 30s（标准）**；非 AWS endpoint / HTTPS / string-match / 10s 快检 / 延迟测量均为**附加费**。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

```mermaid
flowchart TD
    START([Route 53 收到查询, 记录关联了 HC]) --> TYPE{HC 类型?}

    TYPE -->|Endpoint HTTP/HTTPS/TCP| EP[全球多地 checker 探测端点]
    TYPE -->|Calculated| CALC[父检查聚合子检查<br/>1父≤255子, 健康子数≥HealthThreshold]
    TYPE -->|CloudWatch alarm| CW[读 alarm 数据流<br/>OK→健康 / ALARM→不健康<br/>同账号 alarm only]
    TYPE -->|ARC Recovery Control| RC[随 routing control On/Off 判定]

    EP --> THRESH{阈值达标?<br/>HTTP:4s建连+2s回2xx-3xx<br/>TCP:10s建连<br/>strmatch:前5120B命中,区分大小写<br/>HTTPS 不校验证书}
    THRESH -->|是| CHECKER_OK[该 checker 报健康]
    THRESH -->|否| CHECKER_BAD[该 checker 报不健康]

    CHECKER_OK --> AGG{>18% checker 报健康?<br/>仅 Endpoint 适用}
    CHECKER_BAD --> AGG
    CALC --> HC_OK
    CW -->|INSUFFICIENT_DATA| IDHS{InsufficientDataHealthStatus}
    RC --> HC_OK
    IDHS -->|Unhealthy 默认| HC_BAD
    IDHS -->|Healthy| HC_OK
    IDHS -->|LastKnownStatus| LAST[保持上次状态]
    CW -->|OK| HC_OK
    CW -->|ALARM| HC_BAD

    AGG -->|是 >18%| HC_OK[HC = Healthy]
    AGG -->|否 ≤18%| HC_BAD[HC = Unhealthy]

    HC_OK --> BIND
    HC_BAD --> BIND
    LAST --> BIND

    BIND{绑定方式?} -->|指向可建 alias 的 AWS 资源| ETH[用 Evaluate Target Health=Yes<br/>不要再单独建 HC]
    BIND -->|不能建 alias 的资源| INDEP[关联独立 HC]

    ETH --> FO
    INDEP --> FO
    FO{failover 记录 主+备 都不健康?}
    FO -->|是| FAILOPEN[fail open → 返回 Primary<br/>整 zone 全不健康亦 fail open]
    FO -->|否| NORMAL[按健康状态正常返回记录]

    NORMAL --> DONE([返回应答])
    FAILOPEN --> DONE
```

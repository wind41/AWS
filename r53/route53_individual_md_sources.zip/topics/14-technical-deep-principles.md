# Topic 14 — 技术原理深挖（SME 要懂的底层机制）

> **定位**：本专题不讲"怎么配"，只讲"底层为什么这么设计、报文/信任链/数据面到底怎么流转"。SME 与普通用户的分界线就在这里——用户能配 failover，SME 要能在客户追问"为什么切换要等 X 秒""为什么 dig +short 拿到的 NS 和控制台不一样""DNSSEC 报 SERVFAIL 到底断在哪一环"时，从机制层给出准确答案。
> **五大原理块**：(1) 递归解析完整路径与 R53 权威定位；(2) 权威 anycast / 全球 NS 基础设施与四组委派 NS 选择机制；(3) VPC Resolver 数据面架构 / EDNS0 client subnet / 缓存与负缓存；(4) health checker 全球分布 / 18% 共识 / 数据面传播延迟；(5) DNSSEC 验证链密码学原理。
> **配套 topic**：01（Hosted Zone）、04（健康检查）、05（Resolver/混合 DNS）、07（DNSSEC）、03b（路由×HC 交互）。本专题是它们背后的"机制底座"。

---

## 一、DNS 递归解析完整路径与 Route 53 权威定位

### 1.1 三种角色：stub / recursive / authoritative（考点，别混）

| 角色 | 位置 | 职责 | R53 对应 |
|---|---|---|---|
| **Stub resolver（存根解析器）** | 终端设备（笔记本 / EC2 内核 glibc）| 只做一件事：把查询丢给配置的递归解析器，自己不迭代 | 客户端侧，不是 R53 |
| **Recursive resolver（递归解析器）** | ISP / 企业网 / 公共 DNS（8.8.8.8）/ **VPC Resolver** | 代替客户端"跑完全程"：迭代查询根→TLD→权威，缓存结果，回填答案 | **VPC Resolver 就是这一层** |
| **Authoritative name server（权威服务器）** | 域名所有者侧 | 持有 zone 的真实记录，只回答"我负责的 zone"，**从不迭代、从不缓存别人的数据** | **Route 53 public hosted zone 通过公开 awsdns NS 对外应答**；**private hosted zone 的数据不经公开 awsdns 地址暴露，而是经关联 VPC 的 VPC Resolver 私有连接访问**（见 §1.2 与第三块） |

> **核心心法**：Route 53（托管 zone 那一侧）是**权威**，不是递归。它只对"发到它这里的、它负责的 zone"作答，绝不会替你去问别人。VPC Resolver 才是递归。**SME 最常被问混的就是这两个**——见第三块。

### 1.2 一次冷缓存查询的完整迭代路径

以递归解析器解析 `www.pd-market.com`（缓存全空）为例：

```mermaid
sequenceDiagram
    participant C as Stub Resolver<br/>(客户端)
    participant R as Recursive Resolver<br/>(如 VPC Resolver / 8.8.8.8)
    participant Root as 根服务器 (.)
    participant TLD as .com TLD 服务器<br/>(Verisign)
    participant R53 as Route 53 权威<br/>(awsdns NS)

    C->>R: www.pd-market.com A?（递归标志 RD=1）
    R->>Root: www.pd-market.com A?
    Root-->>R: 我不知道，去问 .com（返回 .com NS + glue）
    R->>TLD: www.pd-market.com A?
    TLD-->>R: 我不知道，去问 pd-market.com<br/>（返回 4 条 awsdns NS 委派；awsdns-* 为域外名<br/>glue 可选，解析器可独立解析）
    R->>R53: www.pd-market.com A?
    R53-->>R: 权威应答：A = 203.0.113.10（AA 标志=1）
    R-->>C: A = 203.0.113.10（缓存 TTL 秒）
```

关键机制点：

- **RD（Recursion Desired）标志**：stub→recursive 的查询带 RD=1（"请你替我跑全程"）；recursive→权威的查询 **RD=0**（权威不递归）。R53 收到 RD=1 的查询也**不会**递归，它只按权威身份作答。
- **委派（delegation）靠 NS 记录，glue 仅对 in-bailiwick NS 必需**：`.com` 里存的是 `pd-market.com → 4 条 awsdns NS 名字`。**glue（NS 的 A/AAAA）只在 NS 名字落在被委派域内（in-bailiwick，如 `ns1.pd-market.com`）时才必需**——否则会陷入"要解析 NS 又要先解析 pd-market.com"的死循环。而 R53 的 `awsdns-*` NS 属于**委派域外（out-of-bailiwick）名称**，解析器可**独立**沿 `.net/.org/.co.uk` 等各自的链路解析出它们的地址，**不依赖 `pd-market.com` 这条 child delegation 附带的 glue**（RFC 9471）。TLD 侧仍可能附带 glue 作为优化，但对 awsdns-* 而言不是必需项。
- **AA（Authoritative Answer）标志**：R53 的应答置 AA=1，表示"该服务器对此答案具有权威性（是权威原话，非缓存转述）"，递归解析器据此判定可缓存。**注意：AA=1 只表权威来源，不提供任何密码学真实性**——它不能防止路径上的伪造/篡改。真正的"可信（authenticated data）"来自 **DNSSEC 验证成功后置位的 AD 标志**（RFC 4035），两者是不同层次，别混（见第五块）。
- **谁做缓存**：**递归解析器是主要缓存层**，但缓存不止它一家——**OS 本地存根缓存 / 本地转发代理（dnsmasq、systemd-resolved）/ 应用自身**都可能缓存。权威（R53）本身不缓存。**VPC Resolver（Nitro）作为递归层也维护本地短期缓存**，且在**上游权威故障时可能提供超出 TTL 的缓存答案**（serve-stale 式兜底）。所以"改了记录多久生效"取决于**这条链路上任一缓存层手里旧记录的剩余 TTL**，不只是最近那一跳的递归解析器——R53 权威侧改动本身传播很快（见第二块传播）。

> **SME 排障锚点**：客户说"我改了记录，为什么没生效"——先问"你在哪测的、经过哪个递归解析器、旧记录 TTL 多少"。R53 权威侧的变更**通常在 60 秒内传播到该 hosted zone 的全部 R53 NS**（应以 **`GetChange` 返回 `INSYNC`** 作为传播完成的权威确认，而不是假定"总是已更新"）；一旦 INSYNC，卡的通常就是**下游各缓存层的旧记录 TTL 尚未过期**，不能只归因于递归 TTL。
> 来源：[Amazon Route 53 concepts](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/route-53-concepts.html)、[A Case Study in Global Fault Isolation](https://aws.amazon.com/blogs/architecture/a-case-study-in-global-fault-isolation/)（"DNS Resolution"节）。

---

## 二、权威 anycast / 全球 NS 基础设施与四组委派 NS 选择机制

这一块是 R53 权威侧最"AWS 独有"的工程，来源核心是 2014 年架构博客 [A Case Study in Global Fault Isolation](https://aws.amazon.com/blogs/architecture/a-case-study-in-global-fault-isolation/)（shuffle sharding 系列），SME 必须能讲清楚。

### 2.1 Anycast：一个 IP，全球多个 edge 同时宣告

- R53 权威用 **anycast** 从全球**多个 edge location** 宣告同一批 NS IP 地址。
  > ⚠️ **数字口径提醒**：坊间常引的"**50+ edge**"来自 **2014 年架构博客** [A Case Study in Global Fault Isolation](https://aws.amazon.com/blogs/architecture/a-case-study-in-global-fault-isolation/) 当时的测量，只作**设计背景**，**不代表现行权威数字**（R53 边缘规模早已远超且持续变化，以官方最新文档为准）。
- Anycast 的路由语义：客户端发往某个 NS IP 的包，被 Internet 路由到**网络路径最近**（不是地理最近）的那个宣告该地址的 edge。
- 效果：同一个 `ns-584.awsdns-09.net`，澳洲的递归解析器命中悉尼 edge，欧洲的命中法兰克福 edge——**低延迟 + 天然抗单点**。

### 2.2 四组委派 NS = 四个 stripe（.com/.net/.co.uk/.org），带 shuffle sharding

这是本块最硬的考点。R53 背后有**数千个 NS 名字**，分布在**四个顶级域**上：

| Stripe | TLD | 说明 |
|---|---|---|
| .com stripe | `awsdns-XX.com` | Verisign 运营 |
| .net stripe | `awsdns-XX.net` | Verisign 运营 |
| .org stripe | `awsdns-XX.org` | 不同运营方 |
| .co.uk stripe | `awsdns-XX.co.uk` | 不同运营方 |

**每个 hosted zone 拿到的 4 条委派 NS = 从四个 stripe 各取一条**（一个 zone 的 delegation set 横跨四个 TLD）。

- **多 TLD 的意义**：`.com`/`.net` 同属 Verisign，若某 TLD 自身 DNS 故障（罕见），你至少还有另外两条（.org/.co.uk）能解析——**TLD 层容灾**。
- **shuffle sharding 规则（硬考点）**：分配 NS 时强制"**任意两个 hosted zone 的 4 条 NS 重叠不超过 2 条**"。这样某几个 NS 名字/IP 出问题时，受影响的 zone 集合彼此错开，**故障爆炸半径被切碎**（magical fault isolation）。

### 2.3 "每个 edge 一般只宣告一个 stripe"——延迟 vs 可用性的取舍

R53 **没有**在每个 edge 宣告全部四个 stripe，而是**每个 edge 一般只宣告一个 stripe**。原因：

- 若每个 edge 宣告全部四条：解析器无论选哪条 NS 都落到同一个最近 edge——延迟最优，但**该 edge 一旦不可达（断电 / 断网 / 中间传输商拥塞 / DDoS），四条 NS 全军覆没，解析器无处可退**（实测这类事件恢复约 5 分钟）。
- R53 选择每 edge 一个 stripe：解析器手里的 4 条 NS 分布在 4 个不同 edge，**任一 edge / 路径故障，还有 3 条在别处的 NS 可退**，并获得 Internet 路径多样性（绕开拥塞）。
- 代价：某些 NS 会从"较远的 edge"应答。但由于绝大多数递归解析器用 **SRTT（Smooth Round-Trip Time）自动收敛到最快的 NS**（上引 2014 博客当时测得**约 80% 的解析器**这么做——**此为该博客当年的测量背景，不作现行权威数字**），对最小 RTT / 最快应答几乎无影响。这是 R53 "100% DNS 查询 SLA"背后的取舍。

```mermaid
flowchart TB
    Z["Hosted Zone<br/>pd-market.com"]
    Z --> NS1[".com stripe<br/>ns-A.awsdns.com"]
    Z --> NS2[".net stripe<br/>ns-B.awsdns.net"]
    Z --> NS3[".org stripe<br/>ns-C.awsdns.org"]
    Z --> NS4[".co.uk stripe<br/>ns-D.awsdns.co.uk"]
    NS1 -. anycast .-> E1["Edge 悉尼<br/>(宣告 .com)"]
    NS2 -. anycast .-> E2["Edge 香港<br/>(宣告 .net)"]
    NS3 -. anycast .-> E3["Edge 新加坡<br/>(宣告 .org)"]
    NS4 -. anycast .-> E4["Edge 东京<br/>(宣告 .co.uk)"]
    E1 -. 单 edge 故障 .-x X["解析器仍可退到<br/>E2/E3/E4 的 3 条 NS"]
```

### 2.4 Reusable delegation set / white-label NS（衍生考点）

- 默认每个 hosted zone 分到**独立的一组 4 NS**。若要多个 zone 共用同一组 NS（便于在注册商侧集中配置委派），用 **reusable delegation set**（仅 API，控制台不支持）。
- **white-label（vanity）name server**：把 `ns-XXXX.awsdns-XX.com` 隐藏成 `ns1.yourbrand.com`——本质仍是那 4 台 awsdns NS，只是加了自定义 NS 名字外壳。

> **SME 排障锚点**：客户抱怨"控制台显示的 4 条 NS 和我 dig NS 拿到的不一致"——多半是父区（注册商 / 上级 zone）委派没同步、或存在旧 delegation set 残留。别动 R53 侧那条自动生成的 NS 记录（"Except in rare circumstances, don't change it")。
> 来源：[SOA and NS records R53 creates](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/SOA-NSrecords.html)、[Considerations for public hosted zones](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zone-public-considerations.html)、[Configuring white-label name servers](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/white-label-name-servers.html)、上引 fault-isolation 博客。

---

## 三、VPC Resolver 数据面架构、EDNS0 client subnet、解析缓存与负缓存

### 3.1 VPC Resolver 是"递归数据面"，跑在 VPC+2

- VPC Resolver（旧称 "Amazon-provided DNS" / AmazonProvidedDNS）跑在 **VPC CIDR 基址 +2** 的地址上（例如 VPC `10.0.0.0/16` → Resolver 在 `10.0.0.2`），IPv6 上是 `fd00:ec2::253`，另外还有链路本地地址 `169.254.169.253`。
- 它是**递归解析器**（第一块的 recursive 角色）：对 public 记录会迭代到互联网权威；对 VPC 内名字（EC2 私有 DNS 名）、关联的 **private hosted zone** 直接本地作答。
- **PHZ 数据只经 VPC Resolver 私有连接可达**：private hosted zone 的记录**不发布到公开的 awsdns NS 地址**——从 VPC 外直接 `dig @ns-XXXX.awsdns-XX.com` 查 PHZ 里的名字**不会返回 PHZ 数据**（会得到公网权威的答案或 NXDOMAIN）。要命中 PHZ，查询必须来自关联 VPC 内、经 VPC+2 的 VPC Resolver。
- **可用性 / 扩展**：默认在所有 VPC 中就绪，AWS 侧自动横向扩展。但对**单个 ENI 出方向到 VPC+2 有每秒包数硬上限（约 1024 pps/ENI）**——大量并发解析（如 fleet 同时冷启动查外部域）可能撞这个上限触发丢包，表现为间歇性解析超时。这是 SME 级排障点，不在普通文档首页。

### 3.2 EDNS0 client subnet（ECS）——地理/延迟路由精度的底层报文机制

普通递归解析路径里，权威只看得到**递归解析器的源 IP**，看不到真实终端用户。这对 geolocation / geoproximity / latency / IP-based 路由是致命的——用户在巴西、但用了美国的 8.8.8.8，权威会以为用户在美国。

**EDNS0 的 edns-client-subnet（ECS，RFC 7871）解决这个问题：**

- 支持 ECS 的递归解析器，在转发给 R53 权威时，**在 OPT 伪记录里附带一段"截断后的用户源 IP 前缀"**（如 `203.0.113.0/24`，抹掉主机位保护隐私）。
- R53 据此按**真实用户位置**而非解析器位置做地理/延迟决策，精度大幅提升。
- 若解析器**不支持** ECS：R53 回退用**解析器的源 IP**猜位置（精度差）。
- **private hosted zone 不适用 EDNS0**：私有 zone 的地理/延迟决策改用"private hosted zone 所在 AWS Region 的 VPC Resolver 数据"来判定。

```mermaid
flowchart LR
    U["巴西用户<br/>src 200.x.x.x"] --> RSV["递归解析器<br/>(美国, 支持 ECS)"]
    RSV -->|"查询 + ECS: 200.x.x.0/24<br/>(截断主机位)"| R53["Route 53 权威"]
    R53 -->|"按真实用户地=巴西<br/>回巴西 endpoint"| RSV
    RSV --> U
    style R53 fill:#2d3748,color:#fff
```

> **易错点**：ECS 是"**解析器愿不愿意 + 支不支持**"的可选扩展，R53 侧被动接受。客户抱怨"geolocation 路由把用户导错区"，先查其递归解析器是否支持 ECS、是否发了 client-subnet——不支持时权威只能看解析器 IP。
> 来源：[How R53 uses EDNS0 to estimate user location](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-edns0.html)、[RFC 7871 Client Subnet in DNS Queries](https://datatracker.ietf.org/doc/html/rfc7871)、[VPC Resolver availability and scaling](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-availability-scaling.html)。

### 3.3 正缓存 vs 负缓存（NXDOMAIN / NODATA 缓存）——SOA MINIMUM 的真正用途

- **正缓存**：递归解析器按记录自身 TTL 缓存"有答案"的应答。
- **负缓存（negative caching，RFC 2308 / 更新为 RFC 9077）**：递归解析器也缓存**"这个名字不存在（NXDOMAIN）"或"名字在但该类型无记录（NODATA）"** 的否定应答，以减少对权威的重复无效查询。
- **负缓存时长 = min(SOA 的 MINIMUM 字段, SOA 记录自身 TTL)**。这就是 SOA 最后那个 MINIMUM 字段在现代 DNS 里的**唯一实际用途**——它**不是**记录默认 TTL（这是常见误解），而是**负缓存 TTL 上限**。
  - R53 默认 SOA 的 MINIMUM 约 **900 秒**。
  - **RFC 9077 修订点**：负缓存 TTL 现在取 `min(SOA.MINIMUM, SOA.TTL)`，两者取小，避免 SOA TTL 很小而 MINIMUM 很大时负缓存过久。
- **DNSSEC 下的否定应答**用 NSEC/NSEC3 证明"不存在"，同样受负缓存约束（见第五块）。

> **SME 排障锚点**：客户"新建了记录，但一直解析失败/NXDOMAIN"——若之前查过这个不存在的名字，递归解析器可能已**负缓存 NXDOMAIN 达 SOA MINIMUM 秒**，新建后仍要等负缓存过期。这类"记录明明建了却还 NXDOMAIN"十有八九是负缓存。
> 来源：[SOA/NS records R53 creates](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/SOA-NSrecords.html)、[RFC 2308](https://datatracker.ietf.org/doc/html/rfc2308)、[RFC 9077 (NSEC/NSEC3 TTL & negative caching)](https://www.rfc-editor.org/rfc/rfc9077.txt)。

---

## 四、health checker 全球分布、18% 共识与数据面传播延迟

配套 topic 04 讲"怎么配、四类 HC、fail-open"，本块只钉**底层三大机制**：全球分布、18% 共识数学、跨数据面异步传播。

### 4.1 health checker 是独立的全球数据面

- R53 health checker 分布在**全球多个 AWS Region 的检查点**。这是一个**独立于 DNS 权威的全球数据面**：它执行检查、**聚合结果**、再把结论**投递给 R53 public DNS / private DNS / Global Accelerator 各自的数据面**。
- **各检查点互不协调（don't coordinate）**：所以就算你配 30s 间隔，端点实际会**在某几秒收到多次请求、又有几秒完全没有**——因为多个 Region 的 checker 各自按自己的时钟发。平均下来端点大约**每 2 秒收到一次**探测。

### 4.2 18% 共识——为什么是这个数，数学在哪

聚合规则（硬考点）：

> **可用 checker 中,报告端点健康的比例 > 18% → R53 判定"健康";≤ 18% → 判定"不健康"。**

- **18% 的设计意图**：确保"多个 Region 的 checker 都认为健康"才算健康的反面——即**防止端点仅因为被少数几个检查点的网络路径隔离，就被误判为不健康**。低阈值 = 抗"局部网络隔离误报",偏向 fail-toward-available。
- **含义**：这是**"能被多少比例的全球检查点看到"的共识**,不是"端点自己的负载/业务健康"。所以会出现"端点只对 18%+ 的 checker 可达就被判健康"的场景——这**不可调**(文档明示 "This value might change in a future release",但用户不能设)。
- **各 HC 类型的单点判定阈值**(叠加在 18% 之上):
  - HTTP/HTTPS:4s 内建 TCP 连接 + 连上后 2s 内返回 2xx/3xx。
  - HTTP/HTTPS + 字符串匹配:同上,且响应体前 **5120 字节**内出现指定字符串。
  - TCP:10s 内建立 TCP 连接。
  - **HTTPS 健康检查不校验证书**——证书过期/无效**不会**让 HC 失败(易错,常被问)。

### 4.3 数据面传播延迟——failover"切换要等多久"的真正构成

客户最常问"为什么故障发生后没有立刻切"。SME 要能拆出**串联的三段时延**:

```mermaid
flowchart LR
    A["① 端点真的挂了"] --> B["② HC 达到失败阈值<br/>(间隔×连续失败次数<br/>快速 HC 最短≈10s)"]
    B --> C["③ 健康结论跨数据面<br/>异步传播到全球 DNS<br/>(秒级,非瞬时)"]
    C --> D["④ 递归解析器缓存中<br/>旧记录 TTL 过期<br/>(取决于 record TTL)"]
    D --> E["客户端才拿到新答案"]
    style A fill:#742a2a,color:#fff
    style E fill:#22543d,color:#fff
```

- **② 检测**:间隔 10s / 30s × 失败阈值(默认 3 次)。最快配置(10s 间隔 + 单次)也有**约 10s** 最小检测窗。
- **③ 传播**:health 数据面 → DNS 数据面是**异步**的,秒级但非瞬时,是一个独立的全球复制过程。
- **④ 缓存过期**:即使 R53 已改答案,**下游递归解析器仍会返回旧记录直到其缓存 TTL 到期**——这段完全不受 R53 控制,只由记录 TTL 决定。**failover 场景的记录 TTL 要设小**(如 60s)就是为了压这一段。
- 三段串联 = 客户感知的"切换总耗时"。**别把它简化成"HC 一失败就切"**——这是 SME 与用户的分水岭。

> **来源**:[How R53 determines whether a health check is healthy](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-failover-determining-health-of-endpoints.html)(18% + 各类型阈值 + 不协调 + 新 HC 视为健康)、[Edge network global service guidance (fault isolation whitepaper)](https://docs.aws.amazon.com/whitepapers/latest/aws-fault-isolation-boundaries/appendix-b---edge-network-global-service-guidance.html)(health 数据面聚合→投递给 DNS/AGA 数据面)、[fault-isolation 博客](https://aws.amazon.com/blogs/architecture/a-case-study-in-global-fault-isolation/)(failover 最短 10s + TTL 叠加)。

---

## 五、DNSSEC 验证链密码学原理（RRSIG / DNSKEY / DS 摘要算法）

topic 07 已讲 KSK/ZSK、DS 在父区、island of trust。本块下沉到**密码学与报文层**,SME 要能定位"验证到底断在哪一环"。

### 5.1 三类密码学对象各自签什么、算什么

| 对象 | 全称 | 内容 | 密码学动作 |
|---|---|---|---|
| **RRSIG** | Resource Record Signature | 对**同名+同类型的整个 RRset** 的数字签名 + inception/expiration 时间戳 + 签名者 Key Tag | 用私钥(ZSK/KSK)对 RRset 规范化字节做**签名**;解析器用对应 DNSKEY 公钥**验签** |
| **DNSKEY** | — | zone 的公钥(KSK flag=257 / ZSK flag=256,algo 如 13=ECDSAP256SHA256) | 存放公钥;DNSKEY RRset 本身由 KSK 签(产生一条 RRSIG) |
| **DS** | Delegation Signer | 子区 **KSK** 的**摘要(digest)** + Key Tag + Algorithm + **Digest Type** | 放在**父区**;对子区 KSK 的 DNSKEY 做**哈希摘要**(不含完整公钥) |

### 5.2 验证链:从根信任锚一路验到业务记录

```mermaid
flowchart TB
    ROOT["根区 (.) 信任锚<br/>(解析器内置 root KSK)"]
    ROOT -->|"根 DS/DNSKEY 验证"| TLD["(.com) 区<br/>DNSKEY(KSK/ZSK)"]
    TLD -->|"父区(.com)持有<br/>pd-market.com 的 DS"| ZONE["pd-market.com 区"]
    subgraph ZONE_INNER["pd-market.com 内部验证"]
        DS["父区 DS<br/>= 子 KSK 的 digest"] -->|"① 按 Digest Type<br/>哈希子区 KSK<br/>比对 digest"| KSK["KSK (flag 257)"]
        KSK -->|"② KSK 签<br/>整个 DNSKEY RRset"| DNSKEYSET["DNSKEY RRset<br/>(含 KSK + ZSK)"]
        DNSKEYSET -->|"③ 从中信任 ZSK"| ZSK["ZSK (flag 256)"]
        ZSK -->|"④ ZSK 的 RRSIG<br/>验证业务记录"| REC["www A 记录<br/>+ 其 RRSIG"]
    end
    ZONE --> ZONE_INNER
```

四步链(SME 要能背):

1. **父区 DS → 子区 KSK**:解析器拿子区 DNSKEY 里的 KSK,按 DS 记录声明的 **Digest Type**(1=SHA-1 已淘汰 / **2=SHA-256** 主流 / 4=SHA-384)算出摘要,与父区 DS 的 Digest 比对。一致 → 信任这把 KSK。
2. **KSK 签 DNSKEY RRset**:KSK 对"包含 KSK+ZSK 两把公钥的那条 DNSKEY RRset"产生一条 RRSIG。解析器用刚信任的 KSK 验这条 RRSIG → 从而信任 RRset 里的 ZSK。
3. **信任 ZSK**。
4. **ZSK 的 RRSIG 验业务记录**:每条业务 RRset(A/MX/TXT)带一条由 ZSK 私钥产生的 RRSIG,解析器用 ZSK 公钥验签。全部通过 → 应答置 **AD(Authenticated Data)标志**。

### 5.3 常见签名算法(algo number,考点)

| Algo | 名称 | 密钥体系 | 说明 |
|---|---|---|---|
| 8 | RSASHA256 | RSA | 传统,密钥大 |
| **13** | **ECDSAP256SHA256** | 椭圆曲线 | **R53 用这个**,密钥短、签名小、报文更省 |
| 15 | Ed25519 | EdDSA | 新,部分解析器未普及 |

DS Digest Type:**2 = SHA-256** 是当前应建的类型(1=SHA-1 应淘汰)。

### 5.4 验证为什么会 SERVFAIL——按环定位(SME 排障树)

支持验证的递归解析器,任一环断裂都返回 **SERVFAIL**(不是 NXDOMAIN):

| 断点 | 现象 | 根因 |
|---|---|---|
| 父区无 DS | 不验证,普通解析(**island of trust**) | 签了名但父区没建 DS,信任链接不上——**不是故障,是半启用态** |
| DS digest 与子 KSK 对不上 | SERVFAIL | 换过 KSK 但父区 DS 没更新;或 DS Digest Type 填错 |
| RRSIG 过期 | SERVFAIL(TTL 未到也失败) | 签名 inception/expiration 窗口过期。R53 managed signing 会自动提前重签,一般是**手工/外部签名 zone** 才踩 |
| DNSKEY 缺失/被裁 | SERVFAIL | 中间盒子(老旧防火墙/解析器)裁掉大 DNSSEC 应答或不支持 EDNS0 大报文 |

> **关键区分(易错)**:
> - **RRSIG 有效期 ≠ TTL**。TTL 管"缓存多久",RRSIG inception/expiration 管"签名在什么时间窗内有效"。**签名过期即使 TTL 没到也 SERVFAIL**。
> - **DS 在父区、DNSKEY 在子区**,方向别反;DS 只是"子 KSK 的摘要指纹",不含完整公钥。
> - DNSSEC **只鉴权+保完整性,不加密**——查询/应答仍是明文。
> 来源:[Configuring DNSSEC signing in R53](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-configuring-dnssec.html)、[RFC 4033/4034/4035 (DNSSEC 协议族)](https://datatracker.ietf.org/doc/html/rfc4035)、[RFC 9077 (NSEC/NSEC3 与负缓存 TTL)](https://www.rfc-editor.org/rfc/rfc9077.txt)、topic 07-dnssec.md。

---

## 六、SME 一页速记（本专题浓缩）

1. **R53 托管 zone = 权威(只答不迭代不缓存);VPC Resolver = 递归**。"改了没生效"先看链路上各缓存层(OS/代理/应用/递归解析器,含 VPC Resolver 本地缓存)旧记录 TTL,不是 R53 侧;R53 侧传播以 **GetChange=INSYNC** 确认。**PHZ 数据只经 VPC Resolver 私有连接可达,直查公开 awsdns 不返回 PHZ**。
2. **anycast + 四 stripe(.com/.net/.org/.co.uk)+ shuffle sharding(任两 zone NS 重叠≤2)+ 每 edge 一般只宣告一个 stripe**——延迟 vs 可用性的取舍;"约 80% 解析器靠 SRTT 收敛到最快 NS"与"50+ edge"均为 **2014 架构博客背景数字,非现行权威值**。
3. **ECS(EDNS0 client subnet,RFC 7871)**:解析器支持时发截断用户 IP 前缀,权威才按真实用户位置做地理/延迟路由;private zone 不用 ECS,改用 zone 所在 Region 的 VPC Resolver 数据。
4. **负缓存 TTL = min(SOA.MINIMUM, SOA.TTL)**(RFC 9077);SOA MINIMUM 是负缓存上限,**不是**默认记录 TTL。"建了记录还 NXDOMAIN"常是负缓存。
5. **health checker 独立全球数据面**;**>18% checker 报健康 → 判健康**(抗局部隔离误报,不可调);failover 总耗时 = 检测(≥10s)+ 跨数据面异步传播(秒级)+ 递归缓存 TTL 过期,三段串联。
6. **DNSSEC 验证链四步**:父区 DS(子 KSK 摘要,Digest Type 2=SHA-256)→ KSK 验 DNSKEY RRset → ZSK → 业务记录 RRSIG;R53 用 **algo 13(ECDSAP256SHA256)**。任一环断=SERVFAIL;RRSIG 过期即使 TTL 未到也失败;DNSSEC 不加密。

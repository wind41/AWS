# Topic 19 — IAM / KMS / RAM / SCP 治理（跨账号权限与责任边界）

> 驱动表定位：治理 / 权限梯队。核心价值 = 把「谁能改 DNS、能改哪些记录、DNSSEC 私钥谁能用、跨账号资源怎么共享、组织级怎么设护栏」讲清楚。SME 高频考点：Route 53 **hosted zone 支持资源级权限**（ARN + 三个 record-set 条件键做细粒度）而 **List/Get 需逐 action 判断资源级支持**：针对单个 zone 的 `GetHostedZone`/`ListResourceRecordSets`/`GetDNSSEC` 支持 `hostedzone` ARN，只有账户级枚举 `ListHostedZones` 类才必须 `Resource:"*"`；DNSSEC KSK 的 **KMS key policy 必须授权 `dnssec-route53.amazonaws.com` 三/四个动作**（DescribeKey/GetPublicKey/Sign + CreateGrant）并可用 SourceAccount/SourceArn 防 confused deputy；跨账号靠 **RAM**（Resolver rule 用 resolver-rule-policy + RAM；Profile 直接 RAM 共享）；防误删靠 **SCP + 顺序约束**（禁用 DNSSEC 要先删父区 DS，删 zone 要先关 DNSSEC + 清记录）。

---

## 1. 概念（Concept）

DNS 治理的「权限四件套」各管一层，别混：

| 机制 | 管什么 | 作用面 |
|---|---|---|
| **IAM**（identity-based / resource condition） | 「谁能调哪个 Route 53 API、能动哪个 zone、能改哪些记录」 | 单账号内主体权限 + 记录级细粒度 |
| **KMS key policy** | 「DNSSEC 的 KSK 私钥能被谁/哪个服务用来签名」 | DNSSEC 签名密钥授权 |
| **RAM**（Resource Access Manager） | 「把 Resolver rule / Profile 跨账号共享出去」 | 跨账号资源分发 |
| **SCP**（Service Control Policy） | 「整个 OU/组织里，任何账号都不许做某类危险动作」 | 组织级护栏（只减不加） |

### 1.1 IAM — Route 53 的资源级权限与细粒度条件键（考点①）

- **hosted zone 是可被 ARN 精确授权的资源**：`ChangeResourceRecordSets`、`AssociateVPCWithHostedZone`、`CreateKeySigningKey`、`ActivateKeySigningKey` 等**写操作的资源类型是 `hostedzone*`（必填）**，可以写成 `arn:aws:route53:::hostedzone/<ZONE_ID>` 精确到某个 zone。
- **不能一刀切说"所有 List/Get 都只能 `Resource:"*"`"——要逐 action 判断**：
  - **针对单个 zone 的读操作支持资源级 ARN**：`GetHostedZone`、`ListResourceRecordSets`、`GetDNSSEC`、`ListTagsForResource`（针对 hostedzone）等作用于某个具体 hosted zone 的 Get/List，**资源类型是 `hostedzone`，可绑 `arn:aws:route53:::hostedzone/<ZONE_ID>` 限定到某个 zone**。
  - **账户级枚举操作才只能 `"Resource": "*"`**：`ListHostedZones`、`ListHostedZonesByName`、`GetHostedZoneCount` 等"列举整个账户"的动作没有单一目标资源，必须 `*`。
  - 这是最常见的踩坑：一条策略里 `ChangeResourceRecordSets` / `GetHostedZone` / `ListResourceRecordSets` 都可以绑到具体 zone ARN，而 `ListHostedZones` 必须单独放开成 `*`，否则整条策略报无效。典型正确写法（EKS ExternalDNS 官方样例）就是把两者拆成两个 Statement。以 Service Authorization Reference 的每个 action 的 "Resource types (*required)" 列为准，不要按"动词是 List/Get 还是 Change"一刀切。
- **记录级细粒度靠三个条件键**（作用在 `ChangeResourceRecordSets` 上）：
  - `route53:ChangeResourceRecordSetsNormalizedRecordNames` —— 限制能动**哪些记录名**（可配 `StringLike` + 通配，如只让改 `*.marketing.example.com`）；
  - `route53:ChangeResourceRecordSetsRecordTypes` —— 限制**记录类型**（如只允许 A/AAAA）；
  - `route53:ChangeResourceRecordSetsActions` —— 限制**动作子集**（`CREATE | UPSERT | DELETE` 里只给部分，例如「可改不可删」）。
  - 三者可任意组合，也可配合 `aws:PrincipalTag`（ABAC）把「哪个团队管哪段命名空间」写成一条策略。用途例：给某账号只授「改 A 记录数据、但不能删任何记录」。
- **partition 边界**：跨账号授权时，hosted zone 与 VPC **必须同一 partition**（aws / aws-cn / aws-us-gov 不能跨）。
- **Profile 侧也有专属条件键**：可限制主体只能对 Profile 关联/解绑/更新「特定资源类型 / 特定资源 ARN / 特定 hosted zone 域名 / 特定 Resolver rule 域名 / 特定优先级区间的 Firewall rule group / 特定 VPC」——即 Profile 的关联操作本身可做细粒度授权。

### 1.2 KMS — DNSSEC KSK 的 key policy 授权（考点②，与 topic 07 联动）

启用 DNSSEC signing 时，Route 53 用一把 **customer managed key（KMS CMK）** 建 KSK。**Route 53 必须被 key policy 授权才能用这把 key 签名**。key policy 里必须包含对服务主体 `dnssec-route53.amazonaws.com` 的授权，动作为：

- `kms:DescribeKey`
- `kms:GetPublicKey`
- `kms:Sign`
- （另一条 Statement）`kms:CreateGrant`，且带条件 `"Bool": {"kms:GrantIsForAWSResource": true}`

> 缺任一动作 / 未授权该服务主体 → 启用或使用时报 `<key ARN> could not be used by Route 53 DNSSEC` / `InvalidKMSArn`。CMK 还必须满足 topic 07 的硬要求：**us-east-1 + asymmetric ECC_NIST_P256 + SIGN_VERIFY**。

**Confused deputy 防护（考点）**：为防止别的 hosted zone 冒用你的 key，可在上述 Statement 里加 `aws:SourceAccount`（hosted zone 属主账号 ID）和/或 `aws:SourceArn`（hosted zone 的 ARN `arn:aws:route53:::hostedzone/<ID>`）条件，把 key 的可用范围锁死到「你自己的、指定的那个 zone」。

标准 key policy 片段：

```json
{
  "Sid": "Allow Route 53 DNSSEC Service",
  "Effect": "Allow",
  "Principal": { "Service": "dnssec-route53.amazonaws.com" },
  "Action": ["kms:DescribeKey", "kms:GetPublicKey", "kms:Sign"],
  "Resource": "*",
  "Condition": {
    "StringEquals": { "aws:SourceAccount": "111122223333" },
    "ArnEquals": { "aws:SourceArn": "arn:aws:route53:::hostedzone/<ZONE_ID>" }
  }
},
{
  "Sid": "Allow Route 53 DNSSEC to CreateGrant",
  "Effect": "Allow",
  "Principal": { "Service": "dnssec-route53.amazonaws.com" },
  "Action": ["kms:CreateGrant"],
  "Resource": "*",
  "Condition": { "Bool": { "kms:GrantIsForAWSResource": true } }
}
```

### 1.3 RAM — 跨账号共享（考点③，与 topic 05 / 10 联动）

跨账号 DNS 共享有三条路径，都落在 RAM 上（或等价的资源策略 + RAM 邀请）：

1. **Resolver rule 跨账号**：先用 `route53resolver put-resolver-rule-policy` 写一条资源策略，指定目标账号可执行的动作（`GetResolverRule / AssociateResolverRule / DisassociateResolverRule / ListResolverRules / ListResolverRuleAssociations`），随后目标账号用 RAM 的 `get-resource-share-invitations` + `accept-resource-share-invitation` 接受，再把 rule 关联到自己的 VPC。**共享后仍需在目标账号把 rule 关联到 VPC 才生效。**
2. **Profile 跨账号**（推荐的规模化方式，见 topic 10）：中心账号建 Profile → **RAM 直接共享**给账号 / OU / 整个 Organization → 成员账号接受后关联到自己 VPC。**免去逐 PHZ 的 `VpcAssociationAuthorization`。**
3. **RAM 权限集不必只读**：共享 Profile / rule 时选择的 managed permission 决定成员账号能做什么，可以是「允许关联/管理」，不是默认只读。别把「RAM 共享 = 只读」当结论。

### 1.4 SCP — 组织级护栏与防误删（考点④）

- **SCP 只做减法**：它设的是「整个 OU/账号里任何主体最多能做什么」的天花板，**不授权、只限制**，即便账号内 IAM 允许，SCP 拒绝就拒绝。
- **防误删的典型 SCP**：`Deny` 掉高危动作，如 `route53:DeleteHostedZone`、`route53:DisableHostedZoneDNSSEC`、`route53:DeleteKeySigningKey`、`route53resolver:DeleteResolverRule`、`route53resolver:DisassociateResolverRule` —— 可配 `aws:PrincipalArn` 例外放行给专门的运维角色，其余全禁。也可用 tag 条件（`aws:ResourceTag`）只保护打了 `critical=true` 的 zone。
- **顺序型防呆本身也是护栏**（AWS 内建，非 SCP）：
  - **删 hosted zone** 必须先 (1) 关 DNSSEC signing、(2) 删除除 SOA/NS 外的所有记录，否则报 `HostedZoneNotEmpty`。删除**不可撤销**。
  - **禁用 DNSSEC** 前必须先删父区 DS（`KeySigningKeyInParentDSRecord` / `Please remove DS records in the parent zone first`，island of trust 例外，见 topic 07）。
  - `DisableHostedZoneDNSSEC` **不会**自动 deactivate KSK —— 关 signing 与停用/删 KSK 是两步。

### 1.5 跨账号责任边界（考点⑤）

谁拥有资源、谁负责改、出问题找谁——SME 排障时先划清边界：

| 场景 | 资源属主 | 谁能改 | 边界要点 |
|---|---|---|---|
| PHZ 跨账号关联 VPC | PHZ 属主账号 | 属主账号（+ 被 IAM 授权的主体） | VPC 属主要先 `CreateVPCAssociationAuthorization` 授权，PHZ 属主才能关联；解除授权≠解除关联 |
| Resolver rule 共享 | 创建账号（central） | 共享出的动作集内，目标账号可关联到自己 VPC | rule 定义改动仍在 central；目标账号只按 resolver-rule-policy 授的动作操作 |
| Profile 共享 | 中心账号 | 中心账号定义、成员账号按 RAM permission 关联 | 改 Profile 内配置 = 爆炸半径覆盖所有关联 VPC，变更评审在中心账号 |
| DNSSEC KSK | zone 属主账号 | 属主 + Route 53 服务（经 key policy） | KMS key 属主账号 ≠ zone 属主账号时，key policy 的 SourceAccount 要对上，否则 confused-deputy 条件拒签 |

---

## 2. 案例说明（典型多账号治理场景）

> 无绑定单一 case；用「中心网络账号 + 多业务账号」的组织级 DNS 治理场景推演，落每个考点。

**背景**：某企业 Organizations 下，网络/安全团队在**中心网络账号**统管 DNS，业务团队在各自成员账号只能在授权范围内改自己那段记录。要求：业务团队能自助改自己子域 A/AAAA 记录但不能删；核心 zone 与 DNSSEC 谁都不能误删；混合 DNS 的 Resolver rule 与内网 PHZ 集中下发。

**落法**：
1. **IAM 细粒度**：给业务账号角色发一条策略——`ChangeResourceRecordSets` 绑到具体 PHZ ARN，配 `ChangeResourceRecordSetsNormalizedRecordNames = *.<team>.corp.internal`、`RecordTypes = A,AAAA`、`Actions = CREATE,UPSERT`（不给 DELETE）；`ListHostedZones` 单独一条 `Resource:"*"`。（考点①）
2. **KMS**：核心公网 zone 启用 DNSSEC，KSK 用中心账号 us-east-1 的 ECC_NIST_P256 CMK，key policy 授权 `dnssec-route53.amazonaws.com` 且用 `aws:SourceArn` 锁到该 zone ARN，防其他 zone 冒用。（考点②）
3. **RAM**：内网 PHZ + onprem 转发 Resolver rule 打进一个 Profile，RAM 共享给整个 Organization，成员账号关联到自己 VPC。（考点③）
4. **SCP**：组织根挂一条 SCP，`Deny route53:DeleteHostedZone / DisableHostedZoneDNSSEC / DeleteKeySigningKey` 与 `route53resolver:DeleteResolverRule`，仅 `aws:PrincipalArn` 为中心网络管理员角色时例外放行。（考点④）
5. **责任边界**：业务账号报「我的记录改不了」→ 先看是 IAM 条件键挡了（记录名/类型/动作不在授权集）还是 SCP 全局禁了；报「删不掉 zone」→ 多半是没关 DNSSEC / 没清记录的顺序防呆，不是权限问题。（考点⑤）

---

## 3. 实验步骤（Hands-on Lab）

> 全部为受控/非破坏性演示，用测试 zone 与测试 CMK。删除类步骤最后单独演示且提示不可逆。

### 3.1 记录级细粒度 IAM 策略（只让改某段 A 记录、不许删）

```bash
cat > rr-policy.json <<'JSON'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "route53:ChangeResourceRecordSets",
      "Resource": "arn:aws:route53:::hostedzone/<ZONE_ID>",
      "Condition": {
        "ForAllValues:StringLike": {
          "route53:ChangeResourceRecordSetsNormalizedRecordNames": ["*.marketing.example.com"]
        },
        "ForAllValues:StringEquals": {
          "route53:ChangeResourceRecordSetsRecordTypes": ["A", "AAAA"],
          "route53:ChangeResourceRecordSetsActions": ["CREATE", "UPSERT"]
        }
      }
    },
    { "Effect": "Allow", "Action": "route53:ListHostedZones", "Resource": "*" }
  ]
}
JSON
aws iam create-policy --policy-name R53-marketing-scoped --policy-document file://rr-policy.json
# 验证：用该角色 UPSERT app.marketing.example.com(A) 应成功；
#        DELETE 或改 www.example.com 或改 TXT 应被 AccessDenied 挡下。
```

### 3.2 DNSSEC KSK 的 KMS key policy（授权 Route 53 + confused-deputy 锁定）

```bash
# 建 CMK 时把 §1.2 的两条 Statement 放进 --policy；此处演示改现有 key 的 policy
aws kms put-key-policy --region us-east-1 --key-id <KEY_ID> --policy-name default \
  --policy file://ksk-key-policy.json
# 校验 Route 53 能用：启用 signing 后 get-dnssec 看到 KmsArn 且状态 SIGNING 即通
aws route53 get-dnssec --hosted-zone-id <ZONE_ID>
```

### 3.3 Resolver rule 跨账号共享（资源策略 + RAM 接受）

```bash
# 源账号(111122223333)授权目标账号(444455556666)可关联该 rule
aws route53resolver put-resolver-rule-policy --region us-east-1 \
  --arn arn:aws:route53resolver:us-east-1:111122223333:resolver-rule/<RULE_ID> \
  --resolver-rule-policy '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"AWS":"444455556666"},"Action":["route53resolver:GetResolverRule","route53resolver:AssociateResolverRule","route53resolver:DisassociateResolverRule","route53resolver:ListResolverRules","route53resolver:ListResolverRuleAssociations"],"Resource":["arn:aws:route53resolver:us-east-1:111122223333:resolver-rule/<RULE_ID>"]}]}'

# 目标账号(444455556666)接受 RAM 邀请，再关联到自己 VPC
aws ram get-resource-share-invitations --region us-east-1
aws ram accept-resource-share-invitation --region us-east-1 --resource-share-invitation-arn <INV_ARN>
aws route53resolver associate-resolver-rule --resolver-rule-id <RULE_ID> --vpc-id <VPC_IN_444455556666>
```

### 3.4 防误删 SCP（挂到 OU / 组织根）

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "DenyDangerousR53Deletes",
    "Effect": "Deny",
    "Action": [
      "route53:DeleteHostedZone",
      "route53:DisableHostedZoneDNSSEC",
      "route53:DeleteKeySigningKey",
      "route53resolver:DeleteResolverRule",
      "route53resolver:DisassociateResolverRule"
    ],
    "Resource": "*",
    "Condition": {
      "ArnNotEquals": { "aws:PrincipalArn": "arn:aws:iam::<CENTRAL_ACCT>:role/DNSAdmin" }
    }
  }]
}
```

**判读**：挂上后，任何非 `DNSAdmin` 主体调这些删除/禁用动作都被 SCP 拒（即使其 IAM 允许）。SCP 只减不加——它不会给 `DNSAdmin` 授权，权限仍要在账号内 IAM 单授。

### 3.5 顺序防呆演示（删 zone / 禁 DNSSEC 的内建约束）

```bash
# 直接删带 DNSSEC 的 zone → 被 signing / 非空记录挡下
aws route53 disable-hosted-zone-dnssec --hosted-zone-id <ZONE_ID>   # 先删父区 DS 才允许，否则报错
# 正确顺序：① 删父区 DS → ② disable-hosted-zone-dnssec → ③ 删除非 SOA/NS 记录 → ④ delete-hosted-zone(不可逆)
```

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **①hosted zone 支持资源级权限，但资源级支持要逐 action 判断**：写类动作（ChangeResourceRecordSets、AssociateVPC、CreateKeySigningKey…）与**针对单个 zone 的读动作**（GetHostedZone、ListResourceRecordSets、GetDNSSEC）资源类型都是 `hostedzone`，可绑具体 zone ARN；只有**账户级枚举**（`ListHostedZones`/`ListHostedZonesByName`/`GetHostedZoneCount`）不接受资源级、必须 `Resource:"*"`，需拆成单独 Statement。**别按"List/Get 一律 `*`"一刀切**——以 Service Authorization Reference 每个 action 的 Resource types 列为准。
  - 常见错误认知：把 `ListHostedZones` 也绑 zone ARN，导致整条策略无效/无权列举。
- **②记录级细粒度靠三个条件键**：`...NormalizedRecordNames`（记录名）、`...RecordTypes`（类型）、`...Actions`（CREATE/UPSERT/DELETE 子集），作用在 `ChangeResourceRecordSets` 上，可组合可配 ABAC。用途：可改不可删、只管某段命名空间。
  - 常见错误认知：以为 Route 53 只能整个 zone 一刀切授权，做不到记录级。
- **③DNSSEC KSK 的 KMS key policy 必授权 `dnssec-route53.amazonaws.com`**：DescribeKey + GetPublicKey + Sign（一条）+ CreateGrant 带 `GrantIsForAWSResource:true`（另一条）；缺任一报 `could not be used by Route 53 DNSSEC` / `InvalidKMSArn`。可加 SourceAccount/SourceArn 防 confused deputy。CMK 仍须 us-east-1 + asymmetric ECC_NIST_P256。
  - 常见错误认知：以为 CMK 规格对了就行，忘了 key policy 里授服务主体那三/四个动作。
- **④跨账号靠 RAM，共享后还要在目标账号关联到 VPC**：Resolver rule 走 put-resolver-rule-policy + RAM 接受；Profile 直接 RAM 共享（免逐 PHZ 授权）。共享本身不生效，必须在目标账号 associate 到 VPC。RAM 权限可读可写，不必只读。
  - 常见错误认知：以为 RAM 共享完 rule/profile 就自动生效；以为 RAM 共享一定是只读。
- **⑤SCP 只减不加**：设组织天花板、Deny 危险动作（DeleteHostedZone/DisableHostedZoneDNSSEC/DeleteKeySigningKey/DeleteResolverRule…），可配 PrincipalArn/ResourceTag 例外；但它不授权，权限还要 IAM 单授。
  - 常见错误认知：以为 SCP Allow 能替代 IAM 授权。
- **⑥删除有内建顺序防呆，多为「顺序/前置」问题而非权限问题**：删 zone 要先关 DNSSEC + 清记录（否则 `HostedZoneNotEmpty`，且删除不可逆）；禁 DNSSEC 要先删父区 DS（island of trust 例外）；`DisableHostedZoneDNSSEC` 不自动停用 KSK。
  - 常见错误认知：把「zone 删不掉」直接当权限不足去查 IAM。
- **⑦跨账号责任边界要先划清**：PHZ 跨账号关联需 VPC 属主 `CreateVPCAssociationAuthorization`；Resolver rule/Profile 定义留在中心账号，成员账号只在授权动作集内操作；KMS key 属主 ≠ zone 属主时 SourceAccount 要对上。排障先问「资源属谁、谁有权改」。
  - 常见错误认知：在成员账号里查为什么改不了 Profile 内配置——那本就该在中心账号改。
- **⑧partition 边界**：跨账号授权 hosted zone/VPC 必须同一 partition（aws / aws-cn / aws-us-gov 不能跨）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

四层治理机制各管一层、共同构成「谁能对 DNS 做什么」的决策链：

```mermaid
flowchart TD
    subgraph ORG["组织级护栏 (只减不加)"]
      SCP["SCP: Deny 危险动作<br/>DeleteHostedZone /<br/>DisableHostedZoneDNSSEC /<br/>DeleteKeySigningKey /<br/>DeleteResolverRule<br/>(PrincipalArn/Tag 例外)"]
    end

    subgraph ACCT["账号内主体权限"]
      IAM["IAM identity policy"]
      IAM --> W["写类: hostedzone* ARN 可绑具体 zone<br/>+ 3 条件键<br/>NormalizedRecordNames /<br/>RecordTypes / Actions"]
      IAM --> L["账户级枚举 (ListHostedZones 等):<br/>只能 Resource:*<br/>(单 zone 的 Get/List 仍可绑 ARN)"]
    end

    subgraph DNSSEC["DNSSEC 签名密钥"]
      KMS["KMS CMK key policy<br/>授权 dnssec-route53.amazonaws.com<br/>DescribeKey/GetPublicKey/Sign<br/>+ CreateGrant(GrantIsForAWSResource)<br/>+ SourceAccount/SourceArn 防冒用<br/>(us-east-1 · ECC_NIST_P256)"]
    end

    subgraph XACCT["跨账号共享 (RAM)"]
      RR["Resolver rule:<br/>put-resolver-rule-policy → RAM 接受"]
      PR["Profile: RAM 直接共享<br/>(免逐 PHZ 授权)"]
      NOTE["共享后仍须在目标账号<br/>关联到 VPC 才生效"]
      RR --> NOTE
      PR --> NOTE
    end

    CALL(["主体调用 Route 53 API"]) --> SCP
    SCP -->|"SCP 未拒"| IAM
    SCP -->|"SCP 拒"| DENY["拒绝 (即使 IAM 允许)"]
    IAM -->|"IAM 允许 + 条件键命中"| OK["执行"]
    IAM -->|"条件键不命中/无权"| DENY2["AccessDenied"]
    W -.DNSSEC 启用需要.-> KMS
    OK -.跨账号资源.-> XACCT

    subgraph SEQ["删除顺序防呆 (内建, 非 SCP)"]
      S1["删 zone: 先关 DNSSEC → 清非 SOA/NS 记录 → delete (不可逆)"]
      S2["禁 DNSSEC: 先删父区 DS (island of trust 例外)"]
    end
    OK -.删除类.-> SEQ

    classDef warn fill:#fde,stroke:#b36;
    class SCP,KMS,NOTE,SEQ warn;
```

> 图注：调用先过 **SCP 天花板**（拒则终止，即使 IAM 允许），再过 **IAM**（写类可绑具体 zone ARN + 记录级条件键，List/Get 只能 `*`）；DNSSEC 另有 **KMS key policy** 授权服务主体签名；跨账号资源经 **RAM** 分发但**共享 ≠ 生效，须目标账号再关联 VPC**；删除/禁用受**内建顺序防呆**约束，多数「删不掉」是顺序/前置问题而非权限。

---

## 来源（Sources）

- Using identity-based policies (IAM policies) for Amazon Route 53 —— DNSSEC KMS key policy 授权 `dnssec-route53.amazonaws.com`（DescribeKey/GetPublicKey/Sign + CreateGrant）与 confused-deputy 的 SourceAccount/SourceArn：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/access-control-managing-permissions.html>
- Actions, resources, and condition keys for Amazon Route 53（Service Authorization Reference）—— hostedzone* 资源类型与 ChangeResourceRecordSets 三条件键：<https://docs.aws.amazon.com/service-authorization/latest/reference/list_route53.html>
- Resource record set permissions：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resource-record-sets-permissions.html>
- Using IAM policy conditions for fine-grained access control（含 Profile 专属细粒度条件）：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/specifying-conditions-route53.html>
- Amazon Route 53 API permissions reference（partition 边界）：<https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/r53-api-permissions-ref.html>
- Update customer managed CMK permissions（KSK key policy 需 DescribeKey/GetPublicKey/Sign）：<https://docs.aws.amazon.com/help-panel/Route53/latest/console/dnssec-signing-cmk-review.html>
- How do I configure and manage cross-account access for Amazon Route 53 resources?（PHZ / Resolver rule / Profile 跨账号）：<https://repost.aws/knowledge-center/route-53-cross-account-resources>
- Route 53 Resolver examples using AWS CLI —— put-resolver-rule-policy + RAM 接受邀请：<https://docs.aws.amazon.com/code-library/latest/ug/cli_2_route53resolver_code_examples.html>
- Using Amazon Route 53 Profiles for scalable multi-account AWS environments（RAM 共享 Profile 权限集）：<https://aws.amazon.com/blogs/networking-and-content-delivery/using-amazon-route-53-profiles-for-scalable-multi-account-aws-environments/>
- Amazon Route 53 FAQs —— Resolver 与 RAM 集成、共享后须关联 VPC：<https://aws.amazon.com/route53/faqs/>
- Implementing fine-grained Amazon Route 53 access using IAM condition keys (Part 1/2/3)：<https://aws.amazon.com/blogs/networking-and-content-delivery/implementing-fine-grained-amazon-route-53-access-using-aws-iam-condition-keys-part-1/>
- How do I set up ExternalDNS with Amazon EKS?（List 用 `*`、Change 用 hostedzone ARN 的拆分样例）：<https://repost.aws/knowledge-center/eks-set-up-externaldns>
- How do I delete a Route 53 hosted zone?（删 zone 顺序防呆）：<https://repost.aws/knowledge-center/route53-hosted-zone>
- DisableHostedZoneDNSSEC API（不自动 deactivate KSK、KeySigningKeyInParentDSRecord/InvalidKMSArn 错误）：<https://docs.aws.amazon.com/aws-sdk-php/v3/api/api-route53-2013-04-01.html>

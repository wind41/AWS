# 02. 记录类型与 Alias

## 1. 概念（Concept）

### 1.1 支持的记录类型

Route 53 支持标准 DNS 记录类型，外加自有扩展 **Alias**（不是标准记录类型，是 R53 对 DNS 的专有扩展）。

标准类型：**A / AAAA / CAA / CNAME / DS / HTTPS / MX / NAPTR / NS / PTR / SOA / SPF / SRV / SSHFP / SVCB / TLSA / TXT**（外部 §3，`ResourceRecordTypes.html`）。内部研究常提到的子集：A / AAAA / CNAME / MX / TXT / PTR / SRV / SPF(不推荐) / NAPTR / CAA / NS / SOA。

> **新增记录类型（2024-10-30）**：Route 53 于 2024 年 10 月 30 日发布，新增支持 **SVCB / HTTPS / TLSA / SSHFP** 四种记录类型（AWS Networking & Content Delivery 博客 *"Improving security and performance with additional DNS resource record types in Amazon Route 53"*）。其中 **HTTPS/SVCB（RFC 9460）** 因涉及 apex 别名、HTTP/3 加速、ECH 等 SME 高频考点，单列 **§1.4 深度专节**；TLSA（DANE，RFC 6698）与 SSHFP（RFC 4255）为 DNSSEC 依赖型安全记录，见 §1.4 末尾对比。

各类型 SME 要点：
- **A** = IPv4 地址；**AAAA** = IPv6 地址。
- **CNAME** = 别名到另一个 DNS 名。**关键 DNS 规则：CNAME 不能与任何同名的其他类型记录共存** → 因此 **zone apex（裸域）不能建 CNAME**（apex 至少已有 NS + SOA）。
- **MX** = 邮件路由（含优先级）；**TXT** = 任意文本，用于 SPF/DKIM/DMARC/域名所有权验证；**SRV** = 服务定位（端口/权重/优先级）。
- **CAA** = 限制哪些 CA 可为域名签发证书；同样不能与同名 CNAME 共存。
- **NS / SOA** = 每个 hosted zone 在 apex 自动创建，是委派与权威信息的基础。
- **DS**（Delegation Signer）= DNSSEC 信任链，父 zone 持有子 zone 的 DS 记录。
- 域名尾点可选：`www.example.com` 与 `www.example.com.` 等价。

### 1.2 TTL 与 RRSET 轮换

- **TTL**：系统不为记录设默认 TTL，需自行设定（建议 60–172800 秒）。SOA 也可缩短 TTL，无副作用（内部 §2 QA-322）。
- **Simple RRSET 返回全部值并随机排序**：一个命名空间下 simple 记录只能有一条 RRSET；RRSET 内可含多个值，R53 name server 返回该 RRset 的**全部值并随机排序**（不是"每次最多 8 个"——8 值上限属于 **Multivalue answer** 路由策略）。单条 RRset 的值受配额约束（**每个 RRset 最多 400 个值/资源记录**）。这是 simple routing 的粗粒度"负载分散"，不是真正的负载均衡。

### 1.3 Alias vs CNAME（SME 高频七维对比）

Alias 记录把查询直接路由到选定 AWS 资源或**同 zone 内另一条记录**，R53 在权威侧直接返回目标 IP，隐藏背后的 ELB/CloudFront（外部 §4，`resource-record-sets-choosing-alias-non-alias.html`；内部 §2）。

| 维度 | Alias | CNAME |
|---|---|---|
| **可指向目标** | 选定 AWS 资源（CloudFront、S3 静态站点、ELB/ALB/NLB/CLB、API Gateway、VPC 接口端点、VPC Lattice、Global Accelerator、App Runner、Elastic Beanstalk、OpenSearch、AppSync 等）或**同 zone 内另一条记录（可为另一条 Alias——Alias 链受支持）** | 任意 DNS 名（含非 R53 托管的外部域名） |
| **Zone apex（裸域 example.com）** | **可以** | **不可以**（DNS RFC 禁止 CNAME 与 NS/SOA 共存） |
| **TTL** | 指向 AWS 资源时**不能设 TTL**（用资源默认 TTL）；指向同 zone 记录时用目标记录的 TTL | 可自设 TTL |
| **收费** | 指向 **AWS 资源的查询免费** | 正常按查询计费 |
| **性能（额外 lookup）** | R53 直接回 IP，**少一次 DNS 往返** | resolver 需**额外一次 DNS lookup** 去解析别名目标 |
| **目标健康感知** | 可设 **Evaluate Target Health（ETH）**——自动跟随资源 IP 变化并感知健康 | **无** ETH |
| **记录类型约束** | 同 zone 内目标通常要求 alias 与目标记录**同类型**；记录**类型取决于目标资源**（如 CloudFront 启用 IPv6 才加 AAAA，API Gateway/接口端点通常用 A），不能一概用 A/AAAA；zone apex 因不能建 CNAME，故 apex 处的 Alias **不能最终指向 CNAME 型**目标 | — |

补充边界：
- **Alias 链约束**：Alias 的 target **可以是同 zone 内另一条 Alias（Alias 链受支持）**；同 zone 内目标通常要求同类型，且 **zone apex 处的链不能最终指向 CNAME**。CNAME 的 target 也可以是 Alias/CNAME（内部 §2 QA-317）。整条 Alias 链若末端是合格 AWS 资源，查询仍免费。
- **付费归属**：Alias 指向 AWS 资源的常见查询免费；Alias 指向的**目标记录**查询由"被指向资源的所有者"付费；Alias 指向本 zone 内其他记录仍由本 zone 所有者付费（内部 §2）。
- **apex 指向 ELB/NLB**：apex 必须用 **A-Alias**（不能 CNAME）；子域两者皆可，但 Alias 免费且能配 ETH（内部 §2 QA-305）。

### 1.4 HTTPS / SVCB 记录深度（RFC 9460）★ SME 高频

SVCB（Service Binding，RR type **64**）与 HTTPS（RR type **65**）是 **RFC 9460**（2023-11，Standards Track）定义的一对记录。核心目的：在**建连之前**，把"该连哪个端点、走什么协议、用什么参数（含 TLS ClientHello 加密密钥）"通过一次 DNS 应答一并告诉客户端，减少往返、提升安全与隐私。HTTPS 是 SVCB 针对 `https`/`http` scheme 的**变体**（编码/格式/语义完全相同，只是省去 Attrleaf 下划线前缀）。

Route 53 于 **2024-10-30** 起支持 SVCB/HTTPS/TLSA/SSHFP。

#### 1.4.1 记录结构与两种模式

呈现格式（三字段，空格分隔）：`Name TTL IN HTTPS <SvcPriority> <TargetName> <SvcParams>`
- SVCB 的 owner name 需带 **端口 + 协议** 下划线前缀（Attrleaf，如 `_8443._foo.api.example.com`）；HTTPS **不带**前缀（`https`+443 时 owner name 就是服务名本身），这是两者主要区别。

**模式由 SvcPriority（优先级）字段决定**：
- **AliasMode（priority = 0）**：把一个名字别名到 `TargetName`，语义类似 CNAME，但**只作用于该 RR 类型的查询**（不像 CNAME 劫持整个名字的所有类型），因此**可用于 zone apex**——这是它相对 CNAME 的关键价值（apex 别名，CNAME 做不到）。AliasMode 里的 SvcParams 被**忽略**。
- **ServiceMode（priority ≥ 1，任意非 0 值）**：`TargetName` 是一个候选端点，后附一组 `key=value` 的 **SvcParam** 描述如何连它。可有多条 ServiceMode RR，**优先级越小越优先**；**同优先级的多条要随机洗牌**（均衡负载，注意 SVCB 只支持"均衡"随机，不像 SRV 有 weight 加权）。

优先级取值范围：**RFC 定义 0–65535；Route 53 只支持 0–32767**（SME 易错数字点）。

一个 apex AliasMode + 两条子域 ServiceMode 的典型例（来自 R53 博客）：
```
example.com.        300 IN HTTPS 0 www.example.com.
www.example.com.    300 IN HTTPS 1 host1.example.com. alpn="h3,h2" ipv4hint="192.0.2.34,198.51.100.103" ipv6hint="2001:db8:8f9::c8e1"
www.example.com.    300 IN HTTPS 2 host2.example.com. alpn="h2,http/1.1" ech="123abc456efh789ijk012mno"
```
判读：apex 用 priority 0 别名到 `www`；`host1`（priority 1，更优先）支持 HTTP/3+HTTP/2 并带 IP hint；`host2`（priority 2，次选）支持 HTTP/2+HTTP/1.1 并带 ECH 公钥。

> **AliasMode vs Route 53 Alias 的关键差异**：R53 自有 Alias 只能指向**受支持的 AWS 资源或同 zone 记录**；而 SVCB/HTTPS 的 **AliasMode 可别名到任意 DNS 名**（含外部）。二者都能用于 apex，但能指向的目标范围不同——别混为一谈。

#### 1.4.2 SvcParam（服务参数）逐个说清

RFC 9460 初始注册的 SvcParamKey（IANA "SvcParamKeys" 注册表，SVCB 系列共享）：

| Key（编号） | 含义 | 要点 |
|---|---|---|
| **mandatory**（0） | 声明本 RR 中哪些 key 是"必须理解"的 | 客户端不认其中任一 key 就**整条忽略**；自身永远"自动 mandatory"且不能列自己 |
| **alpn**（1） | 端点支持的 ALPN 协议列表（如 `h3,h2,http/1.1`） | 逗号分隔；客户端据此选传输（QUIC/TLS-over-TCP） |
| **no-default-alpn**（2） | 声明不含 scheme 默认 ALPN | 出现时**必须同时给 alpn** 才自洽 |
| **port**（3） | 非默认 TCP/UDP 端口 | 单个 0–65535 整数 |
| **ipv4hint**（4） | IPv4 地址提示 | 逗号分隔；仅在拿不到 TargetName 的 A/AAAA 时用，拿到就忽略 hint |
| **ech**（5） | Encrypted ClientHello 配置（base64） | **注意：RFC 9460 里 key 5 状态为 RESERVED（held for ECH）**，其正式格式随 ECH 草案（draft-ietf-tls-esni）演进；R53 已可配置该参数 |
| **ipv6hint**（6） | IPv6 地址提示 | 同 ipv4hint；给 v4hint 时 SHOULD 一并给 v6hint |
| **dohpath** | DoH 模板路径 | **来自 RFC 9461（DNS-over-HTTPS 的 SVCB 映射），不属 RFC 9460 初始集**——SME 别把它算进 9460 |
| **keyNNNNN** | 未知/私有参数的通用表示 | `key` 后接十进制编号（无前导零）；65280–65534 为 Private Use，65535 为 Invalid |

- **HTTPS scheme 的默认 ALPN 集 = `["http/1.1"]`；自动 mandatory 的 key = `port` 和 `no-default-alpn`。**
- **Route 53 不支持 `keyNNNNN` 通用未知参数格式**（只支持已命名的标准参数）——这是 R53 相对 RFC 的一个实现限制，SME 高频考点。

#### 1.4.3 主要用例：HTTP/3 加速 与 ECH

- **HTTP/3（QUIC）加速**：没有 HTTPS 记录时，客户端要先建 TCP+TLS、发 HTTP 请求、服务器用 `Alt-Svc` 头告知"我支持 QUIC"、客户端再另起 QUIC 连接（多次往返）。有了 HTTPS 记录（`alpn` 含 `h3`），客户端在 DNS 阶段就知道端点支持 HTTP/3，可直接发起 QUIC，**省掉多次往返**。这是 HTTPS 记录的头号价值。
- **ECH（Encrypted ClientHello）**：ESNI 的继任者，加密整个 ClientHello（不只是 SNI）。主流浏览器依赖 **HTTPS 记录**里的 `ech` 参数拿到服务器公钥来加密 ClientHello。因此 ECH ↔ HTTPS 记录强绑定。
- **HSTS 式升级**：HTTPS 记录的存在本身就是"请用 https 而非 http 连我"的信号（类似 HSTS 的 307 重定向语义）；但因 DNS 是不可信信道，客户端信任度不超过一个明文 HTTP 307。

#### 1.4.4 zone 类型支持差异 与 TLSA/SSHFP 对比（★ 高频考点）

- **HTTPS / SVCB**：**public HZ 和 private HZ（PHZ）都支持**。
- **TLSA / SSHFP**：**仅 public HZ 支持**，且依赖 **DNSSEC**——
  - **TLSA**（DANE，RFC 6698）：把 TLS 证书/公钥指纹放进 DNS，让客户端校验服务器证书是否为域名所有者预期。owner name 需带端口+协议前缀（`_25._tcp.mail.example.com`），值 = `usage selector matching-type cert-data` 四字段。头号用例 **SMTP over TLS（防降级攻击）**。必须 DNSSEC 签名才有信任链意义。
  - **SSHFP**（RFC 4255）：把 SSH 主机密钥指纹放进 DNS，防 SSH 首次连接盲信指纹（中间人）。值 = `key-algorithm hash-type fingerprint`。**必须 DNSSEC 签名**，且**校验要在客户端做**（客户端设 DO 位、解析器能做 DNSSEC 验证）。

一句话记忆：**HTTPS/SVCB → public+PHZ 皆可、DNSSEC 可选；TLSA/SSHFP → 仅 public、DNSSEC 必需。**


---

## 2. 真实案例说明（Real Case）

### Case 178602594200640（SP Global，★ apex A-Alias 指向 NLB）

**一句话**：客户把公网 apex 子域配成 **A (Alias) 指向 Kong NLB**，配置 100% 正确，但 VPC 内解析却返回旧 Apigee ELB —— 根因不在记录/Alias 本身，而在 VPC 解析优先级（Forward Rule 优先于公网）。

- **症状**：`soaapi-av.spgidev.spglobal.com` 在 Public HZ 配置为 `A (Alias) → kong-nlb-dev-av-migen-eks-soa-...elb.us-east-1.amazonaws.com`（HostedZoneID `Z26RNL4JYFTOTI` = NLB us-east-1），但客户 dig 得到旧 `internal-apigee-elb-9001`（10.95.145.77 / 10.95.146.46）。
- **本 topic 的落点**：这正是 Alias 指向 NLB 的**规范用法**——用 A-Alias 而非 CNAME 指向 NLB DNS 名，R53 直接返回 NLB 的 IP。案例里 `Evaluate Target Health: false`，说明客户没有开 ETH（本可开）。
- **根因（属 topic 05 Resolver）**：VPC 内有 `spglobal.com` Forward Rule 和 dot(.) 全局 Forward Rule，把查询转发到企业 Infoblox DNS，**Forward Rule 优先级高于 PHZ 高于公网**，所以公网 HZ 里那条正确的 Alias 记录根本没被查到。
- **教学价值**：即使记录/Alias 配得完全正确，"解析结果不对"也可能是解析路径被上游拦截。SME 要能区分"记录配置层"与"解析优先级层"两类根因——Alias→NLB 是本 topic 的正面范例，而它"看起来失效"的真实原因归入 topic 05。

---

## 3. 实验步骤（Hands-on Lab）

**主题**：建 apex A-Alias 指向 ELB 并开 Evaluate Target Health，对比同目标 CNAME 的 dig 往返差异。

前置：一个测试 public hosted zone（如 `lab.example.com`）+ 一个 ALB/NLB（拿到其 DNS 名与 canonical HostedZoneId）。

### 步骤 1：在 apex 建 A-Alias 指向 ELB（开 ETH）
```bash
# change-batch.json
{
  "Changes": [{
    "Action": "UPSERT",
    "ResourceRecordSet": {
      "Name": "lab.example.com.",
      "Type": "A",
      "AliasTarget": {
        "HostedZoneId": "<ELB-canonical-hosted-zone-id>",
        "DNSName": "<my-alb>.us-east-1.elb.amazonaws.com.",
        "EvaluateTargetHealth": true
      }
    }
  }]
}

aws route53 change-resource-record-sets \
  --hosted-zone-id <ZONEID> \
  --change-batch file://change-batch.json
```
预期：apex 成功建 A-Alias（若尝试在 apex 建 CNAME 会被 API 拒绝——验证"apex 不能 CNAME"）。

### 步骤 2：对比 dig 往返
```bash
# Alias（apex）：权威直接回 A 记录，无中间 CNAME
dig +noall +answer lab.example.com A
# 预期：lab.example.com.  <ttl>  A  <ELB-ip>   ← 直接是 IP，无 CNAME 链

# CNAME（子域）：先返回别名，再解析目标 → 多一跳
dig +noall +answer www.lab.example.com CNAME
# 预期：www.lab.example.com.  <ttl>  CNAME  <my-alb>...elb.amazonaws.com.
#      解析器需再查该目标的 A 记录，比 Alias 多一次往返
```
判读：Alias 应答里**看不到 ELB DNS 名**（只有最终 IP）；CNAME 应答**暴露 ELB DNS 名**且需额外 lookup。

### 步骤 3：验证 Alias 不接受 TTL / ETH 生效
- 在控制台或 API 尝试给指向 AWS 资源的 Alias 设 TTL → 不允许（用资源默认）。
- 把 ELB 目标健康检查打到不健康，开了 ETH 的 Alias 会随目标健康状态收敛（概念验证）。

### 清理
```bash
aws route53 change-resource-record-sets --hosted-zone-id <ZONEID> \
  --change-batch '{"Changes":[{"Action":"DELETE","ResourceRecordSet":{...}}]}'
```
（把 UPSERT 记录改为 DELETE，值需与现有记录完全一致。）

> 全程为只读/可控实验；不涉及需 2PR 的破坏性操作。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

对应外部速记 **A. Alias vs CNAME（A1–A5）** + 本 topic 边界数字。

- **A1 — CNAME 不能位于 zone apex（裸域）；Alias 可以建在 apex。**
  - 准确说法：**apex 上不能建 CNAME**（DNS RFC 禁止 CNAME 与 apex 已有的 NS/SOA 共存），但 apex 可以有普通 **A/AAAA/MX/TXT** 等记录，也可以用 **Alias**。
  - 结论：apex 指向 ELB/CloudFront/S3/API GW 时用 **A/AAAA-Alias**（具体 A 还是 AAAA 取决于目标是否支持 IPv6）。
  - 常见错误：以为"给 apex 建个 CNAME 指向 ALB"就行——API 会拒绝，因为 apex 已有 NS/SOA，CNAME 不能与其共存。

- **A2 — Alias 指向 AWS 资源不能设 TTL（用资源默认）；指向同 zone 记录用目标记录的 TTL。**
  - 常见错误：以为可以给 Alias 单独调 TTL 来控制缓存时长。

- **A3 — Alias 指向 AWS 资源的查询免费；CNAME 正常计费且多一次 DNS 往返。**
  - 结论：成本 + 性能双优，能用 Alias 就别用 CNAME 指 AWS 资源。
  - 常见错误：忽略 CNAME 的**额外 lookup**（多一跳）与计费。

- **A4 — Alias 目标限选定 AWS 资源或同 zone 记录（可含另一条 Alias）；CNAME 可指任意 DNS 名（含外部）。**
  - 结论：要指向**外部/非 R53 托管**域名，只能用 CNAME；Alias 做不到。记录类型取决于目标资源（如 CloudFront 启 IPv6 才加 AAAA），不要一概认为都是 A/AAAA。
  - 常见错误：想用 Alias 指向第三方域名。

- **A5 — Alias 有 Evaluate Target Health；CNAME 无。**
  - 结论：Alias→可建 alias 的 AWS 资源做 failover 时，用 **ETH=Yes**，**不要再单独建健康检查**（外部 §4 / A14 易错点）。
  - 常见错误：既开 ETH 又另建独立 HC，或对 CNAME 期望有健康感知。

**Alias 链 / apex 类型约束（补）**：
- Alias 的 target **可以是同 zone 内另一条 Alias（Alias 链受支持）**；zone apex 处的链**不能最终指向 CNAME**（apex 用 A/AAAA-Alias）。

**HTTPS / SVCB / TLSA / SSHFP 考点（RFC 9460 深度，2024-10 R53 新增）**：
- **H1 — priority 0 = AliasMode，非 0 = ServiceMode。** AliasMode 可用于 apex（只作用于该 RR 类型，不像 CNAME 劫持整名），SvcParams 被忽略；ServiceMode 才带 SvcParam。常见错误：以为 priority 只是排序，忽略"0 切换成别名模式"这一语义。
- **H2 — R53 优先级只支持 0–32767，RFC 是 0–65535。** 数字点必背。
- **H3 — R53 不支持 `keyNNNNN` 通用未知参数格式**，只支持已命名标准参数（mandatory/alpn/no-default-alpn/port/ipv4hint/ipv6hint/ech）。
- **H4 — SVCB/HTTPS AliasMode 可别名到任意 DNS 名（含外部）**，比 R53 自有 Alias（只能指 AWS 资源/同 zone）范围更大；两者都能用于 apex，别混淆。
- **H5 — 头号用例是 HTTP/3 加速（alpn=h3，省往返）与 ECH（ech 参数携带公钥）。** HTTPS 记录存在即"请走 https"（HSTS 式信号）。
- **H6 — zone 类型：HTTPS/SVCB 支持 public + PHZ；TLSA/SSHFP 仅 public，且必须 DNSSEC 签名。** SSHFP 校验须在客户端做。常见错误：想在 PHZ 里配 TLSA/SSHFP，或忘了 TLSA/SSHFP 的 DNSSEC 依赖。
- **H7 — SVCB owner name 带端口+协议下划线前缀；HTTPS 不带（https+443 时就是服务名）。** TLSA owner name 也带 `_port._proto` 前缀。

**记录类型速记（补）**：- **CNAME 不能与同名其他类型共存** → CNAME 不能位于 apex；apex 可用 Alias，也可有普通 A/AAAA/MX/TXT 等记录。
- **RRSET 返回全部值并随机排序**（simple routing）；这是分散不是负载均衡（"最多 8 个值"是 Multivalue answer 的特性，非 Simple；单 RRset 配额 400 个值）。
- **TTL 无默认值，需自设**（60–172800 秒建议区间）；SOA 缩短 TTL 无副作用。
- **免费边界**：仅"Alias 指向 **AWS 资源**"的查询免费；Alias 指向同 zone 普通记录、CNAME、非 AWS 目标均正常计费。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

"该用 Alias 还是 CNAME"决策树 + 记录类型约束：

```mermaid
flowchart TD
    START([要建一条指向某目标的记录]) --> APEX{建在 zone apex<br/>裸域 example.com？}

    APEX -->|是| MUSTALIAS[必须用 A/AAAA-Alias<br/>CNAME 被 DNS RFC 禁止<br/>apex 已有 NS+SOA]
    APEX -->|否 子域| TARGET{目标是什么？}

    TARGET -->|AWS 资源<br/>ELB/CloudFront/S3/API GW/GA/VPCe| PREFERALIAS[优先 Alias]
    TARGET -->|外部/非 R53 托管域名| MUSTCNAME[只能 CNAME<br/>Alias 指不了外部]
    TARGET -->|同 zone 内另一条记录<br/>可为另一条 Alias| ALIASOK[可用 Alias<br/>通常同类型·支持 Alias 链]

    MUSTALIAS --> ETH{做 failover/<br/>要健康感知？}
    PREFERALIAS --> ETH
    ALIASOK --> ETH
    ETH -->|是| SETETH[Alias 开 Evaluate Target Health=Yes<br/>不要再单独建 HC]
    ETH -->|否| DONEA[Alias：免费·无 TTL·少一跳]

    MUSTCNAME --> DONEC[CNAME：可设 TTL·计费·多一次 lookup·无 ETH]

    SETETH --> DONEA
```

```mermaid
mindmap
  root((记录类型))
    标准类型
      A IPv4
      AAAA IPv6
      CNAME 别名·不能与同名共存·apex禁用
      MX 邮件
      TXT SPF/DKIM/DMARC/验证
      SRV 服务定位
      CAA 限制签发CA
      NS SOA apex自动
      DS DNSSEC信任链
    新增RFC9460类(2024-10)
      HTTPS RR65 / SVCB RR64
        priority0=AliasMode(可apex·忽略SvcParam)
        priority非0=ServiceMode(带SvcParam)
        R53优先级0-32767(RFC 0-65535)
        SvcParam alpn/port/ipv4hint/ipv6hint/ech/no-default-alpn/mandatory
        ech=key5 RESERVED·dohpath属RFC9461
        R53不支持keyNNNNN
        AliasMode可指任意名(比R53 Alias宽)
        用例 HTTP3加速·ECH·HSTS式升级
        支持public+PHZ
      TLSA DANE(RFC6698)
        证书指纹·防SMTP降级
        仅public·必须DNSSEC
      SSHFP(RFC4255)
        SSH指纹·防中间人
        仅public·DNSSEC·客户端校验
    Alias 专有扩展
      指AWS资源或同zone记录(可为另一Alias)
      apex可建 类型随目标(A/AAAA)
      免费·不能设TTL·少一跳
      有ETH
      可链到另一Alias·apex链不能终指CNAME
    RRSET
      simple每命名空间一条
      返回全部值随机排序
      8值上限属MVA非Simple
    TTL
      无默认需自设
      建议60-172800s
      SOA可缩短无副作用
```

---

## 来源锚点

- **外部**：`ResourceRecordTypes.html`（记录类型）、`resource-record-sets-choosing-alias-non-alias.html`（Alias vs CNAME）；r53-external-research.md §3、§4、速记 A1–A5。
- **HTTPS/SVCB 深度（§1.4）**：**RFC 9460**（SVCB/HTTPS，2023-11，SvcPriority/AliasMode/ServiceMode/SvcParamKeys/IANA 注册表 mandatory=0·alpn=1·no-default-alpn=2·port=3·ipv4hint=4·ech=5 RESERVED·ipv6hint=6·keyNNNNN·HTTP mapping 默认 alpn=http/1.1、自动 mandatory=port+no-default-alpn）；**RFC 9461**（`dohpath` 等 DoH 的 SVCB 映射，非 9460 初始集）；**RFC 6698**（DANE/TLSA）、**RFC 4255**（SSHFP）；AWS 博客 *Improving security and performance with additional DNS resource record types in Amazon Route 53*（2024-10-30，R53 支持 SVCB/HTTPS/TLSA/SSHFP、优先级 0–32767、apex AliasMode 例、ECH/HTTP3 用例、DNSSEC 依赖）；`ResourceRecordTypes.html#SVCBFormat` / `#TLSAFormat` / `#SSHFPFormat`。
- **内部**：r53-internal-research.md §2（记录类型与 ALIAS、TTL、Simple RRSET 返回全部值随机排序、Alias 链 QA-317、apex A-Alias 指 NLB QA-305）；R53PublicDNS / TAM Field Guides。
- **绑定 case**：178602594200640（apex A-Alias 指向 Kong NLB 的规范配置；解析"看似失效"的真实根因归 topic 05）。

# 22. DNS 迁移与批量变更剧本（DNS Migration · Bulk Change Playbook）

> 驱动表定位：**运维执行域**——把"如何把一个正在用的域从别家 DNS/注册商迁到 Route 53、如何安全地一次性改动大量记录"落成可复现剧本。三条主线：**① 迁入编排（复制配置 → zone file 导入 vs 手工建 → 记录核对）**、**② 批量变更打包（ChangeResourceRecordSets 的原子性 / UPSERT / 硬上限 / 限流分批）**、**③ NS 切换四阶段（降 TTL → 并行验证 → 改注册商 NS → 监控传播）与 dry-run/回滚**。SME 高频易错点：把"导入 zone file"当成"完成迁移"（其实只复制了记录，NS 还没切）；以为一个 change batch 里失败一条只回滚那一条（实为**整批原子失败**）；把 1000 条 zone-file 导入上限、1000 个 ResourceRecord/batch、32000 字符/bat 混为一谈；改了 hosted zone 却忘了去注册商同步 NS；用 `PENDING`（而非 `INSYNC`）就宣布切换完成。

---

## 1. 概念（Concept）

### 1.1 迁移的本质：注册（registrar）与解析（DNS hosting）是两件独立的事（地基）

一次"迁到 Route 53"最多包含**两条互相独立的迁移线**，SME 必须先分清客户要迁哪条（常常两条都要，但顺序和风险点完全不同）：

| 迁移线 | 迁的是什么 | 在哪操作 | 切换动作 | 风险 |
|---|---|---|---|---|
| **DNS 托管迁入** | 记录如何解析（A/AAAA/CNAME/MX/TXT…） | Route 53 hosted zone | 在**注册商**处把 NS 委派改成 Route 53 的 4 个 NS | 记录漏迁 / NS 切换期解析中断 |
| **域名注册转入** | 域名注册权（transfer） | Route 53 Domains（注册商侧） | EPP auth code + 解锁 + 转移确认（见 topic 09） | 转移锁 / 到期 / 邮箱不可达 |

> **核心边界**：**可以只迁 DNS 托管而不转注册**（域名还留在原注册商，只把 NS 指向 Route 53），也可以只转注册而 DNS 仍托管别处。本 topic 主讲 **DNS 托管迁入 + NS 切换**；注册转入的生命周期/TLD 差异见 topic 09。**"导入 zone file 成功"绝不等于"迁移完成"——它只完成了"复制记录"，NS 尚未切，公网流量仍走旧 DNS。**

### 1.2 迁入编排：三条路径按配置复杂度选（官方推荐流程）

官方 [Making Route 53 the DNS service for a domain that's in use](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/migrate-dns-domain-in-use.html) 把迁入拆成"先复制配置、再切 NS"两大段。复制配置有三条路径：

1. **配置简单（几条记录）**：直接在 Route 53 控制台手工建几条记录即可。
2. **配置复杂、只想原样复刻**：向原 DNS 商索取 **zone file / records list**（并非所有 DNS 商都提供），导入 Route 53（见 1.3）。
3. **配置复杂、且想用 Route 53 特性**：先原样导入或手工建，再逐步改造成 Alias / 路由策略 / 健康检查等 Route 53 独有能力（见 topic 02、03、12）。

**Step 0（可选但强烈推荐）**：先从原 DNS 商**完整导出当前配置**（zone file 或逐条抄录），作为迁移的"真相基线"和事后核对依据。

### 1.3 zone file 导入：格式要求与硬规则（★高频易错点）

出自官方导入指引 + [repost 导入排错](https://repost.aws/knowledge-center/route-53-import-dns-zone-files)，导入前必须满足（否则**整份导入失败、一条不建**）：

- **RFC 兼容格式**（标准 BIND 风格 zone file，多数 DNS 商 / BIND 可导出）。
- **记录域名必须与 hosted zone 名一致**。
- **支持 `$ORIGIN` 与 `$TTL` 关键字**；**含 `$GENERATE` 或 `$INCLUDE` 会直接导入失败并报错**。
- **导入时 Route 53 忽略 SOA 记录**；**与 hosted zone 同名的 NS 记录也被忽略**（因为 Route 53 已自建默认 SOA + 4 个 NS，见 topic 01）。
- **单次导入上限 1,000 条记录**（控制台原生导入的专属上限，与批量 API 的 1000 个 `ResourceRecord`/请求是**两个不同的 1000**，别混）。
- **非空 zone 也可以导入**——并非"仅限空 zone"。但**若 zone file 里含有 hosted zone 中已存在的记录，整次导入失败、一条都不建**（冲突即整份失败，不是跳过冲突项）。所以对已有记录的 zone 续灌时，file 里只放尚不存在的记录才能成功；否则改走 `ChangeResourceRecordSets` 的 UPSERT（见 1.4）。
- **尾点（trailing dot）语义**：记录名带尾点（`example.com.`）→ 当作 FQDN 原样建；不带尾点（`www`）→ 与 zone 名拼接成 `www.example.com`。**CNAME/MX/PTR/SRV 的 RDATA 值也适用同样的尾点拼接规则**，导入前务必逐条检查 RDATA 尾点，否则会建出 `www.example.com.example.com` 这类错误目标。
- **导入只能用控制台**（把 zone file 文本粘进 `Import zone file` 面板）；CLI 无 `import-zone-file` 单命令——CLI/SDK 路径要走 `ChangeResourceRecordSets` 批量建（见 1.4）。控制台原生导入最多 1000 条；zone 非空也能导，但**含已存在记录则整次失败**。

### 1.4 ChangeResourceRecordSets：批量变更的原子性、UPSERT 与硬上限（核心 API）

所有对记录的增删改（控制台之外）都走**同一个 API**：`ChangeResourceRecordSets`。一次请求提交一个 **change batch**（变更批），batch 里是一串 `Change`，每个 `Change` 有一个 `Action`：

- **`CREATE`**：新建记录集；若已存在同名同类型 → 报错。
- **`DELETE`**：删记录集；删除时**提交的 `ResourceRecordSet` 值必须与现有的完全一致**（含 TTL、全部 Value），否则报错——这是"删不掉"的经典坑。
- **`UPSERT`**：不存在则建、已存在则**整体替换**（不是"合并"——原有该记录集被这次提交的内容整体覆盖）。**迁移/幂等脚本首选 UPSERT**，因为它可安全重跑。

**★ 原子性（SME 必答）**：**一个 change batch 是一个事务——要么全部成功、要么全部不生效**。batch 里任一 `Change` 校验失败，**整批拒绝、零变更落地**。所以不能靠"提交一大批，失败的自然跳过"——失败会拖垮整批。

**硬上限（出自 [Quotas · Maximums on API requests](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html)，逐字核对）**：

| 约束 | 上限 | UPSERT 的加倍规则（易错） |
|---|---|---|
| 每个请求的 `ResourceRecord` 元素数（含 alias） | **≤ 1,000** | `Action=UPSERT` 时**每个 `ResourceRecord` 计两次** |
| 一个请求内所有 `Value` 元素字符总和（含空格） | **≤ 32,000 字符** | `Action=UPSERT` 时**每个字符计两次** |

> 结论：一批**全 UPSERT** 的有效容量实际减半（≈500 个 ResourceRecord / 16,000 字符）。大量记录必须**分批打包**，每批控制在上限内并预留 UPSERT 加倍余量。

**变更提交后是异步的**——返回 `ChangeInfo`（含 `Id`、`Status`），初始为 `PENDING`（见 1.6 用 `GetChange` 等 `INSYNC`）。

### 1.5 API 限流与分批（大量记录迁移的节流）

Route 53 对 API 做**按账号**限流，两条独立的桶（[Frequency of API requests](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html)）：

- **Request rate**：每秒 API 请求数。
- **Change throughput（令牌桶）**：按"变更条数"计的令牌桶——**突发容量 1,500、持续补充约 100 changes/s**。**关键：`UPSERT` 每个消耗 2 个 token**（`CREATE`/`DELETE` 各消耗 1），因为 UPSERT 在计费上算"可能删+可能建"两步。所以一批全 UPSERT 的实际吞吐上限也相应折半——这是"请求大小 UPSERT 双倍"之外的**第二重双倍**（吞吐令牌）。

任一桶超限 → **HTTP 400**，响应头 `Code=Throttling`、`Message=Rate exceeded`。**处置：指数退避重试（exponential backoff）**。

另一个**同一 hosted zone 的串行约束**：若上一个 `ChangeResourceRecordSets` 还没处理完就来下一个针对**同一 hosted zone**的请求，Route 53 拒绝后到者并返回 **HTTP 400 `PriorRequestNotComplete` / `The request was rejected because Route 53 was still processing a prior request`**。

> **大量记录迁移的分批策略**：① 把总变更切成多个 batch，每批 ≤ 1000 ResourceRecord（UPSERT 折半）且 ≤ 32000 字符（UPSERT 折半）；② **推荐对同一 zone 串行提交**——提交一批后用 `GetChange` 等到 `INSYNC` 再提下一批。**注意这是一种"安全串行"策略，不是 R53 的硬性要求**：R53 并不强制你等 `INSYNC`；只是同一 hosted zone 上一批还没处理完就提下一批时，后到的请求会被拒并返回 `PriorRequestNotComplete`。所以你也可以不等 `INSYNC`、只在收到 `PriorRequestNotComplete` 时退避重试——等 `INSYNC` 只是把这种失败前置规避掉、更省事更可预测。③ 遇 `Throttling` 指数退避；④ 跨不同 zone 可并行，但仍受账号级 request-rate / change-throughput 桶约束。

### 1.6 GetChange 与 INSYNC：判定"变更已全网生效"（★别用 PENDING 宣布完成）

- 每次 `ChangeResourceRecordSets` 返回一个 change `Id`。用 **`GetChange <Id>`** 查状态：
  - **`PENDING`**：变更已收下，但**尚未传播到 Route 53 全部权威 DNS 服务器**。
  - **`INSYNC`**：变更**已在 Route 53 所有权威 DNS 服务器上生效**。
- **SME 铁律**：**只有 `INSYNC` 才代表 Route 53 侧已完成**；脚本要 `wait`/轮询到 `INSYNC` 再推进下一步（下一批变更、或切 NS）。用 `PENDING` 就宣布"改好了"是错的。
- 注意 `INSYNC` 只说明"**Route 53 权威服务器已生效**"，**不等于全球递归解析器缓存已刷新**——那要看记录/NS 的 **TTL** 过期（见 1.7 降 TTL）。两层要分清：**权威生效（INSYNC）** vs **缓存过期（TTL）**。

### 1.7 NS 切换四阶段（迁移的"临门一脚"，风险最高）

DNS 托管迁入的最后一步是把**注册商处的 NS 委派**从旧 DNS 商改成 Route 53 的 4 个 NS。这是唯一会让公网流量真正切过来、也是唯一可能造成停机的动作。按四阶段执行：

**阶段一 · 降 TTL（提前 1~2 天）**
- NS 记录的默认 TTL 是 **172,800 秒（2 天）**。若不提前降，一旦切换出问题，**域名最长可不可用达 2 天**。
- 把**旧 DNS 商侧**和**新建 Route 53 zone 侧**的 NS 记录 TTL 都降到低值（官方建议 **60~900 秒**）。同理，业务关键记录（apex A、www 等）也提前降 TTL，让回滚能快速生效。
- **降 TTL 要等旧 TTL 完全过期**后再进入切换，否则递归解析器仍缓存着旧的长 TTL。
- 若配了 **DNSSEC**：切换前先从父区移除 **DS 记录**（否则新 NS 上的签名与父区 DS 不匹配会导致 SERVFAIL，见 topic 07）。

**阶段二 · 并行验证（切 NS 之前）**
- 记录已在 Route 53 建好、`GetChange` 到 `INSYNC` 后，**直接向 Route 53 的 4 个 NS 逐一发查询**核对解析结果，与旧 DNS 商返回的答案逐条比对：
  ```
  dig @<route53-ns-1> example.com A +norecurse
  dig @<route53-ns-1> www.example.com CNAME +norecurse
  # 对 4 个 NS 都查一遍，且覆盖所有关键记录/类型
  ```
- 目的：在流量切过来**之前**就确认 Route 53 的答案与现网一致，把"记录漏迁 / 值写错"暴露在无影响窗口。

**阶段三 · 改注册商 NS（真正切换）**
- 到**注册商侧**（若域名注册在 Route 53，则在 `Registered domains`；若在别家注册商，则登录该注册商）把 NS 委派改成 Route 53 zone 的 **4 个 NS**（取自 hosted zone 的 NS 记录 / `GetHostedZone`）。
- **只改注册商的委派，不要动别的**。改 hosted zone 里的 NS 记录**不会**自动同步到注册商——注册商侧的委派才决定公网走哪套 NS（"改了 hosted zone 却不解析"的经典坑，见 topic 09 §1.7）。
- **★ 切换后不要立刻拆旧权威**：改注册商 NS 后，父区（TLD / 注册商）对旧委派的缓存**可能持续长达两天**（NS 委派 TTL 默认 172800s），期间仍有递归解析器拿着旧 NS 去查旧 DNS 商。因此**旧 DNS 商的权威区与记录至少保留 48 小时**（保守可更久），确保这段父区缓存窗口内落到旧 NS 的查询仍能被正确应答，避免解析中断。

**阶段四 · 监控传播**
- 切换后按低 TTL 的时长监控传播：从多地 / 多公共递归（如 8.8.8.8、1.1.1.1）反复 `dig NS example.com` 与关键记录，观察答案从旧 NS 收敛到 Route 53 NS。
- 用 **CloudWatch / query logging** 监控 Route 53 侧查询量是否上升（流量切过来的信号）；同时保留客户侧可用性反馈作为回滚触发条件。
- **旧权威至少保留 48h**、父区缓存最长约两天完全过期后，再拆旧 DNS 商配置；**确认稳定后**才把 NS/关键记录 TTL 调回正常值（如 3600/172800）。

### 1.8 dry-run 与回滚（把风险控在可逆区间）

Route 53 的 `ChangeResourceRecordSets` **没有原生 dry-run 参数**，需自建等效手段：

- **dry-run（变更前预演）**：
  - 用 `ListResourceRecordSets` 导出**当前 zone 全量记录**作为回滚基线快照。
  - 在**非生产 hosted zone**（同名或测试子域）先把 change batch 跑一遍，或用工具（如 `octodns`/IaC 的 plan、`cli53` 的 diff）离线比对期望态 vs 现网态。
  - 严格用 **UPSERT**，保证脚本可重复提交而不因 `CREATE` 冲突失败。
- **回滚**：
  - **NS 切换阶段回滚**：把注册商 NS **改回旧 DNS 商**；因阶段一已降 TTL，回滚可在低 TTL 时长内生效——这正是降 TTL 的意义。
  - **记录批量变更回滚**：用变更前 `ListResourceRecordSets` 快照，生成一批反向 UPSERT/DELETE 打回原值。因单 batch 原子，回滚 batch 同样要控上限、串行到 `INSYNC`。
  - **跨账号迁移**的准备/回滚要点（[Migrating a hosted zone to a different AWS account](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zones-migrating.html)）：先降 TTL、配 DNSSEC 的先撤 DS、用 CloudWatch/query logging 监控可用性作为回滚信号（但不应作为唯一信号，还要看客户反馈）。

**边界数字速记**：zone file 控制台导入 **≤1000 条 / 非空 zone 也可导但含已存在记录即整份失败 / 不支持 $GENERATE $INCLUDE / 忽略 SOA 及同名 NS**；change batch **≤1000 ResourceRecord（含 alias）、≤32000 字符、整批原子、UPSERT 请求大小计两次**；change-throughput 令牌桶 **突发 1500 / 持续 ~100 changes/s、每 UPSERT 消耗 2 token**；NS 默认 TTL **172800s（2 天）**、切换前降到 **60~900s**、切换后**旧权威至少保留 48h**（父区缓存最长约两天）；同 zone 未处理完再提 **PriorRequestNotComplete**（等 INSYNC 是安全串行策略非硬要求）、超限 **Throttling/Rate exceeded → 退避**；判完成看 **INSYNC 不是 PENDING**。

---

## 2. 真实案例说明（Real Case）

> 本 topic 为运维剧本型，未强绑定单一 case；以下为可复用的执行范式与典型故障映射。

### 场景 A —— 从别家 DNS 商原样迁入 example.com（DNS 托管迁入，域名暂不转注册）

1. **导出基线**：向原 DNS 商索取 zone file。
2. **建 zone + 导入**：Route 53 控制台 `Create hosted zone`（名与域一致）→ `Import zone file`。预先检查：无 `$GENERATE/$INCLUDE`、记录数 ≤1000、RDATA 尾点正确。导入忽略 SOA 与同名 NS。
3. **核对 + 降 TTL**：`ListResourceRecordSets` 逐条比对导出基线；把新 zone NS 及关键记录 TTL 降到 60~900s，同时去旧 DNS 商把对应 TTL 也降低。
4. **并行验证**：`dig @<route53-ns>` 对 4 个 NS 逐一核对答案与现网一致。
5. **切 NS**：到注册商把委派改成 Route 53 的 4 个 NS。
6. **监控 + 收尾**：多地 `dig NS` 观察收敛、CloudWatch 看查询量；稳定后 TTL 调回。

### 场景 B —— 用 API 批量灌入 3,000 条记录（超出导入上限 + 需分批）

- zone file 单次上限 1000 条，3000 条要么分三次导入（但导入对已含记录的 zone 会整份失败，不适合续灌），**更稳的是走 `ChangeResourceRecordSets` 分批 UPSERT**：
- 按 **≤1000 ResourceRecord（UPSERT 折半按 ≈500 计）** 且 **≤32000 字符（折半按 ≈16000 计）** 切成多批；
- **对同一 zone 串行**：提交一批 → `GetChange` 轮询到 `INSYNC` → 再提下一批，规避 `PriorRequestNotComplete`；
- 遇 `Throttling`/`Rate exceeded` 指数退避重试。

### 典型故障 → 根因映射

| 现象 | 根因 | 处置 |
|---|---|---|
| 导入报错、一条没建 | zone file 含 `$GENERATE/$INCLUDE`，或 file 含 zone 中**已存在**的记录（冲突），或 >1000 条 | 清理关键字 / 去掉已存在记录（或改走 API UPSERT）/ 分批走 API |
| 建出 `www.example.com.example.com` | RDATA/记录名尾点误用 | 导入前逐条检查尾点，FQDN 加尾点 |
| DELETE 报错删不掉 | 提交的记录集值与现有不完全一致 | 先 `ListResourceRecordSets` 拿到精确现值再 DELETE |
| 批量提交 400 `PriorRequestNotComplete` | 同一 zone 上批未完成又提新批 | 串行 + 等 `INSYNC` 再提下一批 |
| 批量提交 400 `Throttling` `Rate exceeded` | 超 request-rate / change-throughput 桶 | 指数退避、降低并发、拆小批 |
| 改了 hosted zone 记录但公网不解析 | 注册商 NS 委派仍指旧 DNS 商 | 到注册商同步 NS 委派 |
| 切 NS 后出问题、域名长时间不可用 | 切换前没降 NS TTL（默认 2 天） | 提前降 TTL 再切；回滚改回旧 NS |
| DNSSEC 域切换后 SERVFAIL | 未先撤父区 DS 记录 | 切换前从父区移除 DS |
| 脚本"改好了"但客户仍看到旧值 | 用 `PENDING` 当完成，或递归缓存未过期 | 等 `GetChange=INSYNC`；再等 TTL 过期 |

---

## 来源（Sources）

- Making Amazon Route 53 the DNS service for a domain that's in use（迁入总流程 / zone file vs 手工 / 降 TTL）：https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/migrate-dns-domain-in-use.html
- How do I import DNS zone files to Route 53 and troubleshoot the errors（导入格式硬规则 / 1000 条 / $GENERATE $INCLUDE / SOA·NS 忽略 / 尾点语义 / 已存在即失败）：https://repost.aws/knowledge-center/route-53-import-dns-zone-files
- 更新注册商 NS 的前提（降 NS TTL、默认 172800s）：https://repost.aws/knowledge-center/route-53-update-name-servers-registrar
- Migrating a hosted zone to a different AWS account（降 TTL、撤 DS、CloudWatch/query logging 监控与回滚信号）：https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zones-migrating.html
- Quotas / Maximums on API requests（ChangeResourceRecordSets ≤1000 ResourceRecord、≤32000 字符、UPSERT 计两次；request-rate 与 change-throughput 两桶；Throttling/Rate exceeded；PriorRequestNotComplete；每 zone 10000 记录 / 每记录集 400）：https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html
- ChangeResourceRecordSets CLI / change-batch（CREATE/DELETE/UPSERT、JSON 结构、PENDING→GetChange 查状态）：https://repost.aws/knowledge-center/simple-resource-record-route53-cli 及 https://docs.aws.amazon.com/code-library/latest/ug/route-53_example_route-53_ChangeResourceRecordSets_section.html
- ChangeResourceRecordSets 参数（Action=CREATE/DELETE/UPSERT、change_batch 结构、AliasTarget）：https://docs.aws.amazon.com/sdk-for-ruby/v2/api/Aws/Route53/Types/ChangeResourceRecordSetsRequest.html
- Amazon Route 53 FAQs（zone 导入支持 BIND / 空 zone；每 zone 10000 记录）：https://aws.amazon.com/route53/faqs/

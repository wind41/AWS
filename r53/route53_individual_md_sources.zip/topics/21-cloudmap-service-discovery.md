# Topic 21：Cloud Map / 服务发现 + ExternalDNS（容器与微服务动态命名）

> Route 53 SME · P2 进阶层。内外部两方缺口分析都点名的整类缺失——**动态服务发现**：R53 不只是静态 DNS，它还是容器/微服务动态命名的底座。本 topic 覆盖 **AWS Cloud Map（namespace / service / instance 三层模型、DNS 发现 vs API 发现、MULTIVALUE/WEIGHTED、A/AAAA/SRV/CNAME、custom health vs Route 53 HC）、ECS 服务发现的 task 注册/注销生命周期、ECS Service Connect vs Service Discovery、以及 EKS ExternalDNS（TXT registry / owner-id / zone filter / IRSA / 限流——一个非托管 R53 的社区功能）**。
>
> 交叉锚点：**topic 01（Hosted Zone / PHZ）**——Cloud Map DNS namespace 底层就是自动建的 R53 hosted zone；**topic 03（路由策略）**——Cloud Map 的 MULTIVALUE/WEIGHTED 直接落成 R53 记录；**topic 04（健康检查）**——Cloud Map custom health 与 R53 public HC 的分工；**topic 12（配额）**——Cloud Map 配额吃 R53 hosted-zone/记录配额。
>
> 来源锚点：
> - Cloud Map API 参考 `DnsConfig`（RoutingPolicy=MULTIVALUE|WEIGHTED；DnsRecords 记录类型不可改，改类型须删服务重建）、`HealthCheckCustomConfig`（`UpdateInstanceCustomHealthStatus` + 30s 判定）、`CreateHttpNamespace`（HTTP namespace 只能 `DiscoverInstances`、不能 DNS 解析）。
> - Cloud Map Developer Guide：service quotas、Shared namespaces、FAQ（public/private namespace 定义）。
> - ECS Developer Guide + repost：service discovery / Service Connect / Interconnect Amazon ECS services；ECS 控制面自动注册/注销 task IP。
> - EKS User Guide：Community add-ons（external-dns，`AmazonRoute53FullAccess` 或收敛到 3 个 action）；repost「How do I set up ExternalDNS with Amazon EKS」（IAM policy + OIDC + IRSA + Helm）；SageMaker HyperPod Direct-SSH 文档（`--policy=sync` vs `upsert-only`、`--txt-owner-id`、`--domain-filter`）。

---

## 1. 概念（Concept）

### 1.1 为什么需要服务发现（动态命名的痛点）
静态 DNS 记录假设"名字 → 固定 IP"。容器/微服务里 IP 是**易变的**（task 重启、扩缩容、滚动部署都换 IP），手工维护记录不可行。**服务发现**让消费方用**逻辑名**（`recommender-svc.ecs-services`）找当前健康实例，注册/注销由平台自动完成。R53 在这里是**底座**：Cloud Map 的 DNS namespace 底层就是它自动建的 hosted zone。

### 1.2 AWS Cloud Map 三层模型（★必须条件反射区分）
Cloud Map 是**全托管服务注册表**，把任意云资源（ECS task、EC2、Lambda、RDS、S3、外部 IP）映射到逻辑名。三个核心组件：

| 层级 | 概念 | 说明 |
|---|---|---|
| **Namespace（命名空间）** | 逻辑分组 + 可见性边界 | 决定"怎么发现"：DNS 和/或 API。三种类型见 §1.3 |
| **Service（服务）** | 一个服务注册表（service registry） | 定义该服务实例要建什么 R53 记录（类型/TTL/路由策略）、用哪种健康检查。**通常一个 ECS 服务对应一个 Cloud Map service** |
| **Instance（实例）** | 服务下的一个具体端点 | 注册时带属性（IP/端口，或任意 metadata 如 ARN、URL）；DNS namespace 下每注册一个 instance，Cloud Map 就在底层 R53 hosted zone 建对应记录 |

- **私有 DNS namespace 名字构成**：消费方用 `{service}.{namespace}` 这个私有 DNS 名解析（如 `recommender-svc.ecs-services`）。
- 来源：Cloud Map FAQ + Containers 博客（三组件 create-private-dns-namespace → create-service → register-instance）。

### 1.3 三种 Namespace 类型 —— 决定"DNS 发现 vs API 发现"（★高频考点）

| Namespace 类型 | 建法 | 可见性 | 发现方式 | 底层 R53 |
|---|---|---|---|---|
| **Public DNS** | `CreatePublicDnsNamespace` | 公网 | 公网 DNS 查询 **+** `DiscoverInstances` API | 自动建 **public hosted zone** |
| **Private DNS** | `CreatePrivateDnsNamespace`（须关联 VPC） | 指定 VPC 内 | VPC 内 DNS 查询 **+** `DiscoverInstances` API | 自动建 **private hosted zone（PHZ）** 关联到该 VPC |
| **HTTP** | `CreateHttpNamespace` | 账号内（无 DNS） | **只能 `DiscoverInstances` API**，**不能用 DNS 解析** | **不建** hosted zone |

- **DNS discovery vs API discovery（两条腿）**：
  - **DNS discovery**：消费方发普通 DNS 查询（`dig recommender-svc.ecs-services`），拿 A/AAAA/SRV/CNAME。**任何标准 DNS 客户端都能用**，不需 AWS SDK。仅 public/private DNS namespace 支持。
  - **API discovery**：消费方调 **`DiscoverInstances`**（AWS SDK），按逻辑名 + **自定义属性过滤**（如 `instance_type=r5.xlarge`）拿实例列表。**所有三种 namespace 都支持**。适合不需要 URL 的场景（Lambda 互调、SQS、拿 ARN）。
  - ⚠️ **HTTP namespace 只能 API discovery**——建了 HTTP namespace 想 `dig` 是解析不到的，这是最容易踩的坑。
- 来源：`CreateHttpNamespace`（"can't be discovered using DNS"）；Cloud Map serverless 博客（DNS/API/both）；Data Prepper peer-forwarder（`discovery_mode: aws_cloud_map` + `aws_cloud_map_query_parameters`）。

### 1.4 记录类型与路由策略（直接落成 R53，衔接 topic 02/03）
Cloud Map service 的 `DnsConfig` 定义要建的记录：

- **记录类型 `DnsRecords[].Type`**：`A`（IPv4）、`AAAA`（IPv6）、`SRV`（含端口，`bridge`/`host` 网络模式必须用）、`CNAME`。
  - ⚠️ **记录类型创建后不可改**——要换类型（如 A→SRV）**必须删掉整个 service 重建**（`DnsConfig` 的 record type 不可 update）。
  - ⚠️ **`CNAME` 记录必须用 `WEIGHTED` 路由策略**（不能 MULTIVALUE），且 **`CNAME` service 不能配 `HealthCheckConfig`**（会报错）——CNAME 只能配 custom health 或不配。
- **路由策略 `RoutingPolicy`（★背记 MULTIVALUE vs WEIGHTED，衔接 topic 03）**：
  - **`MULTIVALUE`**：R53 对每次查询返回**最多 8 个**健康实例的值。若定义了健康检查且健康，返回健康实例（不足 8 个就返回所有健康的）；**不定义健康检查则假定全健康**、返回最多 8 个。**fail-open：若某 service 下没有任何实例被判为健康，Cloud Map 按"全部实例都健康"处理、照常返回**（避免因健康检查全挂而彻底无应答）。→ 客户端侧负载分摊。
  - **`WEIGHTED`**：R53 从注册在同一 service 的实例里**随机选一个**返回。⚠️ **当前所有记录权重相同**（不能真正按权重分流量）。**同样 fail-open：无健康实例时按全部实例处理、仍返回一个**。**要建 Alias 记录、或建 CNAME 记录的场景都必须用 `WEIGHTED`**（Alias/CNAME 不支持 MULTIVALUE）。
- 落地关系：Cloud Map 只是"声明式地告诉 R53 建什么"，真正的解析行为仍是 topic 03 里那套 R53 路由策略语义。
- 来源：Cloud Map API `DnsConfig`（MULTIVALUE/WEIGHTED 无健康实例时按全部处理即 fail-open、最多 8 个、WEIGHTED 随机且等权、Alias 与 CNAME 必须 WEIGHTED、CNAME 不能配 HealthCheckConfig）；CDK ECS 文档（bridge/host 只支持 SRV）。

### 1.5 Custom health check vs Route 53 health check（★分工，衔接 topic 04）
Cloud Map service 二选一（**不能同时**）：

- **`HealthCheckConfig`（= 标准 R53 端点健康检查）**：Cloud Map 帮你建一个 **R53 端点健康检查**（HTTP/HTTPS/TCP），由 R53 全球 checker 探测。**支持 Public DNS namespace 和 HTTP namespace，不支持 Private DNS namespace**（PHZ 里的私有端点公网 checker 探不到）。要探的端点必须公网可达。
- **`HealthCheckCustomConfig`（自定义健康检查）**：
  - **Cloud Map 自己不探测**——它只**记录**你最近一次 `UpdateInstanceCustomHealthStatus` 报的状态。健康判定由**第三方/你自己的健康检查器**做。**并非"仅限 VPC 内资源"**——任何注册进来的实例（含公网/on-prem 资源）都可用 custom health，只要有个外部检查器负责上报状态；VPC 内资源是常见场景，因为它们公网不可达、只能走 custom health（检查器要能网络可达该资源）。
  - **`HealthCheckConfig` 与 `HealthCheckCustomConfig` 不能同时配**（二选一）。
  - **30 秒判定窗**：你报 unhealthy 后 Cloud Map **等 30 秒**；若这 30s 内没有新的 `UpdateInstanceCustomHealthStatus` 把它改回 healthy，Cloud Map 才**停止对该实例路由**。`FailureThreshold` 已废弃、恒等于 1（就是这 30s 一档）；30s 内重复报同值不会加速切换。
  - **为什么 ECS 用这个**：ECS task 多在私有子网、不公网可达，R53 端点 HC 探不到，所以走 custom health（由 ECS 控制面驱动状态）。
- 来源：Cloud Map API `HealthCheckCustomConfig`（30s 窗、FailureThreshold 恒为 1、Cloud Map 不探测只记状态、与 `HealthCheckConfig` 二选一）；`HealthCheckConfig`（R53 端点 HC，支持 Public DNS 和 HTTP namespace、不支持 Private DNS）。

### 1.6 ECS Service Discovery —— task 注册/注销生命周期（★）
ECS 与 Cloud Map **深度集成**：为 ECS 服务启用 service discovery 后——

1. task 启动 → **ECS 控制面自动 `RegisterInstance`**，把 task/容器 IP 注册进 Cloud Map service（DNS namespace 下同步在底层 R53 建记录）。
2. task 消失（新版本部署 / 崩溃 / 重启）→ **ECS 控制面自动 `DeregisterInstance`**，删掉记录。
3. 消费方用 `{service}.{namespace}` DNS 名或 `DiscoverInstances` API 找到当前实例。
- **网络模式约束**：`awsvpc` 模式支持 **A 或 SRV** 记录（task 有自己的 ENI/IP，可只注册 IP 用 A，也可带端口用 SRV）；`bridge`/`host` 模式**只能用 SRV**（端口是动态映射的，必须靠 SRV 带端口信息）。**Service Connect 不兼容 `host` 网络模式**。
- 来源：ECS→Cloud Map 集成博客（控制面自动 register/deregister）；repost ecs-tasks-services-communication；CDK（awsvpc→A 或 SRV、bridge/host→仅 SRV）。

### 1.7 ECS Service Connect vs Service Discovery（★选型考点）

| 维度 | **Service Discovery（旧）** | **Service Connect（新，推荐）** |
|---|---|---|
| 机制 | Cloud Map 注册 + **客户端自己解析 DNS** 直连实例 IP | 注入 **Envoy 代理 sidecar**，按逻辑名路由 + 连接管理 + **流量监控/指标** |
| 底层 | Cloud Map DNS/API | Cloud Map **API 注册表**（`DiscoverInstances`，不靠 DNS 记录） |
| 服务发现随生命周期 | ECS 控制面在 Cloud Map 加/删实例（DNS namespace 下同步加删 R53 记录） | ECS 控制面在 Cloud Map **注册表**加/删实例，**Envoy 托管代理按注册表路由，不依赖增删 DNS 记录**（客户端连的是代理，不是 DNS 解析出的 IP） |
| 健康/重试/负载均衡 | 靠 DNS TTL 与客户端，粗糙 | 代理侧做重试、异常剔除、客户端负载均衡 |
| 网络模式 | 支持 A（awsvpc）/ SRV（bridge/host） | **不支持 `host` 模式** |
| 可观测性 | 无内建 | **内建 traffic metrics/traces** |
| 官方建议 | 传统场景 | **最佳实践优先 Service Connect**（一站式发现+连接+监控） |

- **Service Connect 用 Cloud Map 作服务注册表 + 托管 Envoy 代理**，**不靠增删 DNS 记录**来做发现——task 起停时更新的是 Cloud Map 注册表条目，代理据此路由。
- **namespace 引用**：Service Connect **可引用任何现有 Cloud Map namespace**（不限类型）；若创建时不指定，ECS 会**新建一个 HTTP 类型**的 namespace（"API calls" 发现）。即"默认新建 HTTP"是**未指定时的默认**，不是"只能用 HTTP"。
- 第三条腿：**VPC Lattice** 也可做 ECS 服务互联（应用层，跨 VPC/账号），但不在本 topic 范围。
- 来源：repost ecs-tasks-services-communication（"best practice to use Service Connect"、Service Connect 用 Cloud Map API 注册表 + Envoy 代理路由而非增删 DNS 记录、不兼容 host）；ECS `ClusterServiceConnectDefaultsRequest.namespace`（可引用现有任意 namespace，未指定则新建 HTTP namespace / "API calls" 发现）。

### 1.8 EKS ExternalDNS（★关键定性：**非托管 R53 功能**）
- **ExternalDNS 是 Kubernetes SIG 的开源控制器，不是 AWS 托管服务**——它 watch K8s `Service`/`Ingress` 资源，替你在 R53 里增删记录。AWS 提供它作为 **EKS community add-on**（`external-dns`），但**故障排查最终指向上游 GitHub 项目**，不是 AWS 支持面的托管特性。这条定性两方缺口分析都点名。
- **工作机制**：
  - `--source=service` / `--source=ingress`：watch 哪类资源（headless Service 必须用 `service`）。
  - **`--registry=txt` + `--txt-owner-id=<唯一标识>`（★核心）**：ExternalDNS 为它管理的每条记录**额外建一条 TXT 记录**当"所有权登记（registry）"，TXT 里写 owner-id。**只有 owner-id 匹配的记录 ExternalDNS 才会改/删**——防止多个 ExternalDNS 实例（多集群共享一个 zone）互相误删对方的记录。owner-id 常用集群名。
  - **`--policy` 两档（★易错）**：
    - `upsert-only`（**默认**）：只增/改、**从不删**。删 workload 后 A + TXT 记录会**残留成 stale 记录**。仅测试用。
    - `sync`：增/改/**删**——workload 删了才会清理对应记录。**生产必须 `--policy=sync`**，且**必须配 `--txt-owner-id`**（靠它判断哪些记录归自己、能删）。
  - **`--domain-filter=<zone域名>`（zone filter）**：把 ExternalDNS 限定在指定 hosted zone，**不写会处理账号下所有可见 zone**（危险）。`--aws-zone-type=public|private` 进一步限定 public/private。
- **IAM / IRSA（★权限模型）**：ExternalDNS pod 需要 R53 写权限，通过 **IRSA（IAM Roles for Service Accounts）**授予——关联集群 OIDC provider → 建 IAM role 绑到 `external-dns` ServiceAccount。
  - **最小权限**：`route53:ChangeResourceRecordSets`（收敛到指定 hostedzone ARN）+ `route53:ListHostedZones` + `route53:ListResourceRecordSets`（`*`）。EKS 托管 add-on 默认给的是 `AmazonRoute53FullAccess`（过宽，生产应收敛）。
- **限流（throttling）**：ExternalDNS 频繁调 `ListHostedZones`/`ListResourceRecordSets`/`ChangeResourceRecordSets`，**R53 API 有账号级 5 req/s 的限速**（topic 12）。大集群/多实例共享 zone 时易触发 `Throttling`/`PriorRequestNotComplete`——用 **zone filter 收窄监控范围、拉长同步 interval、少建 zone** 缓解。
- 来源：EKS Community add-ons（external-dns add-on、权限可收敛到 3 个 action）；repost eks-set-up-externaldns（IAM policy + OIDC + IRSA + Helm）；SageMaker HyperPod Direct-SSH（`--policy=sync` vs `upsert-only`、`--txt-owner-id`、`--domain-filter` 生产配置）。

---

## 2. 真实案例说明（Real Case）

> 本 topic 为动态发现能力层，case 以"选型 / 生命周期排障 / 记录残留"为主。

### 场景 A（排障）：`dig service.namespace` 解析不到，但实例明明注册了
- **症状**：客户在 ECS/EKS 里注册了 Cloud Map 实例，`DiscoverInstances` 能看到，但 `dig recommender-svc.ecs-services` 无应答（SERVFAIL/NXDOMAIN）。
- **根因**：namespace 建成了 **HTTP 类型**（常见于用 Service Connect 时自动建的、或手工建错）——HTTP namespace **只支持 API discovery，不建 hosted zone、不能 DNS 解析**。
- **正解**：要 DNS 解析必须用 **private DNS namespace**（或 public）；HTTP namespace 改逻辑改用 SDK `DiscoverInstances`。
- **SME 判断点**：service 发现问题第一步先确认 namespace 类型；HTTP≠可 dig。

### 场景 B（排障）：滚动部署后老 IP 还在被解析、连到已死 task
- **症状**：ECS 服务更新后，客户端仍偶尔连到旧 task IP，超时。
- **根因组合**：(1) DNS 客户端**缓存**了记录（Cloud Map DNS 记录 TTL 太长，如 300s）；(2) custom health 的 **30s 判定窗** + deregister 传播有延迟；(3) 客户端不重解析。
- **正解**：Cloud Map service 的 DnsRecords **TTL 调低（如 10–30s）**；应用侧不要长期缓存 DNS；有条件迁 **Service Connect**（Envoy 侧连接管理，不靠客户端 DNS 缓存），对滚动部署更平滑。
- **SME 判断点**：动态发现的"连到死实例"几乎总是 **TTL/缓存 + 注销传播** 三者叠加，不是 R53 故障。

### 场景 C（排障）：EKS 删了应用，R53 里 A + TXT 记录残留（stale）
- **症状**：客户删了 K8s Service，但 R53 hosted zone 里对应的 A 记录和一条奇怪的 TXT 记录还在。
- **根因**：ExternalDNS 用的是**默认 `--policy=upsert-only`**（只增不删），或没配 `--txt-owner-id` 导致它不认为记录归自己、不敢删。
- **正解**：生产改 **`--policy=sync` + `--txt-owner-id=<集群名>`**；那条 TXT 是 ExternalDNS 的**所有权登记记录**（不是垃圾），手工清理时 A + TXT 一起删。
- **SME 判断点**：R53 里冒出成对的"业务 A 记录 + 内容像 `heritage=external-dns...` 的 TXT 记录"就是 ExternalDNS 的手笔；残留=policy/owner-id 配置问题，**这是 ExternalDNS（非托管）行为，不是 R53 缺陷**。

### 场景 D（排障）：多集群共享一个 hosted zone，ExternalDNS 互删对方记录
- **症状**：两个 EKS 集群都跑 ExternalDNS 指向同一个 zone，A 集群的记录被 B 集群删掉。
- **根因**：两个实例 **`--txt-owner-id` 相同或未设**，都认为对方的记录归自己，`sync` 策略下互删。
- **正解**：每个集群配**唯一 `--txt-owner-id`**（如各自集群名）；配合 `--domain-filter` 收窄各自范围。
- **SME 判断点**：共享 zone 多写方冲突 → 查 owner-id 唯一性；顺带这类高频 Change 调用会撞 R53 5 req/s 限速。

---

## 3. 实验步骤（Hands-on Lab）

> 私有 namespace 会自动建 PHZ（吃 R53 hosted-zone 配额）；实验后清理 namespace/service。

### Lab A：建 private DNS namespace + service（MULTIVALUE + custom health）
```bash
VPC_ID=vpc-xxxx
# 1) 私有 DNS namespace（自动建 PHZ 关联到 VPC）
OP=$(aws servicediscovery create-private-dns-namespace \
  --name ecs-services --vpc $VPC_ID --query OperationId --output text)
NS=$(aws servicediscovery get-operation --operation-id $OP \
  --query "Operation.Targets.NAMESPACE" --output text)
# 2) service：A 记录 TTL=10、MULTIVALUE、custom health（VPC 内资源）
aws servicediscovery create-service \
  --name recommender-svc --namespace-id $NS \
  --dns-config "NamespaceId=$NS,RoutingPolicy=MULTIVALUE,DnsRecords=[{Type=A,TTL=10}]" \
  --health-check-custom-config FailureThreshold=1
# 3) 手工注册一个实例（ECS 会自动做这步）
aws servicediscovery register-instance --service-id srv-xxxx \
  --instance-id i-1 --attributes AWS_INSTANCE_IPV4=10.0.1.10
# 4) VPC 内 dig 验证（最多返回 8 个健康实例）
dig +short recommender-svc.ecs-services A
```

### Lab B：观察 HTTP namespace 不能 DNS 解析（现场验证坑）
```bash
aws servicediscovery create-http-namespace --name api-only
# 注册实例后：DiscoverInstances 能查到，dig 查不到
aws servicediscovery discover-instances \
  --namespace-name api-only --service-name some-svc   # ✅ 有结果
dig +short some-svc.api-only A                          # ❌ 无 hosted zone、解析不到
```

### Lab C：custom health 30s 判定窗
```bash
# 报 unhealthy；Cloud Map 等 30s 才停止路由（30s 内改回 healthy 则取消）
aws servicediscovery update-instance-custom-health-status \
  --service-id srv-xxxx --instance-id i-1 --status UNHEALTHY
# 立即再 dig 仍可能返回该实例；~30s 后才从应答里消失
```

### Lab D：EKS ExternalDNS 生产配置（IRSA + sync + owner-id + zone filter）
```yaml
# helm values 关键 args（生产）
args:
  - --source=service
  - --source=ingress
  - --provider=aws
  - --registry=txt
  - --txt-owner-id=my-eks-cluster        # 唯一，防多实例互删
  - --policy=sync                        # 生产必须（可删 stale）；默认 upsert-only 不删
  - --domain-filter=example.com          # 只动这个 zone
  - --aws-zone-type=public
```
```bash
# IRSA：OIDC + 最小权限 IAM role 绑到 external-dns ServiceAccount
eksctl create iamserviceaccount --cluster $EKS --namespace kube-system \
  --name external-dns --attach-policy-arn arn:aws:iam::$ACCT:policy/R53Min \
  --approve --override-existing-serviceaccounts
# 验证记录：删 Service 后 A + TXT 应随 sync 清理
kubectl logs -n kube-system deploy/external-dns | grep -Ei 'record|throttl'
```

### 清理
```bash
aws servicediscovery deregister-instance --service-id srv-xxxx --instance-id i-1
aws servicediscovery delete-service --id srv-xxxx
aws servicediscovery delete-namespace --id $NS   # 会删自动建的 PHZ
```

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **E1 三层模型**：Namespace（可见性+发现方式）→ Service（一个 registry，定记录/健康）→ Instance（具体端点）。一个 ECS 服务 ≈ 一个 Cloud Map service。

- **E2 三种 namespace ×发现方式（★最易错）**：
  - Public DNS / Private DNS → **DNS 发现 + API 发现**；**HTTP → 只能 API（`DiscoverInstances`），不能 dig、不建 hosted zone**。
  - Private DNS namespace 底层 = 自动建的 **PHZ 关联 VPC**（吃 R53 hosted-zone 配额，见 topic 12）。
  - ❌ 常见错误：以为 HTTP namespace 也能 DNS 解析。

- **E3 记录类型 + 路由策略**：
  - 类型 `A`/`AAAA`/`SRV`/`CNAME`；`awsvpc`→**A 或 SRV**，`bridge`/`host`→**只能 SRV**（要端口）。
  - **记录类型创建后不可改** → 换类型须**删 service 重建**。
  - **MULTIVALUE**：返回**最多 8 个**健康实例（无 HC 则假定全健康）。**WEIGHTED**：**随机选一个**、当前**等权**（不能真按权重分流）。**两种策略都 fail-open：无任何健康实例时按"全部健康"返回**。**Alias 与 CNAME 必须 WEIGHTED**（不支持 MULTIVALUE），**CNAME 不能配 HealthCheckConfig**。

- **E4 custom health vs R53 HC（★）**：
  - `HealthCheckConfig` = 标准 **R53 端点 HC**，**支持 Public DNS 和 HTTP namespace、不支持 Private DNS**（探的端点须公网可达）。
  - `HealthCheckCustomConfig` = **Cloud Map 不探测、只记状态**，靠 `UpdateInstanceCustomHealthStatus` 上报；报 unhealthy 后**等 30s** 才停路由（`FailureThreshold` 废弃、恒为 1）；**不是仅限 VPC 内资源**（任何实例都可用，只要有外部检查器上报），VPC 内资源（如 ECS task）因公网不可达而常用它。**二者只能选一个**。

- **E5 ECS 生命周期**：task 起 → ECS 控制面**自动 register** IP；task 停 → **自动 deregister**。"连到死实例"= **TTL/DNS 缓存 + 注销传播延迟**叠加，先调低 TTL、别缓存，不是 R53 故障。

- **E6 Service Connect vs Service Discovery（★选型）**：
  - Service Discovery = Cloud Map + 客户端 DNS 直连，粗糙。
  - **Service Connect = Envoy sidecar + 连接管理 + 内建监控**，底层用 **Cloud Map API 注册表 + 托管代理路由（不靠增删 DNS 记录）**、**可引用任何现有 namespace（未指定则新建 HTTP namespace）**、**不兼容 host 网络模式**；**官方最佳实践优先它**。

- **E7 ExternalDNS 是非托管 R53 功能（★两方点名）**：
  - **开源 K8s 控制器**（EKS community add-on），排障最终指向上游 GitHub，不是 R53 托管特性。
  - **`--registry=txt` + `--txt-owner-id`**：靠额外的 **TXT 所有权记录**判断哪些记录归自己 → 多实例/多集群共享 zone **必须各配唯一 owner-id**，否则互删。
  - **`--policy`**：默认 `upsert-only`（只增不删 → stale 残留）；**生产必须 `sync`**（且必须配 owner-id 才能删）。
  - **`--domain-filter`**：不写会动账号下所有 zone。
  - **IRSA** 授 R53 写权限；最小权限 = `ChangeResourceRecordSets`（限 hostedzone ARN）+ `ListHostedZones` + `ListResourceRecordSets`；托管 add-on 默认 `AmazonRoute53FullAccess` 过宽。
  - **限流**：撞 R53 **5 req/s** 账号限速（topic 12）→ zone filter 收窄、拉长 interval。
  - ❌ 常见错误：把 R53 里 ExternalDNS 建的 TXT 记录当垃圾删掉（它是所有权登记，删了会破坏 sync 判定）。

- **E8 配额（衔接 topic 12）**：Instances per service 1,000（不可调）、Instances per namespace 2,000（可调）、Namespaces per Region 50（可调）、`DiscoverInstances` 稳态 1,000/s 突发 2,000/s（可调）；**DNS namespace 的 instance 数受 R53"每 hosted zone 记录数"限制、提额会加钱**；namespace 自动建的 hosted zone **算进账号 R53 hosted zone 配额**。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

### 5.1 Cloud Map 三层模型 × namespace 类型 × 发现方式
```mermaid
flowchart TD
    NS{Namespace 类型} --> PUB[Public DNS<br/>建 public hosted zone]
    NS --> PRIV[Private DNS<br/>建 PHZ 关联 VPC]
    NS --> HTTP[HTTP<br/>不建 hosted zone]
    PUB --> D1[DNS 发现 + API 发现]
    PRIV --> D2[DNS 发现 + API 发现]
    HTTP --> D3[仅 API DiscoverInstances<br/>❌ 不能 dig]
    D1 & D2 --> SVC[Service = registry<br/>DnsConfig: A/AAAA/SRV/CNAME<br/>MULTIVALUE≤8 / WEIGHTED随机等权 均 fail-open<br/>Alias·CNAME 必须 WEIGHTED / 记录类型不可改→删重建]
    SVC --> INST[Instance 端点<br/>IP/端口 或 任意 metadata]
    SVC --> HC{健康检查二选一}
    HC --> HCR[HealthCheckConfig<br/>=R53 端点HC 支持 Public DNS+HTTP<br/>不支持 Private DNS · CNAME 不可配]
    HC --> HCC[HealthCheckCustomConfig<br/>Cloud Map 不探测·只记状态<br/>UpdateInstanceCustomHealthStatus+30s]
    style HTTP fill:#ffe0e0
    style D3 fill:#ffe0e0
    style HCC fill:#e0f0ff
```

### 5.2 ECS：Service Discovery vs Service Connect
```mermaid
flowchart LR
    TASK[ECS task 起/停] --> CP[ECS 控制面]
    CP -->|自动 register/deregister IP| CM[Cloud Map]
    subgraph SD[Service Discovery 旧]
      CM --> DNS[client 解析 DNS 直连<br/>awsvpc→A 或 SRV / bridge·host→仅 SRV<br/>靠 TTL+缓存 粗糙]
    end
    subgraph SC[Service Connect 新·推荐]
      CM2[Cloud Map API 注册表<br/>引用任意现有 namespace<br/>未指定则新建 HTTP] --> ENV[Envoy 托管代理<br/>连接管理+重试+内建监控<br/>按注册表路由·不靠增删 DNS 记录<br/>❌ 不兼容 host 模式]
    end
    style SC fill:#e0ffe0
    style SD fill:#fff4d6
```

### 5.3 EKS ExternalDNS（非托管）写 R53 的控制点
```mermaid
flowchart TD
    K8S[K8s Service/Ingress] --> ED[ExternalDNS 控制器<br/>开源·EKS community add-on]
    ED -->|IRSA: OIDC+IAM role| PERM[R53 权限<br/>ChangeRRSets+ListHZ+ListRRSets]
    ED --> POL{--policy}
    POL --> UP[upsert-only 默认<br/>只增不删→stale 残留]
    POL --> SY[sync 生产<br/>可删·须配 owner-id]
    ED --> REG[--registry=txt + --txt-owner-id<br/>TXT 所有权登记<br/>多实例/多集群必须唯一→防互删]
    ED --> FILT[--domain-filter<br/>不写=动所有 zone]
    ED -.高频 Change.-> THR[[撞 R53 5 req/s 限速<br/>zone filter+拉长interval缓解]]
    style UP fill:#ffe0e0
    style SY fill:#e0ffe0
    style THR fill:#fff4d6
```

---

## 来源（Sources）

- Cloud Map API 参考：`DnsConfig`（RoutingPolicy=MULTIVALUE 返回最多 8 个健康实例 / WEIGHTED 随机且当前等权 / alias 用 WEIGHTED；DnsRecords 记录类型不可 update，须删 service 重建）—— docs.aws.amazon.com/cloud-map/latest/api/API_DnsConfig.html
- Cloud Map API 参考：`HealthCheckCustomConfig`（Cloud Map 不直接探测、只记 `UpdateInstanceCustomHealthStatus` 状态；报 unhealthy 后等 30s 停路由；FailureThreshold 废弃恒为 1；VPC checker 须在 VPC 内；与 `HealthCheckConfig` 二选一）—— docs.aws.amazon.com/cloud-map/latest/api/API_HealthCheckCustomConfig.html
- Cloud Map SDK：`CreateHttpNamespace`（HTTP namespace 实例只能 `DiscoverInstances`、不能 DNS 发现）
- Cloud Map Developer Guide：service quotas（Instances per service 1,000 不可调 / per namespace 2,000 可调 / Namespaces per Region 50 / DiscoverInstances 稳态 1,000·突发 2,000；namespace 自动建的 hosted zone 计入 R53 配额、DNS 实例提额需加 R53 记录配额并加钱）—— cloud-map/latest/dg/cloud-map-limits.html；Shared namespaces（配额归属）；FAQ（public/private namespace 可见性定义）
- ECS：repost「How do I allow the tasks in my Amazon ECS services to communicate with each other?」（Service Connect 为最佳实践、用 Cloud Map API 注册表+Envoy 代理路由而非增删 DNS 记录、不兼容 host、service discovery awsvpc 支持 A/SRV、bridge/host 仅 SRV）；AWS Architecture 博客「Application Integration with AWS Cloud Map」（ECS 控制面自动 register/deregister task IP）；Containers/OpenSource 博客（三组件 create-private-dns-namespace→create-service→register-instance，`{service}.{namespace}` 私有 DNS 名，WEIGHTED+A+TTL）；ECS API `ClusterServiceConnectDefaultsRequest.namespace`（Service Connect 可引用现有任意 namespace，未指定则新建 HTTP namespace / "API calls" 发现）
- ECS CDK 文档：`cloudMapOptions`（awsvpc→A 或 SRV、bridge/host→仅 SRV，可指定容器/端口）
- EKS：Community add-ons（`external-dns` add-on，权限可收敛到 `route53:ChangeResourceRecordSets`+`ListHostedZones`+`ListResourceRecordSets`，托管默认 `AmazonRoute53FullAccess`）；repost「How do I set up ExternalDNS with Amazon EKS?」（IAM policy + OIDC + IRSA + Helm）；SageMaker HyperPod Direct-SSH 文档（生产 `--policy=sync`（默认 upsert-only 不删致 stale）、`--txt-owner-id` 标识所有权、`--domain-filter` 限定 zone、`--source=service`）
- Data Prepper peer-forwarder（`discovery_mode: aws_cloud_map` + `aws_cloud_map_query_parameters` 按自定义属性过滤——API discovery 用法）
- 交叉锚点：topic 01（PHZ）、topic 02（记录类型）、topic 03（MULTIVALUE/WEIGHTED 路由策略语义）、topic 04（健康检查）、topic 12（Cloud Map/R53 配额与 5 req/s API 限速）

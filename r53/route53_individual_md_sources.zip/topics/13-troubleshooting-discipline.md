# Topic 13：通用故障排查纪律（横切）

> 本 topic 是横切方法论，不绑定单一 R53 组件。它教 SME 在面对任意 R53/DNS 故障时，如何**建模、取证、定级、下结论**，避免最常见的两类错误：把单点当全局、把必要条件当充分条件。

---

## 1. 概念：排查纪律

DNS/R53 故障排查的核心不是"知道哪个组件会坏"，而是**用什么纪律去判断一个结论能不能下**。以下六条纪律贯穿所有 R53 case。

### 1.1 单点 vs 全局

一个实例（一台 EC2、一个 client、一次查询）解析失败，**不等于**服务整体故障。反过来，一次查询成功也**不等于**路径整体健康。

- R53 Resolver 的 Outbound/Inbound Endpoint 通常有 **多个 ENI**（IpCount≥2），Resolver 可经任一 ENI 发出查询。如果只有一个 ENI 的路径被阻断，则**部分查询成功、部分超时**——表现为"时好时坏"。
- 判断维度：失败是**确定性**（100% 失败）还是**概率性**（部分失败）？确定性全失败往往指向"所有路径共有的一环"（VPC DNS、权威 NS、目标 DNS 本身）；概率性失败往往指向"多路径中的某一条"（某个 ENI 子网的 NACL、某条 TGW 路由）。
- 纪律：**永远先界定故障范围（blast radius）再归因**。问清楚"是所有 client 还是这一台？所有域名还是这一个？所有查询还是偶发？"

### 1.2 证据分级

每条结论必须标注证据强度。四级：

| 级别 | 含义 | 措辞 |
|---|---|---|
| **DIRECTLY_OBSERVED** | 从客户提供的真实导出/日志/工具输出直接读到 | "已确认"/"observed" |
| **DOCUMENTED_FACT** | 官方文档明确规定的行为（如 VPC DNS = CIDR base + 2） | "根据文档" |
| **INFERENCE** | 由观测+文档推出，但存在反例可能 | "suggests"/"很可能" |
| **UNKNOWN** | 未验证、需客户提供 | "待确认"/列入索取清单 |

纪律：**回复中的每个断言都要能对应到一个级别**。INFERENCE 用"suggests"而非"is"；UNKNOWN 绝不当成事实写进结论或承诺。

### 1.3 必要非充分条件

发现一个阻断点（如某 NACL 拦了 DNS），**修它是恢复的必要条件，但不一定是充分条件**。可能同时存在第二个问题（TGW 路由不可达、目标 DNS 不响应）。

纪律：**不要承诺"修 X 就好了"**，除非已证明 X 是唯一阻断点。措辞用"这是需要修复的一处；同时请确认 A/B/C"。

### 1.4 VPC DNS（.2 resolver）不过 SG/NACL

VPC 内 EC2 到 **AmazonProvidedDNS（VPC CIDR base + 2，如 10.201.244.2）** 的查询流量，**不经过 Security Group、NACL、路由表**。这是 AWS 底层实现，不是可配置的数据面路径。

纪律：客户/AI 初稿常错误建议"检查 EC2 到 .2 的 SG/路由"。**SME 必须纠正方向**——EC2→VPC DNS 这段不可能被 SG/NACL 阻断，真正的阻断点在下游（Resolver Endpoint 的 ENI 子网 NACL、转发目标的路由）。

### 1.5 dig 分层定位

用 `dig` 逐层拆解"是权威侧问题还是递归侧问题"：

| 命令 | 定位什么 |
|---|---|
| `dig example.com NS` | NS 记录是否指向 R53 |
| `dig +trace example.com` | 从根逐级委派，定位断在哪一层委派 |
| `dig @ns-xxx.awsdns-yy.com example.com A` | 直接问**权威** NS（绕过递归缓存） |
| `dig +cd example.com` | 关闭 DNSSEC 校验，区分"记录错" vs "DNSSEC 验证失败" |
| `dig @10.x.x.x example.com`（指定 NS） | 直接问某个递归/转发目标，定位单点 |

纪律：**权威查询与递归查询要分开测**。权威直查成功但递归失败 → 递归/缓存/转发链问题；权威直查就失败 → 记录本身或委派问题。

### 1.6 响应码含义

| 响应 | 含义 | 常见方向 |
|---|---|---|
| **NXDOMAIN** | 权威明确回答"此名不存在" | 记录缺失/拼写/未创建；**是权威的确定回答，不是网络问题** |
| **SERVFAIL** | 递归/权威处理失败 | DNSSEC 验证失败、转发目标不响应、上游超时 |
| **REFUSED** | 服务器拒绝应答此查询 | 权限/ACL、非授权区、递归被关 |
| **timeout** | 根本没收到响应 | **网络层**：SG/NACL/路由阻断、目标 DNS 宕、UDP 分片丢失 |

纪律：**timeout 是网络问题，NXDOMAIN 是数据问题**。二者排查方向完全不同——把 timeout 当成"记录没配"会走错路。

### 1.7 负缓存 / TTL

- 记录的 TTL 决定改动后旧值还会被缓存多久。
- **负缓存（SOA minimum / negative TTL）**：NXDOMAIN 也会被缓存。刚创建一条记录，客户可能仍解析失败，因为之前的 NXDOMAIN 还在递归器负缓存里。
- 纪律：改完记录后若客户说"还是不通"，先问"等了多久？用了哪个递归器？"再直查权威确认改动已生效。

### 1.8 不做唱因归因（no premature root-causing）

在证据不足时，**不要为了给客户一个"确定的答案"而把 INFERENCE 说成根因**。收集证据 → 逐条定级 → 只对 DIRECTLY_OBSERVED 的阻断下"已确认"，其余列为待确认。宁可回复"这是一处确认的阻断，另有 A/B 需确认"，也不要唱一个未经证实的单一根因。

---

## 2. 真实案例

### 案例 A — Case 178222843600312（ysshop，三域名解析突然失效）

**现象**：客户三个域名（shop-app-admin.com / yaoshen123.com / yaoshenwang.com）"昨天正常、今早全挂"。

**排查纪律应用**：
- **单点 vs 全局**：三个域名**同时**失效 → 指向"三者共有的一环"（同一账户、同一 Hosted Zone、或注册商 NS 被改），而非单条记录。
- **分层取证顺序**：先 `whois`（域名注册状态/过期/NS 设置）→ 再 `dig <domain> NS`（NS 是否仍指 R53）→ 再查 R53 Hosted Zone 是否存在、NS 是否匹配 → 最后 CloudTrail 查 24-48h 内 `ChangeResourceRecordSets`/`DeleteHostedZone`/`UpdateDomainNameservers`。
- **响应码分层**：若 `dig NS` 返回 NXDOMAIN/无委派 → 注册商侧 NS 问题；若 NS 正确但 `dig A` 超时 → R53 侧或记录问题。
- **不唱因**：现象一致但根因未定，分析文档列出 5 个候选方向（域名过期、Hosted Zone 配置、注册商 NS 被改、记录被删、账户级问题），逐一给验证命令，**不预先断言是哪一个**。

**教学点**：多资源同时失效 → 找公共因子；`whois`→`dig NS`→控制台→CloudTrail 是"注册/委派链"故障的标准取证序列。

### 案例 B — Case 178767531400698（J Crew，EC2 无法解析 jcrew.com，三次全超时）

**现象**：EC2 `nslookup jcrew.com 10.201.244.2` 三次全部 `communications error ... timed out`。

**排查纪律应用**：
- **VPC DNS 不过 SG/NACL**：`10.201.244.2` = VPC CIDR（10.201.244.0/22）base + 2 = AmazonProvidedDNS（DOCUMENTED_FACT + VPC CIDR DIRECTLY_OBSERVED）。EC2→.2 这段**不经 SG/NACL**。Genie AI 初稿建议"查 EC2 到 .2 的 SG/路由"——**方向错误，SME 纠正**：真正阻断点在下游 Resolver Outbound Endpoint 的 ENI 子网 NACL。
- **响应码含义**：现象是 **timeout**（不是 NXDOMAIN）→ 网络层，不是记录问题。
- **证据分级**：NACL `acl-04b92237c4b6395f1`（ENI2 子网）出站命中 `Rule 63 DENY 10.0.0.0/8`、入站仅放行 TCP ephemeral 缺 UDP ephemeral（均 DIRECTLY_OBSERVED，逐条比对客户导出）；目标 DNS 10.201.244.12 是否健康、TGW 双向路由是否有效均 UNKNOWN。
- **单点 vs 全局 + 必要非充分**：Outbound Endpoint 有 2 个 ENI，Resolver 可经任一发出。ENI2 被双向阻断。但客户**三次全超时**——若 ENI1 路径畅通，应有部分成功。三次全失败构成"ENI1 路径亦有问题"的反向证据（INFERENCE，附反例检查：Resolver ENI 选择若粘滞则不成立）。**结论：修 NACL 是必要条件而非充分条件**，回复用"suggests"、不承诺修完即恢复，并把 TGW 路由/目标 DNS 列入索取清单。
- **差分诊断设计**：`nslookup`（UDP）vs `nslookup -vc`（TCP）vs SRV 查询，用于区分 UDP 腿 / TCP 腿 / 记录类型问题；并注明单次成功不能证明两条 ENI 都通。

**教学点**：`.2` = CIDR+2 且不过 SG/NACL；timeout=网络层；多 ENI 下"三次全超时"是判断"单点还是全局"的关键信号；确认的阻断只是必要条件，不做充分性承诺。

---

## 3. 实验步骤（复现"单点 vs 全局"区分）

目标：用 `dig` 分层实验，亲手区分**单点故障**与**全局故障**，并练习证据定级。

### 实验环境
- 任意 Linux 主机（装 `bind-utils` / `dnsutils` 获得 `dig`）。
- 一个自有域名 + 一个 R53 Hosted Zone（或用公共域名做只读观测）。

### 步骤 1：建立"全局正常"基线（权威 vs 递归分层）
```bash
# 递归查询（走本机配置的 resolver）
dig example.com A

# 直查权威 NS（绕过递归缓存）——先拿到权威
dig example.com NS +short
dig @ns-123.awsdns-45.com example.com A     # 用上一步返回的某个 NS

# 从根逐级委派
dig +trace example.com
```
> 判读：递归与权威都返回一致 A 记录 = 全局健康基线。记录每条结果的证据级别（此处均 DIRECTLY_OBSERVED）。

### 步骤 2：制造"单点故障"并观察（只影响一个 client）
```bash
# 在 client A 上把 resolver 指向一个不可达/错误的 DNS
#（实验：临时改 /etc/resolv.conf 指向一个黑洞 IP，如 192.0.2.1）
dig example.com A            # 预期 timeout

# client B 不动，仍用正常 resolver
dig example.com A            # 预期成功
```
> 判读：A 超时、B 成功 → **单点**（client A 的配置/路径问题），权威本身健康。这就是"一个实例失败 ≠ 服务故障"的实证。恢复 resolv.conf。

### 步骤 3：制造"全局故障"并观察（所有 client 都受影响）
```bash
# 在 R53 控制台把某条 A 记录删除，或改错 NS 委派（实验环境）
# 等待/清缓存后，从多个 client 分别查
dig @<权威NS> example.com A +short          # 直查权威：预期 NXDOMAIN 或无 A
dig example.com A                            # 递归：清负缓存前可能仍返回旧值
```
> 判读：多个 client **一致**失败、且**直查权威**就已失败 → **全局**（数据/委派问题）。恢复记录后立刻 `dig @权威` 确认已生效，再解释负缓存导致递归侧的延迟。

### 步骤 4：区分响应码
```bash
dig doesnotexist.example.com A          # 观察 NXDOMAIN（权威确定回答）
dig @192.0.2.1 example.com A            # 观察 timeout（网络不可达）
dig +cd example.com A                   # 关 DNSSEC 校验，若原来 SERVFAIL 现在成功 → DNSSEC 问题
```
> 判读：把 NXDOMAIN（数据）/ timeout（网络）/ SERVFAIL（处理失败）三种排查方向分清。

### 步骤 5：负缓存实测
```bash
# 步骤3删记录后先查一次（进负缓存），再重建记录，立即递归查
dig example.com A          # 重建后仍可能 NXDOMAIN —— 负缓存未过期
dig @<权威NS> example.com A # 直查权威已是新值 —— 证明是缓存而非配置问题
```
> 判读：递归失败但权威成功 = 缓存滞后，不是"没配好"。用 SOA 的 minimum 估算等待时间。

**清理**：恢复所有 resolv.conf 与被删记录，确认基线恢复。

---

## 4. SME 考点 / 易错点

**考点**
- 能对任一结论标注 DIRECTLY_OBSERVED / DOCUMENTED_FACT / INFERENCE / UNKNOWN，并据此选择措辞。
- 能说出 AmazonProvidedDNS = VPC CIDR base + 2，且 EC2→该地址**不过 SG/NACL**。
- 能用 `dig` 区分权威侧 vs 递归侧、用 `+trace`/`+cd`/指定 NS 定位层级。
- 能解释 NXDOMAIN / SERVFAIL / REFUSED / timeout 各自指向的排查方向。
- 能识别"必要条件 ≠ 充分条件"，并在回复中不做充分性承诺。

**易错点**
- ❌ 把"一台实例失败"直接当成"服务故障"下结论（未界定 blast radius）。
- ❌ 建议客户检查 EC2 到 `.2` VPC DNS 的 SG/NACL/路由（该段不经这些）。
- ❌ 把 **timeout** 当成"记录没配"去查记录（timeout 是网络层）。
- ❌ 发现一个 NACL 阻断就承诺"修完即恢复"（多 ENI/多路径下常有第二处问题）。
- ❌ 改完记录客户说不通就以为改错了（可能是负缓存/TTL 未过期，应直查权威确认）。
- ❌ 把 INFERENCE 用"is/确认"措辞写进结论，或把 UNKNOWN 当事实写进承诺。
- ❌ 证据不足时为给"确定答案"而唱一个未证实的单一根因。
- ❌ 多 ENI Endpoint 下用一次查询成功就断言"整条路径都通"。

---

## 5. Mermaid 导图

```mermaid
flowchart TD
    A[收到 DNS/R53 故障] --> B{界定范围<br/>单点 vs 全局}
    B -->|一个 client/域名/偶发| C[单点方向<br/>某 client 配置 / 某 ENI 子网 NACL / 某条路由]
    B -->|多 client/域名/确定性全失败| D[全局方向<br/>VPC DNS / 权威 NS / 目标 DNS / 委派]

    C --> E{看响应码}
    D --> E
    E -->|timeout| F[网络层<br/>SG/NACL/路由/目标宕/UDP分片]
    E -->|NXDOMAIN| G[数据层<br/>记录缺失/委派错]
    E -->|SERVFAIL| H[处理失败<br/>DNSSEC/转发目标不响应]
    E -->|REFUSED| I[权限/ACL/非授权区]

    F --> J[dig 分层定位<br/>+trace / 指定NS / @权威]
    G --> J
    H --> K["dig +cd 区分 DNSSEC"]
    K --> J

    J --> L{是 EC2→.2 VPC DNS?}
    L -->|是| M[[提醒: 不过 SG/NACL<br/>阻断点在下游 Endpoint ENI 子网]]
    L -->|否| N[逐跳核 SG/NACL/路由]
    M --> O
    N --> O[对每条发现定级<br/>OBSERVED/DOCUMENTED/INFERENCE/UNKNOWN]

    O --> P{阻断点是否唯一?}
    P -->|多路径/多ENI 未证唯一| Q[必要非充分<br/>不承诺修完即恢复<br/>列 UNKNOWN 到索取清单]
    P -->|已证唯一 OBSERVED| R[给出修复<br/>直查权威验证 + 提示负缓存/TTL]
    Q --> S[回复: 已确认项用OBSERVED措辞<br/>推断用 suggests<br/>不唱因归因]
    R --> S
```

# 01. Hosted Zones（Public / Private / Split-horizon）

> 驱动表定位：第一梯队基础地基，考试占比最大。绑定真实 case 178118102100384（★合并 vs 分离）、178239640400861（PHZ 只经 VPC DNS）、178782060900806（跨区/跨账号关联、同名 PHZ 冲突）。SME 高频考点编号：B11、E27、外部第 2 节最长匹配。

---

## 1. 概念（Concept）

### 1.1 两种 Hosted Zone

- **Public Hosted Zone（公有）**：控制域名在 **internet** 上如何路由。注册域名时 Route 53 自动创建同名 public zone、分配 **4 个 name server**、写回域名。（外部研究 §2 / AboutHZWorkingWith.html）
- **Private Hosted Zone（PHZ，私有）**：与一个或多个 **VPC** 关联，只在这些 VPC 内经 Route 53 **VPC Resolver（.2 / VPC+2）** 解析。（外部 §2 / hosted-zone-private-considerations.html）

### 1.2 PHZ 的启用前提与关联

- 使用 PHZ 需 VPC 属性 **`enableDnsHostnames=true` 且 `enableDnsSupport=true`**；否则 PHZ 记录不生效。（内部 §1 / 外部 §2）
- **DHCP Option Set 指定自定义 DNS** 时，查询不走 VPC Resolver → PHZ 记录返回 **NXDOMAIN**（内部案例 Index-9 系列）。
- **跨账号关联** PHZ 到别账号的 VPC：需先做 **`VpcAssociationAuthorization`**（或改用 **Route 53 Profiles** 免此步）。（内部 §1）

### 1.3 apex（顶点）记录约束（考点核心）

- **Zone apex 不能建 CNAME**：DNS RFC 规定 CNAME 不能与其他类型共存，而 apex 已强制带 **NS + SOA** 记录 → apex 只能用 **Alias** 记录指向 AWS 资源（ELB/CloudFront/API GW/S3/同 zone 内另一记录）。（内部 §1 / 外部 §3、§4）
- 新建 zone 的 apex **NS + SOA 由 Route 53 自动生成**，迁移记录时**不复制** NS 与 SOA。（case 178118102100384 reply2）

### 1.4 PHZ 支持的路由策略与健康检查（背记表）

| 维度 | PHZ 支持 | PHZ **不支持** |
|---|---|---|
| 路由策略 | simple / failover / multivalue / weighted / latency / geolocation / geoproximity | **IP-based** |
| DNSSEC | — | **不支持**（仅 public zone） |
| 健康检查 | 可与 failover / multivalue / weighted / latency / geolocation / geoproximity 关联 | — |

来源：外部 §2（hosted-zone-private-considerations.html）。

### 1.5 Split-view / Split-horizon 与重叠命名空间

- **Split-view DNS**：同名建 **public + private 两个 hosted zone**；VPC 内解析走 PHZ（内部内容），internet 解析走 public zone。（外部 §2）
- **重叠命名空间取最长 / 最具体匹配（most-specific-match）**：当 public 与 private、或多个 PHZ 命名空间重叠（如 `example.com` 与 `accounting.example.com`），VPC Resolver 按**最具体**选中 PHZ。匹配定义 = 完全相同，或 PHZ 名是请求域名的父级；`seattle.accounting.example.com` 同时命中 `accounting.example.com` 与 `example.com`，**取更具体者**。无匹配 PHZ 时转公网递归。（外部 §2）
- **同域名 PHZ 与 Resolver Forward Rule 冲突 → Forward Rule 优先**（详见 topic 05；本域只需记结论）。（内部 §1 QA-3982）

### 1.6 子域：合并进父域 vs 保持分离（NS 委派）

- **分离**：父域用一条 **NS delegation 记录**把子域委派给独立的子 zone；只要该 NS 委派记录存在，Route 53 就把该子域的所有查询**引向子 zone**，父域里同名的记录**不会被查询**。
- **合并**：把子域记录直接作为父 zone 内的普通记录（FQDN 自带 `sub.` 前缀），删除子域的 NS 委派记录后，父 zone 直接应答。

**边界数字速记**：每个 hosted zone 收费 **$0.50/月**（前 25 个）；同一 zone **12 小时内删除不重复收费**；每 zone 记录默认配额（见 topic 12）。

---

## 2. 真实案例说明（Real Case）

### ★ 核心案例 178118102100384 —— 子域 PHZ 合并进父域 vs 保持分离

- **客户**：Habitat Energy，域名 `habitat-energy.au`，同账号（049918644387）内**同时持有** `habitat-energy.au`（父）与 `prod.habitat-energy.au`（子）两个 public zone。
- **症状 / 问题**：客户问是否应把子域 zone **合并**进父域，有何风险，还是**保持分离**？其中 `my-app.habitat-energy.au` = 客户面 URL，`my-other-app.prod.habitat-energy.au` = 内部生产系统。
- **知识点落点**：
  1. **合并技术可行**：`my-other-app.prod.habitat-energy.au` 作为父 zone 内的普通记录完全正常，不需要为子域单独建 zone —— **除非**需要不同 IAM 访问控制或不同 DNS 服务商。
  2. **NS 委派的关键行为（考点）**：只要 `prod.habitat-energy.au` 的 **NS 委派记录**还在父 zone 里，Route 53 就**始终把 `*.prod.habitat-energy.au` 的查询引向子 zone**；你在父 zone 里预建的同名记录**在删除 NS 委派前不会被查询**。这反而是安全的：**先在父 zone 建全所有记录 → 再删 NS 委派 → 最后删旧 zone**，切换无缝。
  3. **推荐结论**：鉴于客户「客户面 vs 内部」的区分，**保持分离是更好的实践**（IAM 管理边界、爆炸半径隔离、未来可独立委派）；成本差仅 $0.50/月，可忽略。但**合并也是技术上有效**的选项，客户偏好简化即可合并。
  4. **合并时的真实坑（本 case reply3 明确）**：ACM 证书验证的 **CNAME 记录必须精确复制**（否则证书续期失败）；使用 Kubernetes **ExternalDNS** 时（TXT 记录含 `heritage=external-dns`），删旧 zone 前必须把 ExternalDNS 的 `--zone-id-filter`/`--domain-filter` 改指新 zone ID，否则它会继续往已删除的旧 zone 写记录。

### 补充案例

- **178239640400861**（PHZ 只经 VPC DNS）：`inner.yxaws` PHZ 私有域名间歇性 "Name does not resolve"，根因是 K8s Pod 的 `/etc/resolv.conf` 写死了公共 DNS fallback（223.5.5.5），CoreDNS 慢时 fallback 到公共 DNS，而**公共 DNS 无法解析 PHZ → NXDOMAIN**。钉住"PHZ 只能经 VPC Resolver 解析"这条边界。
- **178782060900806**（跨区/跨账号关联、同名 PHZ 冲突）：split-horizon + 多区 DR 场景，引出 **Resolver rule regional 且优先 PHZ**、**同名 PHZ 不能同 VPC 双关联**、**PHZ 跨区/跨账号关联**、以及 Route 53 Profiles 作为 >300 VPC-PHZ 关联时的治理选项。

---

## 3. 实验步骤（Hands-on Lab）

> 主题取自驱动表：①子域 PHZ 零停机合并进父域；②`dig @169.254.169.253` 直验 VPC DNS 命中 PHZ。所有步骤为**受控/非破坏性演示**，删 zone 步骤请在测试域名上做。

### Lab A：子域 PHZ 零停机合并进父域（复现 case 178118102100384 的迁移法）

前置：父 zone `example.com` 与子 zone `sub.example.com` 均在同一账号；父 zone 里有一条 `sub.example.com` 的 NS 委派记录。

```bash
# 1) 列出子 zone 的全部记录（排除 SOA/NS），确认要搬的记录清单
aws route53 list-resource-record-sets --hosted-zone-id <CHILD_ZONE_ID> \
  --query "ResourceRecordSets[?Type!='SOA' && Type!='NS']"

# 2) 在父 zone 里把这些记录逐条 UPSERT 建好（FQDN 自带 sub. 前缀）
#    —— 此时 NS 委派仍在，父 zone 的这些记录还不会被查询（安全预建）
aws route53 change-resource-record-sets --hosted-zone-id <PARENT_ZONE_ID> \
  --change-batch file://records-to-merge.json

# 3) 降低父 zone 里 sub.example.com 那条 NS 委派记录的 TTL 到 60-300 秒，等旧 TTL 过期
#    （提前几天做，缩短切换窗口）

# 4) 删除父 zone 里 sub.example.com 的 NS 委派记录
#    —— 删除瞬间，Route 53 开始用父 zone 直接应答 *.sub.example.com
aws route53 change-resource-record-sets --hosted-zone-id <PARENT_ZONE_ID> \
  --change-batch '{"Changes":[{"Action":"DELETE","ResourceRecordSet":{...NS delegation...}}]}'

# 5) 验证解析已由父 zone 应答
dig +short app.sub.example.com
dig sub.example.com NS      # 应不再返回子 zone 的独立 NS（委派已删）

# 6) 观察 24-48h、确认无流量后，删除子 zone
aws route53 delete-hosted-zone --id <CHILD_ZONE_ID>
```

**预期与判读**：步骤 2 完成后、步骤 4 之前，`dig app.sub.example.com` 仍走子 zone（NS 委派优先）；步骤 4 之后同一查询由父 zone 应答。**关键风险**：若在父 zone 记录未建全并验证前就删 NS 委派，`*.sub.example.com` 会解析失败。**清理**：确认无误后删子 zone；若用 ExternalDNS，删 zone 前先改其 zone-id filter。

### Lab B：`dig` 直验 VPC DNS 命中 PHZ

在 VPC 内的 EC2 上执行（`169.254.169.253` 是 VPC Resolver 的固定 link-local 地址，等价于 VPC+2）：

```bash
# 直接向 VPC Resolver 查一条只存在于 PHZ 的私有记录
dig @169.254.169.253 internal.example.com +short
# 预期：返回 PHZ 里配置的私有 IP —— 证明查询命中 PHZ

# 对照：从公网 resolver 查同名（若无 public zone 同名记录）
dig @8.8.8.8 internal.example.com +short
# 预期：NXDOMAIN / 空 —— 证明公网无法解析 PHZ（呼应 case 178239640400861）
```

**判读**：VPC Resolver 命中 PHZ，公共 DNS 命不中 —— 这正是 resolv.conf fallback 到公共 DNS 会导致 PHZ 域名 NXDOMAIN 的原因。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **B11（IP-based PHZ 不支持）**：PHZ 只支持 simple / failover / multivalue / weighted / latency / geolocation / geoproximity；**IP-based routing 在 PHZ 不支持**。
  - 常见错误认知：以为 8 种路由策略在 PHZ 都能用。
- **外部第 2 节最长匹配（most-specific-match）**：重叠命名空间下 VPC Resolver 取**最具体**的 PHZ；`accounting.example.com` 胜过 `example.com`；无匹配转公网。
  - 常见错误认知：以为按创建时间/随机选一个 zone。
- **E27（Profile 最具体 / local 优先）**：跨 VPC 治理时，**local VPC 设置优先于 Profile**，域名冲突取**最具体**者；**1 VPC 只能 1 Profile**；>300 VPC-PHZ 关联建议改用 Profiles（详见 topic 10）。
- **apex 只能 Alias 不能 CNAME**：因 apex 已带 NS+SOA，CNAME 不能与其他类型共存。裸域指向 ELB/CloudFront 必须用 **A-Alias**。
- **PHZ 只能经 VPC Resolver 解析**：公共 DNS 无法解析 PHZ；resolv.conf/DHCP Option Set 指向自定义或公共 DNS 会导致 PHZ 记录 **NXDOMAIN**（case 178239640400861）。
- **NS 委派存在期间父 zone 同名记录不被查询**：合并子域时，先建全记录再删 NS 委派，切换无缝；顺序颠倒会解析失败（case 178118102100384）。
- **迁移不复制 NS 与 SOA**：新 zone 的 apex NS+SOA 由 Route 53 自动生成，保持原样，只搬其余记录。
- **PHZ 不支持 DNSSEC**（仅 public zone，详见 topic 07）。
- **跨账号关联 PHZ 需 `VpcAssociationAuthorization`**（或用 Profiles 免此步）；启用 PHZ 需 `enableDnsHostnames` + `enableDnsSupport`。
- **删除带 KSK 的 zone 报 `HostedZoneNotEmpty`**：需先 deactivate/delete KSK（内部 §1 QA-325）。
- **边界数字**：hosted zone $0.50/月（前 25 个）；同 zone 12h 内删不重复收费；每 PHZ 关联 **300 VPC**（更多用 Profiles）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

VPC 内一次查询在 Hosted Zone / Resolver 层的解析决策链（含最长匹配与合并/分离的委派分支）：

```mermaid
flowchart TD
    Q["VPC 内发起 DNS 查询<br/>(经 VPC+2 / .2 Resolver)"] --> FR{"存在匹配的<br/>Resolver Forward Rule?"}
    FR -- "是" --> FWD["转发到规则目标<br/>(Forward Rule 优先 PHZ)"]
    FR -- "否" --> PHZ{"存在匹配的 PHZ?<br/>(取最长/最具体匹配)"}
    PHZ -- "命中" --> SUB{"该子域有<br/>NS 委派记录?"}
    SUB -- "有 (分离)" --> CHILD["引向子 zone 应答<br/>父 zone 同名记录不被查询"]
    SUB -- "无 (合并)" --> PARENT["父 zone 直接应答<br/>(sub. 前缀普通记录)"]
    PHZ -- "未命中" --> PUB["转公网递归<br/>(Public zone / internet)"]

    PARENT --> APEX{"是 zone apex?"}
    APEX -- "是" --> ALIAS["只能 Alias<br/>(禁 CNAME: 已带 NS+SOA)"]
    APEX -- "否" --> REC["普通记录<br/>(A/AAAA/CNAME/Alias...)"]

    classDef warn fill:#fde,stroke:#b36;
    class FWD,CHILD warn;
```

> 图注：`Forward Rule > PHZ > 公网` 的优先级链跨 topic 05；本域重点是 **PHZ 最长匹配** 与 **NS 委派决定「子域走子 zone 还是父 zone」** 两个决策点。

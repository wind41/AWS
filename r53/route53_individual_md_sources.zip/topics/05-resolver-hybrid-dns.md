# 05. Resolver 与混合 DNS（解析优先级）

> 高频重灾区（第二梯队之首）。真实 case 最集中，考试最爱考**解析优先级链**与 **Inbound/Outbound 方向**。绑定 case：178602594200640（Forward Rule > PHZ > 公网，★核心）、178767531400698（多 ENI + NACL，★核心）。
> 来源锚点：内部 §5（QA-385 / QA-1466 / Learn108 / BootCamp 1154827 / Networking TFC）；外部 §7 + §15.D（考点 D20–D24）+ re:Post forwarding-rule-and-phz。

---

## 1. 概念（Concept）

### 1.1 VPC Resolver（.2 / VPC+2 架构）
- VPC 内所有资源的 DNS 入口是 **VPC Resolver**，接入地址是 **VPC+2**：VPC 主 CIDR 基地址 +2（经典的 ".2 resolver"，也叫 AmazonProvidedDNS）。例：VPC CIDR `10.201.244.0/22` → VPC DNS = **10.201.244.2**（case 178767531400698 实证）。
- VPC Resolver 默认在所有 VPC 可用，对 VPC 内资源递归应答三类名字：**公网记录（递归查询）、VPC 专有 DNS 名、关联到该 VPC 的 PHZ 记录**。
- **VPC Resolver 是 Regional 服务，不是 global**（区别于 Public DNS / Domains 的全球性）。
- **关键边界：EC2 → VPC DNS（.2）的流量不经过 SG / NACL / 路由表。** 这是排障最常见的方向性误判（见 §2 case 二的 Genie 初稿纠错）。
- 来源：外部 §7 resolver.html；内部 §5 QA-385。

### 1.2 Inbound / Outbound Endpoint（方向易混，考点 D21）
| Endpoint | 方向 | 用途 |
|---|---|---|
| **Inbound** | on-prem → AWS | 让本地/其他网络向本 VPC 发 DNS 查询，解析 PHZ / AWS 内部名 |
| **Outbound** | AWS → on-prem | 让本 VPC 的查询转发到本地/其他网络的 DNS |

- **Outbound endpoint 是私有 IP**；要转发到公网 DNS（8.8.8.8 等）需经 **NAT Gateway**（外部 §7 + 内部 BootCamp 1154827）。
- 混合云（VPN / Direct Connect）DNS：outbound endpoint 把查询转发到 on-prem resolver；on-prem 把 AWS 名转发到 inbound endpoint。

### 1.3 Resolver Rule（条件转发规则）
- **Conditional forwarding rule**：每个域名一条转发规则，指定把该域名的查询转发到哪些目标 DNS IP；直接作用于 VPC。
- **`.`（dot）rule**：你**手动创建**的、域名为 `.` 的 **FORWARD 规则**，覆盖除更具体规则（PHZ / AWS 内部名的 autodefined 规则）以外的所有域名。**要把 VPC 内几乎所有查询都转发到企业 DNS，就建一条域名为 `.` 的 FORWARD 规则**（case 178602594200640 实证）。
  - ⚠️ **`.` 规则并非真的转发"全部"查询**：VPC Resolver 仍保留一批 AWS 内部域名（见 autodefined system rules 列表，如部分 amazonaws.com 子域、反向 DNS）不转发，否则会破坏内部功能。要强制连这些也转发，需把 VPC 的 `enableDnsHostnames` 设为 false，或为这些内部域名单独建规则。
  - 不要把这条你创建的 `.` FORWARD 规则与默认的 `Internet Resolver`（Type=Recursive、不可删）混为一谈。
- **Rule 必须关联一个 outbound endpoint 才生效。**
- **RAM 跨账号共享（考点 D24）**：一个账号建的 forward rule 可用 AWS RAM 共享给**同 Region** 其他账号；共享 rule 的父账号 outbound endpoint 也随之共享，无需额外 VPC peering；成员账号不能改/删共享 rule。

### 1.4 解析优先级链（★★★ 最核心考点 D22 / D23）
对 VPC 内的一次 DNS 查询，VPC Resolver **首先按"最具体域名匹配（most-specific match）"选规则**；当多条规则命中的域名层级相同时，再按**规则类型优先级**打破平手：

```
同域名层级时的类型优先级：
1. Route 53 Resolver Forward Rule   ← Resolver 转发规则
   ↓
2. Private Hosted Zone (PHZ) 规则    ← 关联到该 VPC 的 PHZ
   ↓
3. Auto-defined / Internal 规则      ← amazonaws.com 等 AWS 内部名（含反向 DNS 自动规则）
   ↓
4. 默认 Recursive 规则 "Internet Resolver" → 公网递归 DNS → Public Hosted Zone
```

**两条铁律**：
- **同域名层级时 Forward Rule 优先于 PHZ，PHZ 优先于内部规则**（官方 knowledge-center：same domain level → 1. Resolver rule / 2. Private hosted zone rule / 3. Internal rule）。同一域名既有 PHZ 又有 Forward Rule 时，**Rule 胜**，查询被转发出去而不是用 PHZ 记录解析。
- **先比"最具体"，再比"类型"**：更具体的域名匹配永远优先于更泛的匹配，**跨类型也如此**——例如 `acct.example.com` 的 PHZ 会胜过 `example.com` 的 Forward Rule（因为前者更具体）；只有当两者域名层级相同时才用上面的类型优先级。（`accounting.example.com` 胜过 `example.com`）
- **System 规则可"反向覆盖"Forward Rule**：Forward Rule 默认作用于该域名及其所有子域；若想让某子域**不**被转发、改由 VPC Resolver 本地解析，为该子域建一条 **System 规则**（例：`example.com` 建 FORWARD、`acme.example.com` 建 System，则 acme 子域不转发）。这正是 case 一"方案 B（加更具体的 System Rule）"的机制。
- **默认递归规则名为 `Internet Resolver`（Type=Recursive），不可删除**；它对所有没有自定义规则、也没有 autodefined 规则命中的域名做递归解析。
- 来源：官方 knowledge-center route-53-fix-dns-resolution-private-zone / route-53-override-reverse-dns-rules；DeveloperGuide resolver-rules 系列；内部 §5 QA-3982 + Sage #275365 / #221751。

### 1.5 QPS / 吞吐边界（务必背记）
- **每 Outbound Endpoint 最多 6 个 ENI**，可承受高达 **~60,000 请求/秒**（每 ENI 分担一部分）。
- **每 ENI ~10K QPS**，但**经 NLB 或 Security Group 会因强制 connection tracking 把每 ENI 有效 QPS 从 ~10K 降到 ~1.5–1.7K（约 6 倍下降）**——高 QPS 场景应避免把 Resolver 流量经 NLB。
- ⚠️ **别与 1024 PPS 混淆**：EC2 实例每个网络接口 → VPC+2 link-local 最多 **1024 packets/second 且不可调**（见 topic 12 配额域）；这是**实例侧**限制，与 **endpoint 侧** ~10K QPS/ENI 是两回事。
- 来源：内部 §5 Learn108 + Networking TFC（Resolver QPS 段）。

### 1.6 resolv.conf fallback 陷阱
- 客户端 `/etc/resolv.conf` 若在 VPC DNS 之外还列了公共 DNS（8.8.8.8）做 fallback，当 VPC DNS 因 PHZ 无记录返回 NXDOMAIN 时，客户端会转向公共 DNS，导致本应命中 PHZ 的私有名解析失败/解析到公网结果（关联 case 178239640400861，resolv.conf fallback）。

---

## 2. 真实案例说明（Real Case）

### ★核心 Case 一：178602594200640 —— Forward Rule > PHZ > 公网（SP Global）
- **症状**：域名 `soaapi-av.spgidev.spglobal.com` 在 Public HZ 里明明配成 A(Alias) 指向 Kong NLB，客户在 VPC 内却解析到旧的 Apigee ELB（10.95.145.77 / 10.95.146.46）。
- **排查路径**：先确认 Public HZ 配置 100% 正确（Kong NLB，无 apigee 记录）→ 搜 6 个 spglobal.com PHZ 均无该记录 → **发现两条 FORWARD 规则**：`SPG`（`spglobal.com.` → 企业 Infoblox DNS 10.164.130.42/61/71）和 `RULE-INFOBLX`（`.` 全局 → 企业 DNS）。
- **根因落点**：查询在 VPC Resolver 层就命中 Forward Rule 被转发到企业 DNS，**根本没到达公网 Route 53**；企业 DNS 返回了未同步的旧 Apigee 记录。客户做 Apigee→Kong 迁移只改了 R53 Public HZ，没同步企业 DNS。
- **知识点**：这就是「Forward Rule > PHZ > 公网」的教科书现场。**方案 C（在 PHZ 加正确记录）不可行**——PHZ 优先级低于 Forward Rule，加了也不生效；正解是 A（在 Infoblox 上更新/删除该记录）或 B（加更具体的 System Rule 让子域不走 Forward Rule）。
- **SME 提醒**：大企业 hybrid DNS case **先查 Resolver Rules**，Forward Rule 是比 PHZ 更常见的 DNS 覆盖来源；看到 `.`(dot) 全局 Forward Rule 就知道 VPC 内永远走企业 DNS、不走公网。

### ★核心 Case 二：178767531400698 —— 多 ENI + NACL 双向放行（J Crew）
- **症状**：EC2（AL2023）无法加域，`nslookup jcrew.com 10.201.244.2` 三次全超时（`communications error ... timed out`）。
- **场景建模**：10.201.244.2 = VPC DNS（CIDR `10.201.244.0/22` +2）。流量路径：EC2 → VPC DNS（**不过 SG/NACL**）→ Forward Rule `jcrew-com-DR` → Outbound Endpoint（有 **2 个 ENI**：10.201.200.201 / .216，位于**另一个 VPC**）→ 目标 DNS 10.201.244.12。
- **根因**：Outbound Endpoint 的 **ENI2 所在子网 NACL** 阻断了到目标 DNS 的 DNS 流量——出站命中 `Rule 63 DENY 10.0.0.0/8`（目标 10.201.244.12 落在 10.0.0.0/8 内）；入站只有 `Rule 99 ALLOW TCP 1024-65535`，**UDP DNS 回包被隐式 DENY**。精确缺口 3 条：出站 UDP 53、出站 TCP 53、入站 UDP ephemeral（入站 TCP ephemeral 已被 Rule 99 覆盖，不需新增）。
- **多 ENI 关键推断**：Resolver 可经任一 ENI 发出查询。ENI2 被双向阻断必然超时；但**三次全超时**说明 ENI1 路径可能也有问题（TGW 路由 / 目标 DNS 不响应）→ **NACL 修复是必要条件而非充分条件**，不能承诺"修了就好"。
- **方向性纠错**：Genie AI 初稿建议查 EC2→10.201.244.2 的 SG/路由——**错**，因为 EC2 到 VPC DNS 的流量不经 SG/NACL/路由表，真正阻断点在 Outbound Endpoint 的 ENI 子网 NACL。
- **知识点**：Outbound Endpoint 的**每个 ENI 子网都要在 NACL 上双向放行 DNS**（出站 UDP/TCP 53 + 入站 UDP/TCP ephemeral 1024-65535）；多 ENI 跨不同子网/NACL 时配置必须一致，否则部分查询超时、表现为间歇故障。

---

## 3. 实验步骤（Hands-on Lab）

> 主题（驱动表）：建 outbound endpoint + resolver rule 观察混合解析；差分诊断 UDP vs TCP。
> 标注：以下为**受控实验**（在测试 VPC 内做），涉及 Endpoint/Rule 会产生小额费用，实验后清理。

### 步骤 A：建 Outbound Endpoint（观察混合解析路径）
```bash
# 前提：一个测试 VPC，2 个不同 AZ 的私有子网，一个允许 DNS 的 SG
# 1) 建 outbound endpoint（2 个 ENI，跨 2 AZ）
aws route53resolver create-resolver-endpoint \
  --creator-request-id lab-$(date +%s) \
  --name lab-outbound \
  --direction OUTBOUND \
  --security-group-ids sg-xxxxxxxx \
  --ip-addresses SubnetId=subnet-aaa SubnetId=subnet-bbb
# 预期：返回 ResolverEndpointId=rslvr-out-xxxx，Status=CREATING → OPERATIONAL
# 记下 ENI 私有 IP（两条），后面要在这两个 ENI 子网的 NACL 上放行 DNS
```

### 步骤 B：建 Forward Rule 并关联 VPC（观察优先级压过 PHZ）
```bash
# 2) 对 example.internal. 建 FORWARD 规则，目标指向你的测试 DNS（可临时指向另一台跑 dnsmasq 的 EC2）
aws route53resolver create-resolver-rule \
  --creator-request-id lab-rule-$(date +%s) \
  --name lab-fwd-example \
  --rule-type FORWARD \
  --domain-name example.internal. \
  --resolver-endpoint-id rslvr-out-xxxx \
  --target-ips Ip=10.0.5.53,Port=53
# 3) 关联到测试 VPC
aws route53resolver associate-resolver-rule \
  --resolver-rule-id rslvr-rr-xxxx --vpc-id vpc-xxxx
```
**对照实验（验证 Forward Rule > PHZ）**：先在测试 VPC 关联一个 `example.internal` 的 PHZ、里面放一条 A 记录；再建上面的 Forward Rule 指向另一个目标。从 VPC 内 EC2 执行：
```bash
dig example.internal @10.0.0.2 +short     # .2 = VPC DNS（按你 VPC CIDR 换算）
# 预期：返回的是 Forward Rule 目标 DNS 的应答，而不是 PHZ 里的 A 记录
# → 现场验证「Forward Rule 优先于 PHZ」
```

### 步骤 C：差分诊断（UDP vs TCP，定位出站/入站/路由/目标故障）
```bash
dig example.internal @10.0.0.2            # 默认 UDP
dig example.internal @10.0.0.2 +tcp       # 强制 TCP
dig -t SRV _ldap._tcp.example.internal @10.0.0.2   # AD SRV 记录
```
判读（源自 case 二测试方案）：
- **UDP 失败 / TCP 成功** → UDP 腿有问题：出站 UDP 53 或入站 UDP ephemeral 未放行、目标 DNS 不应答 UDP、或 UDP 响应分片被丢。
- **两者都失败** → 出站被拦 / 跨网络路由不可达 / 目标 DNS 不响应。
- **均成功** → 该路径通；但因 Resolver 可经任一 ENI 发出，**单次成功不能证明两条 ENI 路径都通**——若"有时成功有时超时"，是另一条 ENI 子网 NACL/路由未修好。

### 步骤 D：NACL 放行清单（Outbound Endpoint 每个 ENI 子网都要）
```
出站  UDP 53   → 目标DNS/32
出站  TCP 53   → 目标DNS/32
入站  UDP 1024-65535  from 目标DNS/32
入站  TCP 1024-65535  from 目标DNS/32
# 规则号要放在所有 DENY 之前，用最小 /32 范围
```

### 步骤 E：混合 DNS 中的 Pod 视角（可选）
```bash
kubectl exec -it <pod> -- cat /etc/resolv.conf   # 看 dnsPolicy 与 nameserver 是否指向 CoreDNS/VPC DNS
```

### 清理
```bash
aws route53resolver disassociate-resolver-rule --resolver-rule-id rslvr-rr-xxxx --vpc-id vpc-xxxx
aws route53resolver delete-resolver-rule --resolver-rule-id rslvr-rr-xxxx
aws route53resolver delete-resolver-endpoint --resolver-endpoint-id rslvr-out-xxxx
```

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

逐条对应外部 §15.D（D20–D24）+ 内部边界数字：

- **D20 VPC+2 / .2 resolver**：VPC 内解析入口 = VPC 主 CIDR 基地址 +2，默认所有 VPC 可用。
  - ✅ 结论：`10.201.244.0/22` → VPC DNS = 10.201.244.2。
  - ❌ 常见错误：以为 EC2→VPC DNS 的流量受 SG/NACL/路由表管控（实际**不经过**）——这是排障最大方向性坑（case 二 Genie 初稿即犯此错）。

- **D21 Inbound vs Outbound 方向**：Inbound = on-prem→AWS 查询；Outbound = AWS→on-prem 查询。
  - ❌ 常见错误：方向记反。记忆法：**In**bound 是"别人进来查我"，**Out**bound 是"我出去查别人"。
  - 附加：Outbound 出公网需 NAT Gateway（outbound endpoint 是私有 IP）。

- **D22 Resolver 转发规则优先于 PHZ（★最高频）**：**同域名层级**冲突时 **Forward Rule 胜**。
  - ✅ 结论：同层级类型优先级 **Forward Rule > PHZ > 内部/autodefined 规则 > 默认 Recursive 规则 `Internet Resolver`（公网递归）**；但先比"最具体域名匹配"，再比类型——更具体的匹配跨类型也优先。
  - ❌ 常见错误：以为"在 PHZ 里加条记录就能覆盖"——同层级时 PHZ 优先级低于 Forward Rule，加了不生效（case 一方案 C 不可行的原因）；正解是改企业 DNS，或为子域建更具体的 System 规则让它本地解析。
  - ❌ 常见错误：忘了 `.`(dot) FORWARD 规则会把 VPC 内**几乎所有**查询转出去（AWS 内部名仍默认保留不转），也别把它与默认的 `Internet Resolver` 递归规则混淆。

- **D23 重叠命名空间取最长/最具体匹配**：`accounting.example.com` 胜过 `example.com`；匹配定义 = 完全相同或 PHZ/Rule 名是请求域名的父级。**"最具体"跨规则类型都成立**，只有同层级才用类型优先级打破平手。
  - ❌ 常见错误：以为按创建顺序或随机选，实际是 most-specific-match；也别以为"Forward Rule 永远压 PHZ"——更具体的 PHZ 会压更泛的 Forward Rule。

- **D24 Resolver rule 可经 RAM 跨账号共享**：同 Region、无需 VPC peering；成员账号只能用不能改/删共享 rule。
  - ❌ 常见错误：以为跨账号共享 rule 还要单独建 outbound endpoint（实际父账号 endpoint 随 rule 一起共享）。

**该域特有边界数字速记（内部 §5）**：
- 每 Outbound Endpoint **≤6 ENI**，聚合 **~60K req/s**；每 ENI **~10K QPS**；**经 NLB/SG 降到 ~1.5–1.7K QPS**（connection tracking，约 6 倍）。
- **1024 PPS/ENI 不可调**（实例侧 VPC+2 link-local 限制，别与 endpoint QPS 混淆）。
- Rule 必须关联 outbound endpoint 才生效。
- Resolver / Endpoints 是 **Regional**（Public DNS / Domains 才是 global us-east-1）。
- VPC .2 resolver **支持 EDNS0 但不支持 ECS**（影响 geo/latency/IP 路由准确性，见 topic 03）。
- **多 ENI 排障铁律**：每个 endpoint ENI 子网的 NACL 都要双向放行 DNS（出站 UDP/TCP 53 + 入站 UDP/TCP ephemeral）；单条 ENI 通不代表全通，三次全失败≠只是 NACL（可能 TGW 路由/目标 DNS）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

### 5.1 VPC 内 DNS 解析优先级决策链（★核心）
```mermaid
flowchart TD
    Q[VPC 内一次 DNS 查询<br/>发往 VPC+2 .2 Resolver] --> R1{匹配 Resolver<br/>Forward Rule?<br/>最具体域名优先}
    R1 -- 是 --> FWD[经 Outbound Endpoint 转发到<br/>目标/企业 DNS<br/>★永远不到公网 R53]
    R1 -- 否 --> R2{匹配关联本 VPC 的<br/>PHZ? 最具体优先}
    R2 -- 是 --> PHZ[用 PHZ 记录应答]
    R2 -- 否 --> R3{匹配 autodefined<br/>内部规则?<br/>amazonaws.com 等}
    R3 -- 是 --> SYS[AWS 内部名解析]
    R3 -- 否 --> PUB[默认 Recursive 规则<br/>Internet Resolver<br/>→ 公网递归 → Public Hosted Zone]

    FWD -.同层级冲突时.-> NOTE1[[先比最具体匹配, 再比类型<br/>同层级: Forward Rule > PHZ > 内部<br/>case 178602594200640]]
    style FWD fill:#ffe0e0
    style NOTE1 fill:#fff4d6
```

### 5.2 混合 DNS 数据面路径与多 ENI/NACL 阻断点
```mermaid
flowchart LR
    EC2[EC2 in VPC] -->|不过 SG/NACL| VPCDNS[VPC DNS .2<br/>AmazonProvidedDNS]
    VPCDNS --> RULE[Forward Rule<br/>关联本 VPC]
    RULE --> EP[Outbound Endpoint]
    EP --> ENI1[ENI1 子网<br/>NACL A]
    EP --> ENI2[ENI2 子网<br/>NACL B]
    ENI1 -->|双向放行DNS?| TGT[目标/企业 DNS :53<br/>经 TGW/DX/VPN]
    ENI2 -->|❌ 出站被 DENY 10.0.0.0/8<br/>❌ 入站缺 UDP ephemeral| TGT
    TGT -.案例.-> NOTE2[[case 178767531400698<br/>ENI2 NACL 阻断→三次全超时<br/>NACL 修复=必要非充分]]
    style ENI2 fill:#ffe0e0
    style NOTE2 fill:#fff4d6
```

### 5.3 Inbound/Outbound 方向 + RAM 共享结构
```mermaid
flowchart TB
    subgraph OnPrem[本地网络 on-prem]
      OPDNS[on-prem DNS]
    end
    subgraph AWS[AWS VPC]
      IN[Inbound Endpoint<br/>on-prem→AWS]
      OUT[Outbound Endpoint<br/>AWS→on-prem]
      PHZa[PHZ / AWS 内部名]
    end
    OPDNS -->|查 AWS 名| IN --> PHZa
    OUT -->|转发 on-prem 域名<br/>私有IP，出公网需 NAT| OPDNS
    OUT -. RAM 同 Region 跨账号共享 rule<br/>成员账号只用不可改删 .-> ACCT2[其他账号 VPC]
    style OUT fill:#e0f0ff
    style IN fill:#e0ffe0
```

# Topic 07 — DNSSEC

## 一、概念

DNSSEC（DNS Security Extensions）用数字签名为 DNS 应答提供**来源认证**与**完整性校验**，防止应答被篡改或投毒。它**只鉴权 + 保完整性，不提供机密性——不加密** DNS 查询或应答内容（明文照旧可被中间人看到，只是无法被篡改而不被发现）。

### 签名与验证的角色分工（考点）

- **权威服务器（Route 53）只负责"提供签名数据"**：随应答附上 RRSIG 签名、DNSKEY、（否定应答时）NSEC/NSEC3 记录。
- **DNSSEC 验证通常由递归解析器（recursive resolver / validating resolver）完成**：解析器逐级取签名、沿信任链校验，验证通过才在应答里置 **AD（Authenticated Data）**标志。权威服务器本身不做"验证"动作。

### RRSIG：对整个 RRset 签名（考点）

- **RRSIG 覆盖的是"同名 + 同类型"的整个 RRset**，不是单独某一条记录。例如某域名下的一组 A 记录（同名同类）作为一个 RRset 由同一条 RRSIG 一起签，不能只对其中一条签。
- **RRSIG 有独立的有效期（inception / expiration 时间戳），与记录的 TTL 是两回事**：TTL 控制"应答能被缓存多久"，RRSIG 的 inception/expiration 控制"这份签名在什么时间窗口内被解析器视为有效"。签名过期会导致验证失败（SERVFAIL），即使 TTL 还没到；Route 53 managed signing 会自动在过期前重签，用户不需手动续。

### 两类密钥（KSK / ZSK）

| 密钥 | 全称 | DNSKEY flag（algo 13） | 作用 |
|---|---|---|---|
| KSK | Key Signing Key | **257** | 签署**整个 DNSKEY RRset**（这个 RRset 同时包含 KSK 自身和 ZSK 的公钥），是信任链上被父区 DS 指向的那把钥匙 |
| ZSK | Zone Signing Key | **256** | 签署 zone 内其余所有 RRset（A、MX、TXT……） |

> 易错点：KSK **不是"签 ZSK"**，而是签"包含 KSK+ZSK 两把公钥的那条 DNSKEY RRset"。解析器用父区 DS 验证 KSK → KSK 验证 DNSKEY RRset（从而信任其中的 ZSK）→ ZSK 验证具体业务记录的 RRSIG。

Route 53 托管（managed）signing：ZSK 由 Route 53 内部管理并自动轮换，用户只需管理 KSK（KSK 绑定一个 KMS 客户主密钥 CMK）。

### 信任链与 DS 记录

信任是**逐级从父区向下建立**的：

```
根区 (.)  →  顶级域 (.com)  →  子区 (pd-market.com)
              放 DS 记录            放 DNSKEY(KSK/ZSK)
```

- **DS 记录（Delegation Signer）放在父区**，内容是**子区 KSK 对应 DNSKEY 的摘要（digest）加上算法元数据**（Key Tag、Algorithm、Digest Type、Digest），**并不包含完整的 KSK 公钥**——它只是一个指向、校验子区 KSK 的"指纹 + 元数据"。
- 解析器验证时：拿到子区 DNSKEY → 按 DS 里的 Digest Type 算法算出子区 KSK 的摘要 → 与父区 DS 的 Digest 比对 → 一致则信任该 zone 的签名 → 用 ZSK 验证具体记录。
- **DS 缺失 = 信任链断**：父区没有指向子区 KSK 的 DS，验证链就接不上。

> 记忆点：**DS 在父区，DNSKEY 在子区**，方向别搞反。DS 是"父指子"的摘要指针（子区 KSK 的 digest + 算法元数据），不含完整公钥。

### island of trust（信任孤岛）

zone 自己已经 signing（有 DNSKEY、记录都带 RRSIG 签名），但**父区没有对应的 DS 记录** → 有签名却接不上信任链。此状态下：

- 支持 DNSSEC 的解析器**不会做验证**（因为父区没告诉它该 zone 是签名的），按普通 DNS 正常返回。
- **解析仍然正常，不影响可用性**。
- 这是"半启用"的中间态，常见于：刚在 Route 53 启用了 signing、但还没到父区/注册商建 DS；或禁用过程中先删了 DS 但还没关 signing。

### 启用流程（概览）

1. 在 Route 53 Hosted Zone 启用 DNSSEC signing —— 需要创建一个 **KSK**，绑定一个符合要求的 **KMS CMK**（该 CMK 必须在 **us-east-1**、asymmetric ECC_NIST_P256）。
2. Route 53 生成 DNSKEY，开始对 zone 签名。
3. 到**父区/注册商建立 DS 记录**（把 Route 53 给出的 DS 值填进去），信任链闭合。

### 禁用流程（概览，考点）

**必须先解除信任链**：**先删父区的 DS 记录**，Route 53 才允许关闭 signing。若直接禁用，Route 53 报错：

```
Please remove DS records in the parent zone first
```

例外：处于 **island of trust**（父区本就无 DS）时，文档允许**跳过删 DS 直接禁用**。若此时 Console 仍报"先删 DS"，多半是此前在注册商/父区上传过 DS、Console 的信任链状态尚未同步。参考文档：`dns-configuring-dnssec-disable.html`。

### KSK 的 KMS CMK 硬性要求（考点）

创建 KSK 绑定的 KMS 客户主密钥必须满足：

- **必须位于 us-east-1（N. Virginia）** —— Route 53 DNSSEC 的 KSK 只能用 us-east-1 区域的 KMS 密钥，其他区域的 key 无法绑定；
- **asymmetric（非对称）密钥** —— 不能是对称 key；
- 密钥规格 **ECC_NIST_P256**（用途 SIGN_VERIFY）；
- **key policy 授权 Route 53 DNSSEC 服务**（`dnssec-route53.amazonaws.com`）使用该密钥。

任一不满足，启用/使用时报错：

```
<key ARN> could not be used by Route 53 DNSSEC
```

### 否定应答的鉴权：NSEC / NSEC3（考点）

DNSSEC 也要能"可验证地证明某名字/类型不存在"。这靠 NSEC / NSEC3 记录实现：

- **NSEC** 按字典序把 zone 内的名字串成一个环，每条 NSEC 指出"下一个存在的名字"，从而证明中间的名字不存在。副作用是它**明文暴露了相邻的真实名字**，攻击者可沿链逐跳把整个 zone 的名字全部"走"出来（zone walking / 区域枚举）。
- **NSEC3** 改用名字的**哈希值**串环，不再明文暴露名字。但要清楚：**NSEC3 只是提高了区域枚举的成本，并不能彻底阻止枚举**——攻击者仍可离线对哈希做字典/暴力破解还原名字，NSEC3 只是让这件事更贵、更慢，而非不可能。想真正减小枚举面还需配合白谎（NSEC3 white lies / minimally covering）等手段。

> 易错点：不要把"NSEC3 彻底防止 zone 枚举"当成正确表述——它只是抬高成本。



- 父区 DS、注册商侧的变更都有**传播延迟**（受父区 TTL / 注册商处理影响）。
- **轮换 KSK 需走 DS 双记录过渡**：新旧 DS 并存一段时间，等旧 DS 在解析器缓存中过期后再撤旧，避免中途验证失败。

---

## 二、真实案例说明（Case 178970323600938 · pd-market.com）

**背景**：客户从 EC2 实例 `dig pd-market.com` 持续 **SERVFAIL**（加 `+cd` 仍 SERVFAIL），而公网 8.8.8.8 正常。

**关键澄清**：此案 SERVFAIL 的**真正根因是 stale NS 委派**（解析路径取到了旧的一组 NS，旧 NS 已不托管该 zone、返回 REFUSED，逐级传导为 SERVFAIL），**并非 DNSSEC 问题**。这一点对 SME 很重要：SERVFAIL 会让人第一反应怀疑 DNSSEC 验证失败，但要先区分——见下方考点⑤。

客户在处理过程中**另外**想禁用 DNSSEC，撞上两个真实卡点：

### 卡点 1：禁用报"先删父区 DS"

客户禁用 signing 时报 `Please remove DS records in the parent zone first`。

主会话实测（DIRECTLY_OBSERVED）：

| 查询 | 结果 | 含义 |
|---|---|---|
| `dig DNSKEY pd-market.com @ns-63.awsdns-07.com` | 返回 **256 / 257，algo 13** | zone 已 signing（KSK+ZSK 都在） |
| `dig DS pd-market.com @a.gtld-servers.net`（.com） | **空** | 父区 .com 无 DS |

→ zone 有 DNSKEY 但父区无 DS = **island of trust**。按文档此状态本可直接禁用而无需删 DS。客户仍遇"先删 DS"报错，判定为：此前曾在 Registered domain 上传过 DS，Console 信任链状态未同步。**处理建议**：先到 Route 53 → Registered domains → pd-market.com 的 DNSSEC 区确认已无 DS，再重试禁用。

### 卡点 2：KMS key 报错

客户 KSK 绑定的 CMK `arn:aws:kms:us-east-1:026955879080:key/3564b66a-...` 报 `could not be used by Route 53 DNSSEC`。原因落在上述 KMS 硬性要求上：CMK 非 asymmetric ECC_NIST_P256，或 key policy 未授权 Route 53 DNSSEC，或该 key 被禁用/删除（本案未实查该 key 状态，标 UNKNOWN；仅在客户坚持禁用且卡在 KMS 时才深入排查此项）。

### island of trust 判定小结

`.com 无 DS`（父区）+ `ns-63 有 DNSKEY 256/257`（子区已签名）→ 典型 island of trust → **不影响解析**。本案公网各路径解析 44.196.71.67 均正常，正好印证"有签名无信任链不等于解析故障"。

---

## 三、实验步骤（可复现）

以下命令用 pd-market.com 举例，替换成你自己的 zone 与 CMK。

### 3.1 准备 KSK 用的 KMS CMK（必须符合硬性要求）

```bash
# 创建 asymmetric ECC_NIST_P256、用途为 SIGN_VERIFY 的 CMK
aws kms create-key \
  --key-spec ECC_NIST_P256 \
  --key-usage SIGN_VERIFY \
  --description "Route53 DNSSEC KSK" \
  --policy file://ksk-key-policy.json \
  --region us-east-1
```

`ksk-key-policy.json` 需在 policy 中授权 Route 53 DNSSEC 服务主体（`dnssec-route53.amazonaws.com`）对该 key 执行 `kms:DescribeKey / kms:GetPublicKey / kms:Sign / kms:CreateGrant` 等操作，否则会报 "could not be used by Route 53 DNSSEC"。

### 3.2 启用 DNSSEC signing 并创建 KSK

```bash
# 1) 在 Hosted Zone 上创建 KSK，绑定上一步的 CMK
aws route53 create-key-signing-key \
  --hosted-zone-id Z006303821TK6RC84YJ8P \
  --key-management-service-arn arn:aws:kms:us-east-1:<acct>:key/<key-id> \
  --name my-ksk \
  --status ACTIVE \
  --caller-reference $(date +%s)

# 2) 启用 zone 级 signing
aws route53 enable-hosted-zone-dnssec \
  --hosted-zone-id Z006303821TK6RC84YJ8P

# 3) 取出 Route 53 生成的 DS 值（填到父区/注册商用）
aws route53 get-dnssec \
  --hosted-zone-id Z006303821TK6RC84YJ8P
# 关注返回中的 KeySigningKeys[].DSRecord
```

（控制台路径：Hosted zones → 选中 zone → DNSSEC signing → Enable → 选 CMK / 建 KSK。）

### 3.3 在父区 / 注册商建立 DS 记录

- **注册商在 Amazon Registrar**：Route 53 → Registered domains → 域名 → DNSSEC → 添加上一步的 DS。
- **注册商在第三方**：把 DS 的 Key Tag / Algorithm(13) / Digest Type / Digest 填到注册商控制台。

### 3.4 验证

```bash
# 子区已签名？应看到 256(ZSK) 与 257(KSK)，algo 13
dig DNSKEY pd-market.com @ns-63.awsdns-07.com +short

# 父区已有 DS？信任链是否闭合（向 .com 权威查）
dig DS pd-market.com @a.gtld-servers.net +short
#   有 DS  = 信任链已建立
#   DS 为空 = island of trust（zone 签名了但父区没 DS）

# 完整验证：向支持验证的递归查，看是否带 AD（Authenticated Data）标志
dig pd-market.com @8.8.8.8 +dnssec
#   header 出现 flags: ... ad  → 验证通过

# 区分 SERVFAIL 是不是 DNSSEC 验证失败
dig pd-market.com @<recursive>          # SERVFAIL
dig pd-market.com @<recursive> +cd      # +cd 关闭验证：
#   变 NOERROR → 原 SERVFAIL 是 DNSSEC 验证失败
#   仍 SERVFAIL → 与 DNSSEC 无关（如本案：stale NS 委派）
```

### 3.5 按正确顺序禁用

```bash
# 1) 先删父区 / 注册商的 DS（解除信任链）
#    Amazon Registrar：Registered domains → 域名 → DNSSEC → 删除 DS
#    第三方注册商：在其控制台删 DS
#    等父区 DS TTL 过期、传播完成

# 2) 确认父区已无 DS
dig DS pd-market.com @a.gtld-servers.net +short   # 应为空

# 3) 关闭 signing（此时才允许）
aws route53 disable-hosted-zone-dnssec \
  --hosted-zone-id Z006303821TK6RC84YJ8P

# 4) （可选）删除 KSK
aws route53 deactivate-key-signing-key --hosted-zone-id <id> --name my-ksk
aws route53 delete-key-signing-key     --hosted-zone-id <id> --name my-ksk
```

> island of trust（父区本就无 DS）时可跳过步骤 1；若 Console 仍报"先删 DS"，先到 Registered domains 的 DNSSEC 区确认无 DS 后重试。

---

## 四、SME 考点 / 易错点

1. **禁用必须先删父区 DS（顺序）**：不删父区 DS 就禁用会报 `Please remove DS records in the parent zone first`。正确顺序是"先解信任链（删 DS）→ 等传播 → 再关 signing"。island of trust 时可跳过删 DS。
2. **KSK 的 KMS CMK 必须位于 us-east-1、且是 asymmetric ECC_NIST_P256**（不是对称 key），并且 key policy 要授权 Route 53 DNSSEC（`dnssec-route53.amazonaws.com`）；任一不满足报 `could not be used by Route 53 DNSSEC`。仅"在 us-east-1"并不够，非对称/规格/授权三者也都要满足。
3. **island of trust 不影响解析**：zone 有 DNSKEY 但父区无 DS，只是"有签名无信任链"，解析器不验证、按普通 DNS 正常返回，可用性不受影响。
4. **DS 在父区、DNSKEY 在子区，别搞反**：DS 是子区 KSK 对应 DNSKEY 的**摘要 + 算法元数据**（不含完整公钥）、放在父区做"父指子"的信任指针；DNSKEY（KSK 257 / ZSK 256）在子区自身。
5. **DNSSEC 验证失败表现为 SERVFAIL**：但 SERVFAIL 原因很多（如本案是 stale NS 委派）。用 `dig +cd`（关闭验证）区分——`+cd` 后变 NOERROR 才是 DNSSEC 验证问题；仍 SERVFAIL 则与 DNSSEC 无关。
6. **KSK 签的是整个 DNSKEY RRset（含 KSK+ZSK），不是"签 ZSK"**；ZSK 签其余业务 RRset。**RRSIG 对"同名同类型的整个 RRset"签名**，不是对单条记录签名。
7. **验证由递归解析器做，权威只提供签名**：Route 53（权威）随应答附 RRSIG/DNSKEY/NSEC(3)，真正的信任链校验与 AD 标志由 validating recursive resolver 完成。
8. **DNSSEC 只鉴权 + 保完整性，不加密**：DNS 内容仍是明文，DNSSEC 不提供机密性。
9. **签名有效期与 TTL 独立**：RRSIG 的 inception/expiration 控签名有效窗口，TTL 只控缓存时长；签名过期即使 TTL 未到也会 SERVFAIL（Route 53 managed signing 自动重签）。
10. **NSEC3 只提高枚举成本、不彻底阻止**：NSEC 会明文暴露相邻名字（可 zone walking），NSEC3 用哈希串环降低暴露，但仍可被离线破解还原，只是更贵。

---

## 五、Mermaid 逻辑导图

```mermaid
flowchart TD
    subgraph Chain["DNSSEC 信任链"]
        ROOT["根区 (.)"] --> TLD[".com 顶级域<br/>存放子区的 DS 记录"]
        TLD -->|"DS = 子区 KSK 的<br/>摘要+算法元数据<br/>(不含完整公钥)"| ZONE["pd-market.com 子区<br/>存放 DNSKEY"]
        ZONE --> KSK["KSK flag 257<br/>签整个 DNSKEY RRset<br/>(含 KSK+ZSK)"]
        ZONE --> ZSK["ZSK flag 256<br/>签其余 RRset<br/>(RRSIG 覆盖整个 RRset)"]
    end

    KSK -->|绑定| CMK["KMS CMK<br/>必须在 us-east-1<br/>asymmetric<br/>ECC_NIST_P256<br/>授权 dnssec-route53"]

    subgraph State["状态判定"]
        Q1{"子区有 DNSKEY?"}
        Q2{"父区有 DS?"}
        Q1 -->|否| S0["未启用 DNSSEC"]
        Q1 -->|是| Q2
        Q2 -->|是| S1["信任链完整<br/>解析器可验证 (AD 标志)"]
        Q2 -->|否| S2["island of trust<br/>有签名无信任链<br/>不影响解析<br/>★本案状态"]
    end

    subgraph Disable["禁用流程 (顺序考点)"]
        D1["① 先删父区 DS<br/>解除信任链"] --> D2["② 等 DS 传播"]
        D2 --> D3["③ disable signing<br/>此时才允许"]
        DX["直接禁用未删 DS"] -.报错.-> ERR["Please remove DS<br/>records in the<br/>parent zone first"]
    end

    subgraph Diag["SERVFAIL 区分"]
        F1["dig 得 SERVFAIL"] --> F2{"dig +cd 结果?"}
        F2 -->|变 NOERROR| F3["DNSSEC 验证失败"]
        F2 -->|仍 SERVFAIL| F4["非 DNSSEC 问题<br/>如 stale NS 委派<br/>★本案真正根因"]
    end
```

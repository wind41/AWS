# Topic 12：服务集成 + 配额与限流

> Route 53 SME 培训材料 · Wave3
> 覆盖 Route 53 与其它 AWS 服务的集成（Alias、Evaluate Target Health、Global Accelerator）以及账号级配额、API/DNS 限流与排查。

---

## 一、概念

### 1.1 服务集成 —— Alias 记录

Alias 记录是 Route 53 独有的扩展（非标准 DNS），把一条记录直接指向 AWS 资源，而不是指向一个 IP 或域名。相比 CNAME 有三个关键优势：

- **可用于 zone apex（根域，如 `example.com`）**：标准 DNS 禁止在 apex 放 CNAME，Alias 没有这个限制。
- **不额外收费**：查询 Alias 指向 AWS 资源不计入 DNS 查询费。
- **AWS 自动维护目标 IP**：目标资源换 IP 时 Route 53 自动跟踪，无需手工改记录。

支持作为 Alias 目标的资源类型（SME 高频考点）：

| Alias 目标 | 说明 | 可放 apex？ |
|-----------|------|:---:|
| CloudFront distribution | 目标必须是 CloudFront 域名（`d111111abcdef8.cloudfront.net`），记录类型 A/AAAA | ✅ |
| ELB（ALB / NLB / CLB） | 指向 LB DNS 名，Route 53 解析到 LB 各节点的 A/AAAA | ✅ |
| S3 静态网站 endpoint | **必须是"网站托管" endpoint**（`s3-website-<region>`），不是普通 REST endpoint；bucket 名须与记录名完全一致 | ✅ |
| API Gateway（自定义域名） | 指向 API GW 的 regional / edge 域名 | ✅ |
| VPC Interface Endpoint（PrivateLink） | 指向接口端点的 DNS 名 | ✅ |
| Global Accelerator | 指向 accelerator 的静态 DNS 名 | ✅ |
| Elastic Beanstalk 环境 | 指向 EB 环境的 CNAME/域名 | ✅ |
| App Runner 服务 | 指向 App Runner 服务默认域名 | ✅ |
| AppSync GraphQL API（自定义域名） | 指向 AppSync 自定义域名 | ✅ |
| Amazon OpenSearch Service 域 | 指向 OpenSearch 域端点 | ✅ |
| Lightsail | 指向 Lightsail 负载均衡/实例 | ✅ |
| VPC Lattice service | 指向 VPC Lattice 服务域名 | ✅ |
| 同一 hosted zone 内另一条记录 | Alias 到本 zone 的其它记录 | ✅ |

> 上表为**常见示例**，Alias 支持的 AWS 目标类型仍在扩展，具体以官方文档为准。

> 易混：Alias 到 EC2 实例**不直接支持**——EC2 没有稳定 DNS 名，需在前面放 ELB 或用普通 A 记录指向 EIP。

### 1.2 Evaluate Target Health（评估目标运行状况）

Alias 记录上的一个开关。开启后 Route 53 不需要单独建 health check，就能根据**目标资源自身的健康状态**决定是否返回该记录：

- Alias → ELB：`Evaluate Target Health = Yes` 时，Route 53 看 LB 后端目标组是否有健康目标；全不健康则不返回这条 Alias。
- Alias → CloudFront：**不支持** Evaluate Target Health（CloudFront 是全球边缘，无"目标"概念）。
- Alias → S3 网站：不支持。
- 多级 Alias 链（Alias → Alias → ELB）：健康状态**逐层向上传递**，任一层设了 Evaluate Target Health=Yes 都会参与判定。

这是做故障转移（Failover）路由时的核心机制——把主/备两条 Alias 指向不同区域的 ELB，配 failover 路由 + Evaluate Target Health，即可零 health-check 成本实现区域级切换。

### 1.3 与 Global Accelerator 的集成

- Global Accelerator 提供**两个静态 anycast IP**（Anycast，全球任播），流量从最近边缘接入 AWS 骨干网。
- 集成方式：Route 53 用 A 记录直接指向这两个静态 IP，或用 Alias 指向 accelerator DNS 名。
- 与 Route 53 延迟路由/地理路由的取舍：GA 在网络层做最优接入（TCP/UDP、非 DNS 依赖），Route 53 在 DNS 层做解析选路。二者可叠加，但 SME 要能说清"GA 解决客户端到入口的网络路径，Route 53 解决把哪个 IP 返给客户端"。

### 1.4 配额与限流（Quotas & Throttling）

| 维度 | 默认配额 | 可否提额 | 备注 |
|------|---------|:---:|------|
| 每账号 hosted zones | **500** | ✅ 可提 | 通过 Service Quotas / 开 case |
| 每 hosted zone records | **10,000** | ✅ 可提 | 超大 zone 建议拆分或提额 |
| Resolver endpoint 每 ENI QPS | **~10,000 QPS / IP(ENI)** | 通过加 IP 扩 | endpoint 至少 2 个 IP，加 IP 线性扩吞吐 |
| 公网权威查询（Public HZ 被外部解析） | **不计入账号限流** | — | 权威侧由 AWS anycast 车队承载，客户无需担心 QPS |
| Route 53 公共 API 请求速率（账号桶） | **持续 10 RPS / 突发 50** | 部分可议 | 账号级令牌桶，覆盖 `ChangeResourceRecordSets` 等控制面 API；超限返回 `Throttling` |
| DNS 记录变更（`ChangeResourceRecordSets` 应用速率） | **持续 100 changes/s / 突发 1500** | — | 变更**应用**吞吐，独立于上面的 API 调用速率 |
| Resolver API 速率 | **~5 RPS/账号** | — | 5 RPS 主要指 **Resolver** API（`route53resolver`），别把它当成整个 Route 53 API 的上限 |

要点：

- **数据面 vs 控制面**：公网权威 DNS 查询（数据面）几乎无限、不计账号配额；能被限流的是**控制面 API**（改记录、建 zone）——Route 53 公共 API 账号桶为**持续 10 RPS / 突发 50**，记录变更的**应用**吞吐另有**持续 100 changes/s / 突发 1500**。批量改记录要用**单次 ChangeResourceRecordSets 打包多个变更**，而不是循环单条调用（否则秒级触发 `Throttling` / `PriorRequestNotComplete`）。
- **别把"5 RPS"当成整个 Route 53 API 的上限**：5 RPS 主要指 **Resolver** API（`route53resolver`），与上面的公共 Route 53 API（10 RPS）是不同服务的不同桶。
- Resolver（VPC 递归解析，`.2` 或 Resolver endpoint）才有 per-ENI QPS 上限；不要把它和公网权威混为一谈。

### 1.5 DNS 查询错误 vs 限流的区分（排查核心）

SME 必须能把"响应码"和"被限流"分开：

- **SERVFAIL**：服务器端处理失败——常见是 DNSSEC 验证失败、上游/转发规则问题、Resolver endpoint 后端不可达。**不是限流**。
- **REFUSED**：服务器拒绝应答——常见是查询到了非权威/未委派该 zone 的服务器，或访问控制拒绝。**不是限流**。
- **NXDOMAIN**：记录不存在（正常否定应答）。
- **真限流的表现**：Resolver endpoint 超过 per-ENI QPS 时表现为**丢包/超时**（而非返回某个 rcode），CloudWatch `InboundQueryVolume` / `OutboundQueryVolume` 打满、`EndpointHealthyENICount` 与实际 ENI 数据对不上。控制面被限流则 API 直接返回 `Throttling`。

排查次序：先看是**响应码类**（SERVFAIL/REFUSED/NXDOMAIN，属配置/委派/DNSSEC）还是**无响应类**（超时/丢包，才往 QPS 限流查），避免把配置错误误判为限流去盲目提额。

---

## 二、真实案例：178602958500732（National Bank of Canada）

**背景**：客户（加拿大国家银行，账号 578091176149，Enterprise Support）咨询如何在防火墙上放行 AWS 公共 DNS 服务器的 IP，以实现 DNS zone delegation。属纯咨询（Informational/How-to），无生产影响。

**与本 topic 的关联点 —— 权威 NS 的"集成边界"与限流认知**：

1. **`ip-ranges.json` 中的 service 语义分层**（集成识别的易错点）：
   - `ROUTE53` = 公网**权威 NS** 的 IP 范围（客户要放行的正是这个）。
   - `ROUTE53_RESOLVER` = VPC 内**递归解析器**（就是有 per-ENI QPS 限流的那层）。
   - `ROUTE53_HEALTHCHECKS` = 健康检查车队（Evaluate Target Health 之外的显式 health check 探测源）。
   - SME 必须能瞬间区分这三者——它们分别对应"权威/递归/探测"三条完全不同的数据路径。

2. **公网权威查询不计账号限流的实证**：客户担心放行后的查询量，但权威侧由 AWS **Anycast**（任播）车队承载，属数据面、不计入账号配额，客户无需为 QPS 提额——正好对应本 topic 1.4 的"公网权威查询不计入账号限流"。

3. **静态但可增长**：已有 Route 53 NS IP 是**静态**的（文档原文 "Route 53 name server IP addresses are static."），但仍可能新增前缀。放行时**不按 region 过滤、全量收录**（实测 region 字段有 GLOBAL + us-west-2 / eu-central-1 / cn-north-1 / cn-northwest-1 / us-gov-east-1 / us-gov-west-1 / eusc-de-east-1 共 8 种），并订阅 SNS topic `arn:aws:sns:us-east-1:806199016981:AmazonIpSpaceChanged` 兜底监控变更。

4. **场景澄清**：NS delegation 本身**不需要**防火墙改动，需要放行的是**客户递归解析器 outbound 到权威 NS（UDP/TCP 目的端口 53）**的查询流量。这提醒 SME：集成/放行问题要先定位"是哪条数据路径"，而非按客户措辞直接动手。

**处置**：一次性回复关闭，无需 escalation。

---

## 三、实验步骤（动手 Lab）

目标：亲手建 Alias 记录指向 ELB 与 S3 网站，并观察 Evaluate Target Health 的效果。

### Lab A：Alias → ALB + Evaluate Target Health

1. 建一个 ALB（`my-alb`），目标组挂 1~2 台 EC2，配 HTTP health check。
2. **建成一个多记录组以验证 ETH**：单独一条 simple Alias 即使目标不健康、也可能因 **fail-open** 仍被返回，看不出 ETH 效果。要在 **failover 路由（Primary + Secondary）** 或 **加权/多值组** 里建这条 Alias——Primary 指向 `my-alb`（A 记录 Alias，`Evaluate Target Health = Yes`），Secondary 指向另一个健康端点。
3. 正常态下 `dig your-record.example.com` 返回 Primary（ALB 节点 IP）。
4. **制造故障**：把目标组里所有目标手工停掉/改成不健康（如关掉后端服务）。
5. 再 `dig`：Primary 目标组全不健康时 ETH 判其不健康，Route 53 切到 **Secondary** 记录。观察 TTL 到期后的行为变化。
6. **对照**：若把这条 Alias 单独建成一条 simple 记录（无同名兄弟记录），目标全不健康时它可能仍被 fail-open 返回——这正是"必须用多记录组才能验证 ETH 切换"的原因。

### Lab B：Alias → S3 静态网站

1. 建 bucket，名字**必须等于最终记录名**（如记录是 `www.example.com`，bucket 就叫 `www.example.com`）。
2. 开启 **Static website hosting**，拿到网站 endpoint（`www.example.com.s3-website-us-east-1.amazonaws.com`，注意是 `s3-website`，不是普通 REST endpoint）。
3. 在 hosted zone 建 A 记录 → Alias → "S3 website endpoint" → 选对 region 的 bucket。
4. `dig` + 浏览器访问，确认解析到 S3 并返回静态页。
5. 观察点：S3 网站 Alias **不支持** Evaluate Target Health（灰掉）——对比 Lab A 理解"哪些目标类型才有健康评估"。

### Lab C（可选）：控制面限流观察

- 写脚本循环调用 `aws route53 change-resource-record-sets` 单条变更、每秒持续 >10 次（超过公共 API 账号桶 10 RPS/突发 50）。
- 观察返回 `Throttling` / `PriorRequestNotComplete`，然后改成"单次请求打包多条 Changes"验证不再触发——理解 5 req/s 控制面限流与批处理正解。

---

## 四、SME 考点 / 易错点

1. **CNAME vs Alias**：apex 只能用 Alias；被问"为什么根域配了 CNAME 报错"要立刻答"apex 禁止 CNAME，改 Alias"。
2. **S3 网站 Alias 三条硬约束**：① 用网站 endpoint 不是 REST endpoint；② bucket 名 == 记录名；③ region 要选对。任一不满足解析/访问就失败。
3. **Evaluate Target Health 支持面**：ELB 支持；CloudFront、S3 网站**不支持**。别承诺 CloudFront Alias 能做目标健康评估。
4. **数据面 vs 控制面限流**：公网权威查询不限流、不计配额；被限的是控制面 API（Route 53 公共 API 账号桶 **10 RPS 持续/50 突发**，记录变更应用 **100/s 持续/1500 突发**）和 Resolver endpoint（per-ENI ~10k QPS）。注意 **5 RPS 是 Resolver API**，不是整个 Route 53 API 的上限——混答是高频扣分点。
5. **批量改记录**：用单次 `ChangeResourceRecordSets` 打包，别循环单条——否则触发 `Throttling`/`PriorRequestNotComplete`。
6. **SERVFAIL/REFUSED ≠ 限流**：响应码类问题查配置/委派/DNSSEC；限流表现为**超时/丢包**。排查先分"有响应码"还是"无响应"。
7. **500 zones / 10000 records 可提额**：客户撞上限先走 Service Quotas 提额或拆 zone，不要误报为"硬限制"。
8. **Resolver 三分层**（呼应真实案例）：ROUTE53（权威）/ ROUTE53_RESOLVER（递归、有 QPS 限流）/ ROUTE53_HEALTHCHECKS（探测），三条数据路径别混。
9. **Global Accelerator vs Route 53 选路**：GA 解决网络层最优接入（静态 anycast IP），Route 53 解决 DNS 层返哪个 IP，说清分工。

---

## 五、Mermaid 导图

```mermaid
mindmap
  root((Topic 12<br/>集成 + 配额限流))
    服务集成
      Alias 记录
        可用于 apex
        不额外收费
        AWS 自动维护目标
        目标类型
          CloudFront
          ELB (ALB/NLB/CLB)
          S3 静态网站 endpoint
          API Gateway
          VPC Interface Endpoint
          Global Accelerator
          Elastic Beanstalk
          App Runner
          AppSync
          OpenSearch
          Lightsail
          VPC Lattice
      Evaluate Target Health
        ELB 支持
        CloudFront 不支持
        S3 网站 不支持
        Failover 核心机制
      Global Accelerator
        静态 anycast IP x2
        GA 管网络接入
        R53 管 DNS 选路
    配额与限流
      每账号 500 hosted zones (可提)
      每 zone 10000 records (可提)
      Resolver endpoint ~10000 QPS/ENI
      公网权威查询 不计账号限流
      公共 API 账号桶 10 RPS/突发 50
      DNS 变更 100/s/突发 1500
      Resolver API ~5 RPS
      批量改记录打包 ChangeRRSets
    错误 vs 限流
      SERVFAIL DNSSEC/上游/后端
      REFUSED 非权威/未委派/ACL
      NXDOMAIN 记录不存在
      真限流 超时/丢包 非 rcode
    真实案例 178602958500732
      NBC 放行公网 NS IP
      ip-ranges service 三分层
        ROUTE53 权威
        ROUTE53_RESOLVER 递归
        ROUTE53_HEALTHCHECKS 探测
      公网权威 Anycast 不计限流
      NS IP 静态但可增长
      SNS 订阅变更兜底
```

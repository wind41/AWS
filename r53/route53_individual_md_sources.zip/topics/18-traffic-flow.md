# 18. Traffic Flow / Policy Record（流量策略与可视化编排）

## 1. 概念（Concept）

**Traffic Flow** 是 Route 53 的一个**编排层**，用可视化编辑器把**多种路由策略嵌套成一棵记录树**，并把这棵树一次性物化成一组普通 DNS 记录。它不是"第 9 种路由策略"，而是"批量创建/维护同一 DNS 类型的路由记录树"的工具——**这棵树的节点可以是路由规则（rule）或 endpoint，并不要求节点都是 Alias**（alias 只是可选的一种 endpoint 引用方式）。核心解决两类难题：① 大量执行同一功能的资源（如同域名的多台 web 服务器）；② 想用多种路由策略（latency / failover / weighted / geolocation 等）嵌套组合出一棵复杂的、同一记录类型（如都是 A 记录）的记录树。来源：外部 `traffic-flow.html`（"Using Traffic Flow to route DNS traffic"）；内部 §3 "Traffic Flow / Traffic Policy"（kyoheibb 页 + TSR53DNSService）。

### 1.1 三个核心对象（考点：名词必须分清）

1. **Traffic policy（流量策略）**
   - 就是那棵"记录树"的**模板/定义**（一段 JSON 文档 + 一个版本号）。在可视化编辑器里画出来的东西就是一个 traffic policy。
   - **创建/存在本身不收费**，可以随便建。
   - 来源：外部 `traffic-flow.html`（"Each configuration is known as a *traffic policy*. You can create as many traffic policies as you want at no charge."）。

2. **Traffic policy version（版本）**
   - 一个 traffic policy 可以有**多个版本**——配置变更时不用推倒重来，新建一个版本即可；旧版本一直保留直到你手动删除；每个版本可选加描述。
   - **默认上限 1000 个版本 / 每个 traffic policy**。
   - 版本是"回滚"能力的基础（见 §1.3）。
   - 来源：外部 `traffic-flow.html`（"Versioning ... default limit of 1000 versions per traffic policy"）；配额页 `DNSLimitations.html`（Traffic policy versions = 1,000 per traffic policy）。

3. **Traffic policy record（策略记录）= API/SDK/CLI 里的 "policy instance"（策略实例）**
   - 把某个 traffic policy（的某个版本）**关联到一个具体的 hosted zone + 根记录名**（如 `example.com` 或 `www.example.com`），Route 53 就**自动创建整棵树的所有底层记录**。
   - **只有根记录（traffic policy record）显示在 hosted zone 记录列表里，其余底层记录被 Route 53 隐藏**。
   - **控制台叫 "traffic policy record"，但在 Route 53 API / SDK / CLI / PowerShell 里叫 "policy instance"**（同一个东西的两个名字——高频混淆点）。
   - **每条 policy record 按月收费 $50**（见 §1.4 计费）。
   - 来源：外部 `traffic-flow.html`（"Automatic record creation ... traffic policy record ... Route 53 hides all the other records"）；配额页 `DNSLimitations.html`（"Traffic policy records (referred to as 'policy instances' in the Route 53 API, AWS SDKs, AWS CLI ...)"）。

> 一句话关系链：**你画一个 traffic policy（免费）→ 存成一个 version（≤1000）→ 关联到 zone+名字生成一条 policy record / policy instance（$50/月）→ R53 自动展开整棵底层记录树（只露根）。**

### 1.2 可视化编辑器与嵌套多策略

- **可视化编辑器（visual editor）**：图形化拖拽出记录树并直观看到记录间关系。典型嵌套：**latency alias 记录 → 指向 weighted 记录 → weighted 记录再指向多个 Region 的资源**。一棵 policy 可以代表几十上百条记录。
- **geoproximity 地图**：Traffic Flow 编辑器里有 geoproximity 地图，能直观看到流量如何被路由到各全球端点。**注意（2024-01 起的变化）**：geoproximity **记录本身已可在 Traffic Flow 之外直接创建**（API/CLI/SDK/控制台/普通记录，含 public zone 与 PHZ），**只有"地图可视化"这一交互仍限 Traffic Flow**（见 topic 03 §1.1 第 6 项）。
- **单向性（考点）**：只能"用编辑器编排 → 生成普通记录"，**不能把已经手工建好的普通记录反向导入成 GUI 里的 policy**。排查线上 policy 展开了哪些记录时，用 **R53 Information Search Tool 查 Traffic Policy Instance**。来源：内部 §3（kyoheibb 页 + TSR53DNSService）。

### 1.3 更新与回滚（考点：这是 Traffic Flow 相对手工建记录的最大价值）

- **更新**：新建 traffic policy 的一个新版本后，可**选择性地把用旧版本创建的 policy record 更新到新版本**；更新一条 policy record 时，Route 53 **自动同步更新树里的所有底层记录**——不用你逐条改几十上百条记录。
- **回滚**：把同一条 policy record（policy instance）**再次 `UpdateTrafficPolicyInstance` 更新回某个旧版本**即可回滚整棵树。**注意这不是"秒回滚"**：`UpdateTrafficPolicyInstance` 是异步的控制面操作，有处理时间——需**轮询 instance 的 state**（如从 `APPLIED` 转 `CREATING/UPDATING` 再回 `APPLIED`）确认底层记录已改写完成；且即使权威端已改完，**下游递归解析器的缓存仍会让客户端看到旧答案，直到记录 TTL 到期**。回滚的"生效时间" = 控制面处理时间 + 各客户端 TTL。这也是为什么"版本"要一直保留。
- 对比手工路由策略：手工建的一堆 weighted/latency/failover 记录，改一次要逐条改、回滚更要逐条回退、且没有"版本"概念；Traffic Flow 把这变成"改一个版本、点一次更新/回滚"。
- 来源：外部 `traffic-flow.html`（"selectively update traffic policy records ... automatically updates all the other records ... quickly roll back changes by updating a traffic policy record again to use a previous version"）。

### 1.4 计费（结合 topic 16）

- **traffic policy 本身（未关联到域名）不收费**；**policy record 每条 $50/月（按月 prorate）**——这是 Route 53 里单价最高的"隐形常驻费"之一。
- **降本手段（官方推荐）**：为根名建一条 policy record，再对其他名字建**普通 alias 记录指向这条 policy record**，而不是每个名字都建一条 policy record。例：`example.com` 建 policy record，`www.example.com` 建 alias 指向它 → **只产生一份 policy record 月费 $50**。⚠️ **注意区分两类计费**：省下的只是重复的 policy-record **月费**；这些指向 policy record 的 **alias / CNAME 记录被查询时，仍照常按 DNS query 计费**（alias 指向 R53 内资源的部分场景免 query 费，但指向 traffic policy record 的查询不在免费之列）。即"少付 $50 月费 ≠ 免 query 费"。
- 来源：外部 `traffic-flow.html`（"There's a monthly charge for each traffic policy record ... To minimize these charges, you can create one or more alias records ... that reference a traffic policy record"）；定价页 `route53/pricing`；见 topic 16 §2.4。

### 1.5 适用范围与边界

- **仅 public hosted zone**：Traffic Flow **只能在 public hosted zone 里创建记录**，PHZ 不支持。来源：外部 `traffic-flow.html`（"You can use Traffic Flow to create records only in public hosted zones."）。
- **跨 zone 复用**：同一个 traffic policy 可在**多个 public hosted zone** 里各生成一条 policy record（如同一组 web 服务器服务 example.com / .org / .net）。来源：外部 `traffic-flow.html`（"Reuse for multiple records in different hosted zones"）。
- **配额**（`DNSLimitations.html`，均可提额除版本外）：
  - **Traffic policies：50 / AWS 账户**
  - **Traffic policy versions：1,000 / 每个 traffic policy**
  - **Traffic policy records（=policy instances）：5 / AWS 账户**（默认很小，复杂部署常需提额——考点）

### 1.6 与"直接用普通路由策略"的取舍

| 维度 | Traffic Flow（policy record） | 直接建普通路由策略记录 |
|---|---|---|
| 适用规模 | 复杂 alias 树、多策略嵌套、几十上百条相关记录 | 单层、少量记录 |
| 版本/回滚 | **有版本，一键更新/回滚整棵树** | 无版本，逐条手工改/回退 |
| 可视化 | **有编辑器 + geoproximity 地图** | 无（记录列表纯文本） |
| 计费 | **$50/月/policy record**（+底层记录数） | 无 policy record 月费，只付常规 query/zone 费 |
| 作用域 | **仅 public zone** | public + private（按策略而定） |
| 反向导入 | **不能**把已有普通记录 GUI 化 | — |
| 何时选它 | 树复杂、要频繁改+安全回滚、要跨多 zone 复用同一套编排 | 结构简单、几条记录、想省 $50/月/record |

> **SME 决策口径**：只有当"记录树足够复杂、需要版本化更新/回滚、或要在多 zone 复用同一套编排"时，$50/月/record 才值。结构简单（几条 weighted/failover）就直接建普通记录，省掉 policy record 月费。

---

## 2. 真实案例说明（Real Case）

> 本域暂无独立绑定的 case 编号；以下为内部排障知识与两类高频咨询场景的教学化归纳（来源：内部 §3 kyoheibb 页 + TSR53DNSService；外部 `traffic-flow.html`）。

### 场景 A — "账单里一条看不懂的 $50/月"（计费意外，最高频）

- **现象**：客户看账单发现 Route 53 有若干 $50/月 的条目，域名列表里却"没看到那么多记录"。
- **根因**：这些是 **traffic policy record（policy instance）月费**；底层展开的记录被 R53 隐藏、只露根记录，客户以为"就一条记录"。建了 N 条 policy record 就是 N × $50/月。
- **SME 落点**：① 解释 policy record 隐藏底层记录的机制；② 用 `list-traffic-policy-instances` 盘点账户里所有 policy record；③ 降本——把非根名改成 alias 指向根 policy record，删掉冗余 policy record；④ 提醒 traffic policy 本体不花钱、钱在"关联出来的 record"。

### 场景 B — "改了配置想安全回滚"（Traffic Flow 价值场景）

- **现象**：客户用一棵 latency→weighted→多 Region 资源的树跑生产，要调整权重/加一个 Region，但怕改错影响线上、且记录几十条改不过来。
- **正确做法**：在可视化编辑器里**基于当前版本新建一个版本**改动 → 把生产的 policy record **更新到新版本**（R53 自动同步整棵树）；若出问题，把 policy record **再更新回旧版本**即可回滚（`UpdateTrafficPolicyInstance` 异步、需轮询 instance state，且客户端受各自缓存 TTL 影响，非瞬时）。
- **SME 落点**：强调"版本 + 一键更新/回滚整棵树"正是选 Traffic Flow 而非手工记录的理由；提醒旧版本别急着删（删了就没法回滚到它），注意 1000 版本上限。

### 场景 C — "线上解析异常，想看这条名字到底展开了什么"（排障）

- **现象**：某个用 policy record 建的名字解析结果不符预期，但记录列表只看到根记录。
- **正确做法**：用 **R53 Information Search Tool 查 Traffic Policy Instance**，看该 instance 关联的 policy 版本与展开的底层记录树；注意**不能**把线上普通记录反向 GUI 化，只能查 instance。

---

## 3. 实验步骤（Hands-on Lab）

> 目标：建一个 traffic policy（latency→weighted 嵌套）、生成 policy record、做一次版本更新与回滚、并用 alias 引用降本。全程 CLI，非破坏性，做完清理。前置：一个测试 public hosted zone（`lab.example.com`，`<ZONEID>`）+ 两台可区分目标（IP_A/IP_B）。

### 实验 A：创建 traffic policy（免费对象）
```bash
# policy 文档：根为 A 记录，嵌套 weighted（简化版；真实 latency 树需按 Region 结构）
cat > policy.json <<'JSON'
{
  "AWSPolicyFormatVersion":"2015-10-01",
  "RecordType":"A",
  "Endpoints":{
    "ep-a":{"Type":"value","Value":"IP_A"},
    "ep-b":{"Type":"value","Value":"IP_B"}
  },
  "Rules":{
    "site":{"RuleType":"weighted","Items":[
      {"EndpointReference":"ep-a","Weight":90},
      {"EndpointReference":"ep-b","Weight":10}
    ]}
  },
  "StartRule":"site"
}
JSON
aws route53 create-traffic-policy --name lab-weighted --document file://policy.json
# 记下返回的 Id 与 Version（version 从 1 开始）
```

### 实验 B：把 policy 关联到域名 → 生成 policy record（此刻开始 $50/月计费！）
```bash
aws route53 create-traffic-policy-instance \
  --hosted-zone-id <ZONEID> \
  --name tf.lab.example.com \
  --ttl 60 \
  --traffic-policy-id <POLICY_ID> \
  --traffic-policy-version 1
# 在 hosted zone 记录列表里只会看到 tf.lab.example.com 一条（底层被隐藏）
aws route53 list-traffic-policy-instances   # 盘点账户所有 policy record（=instance）
```

### 实验 C：新建版本并更新（观察一键同步整棵树）
```bash
# 改权重后建新版本（同一 policy 追加 version 2）
# ...修改 policy.json 里的 Weight 为 50/50...
aws route53 create-traffic-policy-version --id <POLICY_ID> --document file://policy.json
# 把线上 instance 更新到 version 2 —— R53 自动改写底层记录
aws route53 update-traffic-policy-instance \
  --id <INSTANCE_ID> --ttl 60 \
  --traffic-policy-id <POLICY_ID> --traffic-policy-version 2
```
判读：向权威 NS 采样 `dig @<NS> tf.lab.example.com A +short`，观察比例从 ~90:10 变成 ~50:50，验证"改一个版本→整棵树自动更新"。

### 实验 D：回滚
```bash
# 把 instance 再更新回 version 1 —— 回滚（异步，轮询 instance state 确认完成；客户端还受 TTL 影响）
aws route53 update-traffic-policy-instance \
  --id <INSTANCE_ID> --ttl 60 \
  --traffic-policy-id <POLICY_ID> --traffic-policy-version 1
```

### 实验 E：降本引用
```bash
# 给 www 建普通 alias 指向根 policy record，而不是再建一条 policy record（省第二份 $50）
# 注：alias 指向同 zone 内的 policy record 根名，避免为每个名字各付一份 policy record 月费
```

### 清理（重要：删掉才停 $50/月）
```bash
aws route53 delete-traffic-policy-instance --id <INSTANCE_ID>   # 先删 instance（停月费 + 删底层记录）
aws route53 delete-traffic-policy --id <POLICY_ID> --version 2  # 再逐版本删 policy
aws route53 delete-traffic-policy --id <POLICY_ID> --version 1
```

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **T1 — "policy record" 与 "policy instance" 是同一个东西**
  - 结论：控制台叫 **traffic policy record**，API/SDK/CLI/PowerShell 叫 **policy instance**。CLI 动词是 `*-traffic-policy-instance`。
  - 常见错误：以为是两种不同资源；在 CLI 里找 "policy record" 找不到。
  - 来源：`DNSLimitations.html`（括注明确）。

- **T2 — traffic policy 免费，policy record 收 $50/月**
  - 结论：画多少 policy、建多少 version 都不花钱；**钱花在"关联到域名生成的 policy record"**，每条 $50/月（prorate）。
  - 常见错误：以为建 policy 就开始扣费；或反过来以为 policy record 不单独收费。
  - 来源：`traffic-flow.html` + 定价页；topic 16 §2.4。

- **T3 — 只有根记录可见，底层记录被隐藏**
  - 结论：一条 policy record 展开成整棵树，但 hosted zone 列表**只显示根**，其余隐藏；排障看展开内容要用 **R53 Information Search Tool 查 Traffic Policy Instance**。
  - 常见错误：以为"只有一条记录"；找不到底层记录以为丢了。

- **T4 — 版本上限 1000 / policy；policy record 默认仅 5 / 账户**
  - 结论：**版本 1,000/policy**、**traffic policies 50/账户**、**policy records（instances）默认 5/账户**（可提额）。复杂部署常撞 policy record 上限。
  - 常见错误：以为 policy record 可以随便建很多；把"50 个 policy"当成"5 个 record"混记。
  - 来源：`DNSLimitations.html` "Quotas on traffic flow policies and policy records"。

- **T5 — 仅 public hosted zone**
  - 结论：Traffic Flow **只能在 public zone 建记录**，PHZ 不支持用 Traffic Flow。
  - 常见错误：想在 PHZ 里用可视化编辑器编排内部记录。
  - 来源：`traffic-flow.html`（Note）。

- **T6 — 单向：能生成普通记录，不能反向 GUI 化**
  - 结论：编辑器 → 生成记录是单向；**已有的普通路由记录无法反向导入成 policy**。
  - 常见错误：以为可以把线上手工建的一堆记录"一键转成 Traffic Flow 管理"。
  - 来源：内部 §3。

- **T7 — 回滚靠"把 instance 更新回旧版本"，所以旧版本别乱删**
  - 结论：回滚 = 再次 update policy record 指向旧 version；**删掉某版本就无法回滚到它**。
  - 常见错误：更新到新版本后立刻删旧版本，出事无法回退。
  - 来源：`traffic-flow.html`（Versioning + 更新/回滚段）。

- **T8 — geoproximity：记录可直接建，地图可视化仍需 Traffic Flow（但别把地图当 Traffic Flow 的"唯一价值"）**
  - 结论：geoproximity 记录已可**直接在 public hosted zone / PHZ 里创建**（API/CLI/SDK/控制台，2024-01 起），不再必须走 Traffic Flow；就 geoproximity 而言，**Traffic Flow 现在的独占项只剩"交互式地图可视化"**。但**这只是 geoproximity 这一维度**——Traffic Flow 本身相对手工记录仍有版本化更新/一键回滚、多策略嵌套编排、跨多 zone 复用同一套编排等价值，**不要说"交互地图是 Traffic Flow 唯一剩余价值"**。
  - 常见错误：仍以为"用 geoproximity 必须走 Traffic Flow"；或反过来因为 geoproximity 可直接建就断言 Traffic Flow 整体已无用。
  - 来源：内部 §3；外部 `routing-policy-geoproximity.html`；topic 03 §1.1。

- **T9 — 何时选 Traffic Flow vs 直接普通路由策略**
  - 结论：树复杂/要版本化更新回滚/多 zone 复用 → Traffic Flow 值这 $50；结构简单几条记录 → 直接建普通记录省月费。
  - 常见错误：给一个只有两条 weighted 记录的简单场景上 Traffic Flow，白付 $50/月。

**边界数字速记**：traffic policies **50/账户** · versions **1000/policy** · policy records(=instances) **默认 5/账户（可提额）** · **$50/月/policy record** · **仅 public zone**。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

对象关系与"是否该用 Traffic Flow"决策：

```mermaid
flowchart TD
    A([可视化编辑器画出记录树]) --> P[Traffic Policy<br/>模板/JSON·免费·50个/账户]
    P --> V[Traffic Policy Version<br/>≤1000/policy·旧版本保留供回滚]
    V --> BIND{关联到 public zone + 根名?}
    BIND -->|是| R[Traffic Policy Record<br/>=API/CLI 的 policy instance<br/>$50/月·默认5个/账户]
    BIND -->|未关联| FREE[仅 policy·不收费]
    R --> TREE[R53 自动展开整棵底层记录树<br/>列表只露根·其余隐藏]
    R -.更新到新版本.-> SYNC[整棵树自动同步]
    R -.更新回旧版本.-> ROLL[回滚:控制面处理+TTL 生效]
    TREE --> CHEAP[其他名字建 alias 指向根 record<br/>避免每名字各付一份 $50]
```

```mermaid
flowchart TD
    Q([要编排一组相关记录]) --> Z{是 public zone 吗?}
    Z -->|否 PHZ| NO[Traffic Flow 不支持<br/>只能直接建普通记录]
    Z -->|是| CX{树复杂/多策略嵌套/几十上百条?}
    CX -->|否 就几条| SIMPLE[直接建普通路由记录<br/>省 $50/月/record]
    CX -->|是| NEED{要版本化更新+安全回滚<br/>或多zone复用同一套编排?}
    NEED -->|是| TF[用 Traffic Flow<br/>policy+version+record]
    NEED -->|否| WEIGH[权衡: $50/月 换可视化+批量创建<br/>值就用 不值就手工]
```

---

## 来源锚点

- **外部**：`traffic-flow.html`（[Using Traffic Flow to route DNS traffic](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/traffic-flow.html)：visual editor、versioning 默认 1000、automatic record creation、隐藏底层记录、选择性更新与快速回滚、geoproximity 地图、跨 zone 复用、仅 public zone、$50/月/record 与 alias 降本）；`traffic-policies-creating.html`（创建/管理 traffic policy）；`routing-policy-geoproximity.html`（geoproximity 地图仍限 Traffic Flow）；配额页 [`DNSLimitations.html`](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html)（traffic policies 50/账户、versions 1000/policy、policy records=policy instances 5/账户）；定价页 [Amazon Route 53 pricing](https://aws.amazon.com/route53/pricing/)。
- **内部**：r53-internal-research.md §3 "Traffic Flow / Traffic Policy"（图形编辑器编排、无法反向 GUI 化、用 R53 Information Search Tool 查 Traffic Policy Instance；geoproximity 2024/01 起可在 Traffic Flow 之外创建）——来源 kyoheibb 页 + TSR53DNSService。
- **交叉引用**：topic 03 §1.1（geoproximity 与 Traffic Flow 关系）、topic 16 §2.4（policy record $50/月计费与 alias 降本）、topic 12（配额）。

# 03b. 路由策略 × 健康检查 × Failover 交互决策（深度专题）

> **定位**：SME 最高频、最易错的交叉区。单看 topic 03（路由策略）或 topic 04（健康检查）都不够——真正的陷阱都出在"某路由策略 **绑定 HC 之后** 到底怎么应答"这个交叉点上。本专题把这条交叉线一次性钉死。
> **来源锚点**：topics/03-routing-policies.md（八策略 + fail-open）、topics/04-health-checks.md（四类 HC + 18% 规则 + ETH 绑定）、exam/codex-review-findings.md（topic 03 第 3/4/5/8 项、topic 04 全部）。
> **核心心法（背记）**：Route 53 的 DNS 层设计原则是 **"宁可返回一个可能坏的答案，也不返回空"**——所以几乎所有"全挂"场景的终局都是 **fail-open**，而不是 no answer。唯一的例外是 **geolocation 无 default** 和 **IP-based 无 `*`**，那不是"全挂"而是"根本没匹配上规则"。把这两类分清，本域大半陷阱自解。

---

## 1. 各路由策略绑定 HC 后的完整行为

先建立统一的判读框架：一条记录能否被返回，取决于三层串联——

1. **该记录是否"参与健康评估"**：绑定了独立 HC，或（对 alias）开了 Evaluate Target Health（ETH）。**没有任何一个 = 该记录"永远健康"**（见第 4 节的核心陷阱）。
2. **参与评估者的健康判定**：Endpoint 走 18% 规则、Calculated 走子检查计数、CloudWatch 走 alarm 数据流（详见 topic 04）。
3. **策略层的选取 + fail-open 兜底**：当"该选的都不健康"时，各策略如何兜底。

下面逐策略给出**绑定 HC 后的完整行为**，重点是每种策略的 **fail-open / 无匹配 终局**。

### 1.1 Weighted（加权）+ HC — 含 0-weight 与全挂

| 场景 | 行为 |
|---|---|
| 组内有健康记录 | 只在**健康**记录中按权重比例分流；不健康记录被剔除，其权重份额按比例重分给健康记录 |
| 单条 weight=0 | 该记录停流量；但它**本身仍受 HC 影响**（0 权重 ≠ 不评估健康） |
| **所有非 0 权重记录都不健康** | 才开始考虑 **0 权重记录**；此时若 0 权重记录健康则返回它 |
| **全部记录（含 0 权重）都不健康** | **fail-open**：按权重在**全部（不健康）记录**里选取——0 权重记录**不会**自动变成唯一兜底 |
| 组内全部 weight=0 | 对 0 权重记录做**平均**分配（等价均分） |

> **易错点（codex-review-findings topic 03 第 5 项）**：很多人以为"设 weight=0 就是永远不返回"。错。0 权重是"正常情况下不引流，但在所有非 0 权重都挂时充当次级候选"；而真正全挂时是 fail-open 按权重选，0 权重也不会独占兜底。

### 1.2 Latency（延迟）+ HC

- 每条 latency 记录**必须指定一个 AWS Region**（目标资源可在 AWS 外，见 findings topic 03 第 2 项）。
- 绑 HC 后：R53 先按用户到各 Region 的**长期实测延迟**排序候选，**再在候选中过滤健康记录**——即"先延迟后健康"，返回**延迟最优且健康**的记录。
- 若延迟最优的 Region 记录不健康 → 顺延到**次优且健康**的 Region。
- **全部 Region 记录都不健康** → **fail-open**，返回延迟最优的那条（即使不健康）。

### 1.3 Geolocation（地理位置）+ HC — 区分"无匹配"与"全挂"

这是最容易和 fail-open 混淆的策略，必须把**两条不同的失败路径**分开：

| 情况 | 是"无匹配"还是"全挂"？ | 终局 |
|---|---|---|
| 用户来源命中某地理规则，该记录健康 | 正常 | 返回该地理记录 |
| 用户来源命中某地理规则，该记录**不健康**，**有 default** | 全挂路径 | 落到 **default**（若 default 健康） |
| 用户来源命中某地理规则，该记录**不健康**，**无 default** | 全挂路径 | **no answer** |
| 用户来源**不匹配任何地理规则**，**有 default** | 无匹配路径 | 返回 **default** |
| 用户来源**不匹配任何地理规则**，**无 default** | 无匹配路径 | **no answer**（findings topic 03 第 8 项硬考点） |

> **关键区分**：geolocation 的"no answer"**不是 fail-open**，而是"没有可返回的地理记录 + 没有 default"。它是本域**唯一不 fail-open 的分散型策略**（连同 IP-based 无 `*`）。**务必建 default（`CountryCode:"*"`）**。

### 1.4 Multivalue Answer（MVA）+ HC

- 正常：随机返回**最多 8 条健康记录**（每条可各带 HC）。
- **全部记录都不健康** → **fail-open**：返回最多 8 条**不健康**记录（findings topic 03 第 8 项：不是"什么都不返回"）。
- **不是 ELB 替代**：无真正负载均衡 / 会话保持。

### 1.5 Simple（简单）— 不能绑 HC

- simple 记录**无 HC 概念**，返回 RRset 全部值随机排序。
- 要健康感知只能换策略（failover / MVA / weighted + HC）或用 **Alias + ETH**（见第 3 节）。

### 1.6 IP-based + HC

- 按客户端源 IP 最长匹配到较短 CIDR；绑 HC 后同样"先匹配 CIDR 后过滤健康"。
- **无 `*`（默认位置）且不匹配任何 CIDR** → **NODATA**（同 geolocation 无 default，非 fail-open）。
- **PHZ 不支持 IP-based**。

### 1.7 一张表：全挂 / 无匹配终局对照（★背记）

| 策略 | 组内全部不健康 | 无匹配规则 |
|---|---|---|
| Weighted | fail-open：按权重选（含不健康/0 权重） | N/A |
| Latency | fail-open：返回延迟最优（不健康） | N/A |
| **Geolocation** | 有 default→default；**无 default→no answer** | 有 default→default；**无 default→no answer** |
| Multivalue | fail-open：返回≤8 条不健康 | N/A |
| Failover | fail-open：**返回 Primary**（见第 2 节） | N/A |
| **IP-based** | fail-open | 有 `*`→`*`；**无 `*`→NODATA** |
| 整个 Hosted Zone 所有 HC 全挂 | **fail-open**：当作全部通过应答 | — |

> 记住这条主线：**分散型策略全挂 = fail-open（返回坏答案）；geolocation/IP-based 无兜底记录 = no answer/NODATA（返回空）**。前者是"健康筛选后全没了"，后者是"压根没进筛选"。

---

## 2. Failover：active-active vs active-passive vs 嵌套（nested）

### 2.1 术语先对齐（findings topic 04 第 C13 项）

- **Active-passive（主备）= failover 路由策略本身**。不存在一个另叫 "active-passive" 的独立策略——它就是 failover。
- **Active-active = 除 failover 外的任意策略**（weighted / latency / MVA / geolocation…）：所有同名同类型同策略记录都活跃，除非被 HC 判不健康而剔除。

### 2.2 Active-passive（单层 failover）完整行为

```
Primary 健康        → 返回 Primary
Primary 不健康,
  Secondary 健康    → 返回 Secondary
Primary + Secondary
  都参与评估且都不健康 → fail-open：返回 Primary（不可配置）
```

- **要"有效"故障转移，Primary 必须真正参与健康评估**：绑独立 HC，或对 alias Primary 开 ETH（findings topic 03 第 3 项）。
- **陷阱（findings topic 03 第 4 项）**：如果 **Secondary 没有 HC**，Secondary **永远健康** → 不存在"两者都不健康"的情形，也就永远不会 fail-open 回 Primary（而是稳定停在 Secondary）。所以"主备都不健康返回 Primary"这句话**只在主备都真正参与评估时成立**。
- **多资源主/备记录**：一条 failover 记录可关联多个资源，**只要至少一个健康，该 failover 记录即视为健康**。

### 2.3 Active-active（用非 failover 策略实现"多活"）

不用 failover，而是用 weighted / latency / MVA 等 + HC：所有端点同时活跃，HC 把不健康的自动剔除，健康的继续分流。**这才是"active-active"**。适合"多个端点同时服务、坏了就摘"的场景，而不是"平时只走主、主挂才走备"。

### 2.4 Nested failover（嵌套 / 与其他策略组合）

真实高可用架构常把 failover 与分散型策略**嵌套**，用 **Traffic Flow policy record** 或**记录集互相引用**实现多层决策。典型两种嵌套：

**嵌套 A：Failover → (Weighted / Latency)**
主备各自内部再做一层分散。

```
              ┌─ Primary 分支（健康时走这里）
              │     └─ Weighted: 90% EndpointA1 / 10% EndpointA2（各带 HC）
Failover 顶层 ┤
              └─ Secondary 分支（Primary 全挂才走）
                    └─ Latency: 就近选备用 Region（各带 HC）
```

- 顶层按 failover 判 Primary 分支是否健康；**Primary 分支的"健康"= 其下 weighted 组里至少一条健康**（子记录的健康向上聚合）。
- Primary 分支整体全挂 → 切到 Secondary 分支的 latency 组。

**嵌套 B：Weighted / Geolocation → Failover**
先按比例/地理分流，每个分片内部再各自做主备。

```
Geolocation 顶层
  ├─ CN  → Failover(Primary=北京主, Secondary=北京备)
  ├─ US  → Failover(Primary=弗吉尼亚主, Secondary=俄勒冈备)
  └─ *   → Failover(default 主备)
```

- **健康向上传递**：内层 failover 记录的健康状态，决定外层分片这条"记录"是否健康、是否被外层策略选中。
- **每一层的 fail-open 独立生效**：内层 failover 全挂 → 内层 fail-open 回其 Primary；外层再看这个（fail-open 返回的）结果是否满足外层选取。
- **实现方式**：嵌套需要**记录集之间的引用关系**，实操上通过 **Traffic Flow policy**（可视化编排）或手工把一条记录指向另一组记录集来搭建。

> **SME 判读要点**：嵌套架构里出问题，先定位**哪一层**在做决策、**那一层的健康是怎么向上聚合的**。一个常见误诊是"外层 failover 没切"，真相往往是内层 fail-open 返回了 Primary 的坏答案，外层据此认为"分支还健康"。

---

## 3. Evaluate Target Health（ETH）在 alias 链上的传递

### 3.1 ETH 是什么、和独立 HC 的关系（findings topic 04 第 C14 项）

- 记录指向**可建 alias 的 AWS 资源**（ELB / CloudFront / S3 网站端点 / API Gateway / 另一条 R53 记录等）时：**不要再单独建 endpoint HC**，而是把该 alias 记录的 **Evaluate Target Health = Yes**。
- ETH = Yes 时，R53 用**目标资源自身的健康状态**决定这条 alias 记录是否健康：
  - alias → ELB：看 ELB 后端 target 健康（至少一个健康 target）。
  - alias → CloudFront：CloudFront 始终视为健康（无 ETH 意义，通常不开）。
  - alias → S3 网站端点：看端点是否可用。
  - alias → **另一条 R53 记录**：看那条记录（及其 HC / 下层 ETH）的健康。

> **易错点**：给一条指向 ELB 的 alias 记录**同时**开 ETH **又**挂一个独立 endpoint HC —— 多余且可能语义冲突。二选一，AWS 资源用 ETH。

### 3.2 ETH 沿 alias 链的传递规则（★本节核心）

Alias 可以指向另一条 alias，形成**链**（findings topic 02 第 2 项：Alias 链受支持）。ETH 的健康信号沿链传递，规则是：

> **只有"该跳 alias 记录本身 ETH=Yes"，它才会去评估自己目标的健康并向上传递；某一跳 ETH=No，则该跳对上层"永远健康"，链上更深处的真实健康被这一跳掩盖。**

用一个三跳链说明：

```
记录1 (apex, alias, ETH=?) ─→ 记录2 (alias, ETH=?) ─→ ELB(有健康/不健康 target)
```

| 记录1 ETH | 记录2 ETH | ELB 实际 | 记录1 对外表现 | 说明 |
|---|---|---|---|---|
| Yes | Yes | 不健康 | **不健康** | 健康信号从 ELB 完整传到顶层 ✅ |
| Yes | **No** | 不健康 | **健康**（假健康） | 记录2 ETH=No → 记录2 对记录1 永远健康，掩盖了 ELB 真实状态 ❌ |
| **No** | Yes | 不健康 | **健康**（假健康） | 顶层不评估目标健康，直接视记录2 健康 |
| Yes | Yes | 健康 | 健康 | 正常 |

> **判读口诀**：**ETH 的传递会被链上任意一跳的 ETH=No"截断"**。排查"底层明明挂了、DNS 还在返回它"的 alias 链故障，逐跳核对 ETH 是否都为 Yes——**一跳为 No，下游健康就传不上来**。
>
> 另注（findings topic 12）：**单条 simple alias 即使目标不健康也可能 fail-open 仍返回**——要真正验证 ETH 生效，需在**多记录组（如 failover/weighted）**里验证，而不是拿一条孤立 alias 看。

---

## 4. "无 HC = 永远健康" 陷阱（本域最高频误诊）

### 4.1 一句话陷阱

> **一条记录如果既没绑独立 HC，也没开 ETH（对 alias），Route 53 就把它视为"永远健康"，永远可被返回。** 它不会因为后端真的挂了而被摘掉。

### 4.2 三种典型踩坑现场

1. **Failover Primary 无 HC**：Primary 指向的真实后端已死，但因为 Primary 记录没 HC / alias 没开 ETH → R53 认为 Primary 永远健康 → **永远不切 Secondary**。客户报"配了 failover 却不切换"，根因几乎都是这个（findings topic 03 第 3 项）。
2. **Failover Secondary 无 HC**：如 2.2 所述，Secondary 永远健康，导致主挂后稳定停在 Secondary、且永不 fail-open 回 Primary——看起来像"切过去就回不来了"。
3. **Alias 链某跳 ETH=No**：如第 3 节，底层 ELB target 全挂，但中间跳 ETH=No 截断了健康信号，顶层始终返回这条链——"后端全红，DNS 还在发流量过去"。

### 4.3 为什么这么设计

这是 DNS 层"**fail-open / 宁可返回坏答案也不返回空**"哲学的直接体现：R53 缺省不假设"没配 HC 就是坏的"，而是"没让我评估健康，我就默认它能用"。所以**健康感知是要显式开启的**——绑 HC 或开 ETH。

### 4.4 排查清单（记录"永远返回坏后端"时逐条核对）

- [ ] 这条记录（及 failover 的 Primary **和** Secondary）**是否各自绑了 HC 或开了 ETH**？
- [ ] 若是 alias 链，**每一跳的 ETH 是否都为 Yes**？（一跳 No 即截断）
- [ ] HC 本身是否卡在假健康？（Endpoint HTTPS **不校验证书**、CloudWatch `InsufficientDataHealthStatus` 配成 Healthy、新建 HC 数据不足前默认健康——见 topic 04）
- [ ] 是否落进了 fail-open？（分散型策略**全挂**、或整个 zone HC 全挂 → 都会 fail-open 返回坏答案，此时"返回坏答案"是**预期行为**不是 bug）
- [ ] simple 记录想要健康感知？—— simple 不能绑 HC，**换策略或 Alias+ETH**。

---

## 5. 高难度场景题（8 道，带详解）

> 难度对标 SME 认证 + 真实疑难 case。先自己判，再看详解。

---

**Q1.** 某 failover 配置：Primary = alias → ALB（ALB 后端 target 全部 unhealthy），ETH=Yes；Secondary = 一条指向 EIP 的 A 记录，**未绑任何 HC**。此刻 ALB 又完全恢复健康。问：从 ALB 挂到恢复的整个过程，R53 分别返回什么？

<details><summary>详解</summary>

- ALB 全挂期间：Primary（ETH=Yes）读到 ALB target 全 unhealthy → Primary 不健康；Secondary 无 HC → **永远健康** → 返回 **Secondary**。
- ALB 恢复后：Primary 重新健康 → 立即切回 → 返回 **Primary**。
- **关键**：因为 Secondary 永远健康，**从不存在"主备都不健康"**，所以全程不会 fail-open。这套配置能正常主备切换（Secondary 是静态 EIP，无 HC 是合理的"总是可用兜底"设计）。对比 Q2 看差异。
</details>

---

**Q2.** 同 Q1，但把 **Primary 的 ETH 改成 No**（其它不变，ALB target 全挂）。R53 返回什么？为什么？这是"正确行为"吗？

<details><summary>详解</summary>

- Primary ETH=No → R53 **不评估** ALB 健康 → Primary **视为永远健康** → 返回 **Primary**（指向全挂的 ALB）。
- 结果：**永远不切 Secondary**，客户流量持续打到死后端。
- 这是**配置错误导致的假健康**，不是预期行为。这正是第 4 节陷阱 1 / findings topic 03 第 3 项。修复：Primary alias 开 ETH=Yes（或改绑独立 HC）。
</details>

---

**Q3.** 一个 weighted 组：A(weight=70, HC 健康)、B(weight=30, HC 健康)、C(weight=0, HC 健康)。现在 A 和 B 的 HC **同时变不健康**。R53 返回谁？如果随后 C 的 HC 也变不健康呢？

<details><summary>详解</summary>

- A、B（非 0 权重）都不健康 → 触发"考虑 0 权重记录"→ C 健康 → 返回 **C**。
- C 也不健康后：**全部记录都不健康** → **fail-open**，按权重（70/30/0）在**全部不健康记录**中选 → 实际在 A、B 间按 70:30 分（C 权重 0 不参与）→ 返回 **A 或 B**（不健康的）。
- **关键**：0 权重记录 C 只在"非 0 权重全挂"时充当次级候选，**不会**在真正全挂时独占兜底（findings topic 03 第 5 项）。
</details>

---

**Q4.** geolocation 记录：`CountryCode=CN → IP_A(HC 健康)`、`CountryCode=US → IP_B(HC 健康)`，**未建 default**。三个查询：(a) 来自中国、IP_A 健康；(b) 来自中国、IP_A **不健康**；(c) 来自德国。分别返回什么？

<details><summary>详解</summary>

- (a) 命中 CN、IP_A 健康 → 返回 **IP_A**。
- (b) 命中 CN、IP_A 不健康、**无 default** → **no answer**（不会跳去返回 US 的 IP_B——geolocation 不跨地理区兜底）。
- (c) 德国不匹配任何规则、**无 default** → **no answer**（findings topic 03 第 8 项）。
- **关键**：geolocation 的失败终局是 **no answer 而非 fail-open**。建 `CountryCode:"*"` default 才能兜住 (b) 的全挂和 (c) 的无匹配。
</details>

---

**Q5.** 嵌套：顶层 failover，Primary 分支指向一个 **weighted 组（A 50% / B 50%，各带 HC）**，Secondary 分支指向单个备用端点（带 HC 健康）。现在 weighted 组里 **A 挂了、B 还健康**。顶层会切到 Secondary 吗？

<details><summary>详解</summary>

- 不会。Primary 分支的健康 = 其下 weighted 组"**至少一条健康**"。B 还健康 → Primary 分支整体**仍视为健康** → 顶层 failover 停在 Primary，只是内部全走 B。
- 只有当 **A 和 B 都挂**（weighted 组全挂）时，Primary 分支才整体不健康，顶层才切 Secondary。
- **关键**：嵌套里"分支健康"是**子记录健康向上聚合**的结果，不是"分支内某一条挂了就切"。
</details>

---

**Q6.** 三跳 alias 链：`apex 记录(ETH=Yes) → 中间记录(ETH=Yes) → 末端 alias → CloudFront`。CloudFront 分发正常但**源站(origin)全挂**。R53 返回什么？这暴露了 ETH 的什么局限？

<details><summary>详解</summary>

- 每跳 ETH=Yes，健康信号沿链传递没问题；但**末端目标是 CloudFront**——CloudFront 对 ETH **始终视为健康**（ETH 看的是"CloudFront 分发是否存在/可用"，不深入探测你的 origin）。
- 所以链上健康 = CloudFront 健康 = **健康** → R53 正常返回这条链，**尽管 origin 全挂**。
- **局限**：ETH 只到"AWS 资源自身层"，不代表业务后端健康。CloudFront/API Gateway 这类目标，ETH 无法反映其背后 origin 的真实状态——需要在 origin 侧另配 endpoint/CloudWatch HC + 用 failover 组来感知。
</details>

---

**Q7.** 一个 multivalue answer 记录集有 6 条记录，各带 endpoint HC。某时刻**全球网络出现大范围隔离**，导致所有 6 条记录的 endpoint HC 都只有约 10% 的全球 checker 能连上（<18%）。R53 此刻返回什么？和"后端真的全挂"有何不同？

<details><summary>详解</summary>

- 每条记录 <18% checker 报健康 → 按 18% 规则**判不健康** → 6 条**全部不健康**。
- MVA 全挂 → **fail-open**，返回最多 8 条（这里 6 条）**不健康**记录。
- 与"后端真挂"**在 DNS 应答上没有区别**——都是返回这些记录。差别在**根因**：这里后端可能其实活着，是**网络隔离**让 checker 连不上；18% 门槛本就是为了缓解"某处隔离误判全挂"，但当隔离范围过大（<18%）仍会判死。
- **判读**：看到"HC 全红但客户说服务正常"，优先怀疑 checker 侧网络/防火墙（HC 源是多 region managed prefix list，别只放本 region CIDR），而非后端。
</details>

---

**Q8.** 某 zone 内所有记录的 HC **同时全部不健康**（比如一次误操作把所有目标端口封了）。R53 对这个 zone 的查询会怎么应答？为什么 AWS 这么设计？运维上这意味着什么？

<details><summary>详解</summary>

- **整个 Hosted Zone 所有 HC 全不健康 → R53 fail-open**：当作"全部通过"来应答，正常返回记录（topic 04 fail-open 行为）。
- **设计原因**：DNS 是流量入口，如果"全挂就返回空"，等于把整个域名从互联网上抹掉，故障被放大到不可恢复；fail-open 至少保留"返回一个地址、让流量到达、可能触发后端自愈"的机会。
- **运维含义**：**不能靠 DNS HC 全红来"熔断"整个域**——它不会熔断，反而照发。真正需要"全挂就停"的语义要在应用层/ELB 层做。同时监控上要意识到：zone 级 fail-open 期间，DNS 应答"看起来正常"会掩盖底层全挂，需用独立的后端监控而非 DNS 探测来发现。
</details>

---

## 6. 交叉决策 Mermaid 树

### 6.1 "一条记录到底会不会被返回"总决策树

```mermaid
flowchart TD
    START([查询到达 R53 权威 NS<br/>某组同名同类型记录]) --> POL{路由策略?}

    POL -->|Simple| SIMPLE[无 HC 概念<br/>返回 RRset 全部值随机排序]
    POL -->|Geolocation / IP-based| MATCH{命中地理/CIDR 规则?}
    POL -->|Weighted/Latency/MVA/Failover| EVAL{该记录参与健康评估?<br/>绑 HC 或 alias ETH=Yes}

    MATCH -->|不匹配 且有 default/*| RETDEF[返回 default / *]
    MATCH -->|不匹配 且无 default/*| NOANS[no answer / NODATA<br/>★非 fail-open]
    MATCH -->|匹配| EVAL

    EVAL -->|否 无 HC 且无 ETH| ALWAYS[视为永远健康<br/>★假健康陷阱: 后端挂也返回]
    EVAL -->|是| HCJUDGE{健康判定<br/>Endpoint:18%规则<br/>Calc:子检查计数<br/>CW:alarm数据流}

    HCJUDGE -->|健康| HEALTHY[候选: 健康]
    HCJUDGE -->|不健康| UNHEALTHY[候选: 不健康]

    ALWAYS --> PICK
    HEALTHY --> PICK
    UNHEALTHY --> PICK

    PICK{组内是否还有健康候选?} -->|有| RETHEALTHY[在健康候选中按策略选取<br/>weighted按权重/latency按延迟/MVA随机≤8]
    PICK -->|全部不健康| FAILOPEN[fail-open<br/>weighted按权重选坏的<br/>latency返延迟最优坏的<br/>MVA返≤8坏的<br/>failover返 Primary]

    RETHEALTHY --> DONE([返回应答])
    FAILOPEN --> DONE
    RETDEF --> DONE
    SIMPLE --> DONE
```

### 6.2 Failover + 嵌套 + 健康向上聚合

```mermaid
flowchart TD
    Q([failover 顶层判定]) --> P{Primary 分支健康?<br/>=分支内子记录健康向上聚合}

    P -->|健康| INP[进入 Primary 分支]
    P -->|不健康| S{Secondary 参与评估?}

    INP --> INNER1{Primary 分支内层策略}
    INNER1 -->|嵌套 weighted/latency| AGG1[至少一条子记录健康<br/>=分支健康; 全挂→内层fail-open]

    S -->|Secondary 有 HC/ETH 且不健康| BOTH{Primary 与 Secondary<br/>都参与评估且都不健康?}
    S -->|Secondary 无 HC 永远健康| RETS[返回 Secondary<br/>★永不fail-open回Primary]

    BOTH -->|是| FO[fail-open 返回 Primary<br/>不可配置]
    BOTH -->|否 Secondary 健康| RETS2[返回 Secondary]

    AGG1 --> RETP[返回 Primary 分支选出的端点]
```

### 6.3 ETH 沿 alias 链传递（一跳 No 即截断）

```mermaid
flowchart LR
    R1[顶层 alias 记录] -->|ETH=Yes 才向下评估| R2[中间 alias 记录]
    R1 -.->|ETH=No| CUT1[视 R2 永远健康<br/>截断下游真实健康]
    R2 -->|ETH=Yes 才向下评估| TGT[末端 AWS 资源<br/>ELB/CF/S3/API GW]
    R2 -.->|ETH=No| CUT2[视目标永远健康<br/>截断真实健康]
    TGT --> REAL{目标自身健康?<br/>ELB看target / CF始终健康}
    REAL -->|不健康 且全链 ETH=Yes| UP[健康信号完整上传→顶层不健康]
    REAL -->|健康| UP2[顶层健康]
```

---

## 7. 一页速记（交叉区结论）

- **fail-open 主线**：分散型策略（weighted/latency/MVA/failover）**全挂 = 返回坏答案**；整个 zone HC 全挂 = fail-open。
- **no answer 主线**：**geolocation 无 default** / **IP-based 无 `*`** = 返回空（**非** fail-open）——这是"没进筛选"，不是"筛完全没了"。
- **Failover**：Primary 必须真参与评估（HC 或 ETH）才切；主备**都参与评估且都不健康** → fail-open 回 **Primary**（不可配置）；**Secondary 无 HC = 永远健康 = 永不 fail-open**。
- **无 HC = 永远健康**：既没 HC 也没 ETH 的记录，后端挂了也照返回——failover 不切、alias 链假健康的头号根因。
- **ETH 沿 alias 链传递，任一跳 ETH=No 即截断**下游真实健康；ETH 只到 AWS 资源自身层（CloudFront/API GW 的 origin 健康它看不到）。
- **嵌套**：分支健康 = 子记录健康**向上聚合**（至少一条健康则分支健康）；每层 fail-open 独立生效；排查先定位是哪一层在决策。
- **简单记录不能绑 HC**；要健康感知换策略或 Alias+ETH。
- 验证 ETH 真生效要用**多记录组**（单条 simple alias 会 fail-open 掩盖）。

---

## 来源锚点

- **本仓**：topics/03-routing-policies.md（八策略、fail-open QA-337、weighted 0 权重、geolocation no answer）、topics/04-health-checks.md（四类 HC、18% 规则、响应时间阈值、ETH 绑定 C14、fail-open 单条/整 zone、Primary 必须 HC）、topics/02-records-and-alias.md（Alias 链受支持）、topics/12-integrations-quotas.md（单条 simple alias fail-open、验证 ETH 需多记录组）。
- **审校**：exam/codex-review-findings.md — topic 03 第 2/3/4/5/8/9 项、topic 04 第 C13/C14/C15/C16 全部、topic 02 第 2 项、topic 12 ETH 实验修正。
- **绑定 case**：178246722300140（geolocation 必配 default 否则 no answer）、P460958645（CloudWatch HC 假健康/状态同步）、178782060900806（failover 设计，见 topic 01/13）。

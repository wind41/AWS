# 06. DNS Firewall / Global Resolver

## 1. 概念（Concept）

DNS Firewall 是 Route 53 Resolver 的一个特性，对 **出站（outbound）DNS 查询** 做 **域名层过滤**，主要用途是防 **DNS 数据渗漏（exfiltration）**——攻击者把窃取的数据编码进 DNS 查询里发往受控域名。它在查询被解析成 IP 之前就检查域名，命中恶意/黑名单域名或高级威胁模式的查询被直接拦截，永远到不了目标 name server。无需额外部署，它就是 VPC Resolver（VPC+2 / .2 resolver）路径上的一层。

**核心组件**
- **Rule group（规则组）**：一组可复用的 rule 集合，**关联到 VPC** 后生效。
- **Rule（规则）**：组内一条过滤规则，指定一个 domain list（或 Advanced 保护）+ 一个动作。
- **Domain list（域名列表）**：待匹配的域名集合。分两类——**自建（customer-managed）** 与 **AWS 托管（AWS-managed）**。托管列表覆盖 C2、恶意软件、钓鱼等类别，由 AWS 持续维护、**至少每日更新一次**、**具体域名不公开**、每个列表含数千域名。
- **DNS Firewall Advanced**：基于机器学习检测 **DNS tunneling / DGA（域名生成算法）** 这类无法用静态列表覆盖的高级威胁。

**匹配特性（只看域名）**
- **只按域名字符串过滤，不解析成 IP，也不看 HTTPS/SSH/TLS/FTP 等应用层协议**。因此即使某域名在公网根本不存在，只要查询字符串命中列表就会被拦截。
- 自建列表支持 **精确匹配**（`example.com`）与 **通配符**（`*.example.com` 匹配所有子域名）。

**动作（Action）**——SME 关键区分：
- **含 domain list 的规则**可选 **ALLOW / BLOCK / ALERT** 三种动作。
- **不含 domain list 的规则（即 Advanced 保护）只能 BLOCK / ALERT**，不能 ALLOW。
- **BLOCK 响应有三种**可自定义：**NXDOMAIN / NODATA / OVERRIDE（CNAME 重定向）**。

**优先级（priority，SME 高频必背）**
- 一个 VPC 关联多个 rule group 时，**按关联的 priority 数字从小到大** 处理（lowest numeric priority first，先执行）。
- 一个 rule group **内部**每条 rule 有组内唯一 priority，**同样从小到大** 处理。
- 用 **AWS Firewall Manager** 集中管理时，FM 管的关联占据**最低（first）与最高（last）** 两个优先级位置。
- 来源：external §8 / 考点 E25；docs `resolver-dns-firewall-overview.html`。

**Domain redirection（重定向链）设置**
- 默认会**检查整条重定向链**（CNAME/DNAME…）。若一个被 ALLOW 的域名，其 CNAME target 指向另一个**不在列表里**的域名，链上后续域名须**显式加入 domain list 并设动作**，否则可能因 A+AAAA 记录缺失而被 BLOCK。trust 行为仅在**单次查询事务内**有效。（对应内部 QA-497 的 allowlist CNAME 未列被 BLOCK 陷阱。）

**与 Network Firewall 的区别（考点 E26）**
- **DNS Firewall**：只看**经 VPC Resolver 的出站 DNS 查询**，域名层。
- **Network Firewall**：过滤网络/应用层流量，但**看不到 Resolver 发起的 DNS 查询**。二者互补，不是替代关系。

**Global Resolver + DNS View（新形态）**
- **Global Resolver** 提供一组**全球可达的 Anycast IP**，授权客户端（办公网、分支、远程用户）从任何位置解析公共域名和 PHZ 私有域名，**无需 VPN**。（旧称 Route 53 Resolver，因引入 Global Resolver 而把 VPC 内那套更名为 **VPC Resolver**。）
- **DNS View** 是 Global Resolver 里承载策略的对象：**DNS Firewall 规则绑定到 DNS View，不是 VPC**（这与 VPC Resolver 的 DNS Firewall 绑定 VPC 相对）。
- 客户端身份靠 **Access Source（源 IP CIDR 匹配）** 或 **Access Token** 验证。
- **Global Resolver 控制面 API 固定在 us-east-2（Ohio）**。
- 查询日志走 **OCSF 格式**，落 CloudWatch Logs。
- **Global Resolver DNS Firewall 保护 VPC 外部客户端；VPC Resolver DNS Firewall 保护 VPC 内部工作负载**——二者互补。

---

## 2. 真实案例说明（Real Case）

本 topic 无绑定的 Support case，教学锚点是 re:Post 文章 + Global Resolver 实验草稿；内部 QA-497 提供一个经典陷阱。

- **场景（re:Post 教学文章）**：企业要阻止 VPC 外部客户端（办公/远程/分支）解析恶意域名。通过 Global Resolver + DNS View + DNS Firewall 三种规则（自定义黑名单、AWS 托管 Malware 列表、DGA 高级检测）在**查询解析前**拦截。落点：DNS Firewall 是 Global Resolver 安全架构的核心层，在解析发生前评估查询。

- **陷阱案例（内部 QA-497，对应考点"Domain redirection"）**：采用 **allowlist（只放行白名单）** 方式时，一个被允许域名的 **CNAME target 指向另一个未列入白名单的域名**，结果因该 target 的 `A+AAAA 记录` 相当于"未被 ALLOW 命中"而被 `firewall_rule_action: BLOCK`。根因是**重定向链上的后续域名没有显式加入 domain list**。知识点落点：ALLOW 白名单要把整条 CNAME 链的域名都覆盖，或正确配置 Trust Redirection Domains 设置。

- **验证陷阱（贯穿实验）**：**ALERT 规则命中的流量，OCSF 日志里 `action_name` 仍是 `Allowed`（因为被放行了）**，只能靠日志中的 `firewall_rule_id` 区分它是否命中了某条 ALERT 规则；同理 **DGA 规则是否命中不能仅凭 dig 返回 NXDOMAIN 判断，必须查日志的 `firewall_rule_id`**。这是"用户可见形态 ≠ 中间判据"的典型：单看 dig 结果会误判。

---

## 3. 实验步骤（Hands-on Lab）

完整端到端实验：**建 Global Resolver → DNS View → Access Source → Query Logging → 三类 Firewall 规则 → dig 验证 → CloudWatch Logs Insights 查 OCSF `firewall_rule_id`**。

> Region 固定 **us-east-2（Ohio）**；资源前缀 `lab-`；预计 30–40 分钟。属**创建资源型（有成本）** 实验，做完务必按 Step 9 清理。

**前提条件**
- IAM 权限：`AmazonRoute53GlobalResolverFullAccess` + `CloudWatchLogsFullAccess`。
- 最新 AWS CLI v2：`aws route53globalresolver help` 确认子命令可用。
- 取本机公网 IPv4：`curl -4 -s https://checkip.amazonaws.com`

**Step 1：创建 Global Resolver**
1. Console → Region 切到 **US East (Ohio) us-east-2** → Route 53 → 左侧 **Global Resolver** → **Create global resolver**。
2. Resolver name `lab-global-resolver`；Regions 选 `us-east-2` + `us-west-2`（≥2 个，就近选）；IP address type `Dual-stack`。
3. Create → 等状态 **Operational**（约 3–5 分钟）→ **记下分配的 Anycast IPv4 地址**（后续测试用）。

**Step 2：创建 DNS View**
1. 进入 `lab-global-resolver` → **DNS views** tab → **Create DNS view** → name `lab-dns-view`。
2. 默认项：DNSSEC validation `Enable`、Firewall rules fail open `Disable`、EDNS client subnet `Enable`。
3. Create → 等 **Operational** 再继续。

**Step 3：配置 Access Source（授权客户端）**
1. `lab-dns-view` → **Access sources** tab → **Create access source**。
2. Name `lab-my-ip`；CIDR block = `你的IPv4/32`（精确匹配本机公网 IP）；Protocol `Do53`。
3. Create → 等 **Operational**。

**Step 4：启用 Query Logging（测试前先开，否则查询不被捕获）**
1. 回 `lab-global-resolver` 详情页 → Resolver details 里 **Observability Region** → **Edit** → 选 `US East (Ohio) us-east-2` → Save。
2. **Log delivery** tab → 目标 **CloudWatch Logs log group**，Log type 保持 `GLOBAL_RESOLVER_LOGS`；log group 用系统推荐路径（形如 `/aws/vendedlogs/route53globalresolver/...`）或建 `/aws/route53globalresolver/lab-firewall-logs` → Save。

**Step 5：创建自定义域名列表**
1. `lab-global-resolver` → **Domain lists** tab（**注意是 Global Resolver 内部的 Domain lists，不是左侧菜单 VPC Resolver 下的**）→ **Create domain list** → name `lab-blocked-domains` → Create → 等 **Operational**。
2. 进入 `lab-blocked-domains` → **Add domains**（Specify manually），每行一个：
   ```
   malicious-test.example.com
   *.phishing-demo.net
   bad-site.org
   ```
3. Add → 再次等 **Operational**。（精确匹配 + 通配符；域名即使公网不存在也会被拦。）

**Step 6：创建三条 Firewall 规则**（`lab-dns-view` → **DNS Firewall rules** tab → **Create rule**）

- **规则 A — 自定义域名 Block**：name `lab-block-custom`；type **Customer managed domain lists**；Domain list 选 `lab-blocked-domains`；Query type 留空（匹配所有类型）；Action **Block**；Block 响应 **NXDOMAIN**。
- **规则 B — AWS 托管恶意域名 Block**：name `lab-block-malware`；type **AWS managed domain lists**；下拉选 **Malware** 类别；Action **Block**；响应 **NXDOMAIN**。
- **规则 C — DGA 高级检测**：name `lab-detect-dga`；type **DNS Firewall Advanced protections**；Protection type **Domain Generation Algorithms (DGAs)**；Confidence threshold **HIGH**；Action **Block**；响应 **NXDOMAIN**。

创建后在规则列表确认三条全为 **Operational**，并**记下每条的 Firewall Rule ID（`fr-xxxxxxxxx`）**。**Priority 由系统按创建顺序自动分配 1、2、3，数字越小越先执行**；如需调整顺序 → 选中规则 → Edit → 改 Priority。

| Priority | Name | Action | Type |
|---|---|---|---|
| 1 | lab-block-custom | Block | Domain lists |
| 2 | lab-block-malware | Block | AWS Managed |
| 3 | lab-detect-dga | Block | Advanced DGA |

**Step 7：dig 测试验证**（从**已授权**客户端执行，`ANYCAST_IP` 换成 Step 1 的 IP）
```bash
ANYCAST_IP="x.x.x.x"

# 1. 正常域名 → 预期 status: NOERROR，返回正常 A 记录
dig @$ANYCAST_IP aws.amazon.com

# 2. 自定义黑名单精确匹配（规则 A）→ 预期 status: NXDOMAIN
dig @$ANYCAST_IP malicious-test.example.com

# 3. 通配符匹配 → 预期 status: NXDOMAIN
dig @$ANYCAST_IP anything.phishing-demo.net

# 4. DGA 风格随机域名（规则 C 可能命中，不保证）
dig @$ANYCAST_IP xk3f9a2bz7mqp4dwn.evil-test.com
```
**判读——如何区分 Firewall Block 与正常公网 NXDOMAIN**：
- Firewall 拦截：flags 含 `qr aa rd`，**无 AUTHORITY section，无 OPT PSEUDOSECTION**。
- 正常公网 NXDOMAIN：flags 含 `qr rd ra`，**有 SOA AUTHORITY section + OPT**。

**Step 8：OCSF 日志确认命中**（等 1–2 分钟日志到 CloudWatch → us-east-2 → Logs Insights → 选对应 log group）
```
fields @timestamp, query.hostname, action_name, rcode
| sort @timestamp desc
| limit 20
```
- `action_name = Denied` → 被拦截；`action_name = Allowed` → 放行（含 DGA 未命中）。
- 展开 Denied 条目，看 `enrichments[].data.firewall_rule_id` 是否与你的规则 ID 一致。
- **DGA 规则是否命中，只能靠此处的 `firewall_rule_id` 确认**，不能凭 dig 的 NXDOMAIN 判断。HIGH 阈值较保守，未命中随机域名属正常行为（可降到 MEDIUM 重建再测）。

**Step 9：清理（按序）**
1. DNS View → Firewall rules → 逐条删 3 条规则；
2. Global Resolver → Domain lists → 删 `lab-blocked-domains`；
3. DNS View → Access sources → 删 `lab-my-ip`；
4. Global Resolver → DNS views → 删 `lab-dns-view`；
5. Global Resolver 列表 → 删 `lab-global-resolver`；
6. CloudWatch → Log groups → 删对应 log group。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

**E25 — DNS Firewall 基本盘**
- 结论：**只管出站、只按域名、防 exfiltration**；rule group 与 rule **都按 priority 数字从小到大** 处理；**含 domain list 的规则才能 ALLOW，Advanced 只能 BLOCK/ALERT**。
- 常见错误：以为它能按 IP/端口/应用层过滤（错，只看域名字符串）；以为 priority 数字大的先执行（错，**小的先**）；以为任何规则都能 ALLOW（错，Advanced 不行）。

**E26 — DNS Firewall vs Network Firewall**
- 结论：DNS Firewall 看**经 Resolver 的出站 DNS 查询**；Network Firewall 看网络/应用层但**看不到 Resolver 发起的 DNS 查询**。
- 常见错误：以为 Network Firewall 能拦住 DNS exfiltration（拦不到 Resolver 的查询），或以为二者二选一（其实互补）。

**BLOCK 响应三选一**：**NXDOMAIN / NODATA / OVERRIDE（CNAME 重定向）**。易错：以为只有 NXDOMAIN 一种。

**Domain redirection 陷阱（内部 §5 QA-497）**
- 结论：allowlist 模式下，被 ALLOW 域名的 CNAME target 若未列入 domain list，会被 BLOCK；默认检查整条重定向链，链上域名须显式加入并设动作，trust 仅在单次查询事务内有效。
- 常见错误：只把入口域名加白名单，忘了 CNAME 指向的后续域名。

**ALERT / DGA 的验证陷阱（横切"报收工前硬性自检"）**
- 结论：**ALERT 命中流量的 `action_name` 仍是 `Allowed`**；**DGA 是否命中必须查 OCSF `firewall_rule_id`，不能凭 dig 的 NXDOMAIN 判断**。
- 常见错误：单看 dig 返回值就下"规则命中/未命中"结论。OCSF 里动作值是 `Allowed`/`Denied`，**不是** `ALLOW`/`BLOCK`。

**AWS 托管域名列表**：具体域名**不公开**，每列表数千域名，**至少每日更新一次**，覆盖 C2/恶意软件/钓鱼等类别。易错：以为能查看/编辑托管列表里的具体域名。

**Firewall Manager**：可跨组织集中管理 rule group 关联，FM 的关联占据**最低与最高**两个优先级位置。

**Global Resolver 特有考点**
- **控制面 API 固定 us-east-2（Ohio）**。
- **Firewall 规则绑定 DNS View，不是 VPC**（对比 VPC Resolver 绑 VPC）。
- 客户端授权靠 **Access Source（源 IP）或 Access Token**。
- **Global Resolver 保护 VPC 外部客户端；VPC Resolver 保护 VPC 内部**。
- **Advanced Protection 与域名列表不能放在同一条规则里**。
- 每个资源（DNS View / Access Source / Domain List / Firewall Rule）创建后都需等 **Operational** 才生效；Domain List 建好等一次、加域名后再等一次。

**内部边界速记（§5）**：DNS Firewall 是 VPC Resolver 特性，无需额外部署；VPC .2 resolver 支持 EDNS0 但不支持 ECS（与 Firewall 无关但同属 Resolver 层，勿混）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

出站 DNS 查询经 DNS Firewall 的处理决策链（priority 从小到大，含 Block 三响应与 OCSF 日志判读）：

```mermaid
flowchart TD
    A["客户端 DNS 查询<br/>(VPC 内经 .2 Resolver / VPC 外经 Global Resolver Anycast IP)"] --> B{"Global Resolver?<br/>验证 Access Source / Token"}
    B -->|未授权| BX["拒绝 (未授权源)"]
    B -->|授权 / 或 VPC 内| C["进入 DNS Firewall<br/>按关联 priority 从小到大取 rule group"]
    C --> D["rule group 内 rule 按 priority 从小到大逐条匹配"]
    D --> E{"命中哪类规则?"}

    E -->|"含 domain list<br/>ALLOW"| F["放行 → 正常解析"]
    E -->|"含 domain list / Advanced<br/>BLOCK"| G{"Block 响应类型"}
    E -->|"含 domain list / Advanced<br/>ALERT"| H["放行(记录) → 正常解析<br/>⚠ 日志 action_name = Allowed"]
    E -->|"无规则命中"| F

    G --> G1["NXDOMAIN"]
    G --> G2["NODATA"]
    G --> G3["OVERRIDE (CNAME 重定向)"]

    F --> I["正常解析: PHZ 优先 → 公网递归"]
    G1 --> J["返回客户端 (flags: qr aa rd, 无 AUTHORITY/OPT)"]
    G2 --> J
    G3 --> J
    H --> I

    F --> K["Query Logging (OCSF)"]
    G --> K
    H --> K
    K --> L["CloudWatch Logs Insights<br/>看 action_name (Allowed/Denied)<br/>+ enrichments[].data.firewall_rule_id<br/>⚠ DGA/ALERT 命中只能靠 firewall_rule_id 确认"]

    subgraph note["优先级与动作要点"]
      P1["rule group 与 rule 均: priority 数字越小越先执行"]
      P2["含 domain list → ALLOW/BLOCK/ALERT"]
      P3["Advanced(DGA/tunneling) → 仅 BLOCK/ALERT"]
      P4["Global Resolver 规则绑 DNS View, 控制面在 us-east-2"]
    end
```

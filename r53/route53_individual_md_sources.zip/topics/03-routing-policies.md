# 03. 路由策略（8 种）

## 1. 概念（Concept）

Route 53 用**路由策略**决定"对一条查询返回哪个（些）记录值"。同一命名空间下、同名同类型的一组记录只能用**同一种**路由策略。总览见外部 §5（`routing-policy.html`）、内部 §3（R53PublicDNS / kyoheibb / TSR53DNSService）。

### 1.1 八种策略逐个

1. **Simple（简单）**
   - 单资源、单条 RRSET；一条记录内可含多个值，权威 NS 返回该 RRset 的**全部值并随机排序**（这是粗粒度分散，不是负载均衡）。单 RRset 值的数量受**单 RRset 配额 400 条**约束（并非"最多 8 值"，8 值上限是 Multivalue 的特性）。
   - **不能关联健康检查**（simple 记录本身无 HC 概念）。PHZ 里可建。
   - 外部 §5.1 `routing-policy-simple.html`；内部 §3。

2. **Weighted（加权）**
   - 按权重比例分流：某记录流量占比 = 该记录 weight ÷ 组内所有 weight 之和。
   - **weight 上限 255**（单条）。可关联健康检查。
   - **权重 0 的行为（考点）**：单条设 0 = 停止该记录流量；零权重记录本身仍受健康检查影响。**仅当组内所有非 0 权重记录都不健康时**，才会考虑启用 0 权重记录——但此时是 fail-open 后**仍按权重选取**，零权重记录不会自动成为唯一兜底（组内全 0 时才对 0 权重记录平均分）。
   - 实务：同一个 ELB 可被多条加权记录引用，以实现比 256 更细的分配（内部 §3 QA-483）。加权是**概率分布**：要观察实际分配比例需直接向权威 NS 采样，样本量按统计目标定，1–2 次查询看不出。
   - 外部 §5.8 `routing-policy-weighted.html`；内部 §3 TSR53DNSService。

3. **Latency（延迟）**
   - 多 Region 部署时，路由到对用户**延迟最低的 AWS Region** 的资源；每条记录**必须指定一个 AWS Region**，但目标资源**可以在 AWS 之外**（延迟依据是用户到该 AWS 数据中心的测量，故对外部资源可能不准）。
   - 基于 AWS **长期测量**的延迟数据（**非实时**），会随网络状况漂移；数据只覆盖到 AWS 数据中心之间的流量。
   - 外部 §5.5 `routing-policy-latency.html`；内部 §3。

4. **Failover（故障转移）**
   - active-passive 主备：Primary 健康回 Primary，Primary 不健康回 Secondary。
   - **要实现有效的故障转移，Primary 需关联健康检查（HC），或对 Alias Primary 启用 EvaluateTargetHealth（ETH）**；无 HC 的记录会被视为**始终健康**，Primary 因此不会切到 Secondary（并非"无法创建 failover 策略"）。
   - **考点（fail-open）**：仅当 Primary 与 Secondary **都真正参与健康评估**且**都不健康时 → R53 返回 Primary**（fail open 到 primary），此行为**不可配置**（内部 §3 QA-337）。注意 Secondary 无 HC 时始终健康，此时不存在"两者均不健康"的情形。
   - 外部 §5.2 `routing-policy-failover.html`；内部 §3。

5. **Geolocation（地理位置）**
   - 按**用户所在地（查询来源地）**路由，粒度可到大洲 / 国家 / 美国州。
   - 重叠时**最小地理区优先**（Canada 优先于 North America）。
   - **可建 default 记录兜底**无法映射的来源；**若无 default，未覆盖来源返回 "no answer"**（考点，见下）。
   - 外部 §5.3 `routing-policy-geo.html`；内部 §3。

6. **Geoproximity（地理邻近）**
   - 按**资源位置 + 用户位置**路由到"最近"资源，且可用 **bias** 扩张/收缩某资源的地理吸引范围。
   - **bias 范围 -99..99（含 0）**：**0 = 无偏移**；**正 bias（+1..+99）扩大**本资源吸引范围（相应缩小相邻资源），**负 bias（-1..-99）缩小**本资源范围。
   - **不再必须使用 Traffic Flow**：自 2024 起可通过普通记录 / API / CLI / SDK 直接创建 geoproximity 记录；**仅地图可视化仍限 Traffic Flow**。
   - **同名同类型 geoproximity 记录上限仅 30**（其他分散型策略是 100，见 topic 12 配额）。
   - 外部 §5.4 `routing-policy-geoproximity.html`；内部 §3。

7. **Multivalue answer（多值应答，MVA）**
   - 正常随机返回**最多 8 条健康记录**，每条可各带健康检查；**当全部记录都不健康时 fail-open，返回最多 8 条（不健康的）记录**。
   - 是"带健康检查的简单负载分散"，**不是 ELB 替代**（无真正负载均衡 / 会话保持）。
   - 外部 §5.7 `routing-policy-multivalue.html`；内部 §3。

8. **IP-based（基于 IP）**
   - 按**客户端源 IP** 的 CIDR-to-endpoint 映射路由（CIDR collection / location / block）。
   - **匹配规则**：查询源 CIDR 比集合中某项更长（更具体）时，匹配到那个**较短**的指定 CIDR。掩码范围：普通条目 **IPv4 /1–/24、IPv6 /1–/48**；可设**默认位置 `*`（相当于 /0，IPv6 为 `::/0`）** 兜底，无匹配且**无默认 `*`** 时返回 **NODATA**。
   - **PHZ 不支持 IP-based**（PHZ 只支持 simple/failover/multivalue/weighted/latency/geolocation/geoproximity）。
   - 外部 §5.6 `routing-policy-ipbased.html`；内部 §3 TSR53DNSService。

### 1.2 EDNS0 / ECS（地理与延迟类策略正确性的核心）

- geolocation / geoproximity / latency / IP-based 依赖"客户端在哪"。若中间 resolver 支持 **EDNS0 的 edns-client-subnet (ECS)**，R53 权威 NS 能拿到用户 IP 的**截断前缀**来更准确估位；不支持 ECS 时，只能用 **resolver 自身的源 IP** 近似判断，可能定位错误。
- **VPC 的 .2 resolver 支持 EDNS0，但不支持 ECS**（考点，内部 §3 / 附录速记）。
- **PHZ 不使用 EDNS0**，改用所在 AWS Region 的 VPC Resolver 数据做路由决策（见绑定 case 分析）。
- 检测 resolver 是否支持 ECS：`dig TXT o-o.myaddr.google.com -4`（或 `host -t txt o-o.myaddr.google.com.`），响应含 `edns0-client-subnet` 即支持。R53 对 ECS 的支持说明见 AWS Knowledge Center 文章 [route-53-resolver-edns-client-subnet](https://repost.aws/knowledge-center/route-53-resolver-edns-client-subnet)（如需在特定域名上验证，将命令中的检测域名替换为目标域名）。
- GeoIP 库：R53 用第三方商业 IP 地理库（内部指引：**MaxMind**），**AWS 官方不公开披露具体供应商**（见绑定 case）。外部 §5.5/§15 `routing-policy-edns0.html`。

### 1.3 八种策略对比表

| 策略 | 依据 | 健康检查 | 关键边界 | PHZ 支持 | 典型场景信号词 |
|---|---|---|---|---|---|
| Simple | 单资源 | **不支持** | 返回 RRset 全部值随机排序（单 RRset 配额 400） | ✅ | 单一后端、无需分流/健康感知 |
| Weighted | 你设的权重比例 | 支持 | **weight ≤255**；权重 0=停流量（全非0不健康才启用0） | ✅ | 灰度/金丝雀、A/B、按比例分流 |
| Latency | AWS 实测网络延迟（非实时） | 支持 | 须指定 AWS Region，目标可在 AWS 外；数据会漂移 | ✅ | 多 Region 求"最低延迟/性能" |
| Failover | Primary/Secondary + HC | **Primary 需 HC 或 ETH 才能有效切换** | 主备都不健康→**返回 Primary（fail open）** | ✅ | active-passive 主备灾备 |
| Geolocation | **用户位置** | 支持 | 重叠取最小区；**无 default→"no answer"** | ✅ | 按国家/州做内容合规、本地化 |
| Geoproximity | **资源+用户位置** | 支持 | **bias -99..99（含0）**；仅可视化需 Traffic Flow；上限 **30** | ✅ | 按地理距离+可调边界的流量再平衡 |
| Multivalue | 随机健康记录 | 支持（每条） | **最多 8 值**；全挂 fail-open 返回不健康记录；非 ELB 替代 | ✅ | DNS 级简单分散+健康剔除 |
| IP-based | **客户端源 IP CIDR** | 支持 | 最长匹配到较短 CIDR；无`*`→NODATA | **❌不支持** | 按已知客户端 IP 段定向（ISP/专线） |

**Weighted vs Latency（高频区分）**：weighted 按**你设的比例**分（负载/灰度）；latency 按 **AWS 测得的网络延迟**（多 Region 性能）。latency 非实时、会漂移、只覆盖到 AWS 数据中心。

**Geolocation vs Geoproximity（高频区分）**：geolocation **只看用户位置**、按大洲/国家/州、重叠取最小区、可设 default 兜底；geoproximity **看资源+用户位置**、可用 **bias（-99..99，含 0）** 移动边界、**仅地图可视化需 Traffic Flow（记录本身可直接创建）**、上限仅 **30**。

---

## 2. 真实案例说明（Real Case）

### Case 178246722300140（Goclouds Data / oasgames.com，★ Geolocation GeoIP + EDNS0）

**一句话**：客户（游戏公司，PLS 合作伙伴）准备用 **Geolocation Routing**，问两件事——① R53 用的 IP 地理库是什么？② 更新频率？根因不是故障，而是对 geolocation **定位机制与边界**的 SME 级理解。

- **落点 1 — IP 库**：R53 geolocation 用**第三方商业 IP 地理库将 IP → 地理位置**；内部指引明确是 **MaxMind**，但**不对客户披露供应商名**（"Do not disclose to customer about the database we use"）。回复用"业界领先的第三方商业 IP 地理定位数据库 + 商业协议限制不便披露"表述。
- **落点 2 — 更新频率**：MaxMind 通常**每周更新一次**（约周二晚），R53 在其发布后自动摄取；但 **R53 传播时间 AWS 无公开承诺**。对客户只说"会定期更新、AWS 持续跟进"，不给具体周期。
- **落点 3 — 判定机制（EDNS0/ECS）**：resolver 支持 EDNS0/ECS 时，R53 用用户 IP 的**截断前缀**更精确定位；不支持时用 **resolver 源 IP** 近似（可能定位偏差）。**PHZ 不使用 EDNS0**，改用所在 Region 的 VPC Resolver 数据。
- **落点 4 — 必配 default（本 topic 硬考点）**：部分 IP 无法映射到任何地理位置，**必须建 Default 记录兜底**，否则这些查询得到 **"no answer"**。回复把"务必建 Default 记录"列为首要建议。
- **落点 5 — 准确性**：国家级映射准确率约 **99.8%**（引 WAF FAQ 公开口径，同库）；粒度越细（省/州）准确率越低。
- **教学价值**：一个"纯咨询"case 串起 geolocation 的三大 SME 要点——**GeoIP 库不披露、default 兜底否则 no answer、EDNS0/ECS 决定定位精度（且 .2 resolver 不支持 ECS、PHZ 不用 EDNS0）**。这三点都是考试反复出现的正误分界。

> 关联：本 case 也是 topic 12（配额/集成）与 topic 05（Resolver/EDNS0）的交叉锚点；failover 设计参考 case 178782060900806（见 topic 01/13）。

---

## 3. 实验步骤（Hands-on Lab）

> 主题（取自驱动表）：**建多个路由策略实验、观察实际解析**——重点做加权比例实测与 ECS 支持检测。全程只读/可控，不涉及需 2PR 的破坏性操作。

前置：一个测试 public hosted zone（如 `lab.example.com`）+ 两个可区分的目标（如两台 EC2 的 EIP，记为 IP_A / IP_B）。先用 `dig NS lab.example.com +short` 拿到该 zone 的 4 个权威 NS。

### 实验 A：加权路由按权重实测分配比例
```bash
# 1) 建两条同名同类型 weighted 记录：A 权重 90，B 权重 10
cat > weighted.json <<'JSON'
{"Changes":[
 {"Action":"UPSERT","ResourceRecordSet":{
   "Name":"w.lab.example.com.","Type":"A","TTL":10,
   "SetIdentifier":"A-90","Weight":90,
   "ResourceRecords":[{"Value":"IP_A"}]}},
 {"Action":"UPSERT","ResourceRecordSet":{
   "Name":"w.lab.example.com.","Type":"A","TTL":10,
   "SetIdentifier":"B-10","Weight":10,
   "ResourceRecords":[{"Value":"IP_B"}]}}
]}
JSON
aws route53 change-resource-record-sets --hosted-zone-id <ZONEID> --change-batch file://weighted.json

# 2) 向权威 NS 采样统计比例（避免 resolver 缓存干扰）；加权是概率分布，
#    样本量按你的统计目标定（样本越大比例越稳），此处示例取若干千次
NS=$(dig NS lab.example.com +short | head -1)
for i in $(seq 1 5000); do dig @"$NS" w.lab.example.com A +short; done | sort | uniq -c
# 预期：IP_A 与 IP_B 约呈 90:10。样本太小（1-2 次）看不出分布，是概率抽样不是精确配额。
```
判读：直接向权威 NS 采样能减少缓存干扰、更快看出概率分布；经缓存/单次查询会误判"加权没生效"。此处顺序循环只是采样手段，并非 AWS 要求的"必须并发/必须直查权威 NS"。

**权重 0 观察**：把 B 改成 weight 0 → 正常只返回 A；再对 A 挂一个**不健康**的 HC → 此时 B（0 权重）才被启用（验证"仅当所有非 0 权重不健康才用 0 权重"）。

### 实验 B：Geolocation + Default 兜底
```bash
# 建：CN→IP_A，default(*)→IP_B
cat > geo.json <<'JSON'
{"Changes":[
 {"Action":"UPSERT","ResourceRecordSet":{
   "Name":"g.lab.example.com.","Type":"A","TTL":30,
   "SetIdentifier":"cn","GeoLocation":{"CountryCode":"CN"},
   "ResourceRecords":[{"Value":"IP_A"}]}},
 {"Action":"UPSERT","ResourceRecordSet":{
   "Name":"g.lab.example.com.","Type":"A","TTL":30,
   "SetIdentifier":"default","GeoLocation":{"CountryCode":"*"},
   "ResourceRecords":[{"Value":"IP_B"}]}}
]}
JSON
aws route53 change-resource-record-sets --hosted-zone-id <ZONEID> --change-batch file://geo.json
```
- 用**控制台 "Test record"**（`dns-test.html`）模拟不同来源国/不同 resolver IP，看命中 CN 还是 default。
- **对照实验**：删除 default 记录后，从"未覆盖来源"测试 → 观察返回 **"no answer"**（坐实"无 default → no answer"考点）。

### 实验 C：检测 resolver 是否支持 EDNS Client Subnet (ECS)
```bash
dig TXT o-o.myaddr.google.com -4 +short
# 响应含 edns0-client-subnet=<你的前缀>  → 该 resolver 支持 ECS，geo/latency 定位更准
# 只回 resolver 自身 IP、无 edns0-client-subnet → 不支持 ECS，按 resolver IP 近似
# 在 VPC 内对 .2 resolver 做同样查询：可观察到 EDNS0 存在但无 ECS
```

### 清理
把上述各 `UPSERT` 改为 `DELETE`（值须与现有记录完全一致）后重放，删掉 `w./g.` 实验记录。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

对应外部速记 **B. 路由策略对比 / 边界（B6–B12）** + 本域内部边界数字。每条给"考点结论 + 常见错误认知"。

- **B6 — Weighted vs Latency**
  - 结论：weighted = 你设的比例（负载/灰度）；latency = AWS 测得的网络延迟（多 Region 性能），**非实时、会漂移、只覆盖到 AWS 数据中心**。
  - 常见错误：以为 latency 是"实时探测"或能覆盖到客户端的真实网络路径。

- **B7 — Geolocation vs Geoproximity**
  - 结论：geolocation **只看用户位置**、大洲/国家/州、重叠取最小区、可设 default；geoproximity **看资源+用户位置**、可用 **bias -99..99（含 0）** 移动边界、**仅地图可视化需 Traffic Flow**、上限 **30**。
  - 常见错误：把两者混为一谈；以为 geolocation 也能调"吸引范围"（那是 geoproximity 的 bias）。

- **B8 — Geolocation 无 default → "no answer"**
  - 结论：未映射/未覆盖来源，**没有 default 记录就返回 "no answer"**（不是随便挑一个）。
  - 常见错误：以为 R53 会兜底返回某个记录——必须显式建 default（`CountryCode:"*"`）。

- **B9 — Multivalue answer 最多 8 个健康记录、带健康检查，但不是 ELB 替代**
  - 结论：MVA 是 DNS 级简单分散 + 健康剔除，正常返回最多 8 条健康记录；**全部不健康时 fail-open，返回最多 8 条不健康记录**；**无真正负载均衡/会话保持**。
  - 常见错误：拿 MVA 当负载均衡器用；以为全挂时"什么都不返回"。

- **B10 — Simple 路由不能关联健康检查**
  - 结论：simple 记录无 HC；要健康感知就换 failover/MVA/weighted+HC 或用 Alias+ETH。
  - 常见错误：想给 simple 记录直接挂 HC。

- **B11 — IP-based 在 PHZ 不支持**
  - 结论：PHZ 仅支持 simple/failover/multivalue/weighted/latency/geolocation/geoproximity；**IP-based 只能在 public zone**。
  - 常见错误：在 PHZ 里尝试建 IP-based 记录。（IP-based 无默认 `*` 且不匹配 → **NODATA**。）

- **B12 — Weighted 权重 0**
  - 结论：单条设 0 = 停该记录流量；**仅当所有非 0 权重记录都不健康时**才启用 0 权重记录（全 0 才对 0 权重平均分）。
  - 常见错误：以为设 0 就是"永远不返回"——它在"非 0 全挂"时会成为兜底。

**本域内部边界数字速记（补）**：
- **weight 上限 255**（单条）。
- **geoproximity bias 范围 -99..99（含 0，0=无偏移）**；**同名同类型 geoproximity 上限 30**（其他分散型策略 100）。
- **Simple 返回 RRset 全部值并随机排序**（单 RRset 配额 400）；**MVA 每查询最多 8 值**（随机取健康记录，全挂 fail-open 返回不健康记录）。
- **Failover**：Primary 需 HC 或 Alias ETH 才能有效切换（无 HC 视为始终健康）；**主备都参与评估且都不健康 → 返回 Primary（fail open，不可配置）**。
- **VPC .2 resolver 支持 EDNS0 但不支持 ECS**；**PHZ 不用 EDNS0**（用所在 Region VPC Resolver 数据）。
- **GeoIP 库**：第三方商业库（内部：MaxMind），**不对客户披露**；国家级准确率约 **99.8%**。
- 加权是概率分布，观察实际比例需向权威 NS 采样，样本量按统计目标定（样本越大越稳）；缓存/单次查询会误判。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

"按需求选路由策略"决策树 + geolocation 定位链：

```mermaid
flowchart TD
    START([要给一组同名同类型记录选路由策略]) --> Q1{需要按什么分流？}

    Q1 -->|单一后端 无需分流/健康| SIMPLE[Simple<br/>返回RRset全部值随机排序·无HC·PHZ可建]
    Q1 -->|按我设的比例 灰度/负载| WEIGHTED[Weighted<br/>weight≤255·权重0=停·可HC]
    Q1 -->|多Region求最低延迟| LATENCY[Latency<br/>AWS实测·非实时·须指定Region目标可在AWS外]
    Q1 -->|主备灾备 active-passive| FAILOVER[Failover<br/>Primary需HC或ETH才能有效切换<br/>主备全挂→返回Primary]
    Q1 -->|按用户地理位置| GEOLOC[Geolocation<br/>用户位置·重叠取最小区<br/>无default→no answer]
    Q1 -->|资源+用户位置 可调边界| GEOPROX[Geoproximity<br/>bias-99..99含0·仅可视化需Traffic Flow·上限30]
    Q1 -->|DNS级分散+健康剔除| MVA[Multivalue<br/>≤8健康记录·全挂fail-open·非ELB替代]
    Q1 -->|按客户端源IP段| IPBASED[IP-based<br/>CIDR最长匹配·无*→NODATA<br/>PHZ不支持]

    GEOLOC --> HASDEF{是否建了 default *？}
    HASDEF -->|否| NOANS[未覆盖来源 → no answer]
    HASDEF -->|是| OKGEO[未覆盖来源 → default 兜底]
```

```mermaid
flowchart LR
    Q([DNS 查询到达 R53 权威 NS]) --> ECS{中间 resolver<br/>支持 EDNS0/ECS?}
    ECS -->|支持| SUB[用用户IP截断前缀<br/>定位更准]
    ECS -->|不支持| RIP[用 resolver 源IP<br/>近似 可能偏差]
    SUB --> GEOIP[查第三方GeoIP库<br/>内部MaxMind·不披露·国家级~99.8%]
    RIP --> GEOIP
    GEOIP --> DEC{命中地理规则?}
    DEC -->|是| RET[返回该地理记录]
    DEC -->|否 且有default| RETDEF[返回 default]
    DEC -->|否 且无default| NOANS2[no answer]
    note1[PHZ 不用 EDNS0<br/>用所在Region VPC Resolver数据]
    Q -.PHZ路径.-> note1
```

---

## 来源锚点

- **外部**：`routing-policy.html`（总览）、`routing-policy-simple/failover/geo/geoproximity/latency/ipbased/multivalue/weighted.html`（八策略）、`routing-policy-edns0.html`（EDNS0/ECS）；r53-external-research.md §5、§15 速记 B6–B12。
- **内部**：r53-internal-research.md §3（八策略逐条、weight≤255、权重0、failover fail-open QA-337、geoproximity bias/上限30、IP-based NODATA、EDNS0/ECS 与 .2 不支持 ECS、加权按概率分布采样 QA-483）；R53PublicDNS / kyoheibb / TSR53DNSService。
- **绑定 case**：178246722300140（Goclouds Data / oasgames.com，Geolocation GeoIP 库不披露 + 更新频率 + EDNS0/ECS + 必配 default 否则 no answer + 国家级 ~99.8% 准确率）。

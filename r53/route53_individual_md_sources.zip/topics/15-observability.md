# 15. 可观测性（Observability：CloudWatch 指标 + Query Logging + CloudTrail）

> 来源锚点：AWS 官方 Route 53 Developer Guide（Public DNS query logging / Resolver query logging / Monitoring hosted zones / Monitoring health checks / Monitoring Resolver endpoints / Monitoring Resolver DNS Firewall / Integrating with CloudTrail）+ 内部 `r53-internal-research.md` §9（ARC 监控 region 坑）、§7（DNSSEC 指标告警）、§5/§11（Resolver/1024 PPS 诊断）。
> 两方评审（Claude / Codex）均标为**必补高频盲区**：多数 SME 陷阱集中在"哪层用哪个指标/日志、投递目标、缓存不产生日志、全球服务指标只在 us-east-1"。
> 本主题以"读信号"为核心：**指标 = 聚合趋势与告警；query logging = 逐条查询取证；CloudTrail = 谁改了配置**，三者互补、不可互相替代。

---

## 1. 概念（Concept）

Route 53 可观测性分三条独立数据面，考试与排障都要求条件反射选对层：

### 1.1 Public DNS Query Logging（公共托管区查询日志）

- 记录 Route 53 **收到的公共 DNS 查询**信息：请求的域名/子域名、请求日期时间、DNS 记录类型（A/AAAA…）、**响应查询的 Route 53 edge location**、DNS 响应码（`NoError` / `ServFail` 等）。
  来源：Route 53 DG — Public DNS query logging（"log information about the public DNS queries … Domain…, Date and time…, DNS record type…, Route 53 edge location…, DNS response code"）。
- **只能投递到 CloudWatch Logs**，且**日志组必须建在 US East (N. Virginia) us-east-1**；日志**永远不能从 Route 53 侧读**，只能用 CloudWatch Logs 工具查看/搜索/导出。
  来源：同上（"The log group must be in the US East (N. Virginia) Region." / "sends query logs directly to CloudWatch Logs; the logs are never accessible through Route 53"）。
- **每个 edge location 一个 log stream**，命名 `hosted-zone-id/edge-location-ID`，如 `Z1D633PJN98FT9/DFW3`；三字母码通常对应就近机场的 IATA 码。
  来源：同上（log stream 命名段）。
- **缓存命中不产生查询日志（★核心陷阱）**：resolver 若已缓存响应（如 example.com 的 LB IP），在 TTL 过期前会持续返回缓存**而不再向 Route 53 发查询**；因此日志可能**采样式**——"某些情况下每几千条查询只记录一条"。
  来源：同上（"Query logs contain only the queries that DNS resolvers send to Route 53. If a DNS resolver has already cached the response … logs contain only one query out of every several thousand"）。
- **配置查询日志本身不产生 Route 53 费用**（只付 CloudWatch Logs / S3 费用）；默认**无限期保留**，可设 retention，或导出到 S3 降存储成本。
  来源：同上（"you don't incur any Route 53 charges" / "By default, CloudWatch Logs stores query logs indefinitely" / "export logs to Amazon S3"）。
- **投 S3 是间接路径**：Public query logging 目标只有 CloudWatch Logs，"投 S3"是通过 **CloudWatch Logs → S3 export** 实现，不是 Route 53 直接投 S3。（区别于下面 Resolver query logging 可原生投 S3。）
  来源：同上（Changing retention & exporting to S3 段）。

### 1.2 Resolver Query Logging（VPC / 混合 DNS 查询日志）

- 记录四类查询：**① 指定 VPC 内产生的查询及其响应；② 经 inbound endpoint 的本地（on-premises）查询；③ 经 outbound endpoint 递归解析的查询；④ 命中 Resolver DNS Firewall 规则（block/allow/monitor）的查询**。
  来源：Route 53 DG — Resolver query logging（四类 bullet）。
- 日志字段：VPC 所在 **Region**、**VPC ID**、**发起查询的源 IP（srcaddr）**、请求的 DNS 名、记录类型、响应码、响应数据（返回的 IP）、以及 **DNS Firewall 规则动作的响应**。**粒度不固定到"实例/ENI"**：来源标识 **srcids 是一个可变字段，其内容取决于查询路径**——可能是发起查询的 **EC2 instance ID**、**Resolver endpoint ID**、或 **Route 53 Resolver network interface（RNI）** 等，并非总能落到某台实例/某个 ENI。
  来源：Route 53 DG — Resolver query logging（源 IP srcaddr + srcids 依查询路径而定）。
- **投递目标三选一（★与 Public query logging 的关键差异）**：**CloudWatch Logs 日志组 / S3 桶 / Firehose 投递流**。
  来源：同上（"You can send the logs to one of the following AWS resources: CloudWatch Logs …, Amazon S3 … bucket, Firehose delivery stream"）。
- **缓存同样不产生日志（★）**：VPC Resolver 缓存来自 VPC 的查询、能命中缓存就从缓存应答，**query logging 只记录唯一查询（unique queries），不记录缓存命中**。示例：同一 ENI 在 TTL 内二次查 accounting.example.com，第二次从缓存应答、**不记录**。
  来源：同上（"logs only unique queries, not queries that VPC Resolver is able to respond to from the cache … The second query is not logged"）。
- Resolver query logging 配置可跨账号用 **RAM 共享**、并被 **Profiles（2025/11 起）**纳入统一分发：建 VPC 分配 Profile 即自动带上 query logging 配置。
  来源：内部 `r53-internal-research.md` §10 Profiles（"2025/11 起 Profiles 支持把 Resolver Query Logging 配置纳入"）。

### 1.3 CloudWatch 指标（聚合趋势 / 告警）

按命名空间与层次分四组，**记牢命名空间 + 是否只在 us-east-1**：

**A. 公共托管区 `AWS/Route53`（全球服务，指标只在 us-east-1 可见）**
- **DNSQueries**：某托管区在指定时段响应的 DNS 查询数。统计 Sum / SampleCount，单位 Count，维度 `HostedZoneId`。granularity **1 分钟**。
- **DNSSECInternalFailure**：区内任一对象处于 INTERNAL_FAILURE 则为 **1**，否则 0。频率约 **1 次/4 小时/托管区**。
- **DNSSECKeySigningKeysNeedingAction**：处于 ACTION_NEEDED（KMS 失败）的 KSK 数。
- **DNSSECKeySigningKeyMaxNeedingActionAge** / **DNSSECKeySigningKeyAge**：KSK 处于 ACTION_NEEDED 的时长 / KSK 创建至今时长（单位 Seconds）。
  来源：Route 53 DG — Monitoring hosted zones with CloudWatch（`AWS/Route53` 指标表 + "you must specify US East (N. Virginia) for the Region" + "granularity of one minute"）。
- **DNSSEC 内部失败要设告警（内部强调）**：强烈建议对 `DNSSECInternalFailure` / `DNSSECKeySigningKeysNeedingAction` 设 CloudWatch 告警，否则失败可能**拖垮整个 zone**。
  来源：内部 `r53-internal-research.md` §7（"强烈建议对 DNSSECInternalFailure / DNSSECKeySigningKeysNeedingAction 设 CloudWatch 告警，快速处理否则可能整 zone 宕"）。

**B. 健康检查 `AWS/Route53`（Health Check Metrics，同样只在 us-east-1）**
- **HealthCheckStatus**：R53 对端点的整体健康判定，**1=健康 / 0=不健康**。
- **HealthCheckPercentageHealthy**：**仅 Endpoint HC**——报告端点健康的全球 checker 百分比（HC 被 disable 时此指标不可用）。
- **ChildHealthCheckHealthyCount（"Number of healthy child health checks"）**：**仅 Calculated HC**——健康子检查数量。
- **ConnectionTime（TCP connection time）**：HTTP + TCP HC，建立 TCP 连接耗时（毫秒）。
- **TimeToFirstByte**：收到首字节耗时。
- **SSLHandshakeTime（Time to complete SSL handshake）**：**仅 HTTPS HC**，SSL 握手耗时（毫秒）。
  来源：Route 53 DG — Monitoring health checks using CloudWatch（"1 indicates healthy and 0 indicates unhealthy" / "percentage of Route 53 health checkers…" / "Number of healthy child health checks" / "TCP connection time (HTTP and TCP health checks only)" / "Time to complete SSL handshake (HTTPS health checks only)"）。
- 告警链路：HC 指标 → CloudWatch Alarm → SNS 通知；**HC 失败到收到 SNS 之间可能间隔数分钟**。Alarm 三态 OK / INSUFFICIENT_DATA / ALARM（新告警初始为 INSUFFICIENT_DATA；删 HC 未删 alarm 也会回到 INSUFFICIENT_DATA）。
  来源：同上（"several minutes might elapse between the time that a health check fails and the time that you receive the associated SNS notification" + Alarm 三态段）。

**C. Resolver endpoint `AWS/Route53Resolver`（Regional 服务，在 endpoint 所在 region 看）**
- **InboundQueryVolume** / **OutboundQueryVolume**：inbound / outbound endpoint 的查询量；可选 **Across All Endpoints** 看账号内全部 inbound 或全部 outbound 汇总。
- **OutboundQueryAggregateVolume**：outbound 聚合查询量。
- **EndpointHealthyENICount** / **EndpointUnhealthyENICount**：endpoint 健康/不健康 ENI 计数。**注意：这两个 ENI Count 指标主要反映 ENI 的运行状态（OPERATIONAL / AUTO_RECOVERING），并不是判断"该不该扩容"的首选信号。**
- **ResolverEndpointCapacityStatus（容量判断首选）**：判断 endpoint 是否需要扩容（加 IP/ENI）应**优先看 `ResolverEndpointCapacityStatus`**，它直接反映端点当前容量档位/是否吃紧；ENI Count 只作辅助的状态观察。
  来源：Route 53 DG — Monitoring Route 53 VPC Resolver endpoints with CloudWatch（"choose InboundQueryVolume or OutboundQueryVolume"）+ CloudWatch component-config 示例（alarmMetricName: EndpointHealthyENICount / EndpointUnhealthyENICount / InboundQueryVolume / OutboundQueryVolume / OutboundQueryAggregateVolume）+ 2020/01 "Query Volume Metrics Now Available for Route 53 Resolver Endpoints"。
- **OutboundQueryVolume 与 VQL count 有差异**（内部排障点：两者口径不同，别当同一数）。
  来源：内部 `r53-internal-research.md` §5（"OutboundQueryVolume 与 VQL count 的差异"）。

**D. Resolver DNS Firewall `AWS/Route53Resolver`（Regional，5 分钟粒度，保留 2 周）**
- **FirewallRuleGroupQueryVolume**（维度 `FirewallRuleGroupId`）、**VpcFirewallQueryVolume**（维度 `VpcId`）、**FirewallRuleGroupVpcQueryVolume**（维度 `FirewallRuleGroupId, VpcId`），均统计命中防火墙规则的查询数（Sum / Count）。
  来源：Route 53 DG — Monitoring Resolver DNS Firewall with CloudWatch（"metric data … sent to CloudWatch at five-minute intervals" / "recorded for a period of two weeks" + 三个指标定义 + 命名空间 `AWS/Route53Resolver`）。

### 1.4 CloudTrail（配置变更审计 — "谁改了什么")

- Route 53（public zone / record / health check / domains 等）是**全球服务**，其 API 事件在 CloudTrail 里**记录到 us-east-1**；这与"指标只在 us-east-1 看"是**同一根因（全球服务归口 us-east-1）**，考试常合并考。
  来源：Route 53 DG — Integrating with CloudTrail（全球服务事件归 us-east-1）+ 内部 `r53-internal-research.md` §9（"Region switch 的部分控制面 API 事件记录在 us-east-1"）。
- **ARC 的可观测性归口不同（★内部易错）**：ARC routing control / readiness check 的 **CloudTrail / CloudWatch（命名空间 `AWS/Route53RecoveryReadiness`）/ EventBridge 事件发生在 us-west-2（俄勒冈）**；在东京等 region `list-metrics` 查不到，设计告警要以 us-west-2 为准。
  来源：内部 `r53-internal-research.md` §9（QA-3396："ARC … CloudWatch（AWS/Route53RecoveryReadiness 命名空间）/ EventBridge 事件发生在 us-west-2；在东京等 region list-metrics 查不到"）。
- **CloudTrail vs Query Logging 的分工**：CloudTrail 记 **管理面变更**（`ChangeResourceRecordSets`、`CreateHealthCheck`、`UpdateHealthCheck`…谁在何时改了配置）；query logging 记 **数据面查询**（谁在解析什么域名）。排 "记录被谁改了/HC 被谁禁用" 用 CloudTrail，排 "解析结果对不对/谁在查" 用 query logging。（惯例分工。）

---

## 2. 真实案例说明（Real Case）

### ★ 缓存导致"查询日志看不到查询"（Public/Resolver 通用高频认知题）

- **典型症状**：客户开了 query logging，但抱怨"某条热门记录几乎没有日志"或"日志条数远小于真实访问量"，怀疑日志功能坏了。
- **根因落点**：这是 DNS 缓存的正常表现——resolver 在 TTL 内命中缓存就不再向 Route 53 发查询，**缓存命中不产生日志**；Public query logging 甚至可能"每几千条只记一条"。所以 query logging **不能用来精确统计流量**。
- **正确做法**：要看"总查询量/趋势"用 **CloudWatch `DNSQueries`（公共区）/ `InboundQueryVolume`·`OutboundQueryVolume`（Resolver endpoint）**；query logging 只用于**逐条取证**（看具体域名/来源实例/响应码）。
  来源：Route 53 DG — Public DNS query logging（缓存段 + "If you don't need detailed logging … use CloudWatch metrics to see the total number of DNS queries"）；Resolver query logging（"logs only unique queries, not … from the cache"）。

### ★ DNSSEC 内部失败无告警 → 整 zone 解析风险（源自 topic 07 场景，可观测性侧钉法）

- **症状**：启用 DNSSEC signing 后 KSK 因 KMS 权限/密钥问题进入 ACTION_NEEDED / INTERNAL_FAILURE，若无告警，团队直到大面积解析失败才发现。
- **可观测性落点**：`DNSSECInternalFailure`（区内任一对象 INTERNAL_FAILURE 即为 1）与 `DNSSECKeySigningKeysNeedingAction` 是**必设告警**的两个指标，频率 1 次/4 小时/托管区；配合 `DNSSECKeySigningKeyMaxNeedingActionAge` 看已积压多久。
  来源：Route 53 DG — Monitoring hosted zones（DNSSEC* 指标定义）+ 内部 §7（强烈建议设告警，否则可能整 zone 宕）。

### ★ 混合 DNS 扩容判断用 endpoint 指标（Resolver 容量类）

- **症状**：on-prem ↔ AWS 混合解析间歇超时，怀疑 endpoint 吞吐不够。
- **可观测性落点**：容量是否吃紧**首选看 `ResolverEndpointCapacityStatus`**；再结合 `InboundQueryVolume` / `OutboundQueryVolume` 趋势判断是否需要给 endpoint 加 IP（每个 IP = 一个 ENI，有 PPS/QPS 上限），`EndpointHealthyENICount` / `EndpointUnhealthyENICount` 作 ENI 运行状态（OPERATIONAL/AUTO_RECOVERING）的辅助观察；同时结合每 ENI ~1.5K–10K PPS/QPS、经 NLB/SG connection tracking 降到 ~1.5–1.7K QPS 的内部经验值。**注意 OutboundQueryVolume 与 VQL count 口径不同，别混为一谈。**
  来源：Route 53 DG — Monitoring Resolver endpoints（Inbound/OutboundQueryVolume、ENI count 指标）+ 内部 §5/§11（ENI 吞吐经验值、OutboundQueryVolume vs VQL count 差异、1024 PPS）。

---

## 3. 实验步骤（Hands-on Lab）

> 主题：为公共区开 query logging + 读 DNSQueries 指标；对 Resolver 开 query logging（三目标之一）；读 HC/endpoint/firewall 指标；用 CloudTrail 查配置变更。**全部只读/可清理，非破坏性。**

### Lab A：公共托管区 Query Logging + DNSQueries 指标（注意 us-east-1）

```bash
# 1. 日志组必须建在 us-east-1
aws logs create-log-group --log-group-name /aws/route53/example.com --region us-east-1

# 2. 给 Route 53 写日志权限（resource policy），然后创建查询日志配置
aws route53 create-query-logging-config \
  --hosted-zone-id <ZONE_ID> \
  --cloud-watch-logs-log-group-arn arn:aws:logs:us-east-1:<ACCT>:log-group:/aws/route53/example.com
#   预期：几分钟后开始出现日志；每个 edge location 一个 log stream，名如 <ZONE_ID>/DFW3

# 3. 读逐条查询日志（数据面取证）
aws logs filter-log-events \
  --log-group-name /aws/route53/example.com --region us-east-1 \
  --filter-pattern '"ServFail"'
#   观察：域名 / 时间 / 记录类型 / edge location / 响应码

# 4. 读聚合趋势（DNSQueries）——务必 --region us-east-1（全球服务指标只在此可见）
aws cloudwatch get-metric-statistics \
  --namespace AWS/Route53 --metric-name DNSQueries \
  --dimensions Name=HostedZoneId,Value=<ZONE_ID> \
  --start-time $(date -u -d '-1 hour' +%FT%TZ) --end-time $(date -u +%FT%TZ) \
  --period 60 --statistics Sum --region us-east-1

# 5.（可选）验证缓存不产生日志：对一条低 TTL 记录 dig 多次，日志里不会逐次出现（resolver 缓存命中）
# 6. 清理
aws route53 delete-query-logging-config --id <QUERY_LOG_CONFIG_ID>
```

判读要点：**日志条数 ≪ 真实访问量是正常的（缓存 + 采样）**；要"总量/趋势"永远看 `DNSQueries`，不要用日志条数估算流量。

### Lab B：Resolver Query Logging（三目标之一）+ endpoint 指标

```bash
# 1. 建 Resolver query logging 配置，目标可选 CloudWatch Logs / S3 / Firehose（此处用 CloudWatch Logs）
aws route53resolver create-resolver-query-log-config \
  --name vpc-qlog --destination-arn arn:aws:logs:<region>:<ACCT>:log-group:/aws/route53resolver/vpc
#   （投 S3 则 destination-arn 用 S3 桶 ARN；投 Firehose 则用 delivery stream ARN——这是与 Public logging 的关键区别）

# 2. 关联到 VPC
aws route53resolver associate-resolver-query-log-config \
  --resolver-query-log-config-id <CFG_ID> --resource-id <VPC_ID>
#   预期日志字段含 VPC ID / 源 IP(srcaddr) / srcids(依查询路径含 instance ID / resolver endpoint / RNI) / 域名 / 记录类型 / 响应码 / 响应数据（粒度不固定到实例/ENI）

# 3. 读 endpoint 容量指标（Regional，在 endpoint 所在 region 看，不用 us-east-1）
aws cloudwatch get-metric-statistics --namespace AWS/Route53Resolver \
  --metric-name OutboundQueryVolume --dimensions Name=EndpointId,Value=<rslvr-out-id> \
  --start-time $(date -u -d '-1 hour' +%FT%TZ) --end-time $(date -u +%FT%TZ) \
  --period 300 --statistics Sum --region <region>
aws cloudwatch list-metrics --namespace AWS/Route53Resolver --region <region>
#   关注 InboundQueryVolume / OutboundQueryVolume / ResolverEndpointCapacityStatus（容量首选）/ EndpointHealthyENICount / EndpointUnhealthyENICount（ENI 运行状态）

# 清理：先 disassociate 再 delete config
```

### Lab C：健康检查指标 + DNS Firewall 指标 + CloudTrail 变更审计

```bash
# HC 指标（全球服务 → us-east-1；HealthCheckStatus 1/0，%healthy 仅 endpoint，ChildHealthCheckHealthyCount 仅 calculated）
aws cloudwatch get-metric-statistics --namespace AWS/Route53 \
  --metric-name HealthCheckStatus --dimensions Name=HealthCheckId,Value=<HC_ID> \
  --start-time $(date -u -d '-1 hour' +%FT%TZ) --end-time $(date -u +%FT%TZ) \
  --period 60 --statistics Minimum --region us-east-1

# DNS Firewall 指标（Regional，5 分钟粒度，保留 2 周）
aws cloudwatch list-metrics --namespace AWS/Route53Resolver --region <region>
#   关注 FirewallRuleGroupQueryVolume / VpcFirewallQueryVolume / FirewallRuleGroupVpcQueryVolume

# CloudTrail 查"谁改了记录/HC"——Route 53 全球服务事件在 us-east-1
aws cloudtrail lookup-events --region us-east-1 \
  --lookup-attributes AttributeKey=EventName,AttributeValue=ChangeResourceRecordSets
aws cloudtrail lookup-events --region us-east-1 \
  --lookup-attributes AttributeKey=EventName,AttributeValue=UpdateHealthCheck

# ARC 的审计/指标在 us-west-2（不是 us-east-1！）
aws cloudwatch list-metrics --namespace AWS/Route53RecoveryReadiness --region us-west-2
```

> 判读要点：**变更类问题（记录/HC 被谁改）用 CloudTrail@us-east-1；ARC 用 us-west-2；数据面查询用 query logging；总量趋势用 CloudWatch 指标。** 选错层是最常见失误。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **O1 — 缓存命中不产生查询日志（★最高频）**：resolver 在 TTL 内命中缓存就不再问 Route 53，**日志缺该查询**；Public logging 甚至"每几千条记一条"。
  - ✗ 错误认知：用 query logging 条数当"真实查询量/流量统计"——应改用 `DNSQueries` / `InboundQueryVolume` / `OutboundQueryVolume`。
  来源：DG Public/Resolver query logging 缓存段。
- **O2 — 全球服务指标只在 us-east-1**：`AWS/Route53`（公共区 + 健康检查）指标**必须在 US East (N. Virginia) 看**，别的 region `list-metrics` 查不到。
  - ✗ 错误认知：在东京 region 找 DNSQueries / HealthCheckStatus 却"没有指标"。
  来源：DG Monitoring hosted zones / health checks（"you must specify US East (N. Virginia)"）。
- **O3 — Public logging 只能投 CloudWatch Logs（且日志组在 us-east-1）；Resolver logging 才能三选一投 CloudWatch Logs / S3 / Firehose**。
  - ✗ 错误认知：以为公共区查询日志能直接投 S3/Firehose——公共区投 S3 要走 CloudWatch Logs → S3 export，是间接的。
  来源：DG Public（"log group must be in us-east-1" / export to S3）vs Resolver（三目标 bullet）。
- **O4 — 三面分工不能互换**：CloudWatch 指标=聚合趋势/告警；query logging=逐条取证（域名/来源实例/响应码）；CloudTrail=配置变更审计（谁改了记录/HC）。
  - ✗ 错误认知：想用 CloudTrail 看 DNS 查询（看不到数据面）；想用查询日志看"谁改了记录"（那是 CloudTrail）。
- **O5 — HC 指标的适用范围**：`HealthCheckPercentageHealthy` **仅 Endpoint HC**（disable 时不可用）；`ChildHealthCheckHealthyCount`（healthy child count）**仅 Calculated HC**；`SSLHandshakeTime` **仅 HTTPS**；`ConnectionTime` HTTP+TCP。
  - ✗ 错误认知：对 calculated HC 找 %healthy，或对 TCP HC 找 SSL 握手时间。
  来源：DG Monitoring health checks（各指标 "…only" 限定）。
- **O6 — Resolver 是 Regional，指标在本 region 看**：`InboundQueryVolume` / `OutboundQueryVolume` / `EndpointHealthyENICount` / `EndpointUnhealthyENICount` / `ResolverEndpointCapacityStatus` 在 `AWS/Route53Resolver`，**endpoint 所在 region**；与公共区/HC 的 us-east-1 归口相反。
  - ✗ 错误认知：把 Resolver endpoint 指标也去 us-east-1 找；或用 ENI Count 指标判断扩容——**容量是否吃紧首选看 `ResolverEndpointCapacityStatus`**，ENI Count 只表 ENI 运行状态（OPERATIONAL/AUTO_RECOVERING）。
  来源：DG Monitoring Resolver endpoints + component-config 示例。
- **O7 — DNSSEC 必设告警**：`DNSSECInternalFailure`（1=有对象 INTERNAL_FAILURE）、`DNSSECKeySigningKeysNeedingAction`（ACTION_NEEDED 的 KSK 数，KMS 失败触发）是"整 zone 宕"级风险，务必设 CloudWatch 告警；这些指标 **1 次/4 小时/托管区**。
  - ✗ 错误认知：以为 DNSSEC 出问题会即时高频报——是 4 小时粒度，靠告警而非盯图。
  来源：DG Monitoring hosted zones（DNSSEC* 定义）+ 内部 §7。
- **O8 — ARC 可观测性在 us-west-2**：ARC routing control / readiness check 的 CloudTrail / CloudWatch（`AWS/Route53RecoveryReadiness`）/ EventBridge **在俄勒冈 us-west-2**，不是 us-east-1。
  - ✗ 错误认知：把 ARC 也当"全球服务归 us-east-1"去查。
  来源：内部 §9（QA-3396）。
- **O9 — HC 失败到 SNS 通知有分钟级延迟**：HealthCheckStatus → CloudWatch Alarm → SNS 之间"可能数分钟"，别把延迟当告警失效。
  来源：DG Monitoring health checks（"several minutes might elapse …"）。
- **O10 — DNS Firewall 指标粒度**：`AWS/Route53Resolver` 下 `FirewallRuleGroupQueryVolume` / `VpcFirewallQueryVolume` / `FirewallRuleGroupVpcQueryVolume`，**5 分钟粒度、保留 2 周**（比 1 分钟粒度粗）。
  来源：DG Monitoring Resolver DNS Firewall。

### 该域边界数字速记（★背记）

- Public query logging 目标：**仅 CloudWatch Logs**，日志组 **us-east-1**，log stream = `zone-id/edge-id`，配置本身**免 Route 53 费**，默认**无限期保留**。
- Resolver query logging 目标：**CloudWatch Logs / S3 / Firehose 三选一**；字段含 **VPC ID / 源 IP(srcaddr) / srcids（依查询路径可含 instance ID / resolver endpoint / RNI）**，**粒度不固定到实例/ENI**；**只记 unique 查询，缓存命中不记**。
- 公共区指标 `AWS/Route53`：**DNSQueries**（Sum/SampleCount，1 分钟）、**DNSSECInternalFailure / DNSSECKeySigningKeysNeedingAction / …Age / …MaxNeedingActionAge**（1 次/4 小时）；**只在 us-east-1**。
- 健康检查 `AWS/Route53`（us-east-1）：**HealthCheckStatus(1/0)、HealthCheckPercentageHealthy(仅 endpoint)、ChildHealthCheckHealthyCount(仅 calculated)、ConnectionTime、TimeToFirstByte、SSLHandshakeTime(仅 HTTPS)**。
- Resolver endpoint `AWS/Route53Resolver`（本 region）：**InboundQueryVolume / OutboundQueryVolume / OutboundQueryAggregateVolume / EndpointHealthyENICount / EndpointUnhealthyENICount / ResolverEndpointCapacityStatus**；**容量判断首选 `ResolverEndpointCapacityStatus`，ENI Count 只表运行状态**；OutboundQueryVolume ≠ VQL count。
- DNS Firewall `AWS/Route53Resolver`（本 region，5 分钟，2 周）：**FirewallRuleGroupQueryVolume / VpcFirewallQueryVolume / FirewallRuleGroupVpcQueryVolume**。
- CloudTrail：Route 53 全球服务事件 → **us-east-1**；**ARC → us-west-2**（`AWS/Route53RecoveryReadiness`）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

```mermaid
flowchart TD
    Q([排障/监控需求]) --> WHAT{要看什么?}

    WHAT -->|总量/趋势/告警| METRIC[CloudWatch 指标]
    WHAT -->|逐条查询取证<br/>域名/来源实例/响应码| QLOG[Query Logging]
    WHAT -->|谁改了配置<br/>记录/HC/domains| TRAIL[CloudTrail]

    METRIC --> NS{哪层?}
    NS -->|公共托管区| PZ["AWS/Route53<br/>DNSQueries + DNSSEC*<br/>★ 只在 us-east-1"]
    NS -->|健康检查| HC["AWS/Route53 Health Check<br/>Status1/0 · %Healthy(仅endpoint)<br/>ChildHealthyCount(仅calc)<br/>ConnectionTime/SSLHandshakeTime<br/>★ 只在 us-east-1"]
    NS -->|Resolver endpoint| RE["AWS/Route53Resolver<br/>In/OutboundQueryVolume<br/>Endpoint(Un)HealthyENICount<br/>★ 本 region"]
    NS -->|DNS Firewall| FW["AWS/Route53Resolver<br/>FirewallRuleGroup/Vpc QueryVolume<br/>★ 本 region · 5min · 保留2周"]
    NS -->|ARC| ARC["AWS/Route53RecoveryReadiness<br/>★ us-west-2!"]

    QLOG --> QTYPE{公共 or Resolver?}
    QTYPE -->|Public DNS| PUB["目标: 仅 CloudWatch Logs<br/>日志组 us-east-1<br/>投S3 = 经 CW Logs export<br/>缓存命中不记 · 可能采样"]
    QTYPE -->|Resolver VPC| RSV["目标三选一:<br/>CloudWatch Logs / S3 / Firehose<br/>字段: VPC/srcaddr/srcids(依路径:instance/endpoint/RNI)<br/>粒度不固定到实例·ENI<br/>只记 unique · 缓存命中不记"]

    TRAIL --> TREG{哪个 region?}
    TREG -->|Route53 全球服务| TE1["us-east-1<br/>ChangeResourceRecordSets<br/>Create/UpdateHealthCheck"]
    TREG -->|ARC| TW2["us-west-2"]

    PZ --> DONE([据信号定位])
    HC --> DONE
    RE --> DONE
    FW --> DONE
    ARC --> DONE
    PUB --> DONE
    RSV --> DONE
    TE1 --> DONE
    TW2 --> DONE

    CACHE{{★ 通用陷阱: 缓存命中不产生查询日志<br/>→ 日志条数 ≪ 真实流量 → 统计用指标不用日志}} -.-> QLOG
```

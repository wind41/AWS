# 11. Application Recovery Controller (ARC)：Routing Control / Readiness Check / Zonal Shift / Zonal Autoshift

> 驱动表定位：Wave3 高可用 / DR 进阶主题，考"确定性人工切流"与普通 health check 探测切流的本质区别，以及 ARC 四大能力（跨 Region 的 routing control / readiness check，单 Region 多 AZ 的 zonal shift / zonal autoshift）的职责边界与选型。无绑定真实 case，用多 Region 主备切换（DR failover）与单 Region 多 AZ 受损隔离场景说明。SME 高频易错点：①routing control 是开关不是探测；②灾难时用 cluster data plane endpoint 而非 control plane；③5-Region cluster 高可用（3/5 quorum）；④safety rule 防全关；⑤与普通 health check failover 的区别；⑥zonal shift 是单 AZ、手动、最长 72h；⑦zonal autoshift 是 AWS 代管自动、必须配 practice run；⑧readiness check 只是"配置就绪度审计"，不是健康探测、不可作灾难切流的主触发、且已停止对新客户开放。

> **ARC 能力全景（先建立框架，细节见后文各节）**：ARC 是一把"恢复控制"伞，下面挂着四类相互独立的能力，按"作用范围（跨 Region vs 单 Region 多 AZ）×动作性质（人工/编程 vs AWS 代管 vs 只审计不动作）"划分：
>
> | 能力 | 作用范围 | 谁来动作 | 本质 | 典型用途 |
> |---|---|---|---|---|
> | **Routing Control** | 跨 Region / 跨 AZ | 人工 / 编程（确定性开关） | 拨开关→改 RECOVERY_CONTROL health check→切 R53 failover 记录 | 大规模 DR 演练、灾难确定性人工切 Region |
> | **Readiness Check** | 多 Region / 多 AZ 副本间 | 只审计、不切流 | 每分钟持续校验各副本配置/容量是否对齐 | 确认 standby 副本随时具备接管能力（**注：已停止对新客户开放**）|
> | **Zonal Shift** | 单 Region 内一个 AZ | 人工 / 编程（单动作） | 把某 AZ 标记为不健康，流量移走 | AZ 级受损/坏部署时手动隔离一个 AZ |
> | **Zonal Autoshift** | 单 Region 内一个 AZ | **AWS 代管自动** | AWS 依内部遥测检测 AZ 受损，自动移走流量 | 无人值守下自动规避 AZ 级故障（必须配 practice run）|
>
> 记忆口诀：**routing control / readiness check 面向"跨 Region DR"；zonal shift / zonal autoshift 面向"单 Region 内某个 AZ 受损"。** readiness check 只"看"不"动"；routing control 与 zonal shift 是"人拨"；zonal autoshift 是"AWS 替你拨"。

---

## 1. 概念（Concept）

### 1.1 什么是 ARC Routing Control

- **Routing Control** 是一个 **开关式（on/off）** 的控制开关，由运维人员 **手动** 或 **编程**（API/CLI）切换，用来 **确定性地** 触发或撤销跨 Region / 跨可用区的 **failover**。
- 切换一个 routing control 的状态（`On`/`Off`），背后会 **改变一个 Route 53 health check 的状态**，从而让绑定该 health check 的 **Route 53 failover 记录** 把流量切到/切走某个端点。
- **本质**：ARC 把"要不要把流量放到这个 Region"这件事，从"由探测结果自动决定"变成"由人/程序确定性地拨动开关决定"。

### 1.2 与普通 Route 53 Health Check 的根本区别（核心考点）

| 维度 | 普通 R53 Health Check | ARC Routing Control |
|---|---|---|
| 触发切流的依据 | **主动探测**端点（HTTP/HTTPS/TCP、CloudWatch 告警、计算型），探测失败自动切 | **人工 / 编程拨开关**，确定性，不依赖探测结果 |
| 决定权 | 系统自动（探测健康度） | 运维人员 / 应用程序显式控制 |
| 典型误判风险 | 探测抖动 / 误报导致误切、灰色故障探不到 | 无探测抖动；风险在误操作（人为切错） |
| 适用场景 | 端点自身健康的自动摘除 | **大规模 DR 演练 / 灾难时的确定性人工切换** |

- 关键记忆点：**ARC routing control 是「开关」，不是「探针」**。它不去 ping 你的应用；它是你（或你的自动化）来决定 Region 上下线，规避了灰色故障下探测不准、或探测本身也故障时无法可靠切流的问题。

### 1.3 Routing Control 如何绑定到 R53 Failover 记录

- routing control 与 health check **不是自动一一对应**——你必须**显式创建**一个 `Type=RECOVERY_CONTROL` 的 Route 53 health check，并在创建时用 `RoutingControlArn` 把它**关联**到某个 routing control（这种 health check 的状态由该 routing control 直接驱动，而非探测得出）。
- 再把这个 health check **关联到一条 Route 53 failover 类型的记录**（Primary / Secondary）。
- 拨动 routing control → 其驱动的 RECOVERY_CONTROL health check 状态变化 → failover 记录按 Primary/Secondary 逻辑切换应答 → DNS 层完成切流（实际客户端看到切换还受 **DNS TTL/缓存**影响，不是瞬时）。

### 1.4 Cluster：5-Region 高可用 Data Plane（核心考点）

- **Cluster** 是承载 routing control 状态的高可用基础设施，由 **5 个 AWS Region** 组成，跨 Region 分布以获得极高可用性。
- **3/5 quorum 是 ARC 后端的复制一致性**：cluster 在后端跨 5 个 Region 复制 routing control 状态，读/写需 **5 个中至少 3 个达成一致**——即使有 2 个 Region 不可用，状态仍可靠。
- **客户端只需调用「一个」data plane endpoint**：5 个 endpoint 是等价的接入点，客户端脚本任选一个即可切换状态（灾难时可轮询换用另一个），quorum 由 ARC 后端自动完成，**不需要客户端自己去访问 3 个端点凑 quorum**。
- 这正是 ARC 在灾难场景下值得信赖的原因：**你要用来救灾的切换机制，本身不能和被救的系统一起挂掉**。

### 1.5 Control Plane 与 Data Plane 分离（核心考点）

- **Control Plane（控制平面）**：用于 **创建 / 配置** cluster、routing control、safety rule 等。**ARC 的控制平面位于 `us-west-2`**（配置类 API 在此 Region）。控制平面像多数 AWS 服务一样，可用性正常但不保证在大区域性灾难中始终可达。
- **Cluster Endpoint Data Plane（数据平面，5 个 Region 各一个 endpoint）**：用于 **读取和切换 routing control 状态**。这是高可用、专为灾难时刻设计的路径。
- **考点铁律**：**灾难发生时，用 cluster 的 data plane endpoint（5 个 Region endpoint）去切 routing control，绝不要依赖 control plane。** 平时配置用 control plane，救灾切流用 data plane —— 切换脚本应轮询 5 个 data plane endpoint 直到有一个成功。

### 1.6 Safety Rules：防误操作（核心考点）

Safety rule 是加在 routing control 之上的护栏，防止一次误操作把所有 Region 同时关掉、导致"两边都没流量"的自陷式全局中断。两类：

- **Assertion Rule（断言规则）**：约束一组 routing control 必须满足某条件才允许改变。例如"这 3 个 Region 的 routing control 至少有 1 个必须为 On" —— 当你试图把最后一个也关掉时，切换被拒绝。
- **Gating Rule（门控规则）**：用一个"门"control 来 **允许/禁止** 对另一组 control 的更改。例如只有先打开"允许 DR 切换"这个门，才准许切换生产 Region 的 routing control，防止误触。

> 记忆点：safety rule 的核心目的是 **防止"全关"**（防止同时把所有区切下线）以及防止未授权/误触的切换。
>
> **但 safety rule 不是绝对不可逾越**：紧急情况下，`update-routing-control-states` 可带 **`SafetyRulesToOverride`** 参数（传入要绕过的 safety rule ARN）来**显式覆盖**该护栏、强制执行本会被拒绝的切换。护栏是"防误触"，不是"锁死"——真需要全关时运维仍可有意覆盖。

---

## 1B. Readiness Check（就绪度校验）—— 只审计，不切流（核心考点）

### 1B.1 是什么

- **Readiness Check** 让 ARC **持续（每分钟一次）审计**你的多 Region / 多 AZ 应用副本，校验各副本的 **配置与运行时状态是否对齐**——例如各 Region 的 **EC2 实例数、Aurora 读写容量单元、EBS 卷大小、Auto Scaling 组的 min/max、网络路由策略** 等是否匹配，确保 standby 副本随时具备接管 failover 流量的能力。
- 建模结构：**Recovery Group（代表整个应用）→ Cell（每个失败隔离单元/副本，如每个 Region 或 AZ 的版本）→ Resource Set（按资源类型分组）→ Readiness Check（关联到 resource set）**。ARC 由此逐副本给出就绪状态（`Ready` / `Not ready`），可经 EventBridge 通知状态变化。
- 还有一类 **DNS target resource readiness check**：持续扫描应用架构与 Route 53 路由策略，审计 **跨 AZ / 跨 Region 的依赖**是否被正确"隔离（siloed）"，并给出架构改进建议。

### 1B.2 与 Routing Control 的根本区别（易错点）

| 维度 | Readiness Check | Routing Control |
|---|---|---|
| 动作性质 | **只审计、不切流**（观测/告警） | **切流开关**（确定性拨动触发 failover）|
| 回答的问题 | "我的 standby 副本**准备好接管**了吗？"（配置/容量是否对齐）| "现在**把流量切**到哪个副本？" |
| 频率/触发 | 后台每分钟持续跑，被动出状态 | 由人/程序主动拨动 |
| 高可用性 | **不是高可用**，灾难时可能不可达 | cluster data plane 高可用（5-Region 3/5 quorum）|

### 1B.3 铁律与限制（考点）

- **不要把 readiness check 当作灾难切流的主触发**：它 **不是** 用来判断生产副本是否健康的探针，**不可依赖它作为灾难时 failover 的主要触发器**。灾难切流的健康判断应来自你自己的监控/health check 体系，readiness check 只是**补充**（确认"备用副本配置是否对齐"）。
- **readiness check 本身不是高可用**：灾难中它可能不可达，被校验的资源也可能不可用——所以更不能在救灾链路上依赖它。
- **可用性变更（必答点）**：ARC 的 readiness check 特性 **已不再对新客户开放**；现有客户可继续正常使用。SME 遇到"想新用 readiness check"的诉求，应告知此变更，并引导用其自有监控 + routing control 组合来实现确定性切流。
- 记忆点：**readiness check = "副本配置对齐度的持续体检"，是"准备度"不是"健康度"，只看不动、非高可用、不作切流主触发、且已停止新开放。**

来源：
- [What is readiness check in ARC?（recovery-readiness / readiness-what-is）](https://docs.aws.amazon.com/r53recovery/latest/dg/readiness-what-is.html)
- [Readiness check in ARC（含"不再对新客户开放"说明）](https://docs.aws.amazon.com/r53recovery/latest/dg/recovery-readiness.html)
- [DNS target resource readiness checks（架构/隔离审计）](https://docs.aws.amazon.com/r53recovery/latest/dg/recovery-readiness.readiness-checks.architectural.html)

---

## 1C. Zonal Shift（可用区移流）—— 单 Region 内手动隔离一个 AZ（核心考点）

### 1C.1 是什么

- **Zonal Shift** 让你用 **单个动作**，把某个 **受损可用区（AZ）** 的流量 **临时移走**，让应用继续用同一 Region 内的其它健康 AZ 运行。用于 AZ 级问题：如坏部署导致某 AZ 延迟飙升、或 AWS 单 AZ 基础设施故障。
- 支持的资源：**Application Load Balancer (ALB)、Network Load Balancer (NLB)、EC2 Auto Scaling groups、Amazon EKS**。（资源由 AWS 自动注册到 ARC；部分资源需先"启用 zonal shift"。）
- 机制：启动 zonal shift 后，ARC 让集成的资源把 **指定 AZ 标记为不健康**，从而把流量移出该 AZ。**移流不是瞬时**——已建立的在途连接需要几分钟自然完成（DNS/连接复用等因素），新连接会绕开该 AZ。

### 1C.2 关键约束（易错点）

- **一次只能移一个 AZ**：对一个负载均衡器，一次 zonal shift 只针对 **单个 AZ**，不能一次移多个 AZ。
- **必须设过期时间，最长 72h，可延长/可取消**：启动时必须设置过期（**初始最长 3 天 / 72 小时**）；之后可随时 **update** 设一个新的过期时间（**即可延长**），也可在到期前 **cancel** 提前恢复。到期或取消后，ARC 反向操作、恢复的 AZ 重新接收流量。
- **fail-open 例外**：若目标 AZ 的 target group 本就没有实例、或实例全不健康（负载均衡器处于 fail-open），启动 zonal shift **不会** 真的移走流量。
- **容量提示**：移走一个 AZ 前应确认其余 AZ 有足够容量接住流量；NLB 关闭跨区负载均衡时，移走某 AZ 的 IP 也会同时损失该 AZ 的目标容量。

### 1C.3 与 Region 级 failover 的区别

- Zonal shift 处理的是 **同一 Region 内的一个 AZ**，不涉及跨 Region 切换、不改 Route 53 failover 记录、不需要 cluster/routing control。它是"把一个坏 AZ 从负载均衡里摘出去"的轻量、快速、可自愈的操作。
- 记忆点：**zonal shift = 单 Region、单 AZ、手动/编程、单动作、临时（≤72h 可延可取消）、面向 ALB/NLB/ASG/EKS 的"把坏 AZ 移出去"。**

来源：
- [How a zonal shift works（含 72h、可 update 延长、可 cancel、fail-open）](https://docs.aws.amazon.com/r53recovery/latest/dg/arc-zonal-shift.how-it-works.html)
- [start-zonal-shift CLI（支持资源：ALB/NLB/ASG/EKS；"temporarily move"）](https://docs.aws.amazon.com/cli/latest/reference/arc-zonal-shift/start-zonal-shift.html)
- [Zonal shift for your Network Load Balancer（在途连接不被终止、需几分钟）](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/zonal-shift.html)

---

## 1D. Zonal Autoshift（可用区自动移流）—— AWS 代管自动，需 practice run（核心考点）

### 1D.1 是什么

- **Zonal Autoshift** 是 zonal shift 的 **自动、AWS 代管** 版本：你 **授权 AWS**，当其 **内部遥测（internal telemetry）** 检测到某 AZ 受损、可能影响客户时，**AWS 代替你自动** 把该 AZ 的流量移走，**无需人工介入**，以缩短恢复时间（time to recovery）。启用后状态为 `ENABLED` 即表示已授权。
- 支持资源与 zonal shift 相同：ALB / NLB / EC2 Auto Scaling groups / EKS。

### 1D.2 必须配 Practice Run（易错必答点）

- **启用 zonal autoshift 必须配置 practice run**：这是 **强制的每周演练**——ARC 每周自动为资源发起一次 zonal shift，把流量从某个 AZ 移走 **约 30 分钟**，验证你的应用在少一个 AZ 时仍能正常运行，并记录结果（`SUCCEEDED` / `FAILED`）。
- **可控时间窗**：可配置 **blocked windows**（阻塞时间窗），定义不允许做 practice run 的时段（如业务高峰或维护窗口）。
- 目的：practice run 保证"真正的自动移流"在紧急时刻是安全可行的——不会因为应用其实无法承受少一个 AZ 而在自动移流时造成更大故障。

### 1D.3 与 Zonal Shift 的区别

| 维度 | Zonal Shift | Zonal Autoshift |
|---|---|---|
| 谁触发 | **你**（人工/编程）start & stop | **AWS** 依内部遥测自动 start/stop |
| 是否需授权 | 不需要额外授权，直接动作 | 需 **显式授权 AWS**（`ENABLED`）|
| 演练 | 无强制演练 | **强制每周 practice run（~30 分钟）** + 可配 blocked windows |
| 期限 | 手动设过期（≤72h，可延可取消）| 由 AWS 依 AZ 恢复情况自动结束 |

- 记忆点：**zonal shift 是"你拨"，zonal autoshift 是"AWS 替你拨"；开 autoshift 就必须接受强制每周 practice run（~30min），否则不给开。**

来源：
- [ARC FAQs — Zonal Autoshift（practice run ~30min、blocked windows、与 zonal shift 区别）](https://aws.amazon.com/application-recovery-controller/faqs/)
- [Zonal autoshift Getting started（AWS 代管、依内部遥测、必须配 practice run）](https://docs.aws.amazon.com/help-panel/r53recovery/latest/help-panel/zonalautoshift.html)
- [UpdateZonalAutoshiftConfiguration API（ENABLED=授权 AWS 代切、每周 practice run）](https://docs.aws.amazon.com/arc-zonal-shift/latest/api/API_UpdateZonalAutoshiftConfiguration.html)

---

## 1E. 四大能力选型与职责边界（核心考点）

先问两个问题即可定位到正确能力：

1. **故障/演练的作用范围是"跨 Region"还是"单 Region 内的某个 AZ"？**
   - 跨 Region / 整副本级 → **routing control**（要切）或 **readiness check**（先确认备副本准备好）。
   - 单 Region、只是一个 AZ 坏了 → **zonal shift**（手动移）或 **zonal autoshift**（AWS 自动移）。
2. **你要"动作切流"还是"只审计准备度"？要人拨还是让 AWS 自动？**
   - 只审计、不切 → **readiness check**（且注意已停止新开放）。
   - 人工/编程确定性切 Region → **routing control**。
   - 人工/编程移走一个坏 AZ（≤72h）→ **zonal shift**。
   - 让 AWS 依遥测自动移坏 AZ（须每周 practice run）→ **zonal autoshift**。

常见组合：跨 Region DR 用 **routing control 做确定性切换** + 自有监控做健康判断（readiness check 作补充确认副本对齐，不作切流主触发）；单 Region 高可用用 **zonal autoshift 兜底自动隔离坏 AZ**，配合运维在特定事件时用 **zonal shift 手动干预**。



### 场景：跨 Region 主备（Active/Standby）DR 切换

- **架构**：应用在 `us-east-1`（Primary）与 `us-west-2`（Secondary）各部署一套，域名 `app.example.com` 用 **Route 53 failover 记录**：Primary 指向 us-east-1 端点、Secondary 指向 us-west-2 端点。
- **诉求**：客户要做 **可控的 DR 演练** 和 **灾难时确定性切换**，不希望"靠探测自动切"—— 因为一次区域性灰色故障中，探测可能既不稳定又不可信，团队要的是"我说切就切、我说切回就切回"的确定性开关。
- **落点（ARC 如何解）**：
  1. 建一个 **cluster**（自动跨 5 个 Region 部署，3/5 quorum 保证救灾时可切）。
  2. 建两个 **routing control**：`rc-primary`（对应 us-east-1）、`rc-secondary`（对应 us-west-2）；再为每个**显式创建**一个 `Type=RECOVERY_CONTROL` 的 R53 health check，用 `RoutingControlArn` 关联到对应的 routing control。
  3. 把 `rc-primary` 的 health check 绑到 failover **Primary** 记录，`rc-secondary` 的绑到 **Secondary** 记录。
  4. **平时**：`rc-primary=On`、`rc-secondary=Off` → 流量在 us-east-1。
  5. **灾难/演练切换**：通过 **cluster data plane endpoint**（不是 control plane）执行 `rc-primary=Off`、`rc-secondary=On` → failover 记录把流量切到 us-west-2。**确定性、不等探测**。
  6. **加 safety rule**：assertion rule 约束"`rc-primary` 与 `rc-secondary` 不能同时为 Off"，防止运维一次误操作把两边都关掉、导致全站无端点。
- **对比普通 health check 方案**：若只用普通 failover + 探测型 health check，切流由探测结果自动决定；灰色故障下探测可能误判，团队无法确定性掌控切换时机。ARC 把决定权交回给人/自动化，这就是它在 DR 场景的价值。

---

## 3. 实验步骤（Hands-on Lab）

> 目标：建 cluster → 建 routing control 并绑 R53 failover 记录 → 通过 data plane endpoint 切换 → 配 safety rule。ARC 的操作命令行属于 `route53-recovery-control-config`（控制平面，配置用）与 `route53-recovery-cluster`（数据平面，切换用）两组。均在测试域名/测试栈上演示。

### Lab A：建 Cluster 与 Routing Control（控制平面）

```bash
# 1) 创建 cluster（自动跨 5 个 Region 部署，返回 5 个 data plane endpoint）
aws route53-recovery-control-config create-cluster \
  --cluster-name dr-cluster
# 记下返回里的 ClusterArn 与 ClusterEndpoints（5 个，每个含 Endpoint + Region）—— 切换时要用

# 2) 创建 control panel（承载 routing control 的面板）
aws route53-recovery-control-config create-control-panel \
  --cluster-arn <CLUSTER_ARN> --control-panel-name dr-panel

# 3) 创建两个 routing control
aws route53-recovery-control-config create-routing-control \
  --cluster-arn <CLUSTER_ARN> --control-panel-arn <PANEL_ARN> \
  --routing-control-name rc-primary
aws route53-recovery-control-config create-routing-control \
  --cluster-arn <CLUSTER_ARN> --control-panel-arn <PANEL_ARN> \
  --routing-control-name rc-secondary
```

### Lab B：为 Routing Control 建 Health Check 并绑 R53 Failover 记录

```bash
# 4) 为每个 routing control 建一个 "由 routing control 驱动" 的 R53 health check
#    —— 类型为 RECOVERY_CONTROL，用 RoutingControlArn 关联（不是探测型 health check）
aws route53 create-health-check \
  --caller-reference rc-primary-hc-$(date +%s) \
  --health-check-config Type=RECOVERY_CONTROL,RoutingControlArn=<RC_PRIMARY_ARN>
# 记下返回的 HealthCheckId（primary），对 rc-secondary 重复本步

# 5) 把这两个 health check 绑到 app.example.com 的 failover 记录
#    Primary 记录关联 rc-primary 的 HealthCheckId，Secondary 记录关联 rc-secondary 的
aws route53 change-resource-record-sets --hosted-zone-id <ZONE_ID> \
  --change-batch file://failover-records-with-arc-hc.json
# failover-records-with-arc-hc.json 中：Primary 记录 Failover=PRIMARY + HealthCheckId=<primary hc>
#                                       Secondary 记录 Failover=SECONDARY + HealthCheckId=<secondary hc>
```

### Lab C：通过 Data Plane Endpoint 切换（救灾路径 —— 关键考点）

```bash
# 6) 【核心】切换 routing control 必须走 cluster 的 data plane endpoint（--region + --endpoint-url）
#    生产脚本应遍历 5 个 endpoint，直到有一个成功（灾难时部分 Region 可能不可用）
#    先读当前状态：
aws route53-recovery-cluster get-routing-control-state \
  --routing-control-arn <RC_PRIMARY_ARN> \
  --region <ENDPOINT_REGION> --endpoint-url <CLUSTER_ENDPOINT_URL>

# 7) 执行确定性切换：把 primary 关掉、secondary 打开（原子地一起改）
aws route53-recovery-cluster update-routing-control-states \
  --update-routing-control-state-entries \
  '[{"RoutingControlArn":"<RC_PRIMARY_ARN>","RoutingControlState":"Off"},
    {"RoutingControlArn":"<RC_SECONDARY_ARN>","RoutingControlState":"On"}]' \
  --region <ENDPOINT_REGION> --endpoint-url <CLUSTER_ENDPOINT_URL>

# 8) 验证 DNS 已切到 us-west-2
dig +short app.example.com    # 预期返回 secondary（us-west-2）端点
```

**判读**：步骤 7 拨开关后，routing control 驱动的 health check 状态翻转，failover 记录把 Primary 判为不健康、Secondary 判为健康，DNS 应答切到 us-west-2。**全程不依赖对应用的探测**。**关键风险**：若在灾难中改用 control plane 去切，可能因区域性故障而不可达 —— 必须走 data plane 的 5 个 endpoint 轮询。

### Lab D：配 Safety Rule 防全关

```bash
# 9) 建 assertion rule：约束 [rc-primary, rc-secondary] 中为 On 的数量必须 >= 1（不允许同时全 Off）
aws route53-recovery-control-config create-safety-rule \
  --assertion-rule '{
    "Name":"at-least-one-region-on",
    "ControlPanelArn":"<PANEL_ARN>",
    "AssertedControls":["<RC_PRIMARY_ARN>","<RC_SECONDARY_ARN>"],
    "RuleConfig":{"Type":"ATLEAST","Threshold":1,"Inverted":false},
    "WaitPeriodMs":5000
  }'

# 10) 验证护栏生效：尝试把两个 control 都设为 Off（应被拒绝）
aws route53-recovery-cluster update-routing-control-states \
  --update-routing-control-state-entries \
  '[{"RoutingControlArn":"<RC_PRIMARY_ARN>","RoutingControlState":"Off"},
    {"RoutingControlArn":"<RC_SECONDARY_ARN>","RoutingControlState":"Off"}]' \
  --region <ENDPOINT_REGION> --endpoint-url <CLUSTER_ENDPOINT_URL>
# 预期：被 safety rule 拒绝（会导致所有区下线，违反 ATLEAST 1 On 断言）
```

**判读**：assertion rule 拦下"全关"操作，证明 safety rule 起到了防误操作、防全局自陷中断的作用。**清理**：演练后删 safety rule → routing control → control panel → cluster，以及测试用的 health check 与 failover 记录。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **①routing control 是开关，不是探测**：ARC routing control 由人工/编程确定性拨动，背后改 R53 health check 状态切流；它 **不主动探测应用**。
  - 常见错误认知：以为 ARC 会像普通 health check 那样去 ping 端点、探测失败才切。
- **②灾难时用 data plane endpoint，不是 control plane**：切换 routing control 走 **cluster 的 5 个 data plane endpoint**（`route53-recovery-cluster`，轮询直到成功）；control plane（`route53-recovery-control-config`）只用于平时配置，灾难中可能不可达。
  - 常见错误认知：以为救灾时也用控制平面 API 去切开关。
- **③5-Region cluster 高可用，3/5 quorum**：cluster 跨 5 个 Region，读写状态需 **至少 3 个** 一致；即使 2 个 Region 挂掉仍可切换 —— 保证"救灾工具本身不和被救系统同挂"。
  - 常见错误认知：以为 cluster 是单 Region、或以为需要 5 个全在线才能切。
- **④safety rule 防"全关"**：**assertion rule**（约束一组 control 必须满足条件，如至少 1 个 On）与 **gating rule**（用门 control 控制能否更改其它 control）防止一次误操作把所有 Region 同时下线或误触切换。
  - 常见错误认知：以为切换 routing control 没有任何护栏、可任意全关。
- **⑤与普通 health check failover 的区别**：普通 failover 靠探测结果自动切（有探测抖动/灰色故障误判风险）；ARC 把切换决定权交给人/自动化，**确定性、不依赖探测**，适合大规模 DR 演练与灾难确定性切换。
  - 常见错误认知：把两者混为一谈，或认为 ARC 只是"更贵的 health check"。
- **绑定关系速记**：`routing control ── 驱动 ──> R53 health check (Type=RECOVERY_CONTROL) ── 关联 ──> failover 记录 (Primary/Secondary)`；拨开关即改 health check 状态即切 DNS。
- **⑥zonal shift 是单 Region、单 AZ、手动、临时**：一次只移一个 AZ；**必须设过期，初始最长 72h（3 天），可 update 延长、可 cancel 提前恢复**；支持 ALB/NLB/ASG/EKS；fail-open 时（目标 AZ 无健康实例）不会真的移流。
  - 常见错误认知：以为能一次移多个 AZ、以为无期限、或以为它会改跨 Region failover 记录。
- **⑦zonal autoshift 是 AWS 代管自动，须配 practice run**：授权 AWS（`ENABLED`）依 **内部遥测** 检测 AZ 受损后 **自动移流**；**强制每周 practice run（约 30 分钟）**，可用 **blocked windows** 排除高峰/维护时段。
  - 常见错误认知：以为开 autoshift 不用演练、或把它和手动 zonal shift 混为一谈。
- **⑧readiness check 是"准备度审计"，不是"健康探针"**：每分钟持续校验多副本 **配置/容量是否对齐**；**非高可用、不可作灾难切流的主触发**；且 **已停止对新客户开放**（现有客户继续可用）。
  - 常见错误认知：把 readiness check 当作 failover 的触发器、或当作判断生产副本是否健康的探针。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

ARC 切流决策链与"平时配置 / 灾难切换"的平面分离：

```mermaid
flowchart TD
    subgraph CFG["平时：Control Plane (route53-recovery-control-config)"]
        C1["建 Cluster<br/>(自动跨 5 Region, 3/5 quorum)"] --> C2["建 Control Panel + Routing Control"]
        C2 --> C3["建 Safety Rule<br/>(assertion / gating 防全关)"]
    end

    subgraph SW["灾难/演练：Data Plane (route53-recovery-cluster)"]
        D1["遍历 5 个 cluster endpoint<br/>直到一个成功"] --> D2{"Safety Rule 通过?<br/>(如: 至少 1 个 On)"}
        D2 -- "否 (会全关)" --> BLOCK["切换被拒绝<br/>防止所有区下线"]
        D2 -- "是" --> D3["update-routing-control-states<br/>确定性拨开关 (不靠探测)"]
    end

    D3 --> HC["Routing Control 驱动的<br/>R53 Health Check<br/>(Type=RECOVERY_CONTROL) 状态翻转"]
    HC --> FO["Route 53 Failover 记录<br/>Primary/Secondary 按 health check 切换"]
    FO --> DNS["app.example.com 解析<br/>切到目标 Region 端点"]

    classDef warn fill:#fde,stroke:#b36;
    classDef good fill:#dfe,stroke:#3a6;
    class BLOCK warn;
    class D1,D3 good;
```

> 图注：左上"平时用 control plane 配置"，右侧"灾难用 data plane 切换（5 endpoint 轮询）"是两条必须分清的路径；safety rule 在切换前拦"全关"；开关 → health check → failover 记录 → DNS 是确定性、无探测的切流链。这四点（data plane 救灾、5-Region quorum、safety rule 防全关、开关非探测）是 SME 最易错处。

ARC 四大能力选型决策树（先分"作用范围"，再分"动作性质"）：

```mermaid
flowchart TD
    Q0["ARC 恢复控制：需要哪种能力?"] --> Q1{"故障/演练作用范围?"}

    Q1 -- "跨 Region / 整副本级" --> R1{"要动作切流, 还是只审计准备度?"}
    R1 -- "只审计副本是否对齐<br/>(不切流)" --> RC["Readiness Check<br/>每分钟持续校验配置/容量对齐<br/>⚠非高可用·不作切流主触发<br/>⚠已停止对新客户开放"]
    R1 -- "确定性人工/编程切 Region" --> RTC["Routing Control<br/>拨开关→RECOVERY_CONTROL health check<br/>→R53 failover 记录→DNS<br/>cluster 5-Region 3/5 quorum + safety rule"]

    Q1 -- "单 Region 内某个 AZ 受损" --> R2{"人工移, 还是 AWS 自动移?"}
    R2 -- "人工/编程, 单动作" --> ZS["Zonal Shift<br/>移走 1 个 AZ (ALB/NLB/ASG/EKS)<br/>必设过期≤72h, 可延长/可取消<br/>fail-open 时不移"]
    R2 -- "AWS 依内部遥测自动移" --> ZAS["Zonal Autoshift<br/>授权 AWS 自动移坏 AZ<br/>必须配每周 practice run(~30min)<br/>可设 blocked windows"]

    classDef region fill:#dfe,stroke:#3a6;
    classDef zonal fill:#def,stroke:#36b;
    classDef warn fill:#fde,stroke:#b36;
    class RTC region;
    class RC warn;
    class ZS,ZAS zonal;
```

> 图注：**第一刀切"作用范围"**——跨 Region 走绿/黄支（routing control 切 / readiness check 审计），单 Region 内某个 AZ 走蓝支（zonal shift 手动 / zonal autoshift 自动）。**第二刀切"动作性质"**——只审计不动作的是 readiness check（且非高可用、已停新开放，最易错）；人拨的是 routing control 与 zonal shift；AWS 替你拨的是 zonal autoshift（代价是强制每周 practice run）。记住三个数字：routing control 的 **5-Region 3/5 quorum**、zonal shift 的 **72h 上限**、zonal autoshift practice run 的 **~30 分钟/周**。

# 09. 域名注册 / TLD 特性 / 生命周期（Domain Registration · Lifecycle · TLD Differences）

> 驱动表定位：Route 53 Domains（注册商侧）核心域，考察「注册商 vs Hosted Zone 边界」「续期/赎回生命周期」「TLD 差异」三条主线。绑定真实 case 178238086600080（★.jp WHOIS 到期日显示机制 / Gandi 注册商）、178636929200282（★关闭账号域名迁移 / Amazon Registrar / suspend-delete 生命周期）。SME 高频易错点：注册商到期日 vs 注册局(registry)到期日、transfer lock、EPP auth code、赎回期不保证、NS 委派 vs 注册局同步。

---

## 1. 概念（Concept）

### 1.1 Route 53 的两个角色：注册商 vs DNS 托管（考点地基）

Route 53 同名一物两职，SME 必须分清：

- **Route 53 Domains（域名注册商侧）**：`Registered domains` 面板，负责向**注册局（registry）**注册/续期/转移域名、管理联系人、transfer lock、auto-renew、WHOIS/RDAP 信息。**AWS 不是注册局**，它通过下游注册商代理。具体某个域名由哪家注册商承接，**以 `GetDomainDetail` 返回的注册商信息 / AWS 官方 TLD 支持表为准**，不要凭 TLD 类别泛化：
  - **Amazon Registrar**（内部代号 `AMAZON_KS` / `AMAZON_REGISTRAR`）：承接 AWS 官方列出的一部分 TLD。（case 178636929200282，registrant 为 Amazon Registrar）
  - **Gandi**（内部注册商 ID `GANDI (81)`）：承接 Amazon Registrar 不直接支持的 TLD（含相当一部分国家代码 TLD ccTLD，如 .jp）。（case 178238086600080，registrar = GANDI）
  - 注意："gTLD 一律 Amazon Registrar、ccTLD 一律 Gandi" 是**过度概括**——实际归属按官方 TLD 表 / `GetDomainDetail` 逐个确认。
- **Route 53 Hosted Zone（DNS 托管侧）**：只负责域名**如何解析**（见 topic 01）。删除 hosted zone **不会**注销域名注册；注销域名注册**不会**自动删 hosted zone。

> 核心边界：**注册（registration）与解析（resolution）是两套独立生命周期**。域名到期/被 suspend 影响的是注册局对 NS 委派的呈现（clientHold），hosted zone 里的记录仍在——但公网查不到，因为注册局停止委派。

### 1.2 域名生命周期与状态（Lifecycle）

标准 gTLD 生命周期（Amazon Registrar 侧，case 178636929200282 观察 + 文档）：

| 阶段 | 触发 | 行为 | 是否可恢复 |
|---|---|---|---|
| Active | 注册成功 | 正常解析、可管理 | — |
| 续期窗口 | 到期前一定天数 | auto-renew 默认开启，AWS 提前扣费续期 | — |
| Expired / Grace | 到期未续 | 部分 TLD 有宽限续期期 | 宽限期内正常续 |
| **Redemption（赎回期）** | 宽限期后 | 域名暂停，注册局保留；赎回**通常收费且不保证成功** | 需走 restore 流程，**not guaranteed** |
| Pending Delete | 赎回期后 | 进入删除队列，不可赎回 | 否 |
| Released | 删除完成 | 域名回到公开可注册池 | 需重新抢注 |

**账号关闭触发的独立生命周期**（case 178636929200282，Amazon Registrar 侧）：账号关闭 → 每日 `WILL_SUSPEND` 通知 5 天 → `SUSPEND_DOMAIN`（域名进入 **clientHold**，公网 DNS 中断） → suspend 约 **30 天后进入删除流程** → 关闭后 **90 天是 AWS 账号可重开（reopen）的期限**（此期限针对的是账号本身能否恢复，**不是"域名 90 天后被永久删除"的定时器**；域名的最终处置仍依 registrar/registry 的删除生命周期）。在账号可重开期内重开会触发 **AES 事件驱动的自动 unsuspend**（文档给出恢复窗口最长 24 小时，为指引性说明非合同 SLA）。

### 1.3 到期日：注册商到期日 vs 注册局到期日（★.jp 高频易错点）

出自 case 178238086600080 的核心机制——**两个到期日可以不一致，且都"正确"**：

- **Gandi / Route 53 到期日**：客户的**实际有效到期日**。续期窗口、auto-renew 都以它为准。
- **注册局(registry) WHOIS 到期日**：由注册局按自身规则呈现，可能滞后或按 TLD 特殊规则显示。
- **.jp（JPRS 注册局）特殊规则**（Gandi 官方确认）：
  1. JPRS WHOIS 显示的到期日**始终是"到期月的月末日"**（实际 6/29 → WHOIS 显示 6/30）。
  2. JPRS **只在旧到期月过去后**才把 WHOIS 更新到新年份（5 月续期成功，WHOIS 要等 7/1 左右才更新）。
  3. 对客户**无实际影响**——有效期以 Gandi/Route 53 记录为准。
  4. **.jp 续期窗口很窄：仅到期前 30 天到 6 天（D-30 ~ D-6）**；**.jp 不支持 late renewal**；**.jp 不支持 transfer lock**（状态码显示 "-" 属正常）。

### 1.4 Transfer Lock 与 EPP Auth Code（转移机制）

- **Transfer Lock（转移锁 / registrar lock）**：防止未授权转出。转出前必须**先解锁**。**部分 TLD 不支持 transfer lock**（如 .jp，case 178238086600080 中状态码 "-" 即因此）。
- **EPP Auth Code（转移授权码，又称 auth code / EPP code / transfer code）**：转出到别的注册商时，源注册商生成的一次性授权凭证，交给目标注册商完成转移。转入 Route 53 需向原注册商索取此码。
- **转移前提清单（按 TLD / 注册商规则确认，非一刀切）**：解除 transfer lock（**部分 TLD 不支持锁**，如 .jp）、取得 **EPP auth code**（**部分 TLD 不要求 auth code**）、域名满足最短持有期后方可转出（新注册/刚转入常见 **60 天**锁，但**具体天数与是否适用按 TLD/注册商规则确认**）、admin/registrant 邮箱可达（转移确认邮件）。**不要把"解锁+一次性 auth code+60 天"当成对所有 TLD 通用的绝对条件。**

### 1.5 联系人：Registrant / Admin / Tech（WHOIS 联系人）

- **Registrant（注册人）**：域名的**法律所有人**，权重最高，变更 registrant 常触发 60 天转移锁。
- **Admin（管理联系人）**：接收管理类通知、转移确认。
- **Tech（技术联系人）**：接收技术类通知。
- Route 53 允许三类联系人分别设置；转移/续期确认邮件的可达性是常见故障点（case 178636929200282 中 registrant 邮箱 `domain-renewals@...` 退信是关闭通知未被察觉的一环）。

### 1.6 WHOIS vs RDAP（目录服务）

- **WHOIS**：传统文本协议，不同注册局格式各异（.jp 走 `whois.jprs.jp`，返回日文字段）。
- **RDAP（Registration Data Access Protocol）**：WHOIS 的现代 JSON/HTTP 替代，结构化、支持权限分级。**自 2025-01-28 起，RDAP 已成为 gTLD 注册数据的权威来源**（ICANN 的 gTLD 合同要求已从 WHOIS 迁移到 RDAP）；WHOIS 对 gTLD 而言已不再是权威渠道。
- **隐私保护（Privacy Protection）**：Route 53 默认对支持的 TLD 开启隐私保护，WHOIS/RDAP 中隐藏个人联系人信息（部分 ccTLD 不支持隐私保护，信息公开可见）。

### 1.7 NS 委派与注册局同步（注册侧 ↔ 解析侧的接缝）

- 注册域名时 Route 53 自动创建同名 public hosted zone、分配 **4 个 NS**、并把这 4 个 NS **写回注册局（NS 委派）**。
- 改 hosted zone 的 NS 后，必须在 **`Registered domains` 侧同步更新 NS 委派**，否则注册局仍指向旧 NS——解析不生效。这是"改了 hosted zone 却不解析"的经典坑。
- 转入的域名/外部注册的域名，需手动把 Route 53 的 4 个 NS 填到注册商的委派配置里。

**边界数字速记**：新注册/转入后常见 **60 天**内不可再转出（具体按 TLD/注册商规则确认）；gTLD 赎回期恢复**收费且不保证**；.jp 续期窗 **D-30~D-6**、无 late renewal、无 transfer lock；账号关闭后域名 suspend **约 30 天**进入删除流程，**90 天是 AWS 账号可重开的期限**（非"域名 90 天必被删"）。

---

## 2. 真实案例说明（Real Case）

### ★ 核心案例 178238086600080 —— .jp 域名注册局到期日显示机制（Gandi 注册商）

- **客户**：Gate Information（gate.io），域名 `gateio.jp`，Enterprise。
- **症状 / 问题**：客户发现三处"矛盾"：① Route 53 控制台显示到期 **2027/6/29**；② WHOIS（whois.jprs.jp）显示到期 **2026/06/30**；③ 域状态码显示 **"-"**，疑似异常。想知道哪个到期日有效、是否需续期。
- **内部验证**：RISOps 显示 Expiration **6/29/27**、Auto Renewable **true**、Registrar **GANDI (81)**；`RENEW_DOMAIN` 操作 5/25/26 **SUCCESSFUL**（续期已成功）。
- **知识点落点**：
  1. **两个到期日都对**：Route 53/Gandi 的 2027/6/29 是有效到期日；JPRS WHOIS 的 2026/06/30 是注册局按"到期月月末"呈现的旧年份值。
  2. **JPRS 更新滞后是设计行为**，非 bug：5 月续期成功，JPRS 要等旧到期月（6 月）过完，约 **7/1 左右**自动更新为 2027/06/30。
  3. **状态码 "-" 正常**：.jp **不支持 transfer lock**，无锁状态即显示 "-"。
  4. **客户无需任何操作**，保持 auto-renew 开启即可。
  5. 同类先例 momentapharma.jp（V987680859）、pnxr.jp/pnvr.jp（P403473906）均由 Gandi 确认同一机制："it's at the end of the month the domain expires"、"they renew all domains at once on their end at the end of each month"。
- **SME 提炼**：注册商到期日 ≠ 注册局到期日；ccTLD 由 Gandi 代理且各有特殊规则；.jp 三特性（月末显示 / 滞后更新 / 无 transfer lock）成套记忆。

### ★ 核心案例 178636929200282 —— 关闭账号的域名迁移（Amazon Registrar / suspend-delete 生命周期）

- **场景**：客户在域名转移**完成前**关闭了源账号（003013821629），三个域名（omnipresent.com / omnipresentdev.com / omnipresent.group，registrar = **Amazon Registrar / AMAZON_KS**）被账号关闭流水线 suspend，进入 **clientHold**，公网 DNS 中断。
- **观察到的生命周期（DIRECTLY_OBSERVED 公网+内部双源）**：
  - 关闭后 8/5–8/9 每日 `WILL_SUSPEND` 通知 ×5；
  - 8/10 15:17 UTC `SUSPEND_DOMAIN` 成功 → 三域名 **clientHold** → 公网 NS/A/MX 查询为空；
  - suspend **+30 天**（≈9/9）进入删除流程，删除后"might be able to be restored"（**不保证**）；
  - **90 天**为账号关闭后可重开（reopen）的期限（针对账号恢复，非"域名 90 天被永久删除"的定时器）。
- **恢复路径**：重开源账号（Account & Billing case）→ **AES 事件驱动自动 unsuspend**（重开后域名自动解锁，文档恢复窗口最长 24 小时，非合同 SLA）→ 随后走标准跨账号转移四步。case 最终结果：账号 08-11 重开，域名 14:40 自动 unsuspend，16:02–16:07 完成转移到目标账号；剩余 hosted zone AES isolation 另线处理。
- **知识点落点**：
  1. **转移必须由源账号发起**——账号一关，自助转移路径被切断，只能重开或走服务团队（Route 53 CS Domains TT，先例 Primary Review 双人审核）。
  2. **suspend ≠ delete**：clientHold 后仍有约 30 天窗口；**删除后的赎回不保证**。
  3. **注册侧生命周期独立于 hosted zone**：域名 unsuspend 后，hosted zone 可能仍处 isolation（权威 NS REFUSED），DNS 恢复是另一条恢复链。
  4. **合规三分法**（跨账号信息边界）：客户自报的可复述；公网 WHOIS/DNS 可引用并注明来源；内部 RISOps 数据不进客户回复。
- **SME 提炼**：账号关闭是域名生命周期的**独立触发器**；转移的账号归属前提；suspend→delete 进程 + **90 天账号可重开期限**（非域名删除定时器）三段时限；registrar 为 Amazon Registrar（非 Gandi 释放路径）。

---

## 3. 实验步骤（Hands-on Lab）

> 主题：①查 WHOIS/RDAP 对比注册商与注册局到期日；②查看 transfer lock 状态；③改 NS 委派并观察注册局同步/传播。均为**只读或受控演示**，改 NS 请在测试域名上做。

### Lab A：WHOIS / RDAP 查询与到期日对比（复现 case 178238086600080 的判读）

```bash
# 1) gTLD WHOIS（如 .com）——观察 Registrar、Expiration、Domain Status
whois example.com | grep -iE "registrar:|expiry|expiration|status"
# 关注 Registrar（Amazon Registrar? Gandi?）与 Registry Expiry Date

# 2) ccTLD 走各注册局的 WHOIS 服务器（.jp 示例，复现 case）
whois -h whois.jprs.jp gateio.jp
# 预期字段：[有効期限]=到期月月末日；[状態]=Active；状態锁位可能为 "-"（.jp 无 transfer lock）

# 3) RDAP（结构化 JSON，ICANN gTLD 引导）
curl -s "https://rdap.org/domain/example.com" | python3 -m json.tool | grep -iE "eventAction|eventDate|status"
# events 里 registration / expiration / last changed；status 数组含 client transfer prohibited 等

# 4) Route 53 侧的注册商到期日（需域名在本账号 Registered domains）
aws route53domains get-domain-detail --region us-east-1 --domain-name example.com \
  --query "{Expiry:ExpirationDate, AutoRenew:AutoRenew, Locked:StatusList, Registrar:RegistrarName}"
```

**判读**：Route 53/`get-domain-detail` 的 `ExpirationDate` 是**有效到期日**；WHOIS 到期日可能滞后或按 TLD 规则（.jp 月末）呈现。两者不一致时，先确认 `RENEW_DOMAIN`/续期是否成功，再对照该 TLD 的注册局更新规则判断是否为正常滞后（呼应 case 178238086600080）。

### Lab B：查看 / 判断 Transfer Lock 状态

```bash
# StatusList 里含 clientTransferProhibited 即为已上锁；空或 "-" 视 TLD 而定
aws route53domains get-domain-detail --region us-east-1 --domain-name example.com \
  --query "StatusList"

# 对照 WHOIS 的 Domain Status 行
whois example.com | grep -i "Domain Status"
# clientTransferProhibited = 已锁；ok / active = 未锁
# .jp 等不支持 transfer lock 的 TLD：状态位可能显示 "-"（正常，非异常）
```

**判读**：转出前若 `StatusList` 含 `clientTransferProhibited`，须先 `disable-domain-transfer-lock` 解锁并取得 EPP auth code；若该 TLD 本就不支持 transfer lock（.jp），"-" 是正常状态，无需也无法解锁。

### Lab C：改 NS 委派并观察注册局同步 / 传播

```bash
# 1) 查看当前注册局侧的 NS 委派（Route 53 Domains 侧）
aws route53domains get-domain-detail --region us-east-1 --domain-name example.com \
  --query "Nameservers[].Name"

# 2) 更新注册局侧 NS 委派为新的 4 个 NS（改 hosted zone NS 后必做的同步）
aws route53domains update-domain-nameservers --region us-east-1 --domain-name example.com \
  --nameservers Name=ns-1.awsdns-00.org Name=ns-2.awsdns-00.co.uk \
                Name=ns-3.awsdns-00.com Name=ns-4.awsdns-00.net

# 3) 观察公网委派传播（父区 NS 记录）
dig example.com NS @8.8.8.8 +short          # 递归解析器视角
dig example.com NS @<TLD-authoritative> +trace | tail -20   # 从根到 TLD 看委派链
```

**判读**：`update-domain-nameservers` 改的是**注册局侧委派**，传播受父区（TLD）NS 记录 TTL 影响，通常数分钟到数十分钟可见。**只改 hosted zone 而不改注册局委派 → 解析仍走旧 NS**，这是"改了 NS 却不生效"的根因。**清理**：测试后把 NS 委派改回原值。

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

- **注册商到期日 vs 注册局到期日**：`get-domain-detail`/Route 53 的到期日是有效期；WHOIS 到期日可能滞后或按 TLD 规则显示。
  - 常见错误认知：以为 WHOIS 到期日是权威、两者不一致就是 bug。（case 178238086600080）
- **.jp 三特性成套记忆**：① WHOIS 到期日恒为到期月**月末**；② 旧到期月过完才更新新年份（约次月 1 日）；③ **不支持 transfer lock**（状态 "-" 正常）；④ 续期窗 **D-30~D-6**、**无 late renewal**。
- **注册 ≠ 解析（两套独立生命周期）**：删 hosted zone 不注销域名；注销域名不删 hosted zone；域名 suspend/clientHold 断的是注册局委派，hosted zone 记录仍在但公网查不到。
  - 常见错误认知：以为 hosted zone 存在就代表域名注册有效。
- **改 NS 必须两侧同步**：改 hosted zone NS 后，要在 `Registered domains` 更新注册局 NS 委派，否则解析走旧 NS。
- **transfer lock + EPP auth code + 最短持有期（按 TLD 确认）**：转出前一般须解锁、取 EPP auth code，但**部分 TLD 不支持锁 / 不要求 auth code**；新注册/刚转入常见 **60 天**锁、变更 registrant 常触发 60 天锁——具体天数与是否适用**按 TLD/注册商规则确认**，勿一刀切。
- **赎回期不保证**：进入 redemption 后 restore **收费且不保证成功**；进入 pending delete 后不可赎回。
  - 常见错误认知：以为过期域名随时能免费找回。
- **注册商归属按官方 TLD 表 / GetDomainDetail 确认**：Amazon Registrar（AMAZON_KS）与 Gandi (81) 各承接一部分 TLD，**不要凭"gTLD=Amazon / ccTLD=Gandi"泛化**；ccTLD 特殊规则要查该 TLD 的注册局机制（.jp→JPRS）。
- **账号关闭是域名生命周期独立触发器**：关闭 → 每日通知 5 天 → suspend(clientHold) → +30 天进入删除流程 → **90 天为账号可重开期限**（非域名删除定时器）；转移必须由源账号发起，账号关了只能重开或走服务团队 TT。（case 178636929200282）
- **重开自动 unsuspend，但 hosted zone 恢复是另一条链**：AES 事件驱动，文档恢复窗口最长 24h（指引非 SLA）；域名 unsuspend 后 hosted zone 可能仍 isolation（NS REFUSED）。
- **联系人可达性**：admin/registrant 邮箱退信会导致转移确认、关闭/续期通知漏收——排查转移/续期失败先查联系人邮箱可达性。
- **隐私保护与 RDAP**：Route 53 对支持的 TLD 默认开隐私保护；部分 ccTLD 不支持；**RDAP 自 2025-01-28 已是 gTLD 注册数据的权威来源**（WHOIS 对 gTLD 不再权威）。
- **跨账号信息合规三分法**：客户自报可复述、公网 WHOIS/DNS 可引用注明来源、内部 RISOps 数据不进客户回复。（case 178636929200282）

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

域名从注册到到期/关闭的生命周期决策链，及注册商侧与注册局/解析侧的接缝：

```mermaid
flowchart TD
    REG["注册域名<br/>(Route 53 Domains)"] --> RGR{"注册商归属"}
    RGR -- "gTLD .com/.net" --> AMZ["Amazon Registrar<br/>(AMAZON_KS)"]
    RGR -- "ccTLD .jp 等" --> GANDI["Gandi (81)<br/>各注册局特殊规则"]

    AMZ --> ACT["Active<br/>自动建 public zone + 4 NS 委派回注册局"]
    GANDI --> ACT

    ACT --> EXP{"到期?"}
    EXP -- "auto-renew 开+续期成功" --> ACT
    EXP -- "未续 → 宽限/赎回" --> RDM{"Redemption 赎回期"}
    RDM -- "restore(收费,不保证)" --> ACT
    RDM -- "超期" --> DEL["Pending Delete → Released<br/>(不可赎回)"]

    ACT --> CLOSE{"账号关闭?"}
    CLOSE -- "是" --> SUS["WILL_SUSPEND x5 → SUSPEND(clientHold)<br/>公网 DNS 断; +30天进入删除流程<br/>90天=账号可重开期限(非域名删除)"]
    SUS -- "重开账号" --> UNSUS["AES 自动 unsuspend(≤24h指引)<br/>hosted zone 恢复为另一条链"]

    ACT --> DUAL["到期日双轨:<br/>Route53/Gandi=有效期<br/>vs 注册局WHOIS(.jp=月末,滞后)"]
    ACT --> XFER{"转移出?"}
    XFER --> LOCK["解 transfer lock(部分TLD不支持,如.jp)<br/>+ EPP auth code + 60天锁"]

    classDef warn fill:#fde,stroke:#b36;
    class RDM,SUS,DEL warn;
```

> 图注：左侧 `注册商归属`（Amazon Registrar vs Gandi）决定 TLD 特殊规则查证方向；`账号关闭`是与正常到期并行的独立 suspend→delete 触发器（case 178636929200282）；`到期日双轨`是 .jp 类 WHOIS 到期日矛盾的判读依据（case 178238086600080）；转移三前提（解锁 / EPP code / 60 天锁）为高频易错点。

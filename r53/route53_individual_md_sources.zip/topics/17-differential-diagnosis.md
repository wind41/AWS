# Topic 17：相似症状不同根因（同症状异根因对照库）

> 本 topic 是反例库/鉴别诊断（differential diagnosis）方法论。同一个**症状**（客户看到的表象）在 R53 里往往对应**多个互斥根因**，判错方向就修错东西。
> 与 topic 13 的关系：topic 13 教「排查纪律」（界定范围、证据分级、响应码语义、必要非充分）；topic 17 把纪律落到**具体症状**上——给每个高频症状列 3-5 个不同根因，每个根因配【判别特征】（怎么一眼区分它和邻居）+【下一步验证】（用哪条 dig/工具/日志坐实）。
> 核心纪律（继承 topic 13）：**症状 ≠ 根因**。看到 SERVFAIL 不能直接说「DNSSEC 坏了」；先按判别特征分流，再用验证命令坐实，只对 DIRECTLY_OBSERVED 的分支下「已确认」。

---

## 使用方法

1. 从客户描述里提取**症状类别**（下面 5 大类）。
2. 在该类的对照表里，用【判别特征】逐行排除——问：客户环境里哪个特征成立？
3. 对候选根因跑【下一步验证】命令/日志，坐实到 DIRECTLY_OBSERVED。
4. 未坐实的分支列入索取清单（UNKNOWN），**不预先唱因**。
5. 记住：同一症状可能**同时**有两个根因（必要非充分），修一个不代表恢复。

---

## 类别一：SERVFAIL

> SERVFAIL = 递归器/权威「处理失败」（不是「记录不存在」，那是 NXDOMAIN；不是「没收到响应」，那是 timeout）。它是**最容易误判为 DNSSEC** 的症状，实际有 5 个常见根因。

| # | 根因 | 判别特征（怎么区分） | 下一步验证 |
|---|---|---|---|
| 1.1 | **DNSSEC 验证失败**（信任链断/DS 缺/签名过期） | `dig +cd`（关校验）就**成功**，不加 `+cd` 才 SERVFAIL；查询名所在区已启用 DNSSEC | `dig +cd example.com A`（成功=DNSSEC）；`dig example.com DNSKEY`、`dig DS example.com @父区NS` 核对逐级 DS 是否注册到父区（KSK 哈希）；`delv example.com` 看链断在哪级 |
| 1.2 | **stale / 错误 NS 委派**（父区 NS 指向已释放或错误的区） | `dig +trace` 在某一级委派后拿到**指向无效 NS** 或该 NS 无应答；`+cd` 仍 SERVFAIL（排除 DNSSEC） | `dig +trace example.com`（看断在哪级委派）；`dig example.com NS @父区权威`，对比 R53 Hosted Zone 实际下发的 4 个 NS 是否一致 |
| 1.3 | **上游/转发目标超时**（Outbound Endpoint 转到的 on-prem NS 不响应） | 走 Resolver forward rule 的域才 SERVFAIL/timeout；同 VPC 查公网域正常；限流指标正常 | CloudWatch Insights 按分钟算 `sum(timeout_queries)/sum(received_queries)*100`；对 `eniloganalysisdb.eniloganalysis_new` 按 `destip` 聚合 `respcode='TIMEOUT'`，定位是哪台目标 NS 不响应（见 topic：Resolver 限流/出站） |
| 1.4 | **限流 / conntrack**（endpoint ENI 超 10K QPS，或 SG 限制/走 NLB 把上限压到 ~1.5K） | 高峰期概率性 SERVFAIL/丢包，低峰恢复；ENI 挂了限制性 SG 或查询经过 NLB | 查 `conntrack_allowance_exceeded_delta`（conntrack 根因）与 `udp_throttled_count`（超 10K 根因），两指标在 Proxy Instance 账户 `ProxyInstance/ContributorInsightsLog`（区域级）；对照 CloudWatch `InboundQueryVolume`/`OutboundQueryAggregateVolume` 是否逼近 `10000×ENI 数` |
| 1.5 | **空 zone / 记录类型缺失**（PHZ 存在但该名/该类型无记录，某些递归器对权威返回的空应答表现为 SERVFAIL 而非 NXDOMAIN；或 CNAME 链断） | 直查权威即空应答；换查询类型（A vs AAAA vs CNAME）行为不同 | `dig @权威NS example.com A +short` 与 `... AAAA` 分别测；核对 Hosted Zone 里是否真有对应 name+type 的记录；CNAME 链逐跳 `dig` 到底 |

**SERVFAIL 一句话判别顺序**：先 `dig +cd`（分出 DNSSEC）→ 再 `dig +trace`（分出委派）→ 再看是否走 forward rule（分出上游超时）→ 再看限流指标（分出 throttle/conntrack）→ 最后核记录本身（空 zone）。

---

## 类别二：解析不一致（同名不同答案 / 时对时错的解析值）

> 症状：不同 client、不同 resolver、不同区域，或不同时刻，对同一域名拿到**不同结果**（不同 IP、有时私有有时公网、有时 NXDOMAIN）。这是**「查的人不同答案不同」**类，根因几乎都在「解析路径分叉」。

| # | 根因 | 判别特征 | 下一步验证 |
|---|---|---|---|
| 2.1 | **PHZ vs 公网 split-view 命名空间重叠** | VPC 内解析到私有 IP / NXDOMAIN，VPC 外（8.8.8.8）解析到公网值；同名同类型 | VPC 内 `dig example.com A` vs `dig @8.8.8.8 example.com A` 对比；列出该 VPC 关联的所有 PHZ，看是否有覆盖该名的 PHZ（PHZ 内权威、**不 fallback 公网**） |
| 2.2 | **解析优先级命中不同规则**（Firewall→Resolver 规则→PHZ→公网，longest match） | 不同 VPC 关联的规则集不同 → 结果不同；同域 PHZ 子域 vs 父域 forward rule 命中不同 | 画出该 VPC 关联的全部 rule+PHZ，按域名前缀长度排序，逐条对照查询名判断命中哪条；用 **Resolver Query Log** 抓精确时间戳+域名确认分类 |
| 2.3 | **latency/geo 路由按 resolver IP（非客户端）判定** | 同一 DC 内经 NAT 的 server 与带公网 IP 的 resolver 解析到**不同区**；换 resolver 就变 | 查两条查询实际用的源 IP（ipinfo.io 看 ISP 归属）；确认 resolver 是否启用 EDNS0/ECS（VPC resolver **不支持 ECS**）；权威侧 latency 记录 vs resolver 地理判定 |
| 2.4 | **TTL / 负缓存滞后**（记录已改，部分递归器仍返回旧值或旧 NXDOMAIN） | 直查权威已是**新值**，递归侧仍旧值；「等一会就好」；改动时间越近越明显 | `dig @权威NS example.com A +short`（新值）对比 `dig example.com A`（旧值）；用 SOA `minimum` 估负缓存时长；问客户「改了多久、用哪个递归器」 |
| 2.5 | **多值/weighted/加权 0 交互**（一组记录返回不同成员，或健康状态变化导致成员进出） | 反复查返回不同 IP（正常的多值/加权）；或权重 0 成员只在非 0 全不健康时才出现 | 核对 routing policy（simple multivalue / weighted）；weighted+HC 先只考虑非 0 权重，全不健康才用 0 权重；看各成员 health check 状态 |

**解析不一致一句话判别**：先做**「VPC 内 vs VPC 外」双查**（分出 split-view）→ 再做**「递归 vs 直查权威」双查**（分出缓存滞后）→ 再看是否 latency/geo（换 resolver 变化）→ 最后核 routing policy。

---

## 类别三：间歇超时（时好时坏的 timeout）

> 症状：**概率性** timeout（不是 100% 失败）。topic 13 纪律：概率性失败通常指向「多路径中的某一条」。timeout = 网络层（没收到响应），不是记录问题。

| # | 根因 | 判别特征 | 下一步验证 |
|---|---|---|---|
| 3.1 | **多 ENI 中某条路径被阻断**（Outbound/Inbound Endpoint ≥2 ENI，某 ENI 子网 NACL 拦了 DNS） | 部分查询成功、部分超时；成功/失败比例≈健康 ENI 占比；换个查询有时通 | 列出 endpoint 各 ENI 及所在子网；逐 ENI 子网核 NACL 出入站是否放行 **UDP 53 + ephemeral**（易漏 UDP ephemeral）；Query Log 看失败查询集中在哪个源 ENI |
| 3.2 | **限流 / conntrack（概率性丢包）** | 高峰期超时率升、低峰恢复；ENI 逼近 10K QPS，或挂限制性 SG / 经 NLB（压到 ~1.5K） | `udp_throttled_count`（超 10K）与 `conntrack_allowance_exceeded_delta`（conntrack）；`InboundQueryVolume`/`OutboundQueryAggregateVolume` vs `10000×ENI 数`；修复：加 ENI/均衡分流（throttle）或去 SG 限制/不走 NLB（conntrack） |
| 3.3 | **1024 PPS 硬限（.2 每 ENI）被偷额度** | 单实例查询被丢，且**缓存命中也算**、IMDS 查询也吃这条 ENI 额度；不可提升 | 确认是否 `.2`（VPC CIDR+2）侧；查应用缓存是否过差、TTL 是否设太低、IMDS 是否高频；`.2` 侧 1024 PPS **不可增**，只能降查询量/改缓存 |
| 3.4 | **转发目标 NS 间歇不响应**（on-prem BIND 过载/丢包/UDP 分片） | 只有走 forward rule 的域间歇超时；同 VPC 公网域正常；按 destip 聚合超时集中在某台 NS | 按 destip 聚合 `respcode='TIMEOUT'`；`dig @on-prem-NS example.com A` 直接压测该目标；查大包切 TCP（EDNS0 >4096B）是否被中间设备丢 |
| 3.5 | **共享出站 endpoint 吵闹邻居**（多租户 endpoint 被同区他人打爆） | 你的查询量没变但突然大面积超时，且和某次外部流量峰值时间吻合；专用 endpoint 的服务无恙 | 看是否用**共享**出站 endpoint（rslvr-out-xxx）；对照区域共享容量与当时 QPS 峰值；缓解：迁专用 endpoint / tier-1 预置专用 |

**间歇超时一句话判别**：先确认**概率性**（部分成功=多路径其一，全失败=公共环）→ 多 ENI 就逐 ENI 核 NACL → 看限流/conntrack 指标 → 再看是否 forward 目标或共享 endpoint。**timeout 永远先往网络层查，别去查记录。**

---

## 类别四：NXDOMAIN（权威明确回答「此名不存在」）

> 症状：NXDOMAIN 是**权威的确定回答**（数据层），不是网络问题（那是 timeout）。纪律：看到 NXDOMAIN 去查**记录/委派/命名空间**，不要查 SG/NACL/路由。

| # | 根因 | 判别特征 | 下一步验证 |
|---|---|---|---|
| 4.1 | **PHZ 重叠命名空间「不 fallback 公网」** | VPC 内 NXDOMAIN，`@8.8.8.8` 却能解析；有覆盖该名的 PHZ 但 PHZ 里没这条记录 | VPC 内 vs `@8.8.8.8` 对比；确认存在覆盖查询名的 PHZ；正解 split-view（PHZ 内补记录）或收窄 PHZ；**反模式**：加 forward rule 想 fallback 公网（会让整域走公网） |
| 4.2 | **记录确实缺失 / 拼写 / 未创建** | 直查权威即 NXDOMAIN，VPC 内外一致；Hosted Zone 里搜不到该 name | `dig @权威NS example.com A`；到 Hosted Zone 核对 name/type 拼写（尾点、大小写、通配符 `*`） |
| 4.3 | **委派链断裂 / 跳级委派** | `dig +trace` 在某级委派后即 NXDOMAIN；多级子域被直接从顶级区委派（跳过中间区）→ 间歇 NXDOMAIN | `dig +trace dev.api.example.com`；核对逐级 NS：`example.com→api.example.com→dev.api.example.com` 每级 NS 建在**直接父区**（不可跳级） |
| 4.4 | **私区「最近父域 PHZ 吸走查询」** | 删掉某父域 PHZ 立即恢复；私区优先且从最靠近根域的区开始解析，多余父域 PHZ 返回空 | 列出 VPC 关联全部 PHZ，找把查询吸走的最近父域 PHZ；修复两条路：删该 PHZ，或在其内补齐指向 LB 的 A/别名记录 |
| 4.5 | **负缓存把旧 NXDOMAIN 留住**（记录刚建但递归器仍缓存之前的 NXDOMAIN） | 直查权威已能解析，递归侧仍 NXDOMAIN；「刚建的记录还不通」 | `dig @权威NS example.com A`（成功）vs `dig example.com A`（仍 NXDOMAIN）；按 SOA `minimum` 估等待；换未缓存的递归器验证 |

**NXDOMAIN 一句话判别**：先 **VPC 内 vs 8.8.8.8 双查**（分出 PHZ 重叠不 fallback）→ 再 `dig +trace`（分出委派断/跳级）→ 再 **递归 vs 直查权威**（分出负缓存）→ 最后核记录拼写。

---

## 类别五：Failover 不切换（主不健康但流量不转移）

> 症状：后端/主资源明显不健康，但 R53 不把流量切到备。纪律：failover 依赖 health check 的**真实**健康信号，多数根因是「HC 看到的健康 ≠ 后端真实健康」。

| # | 根因 | 判别特征 | 下一步验证 |
|---|---|---|---|
| 5.1 | **HC 探不了私有 IP**（R53 HC 从全球公网发起，私有资源永远探不到） | 主是私有 ALB/内部应用；自建 IP health check 对私有地址无效 | 确认目标是私有 IP；内部资源应改用 **CloudWatch alarm 型 HC** 或对 ELB 用 **Evaluate Target Health(ETH)**；核对当前 HC 类型 |
| 5.2 | **NLB fail-open**（后端 100% 不健康时 NLB 仍放行，ETH 认为「健康」） | 某区 NLB 后端全不健康但 R53 仍发流量该区；ETH 依赖 LB 上报，LB fail-open 骗过 ETH | 查 NLB 目标组健康状态（全 UNHEALTHY 仍收流量=fail-open）；改用 failover routing 配能反映真实后端的 HC（CW 复合指标/应用级 HC） |
| 5.3 | **ETH 与显式 HC 同开 = AND**（两者都过才算健康，产生不想要的结果） | Alias 记录既勾 ETH 又挂自定义 HC；行为「不一致/不可预期」 | 核对 Alias 记录是否同时开 ETH+HC；best practice **只开一个**；注意 **Simple routing 下 ETH 无效**（无论健康与否都返回） |
| 5.4 | **HC「假不健康」403/SNI/证书**（探测被鉴权拦或 HTTPS 探测失配 → 主被误判不健康，反而触发不该切的切换，或备也假不健康） | 新建 HC 立刻 unhealthy；探测路径需鉴权（403 算不健康）；HTTPS 探测缺 SNI / 证书不覆盖被探 FQDN | 确认探测路径返回 2xx/3xx（403=不健康）；HTTPS 开 SNI + 证书覆盖被探 FQDN；`describe-target-health` + 应用日志/SG |
| 5.5 | **Failover 双记录兜底语义被误读**（主备都不健康 → 返回主，不是不返回） | 主备都不健康时客户以为「应该返回备/应该失败」，实际返回主（last resort） | 确认这是**设计行为**：主健康→主；主坏备好→备；主备都坏→**返回主**；在目标 SG 移除 NLB VPC IP 制造不健康观察 DNS 变化验证 |

**Failover 一句话判别**：先问「HC 探的是私有还是公网」（分出 5.1）→ 是 NLB 就查 fail-open（5.2）→ 核 Alias 是否 ETH+HC 同开、是否 simple routing（5.3）→ 看 HC 是否 403/SNI 假不健康（5.4）→ 最后确认双记录兜底不是 bug（5.5）。

---

## 通用分流图（症状 → 判别 → 分支）

```mermaid
flowchart TD
    S[客户症状] --> C{哪类症状?}

    C -->|SERVFAIL| SF{dig +cd 是否成功?}
    SF -->|加+cd成功| SF1[DNSSEC 验证失败<br/>核逐级DS/DNSKEY]
    SF -->|+cd仍失败| SF2{dig +trace 断在委派?}
    SF2 -->|是| SF3[stale/错误NS委派]
    SF2 -->|否, 走forward rule| SF4[上游目标NS超时<br/>timeout% + destip聚合]
    SF2 -->|否, 高峰概率性| SF5[限流/conntrack<br/>udp_throttled/conntrack_delta]
    SF2 -->|否, 记录空| SF6[空zone/类型缺失<br/>直查权威分A/AAAA/CNAME]

    C -->|解析不一致| DI{VPC内 vs 8.8.8.8?}
    DI -->|结果不同| DI1[PHZ split-view重叠<br/>私区不fallback]
    DI -->|一致但递归旧值| DI2[TTL/负缓存滞后<br/>直查权威=新值]
    DI -->|换resolver就变| DI3[latency/geo按resolver IP<br/>ECS是否启用]
    DI -->|同VPC命中不同规则| DI4[解析优先级/longest match<br/>Query Log分类]

    C -->|间歇超时| TO{100%失败还是部分?}
    TO -->|部分失败| TO1[多ENI某路径NACL阻断<br/>逐ENI核UDP53+ephemeral]
    TO -->|高峰概率性| TO2[限流/conntrack/1024PPS<br/>看指标+PPS偷额度]
    TO -->|仅forward域| TO3[转发目标NS间歇不响应<br/>destip聚合超时]
    TO -->|吻合外部峰值| TO4[共享endpoint吵闹邻居<br/>迁专用endpoint]

    C -->|NXDOMAIN| NX{VPC内 vs 8.8.8.8?}
    NX -->|内NX外可解| NX1[PHZ重叠不fallback公网<br/>split-view补记录]
    NX -->|+trace断委派| NX2[委派断裂/跳级委派<br/>逐级NS建直接父区]
    NX -->|递归NX权威可解| NX3[负缓存留旧NXDOMAIN<br/>按SOA minimum等]
    NX -->|直查权威即NX| NX4[记录缺失/拼写 或<br/>最近父域PHZ吸走]

    C -->|Failover不切| FO{HC探私有还是公网?}
    FO -->|私有IP| FO1[HC探不了私有<br/>用CW-alarm HC或ETH]
    FO -->|NLB| FO2[NLB fail-open<br/>全不健康仍收流量]
    FO -->|Alias同开ETH+HC| FO3[ETH+HC=AND<br/>simple routing ETH无效]
    FO -->|HC假不健康| FO4[403/SNI/证书<br/>探测需2xx/3xx]
    FO -->|主备都坏| FO5[双记录兜底=返回主<br/>设计行为非bug]

    SF1 & SF3 & SF4 & SF5 & SF6 --> Z
    DI1 & DI2 & DI3 & DI4 --> Z
    TO1 & TO2 & TO3 & TO4 --> Z
    NX1 & NX2 & NX3 & NX4 --> Z
    FO1 & FO2 & FO3 & FO4 & FO5 --> Z
    Z[对坐实的分支下OBSERVED结论<br/>未坐实列UNKNOWN索取清单<br/>可能多根因并存-必要非充分]
```

---

## SME 考点 / 易错点

**考点**
- 能对每个症状说出 3-5 个互斥根因，并用**一个判别特征**把相邻根因区分开（不是背根因清单，是背「怎么区分」）。
- SERVFAIL：会用 `dig +cd` 一步分出 DNSSEC；知道 SERVFAIL 还可能是委派/上游超时/限流/空 zone。
- 解析不一致：会用「VPC 内 vs 8.8.8.8」和「递归 vs 直查权威」两组双查快速分流 split-view 和缓存滞后。
- 间歇超时：会用「部分 vs 全失败」判单点/全局；timeout 先查网络层不查记录。
- NXDOMAIN：知道它是权威确定回答（数据层），排查方向是记录/委派/命名空间，不是 SG/NACL。
- Failover：能列出 HC 探不了私有、NLB fail-open、ETH+HC=AND、假不健康、双记录兜底五种，并知道各自的验证手法。

**易错点**
- ❌ 看到 SERVFAIL 直接归因 DNSSEC——没先 `dig +cd`，漏掉委派/上游超时/限流/空 zone 四种。
- ❌ 把 NXDOMAIN 当网络问题去查 SG/NACL/路由（NXDOMAIN 是数据层的确定回答）。
- ❌ 把 timeout 当「记录没配」去查记录（timeout 是网络层）。
- ❌ 解析不一致不做「VPC 内外双查」就下结论，漏掉 PHZ split-view「不 fallback」。
- ❌ 间歇超时不先判「部分还是全失败」，把多路径其一的问题当全局。
- ❌ Failover 不切只想到「HC 配错」，漏掉 NLB fail-open 和「主备都坏返回主」是设计行为。
- ❌ 坐实一个根因就承诺「修完即恢复」——同症状可能多根因并存（必要非充分）。
- ❌ 把未坐实的分支（INFERENCE/UNKNOWN）用「已确认」措辞写进结论。

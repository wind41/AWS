# 08. DNS 安全 / dangling delegation / subdomain takeover

## 1. 概念（Concept）

本域讲**子域接管（subdomain takeover）**这一类 DNS 安全风险的原理、Route 53 的防护边界（StopZoneSniping / dangling delegation 保护），以及运维侧的正确删除顺序与防御手段。核心心智模型：**接管不是 AWS 服务漏洞，而是父域侧留下的"悬空指针"被他人抢占**——属**共享责任模型的客户侧**（外部 §14/security blog；内部 §1/§12）。

### 1.1 什么是 dangling DNS 记录 / 悬空委派

- **dangling DNS record（悬空记录）**：一条 DNS 记录仍指向一个**已不再由你掌控**的目标。两种典型向量：
  - **CNAME 向量**：`app.example.com` CNAME 指向一个已释放的 AWS 资源。当前典型可被抢注的目标是 **S3 静态站点桶、Elastic Beanstalk 环境、以及 AWS 重新分配域名场景下的 CloudFront**——攻击者在同一服务里"抢注"那个已释放的名字/桶/环境，就能用你的子域名提供内容（AWS security blog 主讲这一向量）。（注意：不要把 ELB/ALB 的 DNS 名列为典型可抢注目标。）
  - **NS 委派向量（本 topic 绑定 case 的向量）**：父 zone 里 `sub.example.com` 的 **NS 委派记录**仍指向一组 Route 53 权威 NS，但那组 NS 上**对应的 child hosted zone 已被删除**（或从未建立）。递归解析器仍会把该子域的查询送到那组 NS。
- **悬空委派（dangling delegation）**：即上面的 NS 向量——**父域的委派"悬空"**，指向没有权威 zone 撑腰的 NS 组。

### 1.2 subdomain takeover 原理

1. 父 zone 保留了 `sub.example.com` 的 NS 记录（4 个 awsdns NS），但 child zone 已删。
2. 攻击者在**任意 AWS 账号**里反复创建同名 hosted zone（`sub.example.com`），直到 Route 53 分配给它的委派组**与那 4 个悬空 NS 有重叠**（哪怕只重叠 **1 个** NS）。
3. 递归解析器在委派的多个 NS 间选择/重试，只要命中攻击者掌控的那个重叠 NS，就会拿到攻击者 zone 里的权威应答——攻击者即可用**你的子域名**发内容（钓鱼、发证书、Cookie 窃取等）。**重叠的 NS 越多，接管越稳定**（"只需命中 1 个 NS 就一定接管"是不精确的稳定性描述）。

### 1.3 Route 53 的防护：StopZoneSniping 与 5 个 Scenario（硬考点）

官方文档 `protection-from-dangling-dns.html` 定义 5 个场景，**Route 53 只对 Scenario 1 提供防护**：

| Scenario | 情形 | R53 是否防护 |
|---|---|---|
| **1** | child zone **曾存在**→被删除，父域**仍留委派** | **✅ 唯一会防护**（对被删 zone 的那组 NS 加 **hold**，阻止重叠 NS 被重新分配给任何新同名 zone） |
| 2 | 迁移/换 DNS 供应商，主动 remove the hold | ❌ 不防护（hold 被移除） |
| 3 | 委派到 R53 NS 但记录配置错误 | ❌ 不防护 |
| 4 | 用了不属于你的 zone 的 NS | ❌ 不防护 |
| 5 | **先委派、后建 zone**（那组 NS 从未托管过该域，从无 hold 可建立） | ❌ 不防护 |

- 文档原文：**"scenarios 2 through 5 ... Route 53 can't protect against"**。
- **StopZoneSniping 保护特性（对外公开结论，不涉内部实现）**：
  - **全局 / 跨账号**：保护阻止**任何账号**被分配到与已删 zone 重叠的 NS（Harbinger notice: "all Route 53 customers are now protected"；文档 "prevent any overlapping name servers from being assigned"）。**不是"仅限删除账号内"**。
  - **per-NS（覆盖任一重叠 NS）**：新同名 zone 只要**重叠一个或多个** NS 即被阻止（"share one or more Route 53 name servers"）。**不是"必须整组重叠才拦"**。
  - **hold 生命周期（公开结论层面）**：删父区委派后 hold 被移除、对应 NS 组不再被保护；因此**hold 不是永久的**——父域委派仍在时才持续保护，委派移除后保护随之解除。（其内部实现机制不是公开契约，不作展开。）
  - **backfill 边界**：保护启用**之前**就已 dangling 的委派，若未 backfill，可能不覆盖（重用概率更高）。

### 1.4 边界数字 / 硬结论（背记）

- **只有 Scenario 1 有防护**；2–5 一律不防护。
- 接管**命中 1 个重叠 NS 即可**（保护也按 per-NS 生效）。
- 保护是**跨账号全局**的，不是账号内。
- child zone 委派**新建的空 zone SOA serial 常为 1**，但这**不是可靠的修复指纹**（1 只是默认示例值，不会自动递增、也可被改写）；判定修复应**核对父区委派是否指向真正权威的目标 NS**，而非看 serial 值。
- **删 zone 正确顺序**：先删父域 NS 记录 → **等 TTL 过** → 再删 child zone（见 §3）。
- **DNSSEC signing** 是对该风险的密码学防护（应答需权威源签名，伪造 zone 无法通过验真）。
- AWS **无法读取/删除第三方账号的 Hosted Zone**；NS 向量的修复只能由**父域持有方**在父域侧完成。

---

## 2. 真实案例说明（Real Case）

### Case 178715620200407（Thales / kycshowcase.d1.thalescloud.io，★ subdomain takeover + StopZoneSniping）

**一句话**：客户（Thales，父域 `thalescloud.io` / `d1.thalescloud.io` 持有方）内部 pentest 成功接管子域 `kycshowcase.d1.thalescloud.io`；客户不求修复，只问**为何 Route 53 的 dangling delegation 保护（StopZoneSniping）没能阻止这次接管**。根因是 NS 委派向量的悬空 + hold 未在效——把 Scenario 1 的防护边界钉到真实故事上。

**事件链（客户第一手确认）**：
- child zone `kycshowcase.d1.thalescloud.io` **曾存在**，退役时被删，但父域 `d1` 里那 4 个 NS 委派**未同步删** → 悬空委派。
- 约 2026-03-03，pentester 在**另一个 AWS 账号**反复建同名 zone，直到分配到的委派组与悬空 NS 中的**一个**重叠，用那个重叠 NS 发权威内容，接管成功。
- 客户已自行修复（新建占位 zone + 换新 NS 组）。

**场景归类的反转（教学关键）**：
- 首轮据"报告时点 SERVFAIL（无权威 zone）"**推断为 Scenario 5**（从无 zone，by-design 不防护）。
- 客户澄清后翻案为 **Scenario 1**（zone 曾存在→删→父域留委派）——即文档声称 R53 **会**防护的**唯一**场景。**教训**：Scenario 归类必须以父域/删除历史的第一手信息为准，不能只凭报告时点的 dig 签名反推。

**张力与 Q1/Q2/Q3（SME 级思辨）**：
- **Q1（跨账号？）**：现行设计答案 = **全局/跨账号**（与客户"账号内"假设相反）。
- **Q2（per-NS？）**：现行设计答案 = **覆盖任一重叠 NS**（单 NS 即拦，与客户"单 NS 可绕过"相反）。
- **Q3（为何这次没拦？）**：Q1/Q2 都成立 → 按设计本应被阻止，但确实发生了。差别不在"是否跨账号/per-NS"，而在"**这次删除的 hold 为何当时不在效**"。三种可能无法从公开数据区分：① hold 从未成立 / 已被 purge 释放（委派不再被观测）；② 委派早于保护 backfill；③ 已知 backlog 边界。→ **需 Route 53 服务团队查后端删除事件 + hold 记录**才能定性，已起 escalation TT。

**对客纪律（可迁移到任何安全 case）**：拿到后端记录前，**不对客下"保护本应生效却失效（defect）"的定性**；先给 Q1/Q2 方向性答案 + 明说 Q3 已升级待回。若服务团队确认属保护缺陷 → 走 **MAPS** 后再对外，并同步 **SecOps**。

**实测证据（DIRECTLY_OBSERVED，2026-08-20 已不复现）**：
```
# 父域权威确认子域委派到全新一组 NS（非报告里的旧 NS）
dig kycshowcase.d1.thalescloud.io NS @ns-459.awsdns-57.com.
# 新 NS 权威应答（flags: qr aa），SOA serial=1 的占位空 zone
dig kycshowcase.d1.thalescloud.io SOA @ns-997.awsdns-60.net.  -> aa, SOA serial=1
dig kycshowcase.d1.thalescloud.io A @8.8.8.8                  -> NOERROR, ANSWER:0 (NODATA)
# 报告里的旧 NS 已不托管该域
dig kycshowcase.d1.thalescloud.io SOA @ns-90.awsdns-11.com.   -> REFUSED
```
判读："新建占位 zone（serial=1）+ 重新委派到新 NS 组 + 旧 NS 对该域 REFUSED" 是**修复 dangling delegation 的典型指纹**。

**共享责任 / abuse 入口（DOCUMENTED_FACT）**：subdomain takeover "does not leverage vulnerabilities of AWS services. It exploits a dangling DNS record"（AWS security blog）——属客户侧。研究员报告漏洞应走 **AWS abuse form**（`aws.amazon.com/forms/report-abuse`，备用 `trustandsafety@support.aws.com`），**不由普通 support case 直接触发**对接管者账号的动作（须经 T&S/Abuse 正式定性）。

---

## 3. 实验步骤（Hands-on Lab）

> 主题（取自驱动表）：**复现 Scenario 1 的 dangling 风险并演示检测/清理**。**受控 / 概念演练**——真正"抢注"需第二账号反复建 zone 撞 NS，属破坏性/滥用类，本 lab **只做检测与正确清理**，不执行抢注、不触碰他人 zone。

前置：一个你掌控的父 public zone（如 `d1.example.com`）+ 权限建/删 child zone。

### 实验 A：制造并检测一个悬空委派（Scenario 1 的"错误顺序"）

> ⚠️ **破坏性实验**：本实验会真实制造一个 dangling delegation（悬空委派），期间该子域存在被抢注接管的窗口。**仅在你完全掌控、严格隔离的专用测试域上执行**（切勿在生产域或对外可见的真实域上做），并在演示结束后**立即按实验 B 修复**、消除悬空状态。

```bash
# 1) 建 child zone sub.d1.example.com，记下它的 4 个 NS
aws route53 create-hosted-zone --name sub.d1.example.com --caller-reference lab-$(date +%s)
aws route53 get-hosted-zone --id <CHILD_ZONE_ID> --query 'DelegationSet.NameServers'
# 2) 在父 zone d1.example.com 里为 sub 建 NS 委派记录（指向上面 4 个 NS）
#    （UPSERT 一条 Type=NS 的 sub.d1.example.com 记录）
# 3) 验证委派生效
dig sub.d1.example.com NS +short            # 应返回那 4 个 awsdns NS
dig sub.d1.example.com SOA @<其中一个NS>     # flags 含 aa（权威）

# 4) *错误操作*：直接删 child zone，但父域 NS 委派不删
aws route53 delete-hosted-zone --id <CHILD_ZONE_ID>

# 5) 检测悬空：父域仍委派，但 NS 上已无权威 zone
dig sub.d1.example.com NS +short            # 仍返回 4 个 NS（父域委派还在 = 悬空）
dig sub.d1.example.com SOA @<被删NS>         # REFUSED / SERVFAIL（无权威 zone）
dig anything.sub.d1.example.com A @8.8.8.8   # SERVFAIL / 无权威 = 悬空信号
```
判读：**父域仍返回 NS 委派**（步骤 5 第一行）**但那组 NS 对该域不再权威**（REFUSED/SERVFAIL）= **典型悬空委派签名**。此刻若他人抢到重叠 NS 即可接管。

### 实验 B：正确清理 / 修复顺序（消除悬空）

```bash
# 修复路线一（退役子域）：先删父域委派，等 TTL，再删 child zone
# 1) 在父 zone 删除 sub.d1.example.com 的 NS 委派记录（DELETE，值须与现有完全一致）
# 2) 等待该 NS 记录的 TTL 完全过期（确保各 resolver 缓存清空）
dig sub.d1.example.com NS +short            # 应为空/NXDOMAIN（委派已撤）
# 3) 此时才删 child zone（若还没删）——不再有悬空指针可被劫持

# 修复路线二（已经悬空、要恢复控制，同本 case 客户做法）：
# 新建同名占位 zone -> 拿到新 NS 组 -> 父域委派改指向新 NS 组
dig sub.d1.example.com SOA @<新NS>           # 期望 aa + SOA serial=1（占位空 zone）
```
**文档原句锚点**（删 zone 顺序，`DeleteHostedZone.html`）：**"delete the NS record first, and wait for the TTL ... before you delete the child hosted zone. This ensures that no one can hijack the child hosted zone."**

### 实验 C：DNSSEC 作为密码学防护（概念演练）

- 对父 zone 启用 **DNSSEC signing** 后，resolver 会验证应答"确来自权威源且未被篡改"。即使他人抢到重叠 NS，其伪造 zone 的应答**无法通过 DNSSEC 验真**（无正确签名 / DS 信任链断裂），验证型 resolver 将拒绝。
- 文档原句：**"enabling DNSSEC signing ... authenticates that DNS answers come from the authoritative source, effectively protecting against this risk."**
- 注意：DNSSEC 启用后**签名 zone 的最大有效 TTL 为 1 周**（原本 TTL 小于 1 周的记录不受影响，仍按其自身较短的 TTL）、**PHZ 不支持**、需父域支持 **DS 记录**（细节见 topic 07）。这是**纵深防御**，不替代"正确的删除顺序"。

### 检测巡检（可日常做的只读检查）

```bash
# 对所有子域委派做悬空巡检：父域有 NS 委派 但 该 NS 对子域非权威 = 悬空
for sub in $(列出父zone里所有 Type=NS 的子域名); do
  NS=$(dig $sub NS +short | head -1)
  RESULT=$(dig $sub SOA @"$NS" +noall +comment 2>/dev/null | grep -o 'status: [A-Z]*')
  echo "$sub -> $NS -> $RESULT"   # REFUSED/SERVFAIL 且父域仍委派 = 需处理的悬空
done
```

---

## 4. SME 考点 / 易错点（Exam Points & Pitfalls）

对应外部速记 **E28（DNSSEC 作为防护）** + **F 组（故障排查纪律）**，补本域特有结论。每条给"考点结论 + 常见错误认知"。

- **只有 Scenario 1 有防护（核心）**
  - 结论：child zone 曾存在→删→父域留委派 = **唯一**被 StopZoneSniping 防护的场景；Scenario 2–5 **一律不防护**。
  - 常见错误：以为 Route 53 会防所有 dangling 委派；把"先委派后建 zone"（Scenario 5）当成也受保护。

- **保护是跨账号全局，且 per-NS（本 case Q1/Q2）**
  - 结论：hold 阻止**任何账号**拿到重叠 NS；**重叠 1 个 NS 即拦**。
  - 常见错误：以为保护只在删除账号内生效；以为"必须整组 4 个 NS 都重叠才拦 / 单 NS 能绕过"。

- **hold 不是永久的（本 case Q3）**
  - 结论：hold 靠"父域仍观测到委派"续命（`DaasPurgeDelegations`/`DaasDNSLookUpLambda` 周期重评估）；委派从父域消失后 hold 被 purge、NS 回池；保护 backfill 之前的老悬空委派可能不覆盖。
  - 常见错误：以为删过 zone 的 NS 组"永远被锁定"；忽略"委派早于 backfill 可能不受保护"。

- **subdomain takeover 属客户侧（共享责任）**
  - 结论：不是 AWS 服务漏洞，是父域侧悬空指针被抢；AWS 不能读/删第三方账号 zone，NS 向量修复只能父域持有方做。
  - 常见错误：把它当成"AWS 该负责的服务缺陷"；期望 support 直接删掉接管者的 zone。

- **删 zone 正确顺序（硬考点）**
  - 结论：**先删父域 NS 记录 → 等 TTL → 再删 child zone**；反过来（先删 zone 后留委派）就制造了 Scenario 1 悬空。
  - 常见错误：直接删 child zone、忘了父域还留着委派记录。

- **E28 — DNSSEC 作为防护**
  - 结论：DNSSEC signing 让应答需权威源签名，伪造 zone 无法验真——是对该风险的纵深防御；但受"签名 zone 最大有效 TTL 为 1 周（原 TTL<1 周者不受影响）、PHZ 不支持、需父域 DS"约束（详见 topic 07）。
  - 常见错误：把 DNSSEC 当成能"替代"正确删除顺序；忘了 PHZ 不支持、启用后签名 zone 的 TTL 上限被压到 1 周。

- **F — 排查纪律（安全 case 版）**
  - 结论：Scenario 归类**以第一手删除/委派历史为准**，不凭报告时点 dig 签名反推（本 case 从 Scenario 5 翻案到 1）；拿到后端记录前**不下 defect 定性**；确认缺陷走 **MAPS + SecOps**；研究员漏洞报告走 **abuse form**，非 support case 直接处置。
  - 常见错误：只看 SERVFAIL 就定 Scenario；未经服务团队后端就对客说"保护失效是 bug"。

**本域悬空/接管签名速记（背记）**：
- **悬空委派签名**：父域 `dig NS +short` **仍返回**那组 NS，但 `dig SOA @那组NS` **REFUSED/SERVFAIL**（NS 上无权威 zone）。
- **修复指纹**：新委派 NS 组 + 旧 NS 对该域 **REFUSED** + 目标 NS 对该域**真正权威（aa）**。（占位空 zone 常见 `SOA serial=1`，但 serial 值本身不可靠，不作为判定依据——以父区委派是否指向真正权威 NS 为准。）
- **接管条件**：只需重叠 **≥1** 个 NS（多重叠更稳）。

---

## 5. 该域 Mermaid 逻辑导图（Logic Diagram）

subdomain takeover 成因链 + StopZoneSniping 防护/失效判定：

```mermaid
flowchart TD
    START([子域 sub.example.com 的 NS 委派留在父域]) --> Q1{child zone 现在还在吗？}
    Q1 -->|在, 且是你掌控的| SAFE[正常委派, 无悬空风险]
    Q1 -->|已删除 / 从未建立| DANGLE[悬空委派 dangling delegation]

    DANGLE --> SIG[[悬空签名: 父域仍返回NS<br/>但 dig SOA @该NS = REFUSED/SERVFAIL]]
    SIG --> SCN{属哪个 Scenario?}
    SCN -->|zone 曾存在→删→父域留委派| S1[Scenario 1<br/>★R53 唯一防护]
    SCN -->|先委派后建 / 换供应商 / 配错 / 借用他人NS| S25[Scenario 2-5<br/>R53 不防护]

    S1 --> HOLD{StopZoneSniping hold 当前在效?<br/>全局跨账号 · per-NS}
    HOLD -->|在效: 父域仍被观测到委派| BLOCK[新同名 zone 重叠任一NS → 被阻止<br/>攻击者拿不到可用重叠NS]
    HOLD -->|已释放/purge 或早于backfill| GAP[hold 不在效 → 可被接管<br/>本 case Q3: 需服务团队查后端]

    S25 --> TAKE[攻击者他账号反复建同名zone<br/>撞到≥1个重叠NS → 接管]
    GAP --> TAKE
    TAKE --> IMPACT[用你的子域名发权威内容<br/>钓鱼/发证书/窃取]
```

```mermaid
flowchart LR
    FIX([消除悬空 / 防御]) --> ORDER[退役顺序:<br/>先删父域NS记录 → 等TTL过 → 再删child zone]
    FIX --> RECLAIM[已悬空则恢复控制:<br/>新建同名占位zone → 父域委派改指新NS组]
    FIX --> DNSSEC[纵深防御:<br/>父域启DNSSEC signing<br/>伪造zone无法验真]
    FIX --> PATROL[日常巡检:<br/>父域有NS委派 且 该NS对子域非权威 = 悬空]
    DNSSEC -.约束.-> C[签名zone最大TTL=1周·PHZ不支持·需父域DS<br/>见topic 07]
    REPORT([研究员/第三方接管]) --> ABUSE[走 AWS abuse form / T&S<br/>非support case直接处置]
    REPORT --> DISC[对客: 拿后端记录前不下defect<br/>确认缺陷→MAPS+SecOps]
```

---

## 来源锚点

- **外部**：`protection-from-dangling-dns.html`（5 个 Scenario，只防护 Scenario 1）、`DeleteHostedZone.html`（先删 NS 记录等 TTL 再删 child zone）、`welcome-dns-service.html`（委派链 / NS 缓存典型 2 天）、`dns-configuring-dnssec.html`（DNSSEC 防护，topic 07）、AWS security blog "Threat tactic spotlight: subdomain takeover"（共享责任、CNAME 向量）、`aws.amazon.com/forms/report-abuse`（abuse 入口）；r53-external-research.md §1/§9/§15 速记 E28、F。
- **内部**：r53-internal-research.md §1（PHZ/委派）、§12（NXDOMAIN/Subdomain Delegation Failure/Lame delegation 签名、排查纪律）；StopZoneSniping 控制面项目、DaasPurgeDelegations Runbook、Tech Talk broadcast 352435（hold 生命周期 / 跨账号 / per-NS / backfill 边界，对客不引用内部链接）。
- **绑定 case**：178715620200407（Thales / `kycshowcase.d1.thalescloud.io`，NS 委派向量的 subdomain takeover；Scenario 5→1 翻案；StopZoneSniping 跨账号 + per-NS + hold 生命周期；Q1/Q2/Q3 与 escalation TT；DNSSEC 防护、删 zone 顺序、abuse 流程、MAPS/SecOps 对客纪律）。

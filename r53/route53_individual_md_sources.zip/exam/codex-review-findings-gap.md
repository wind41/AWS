# Codex 校验 findings — 缺口补充域 21/22/23（2026-09-20）

## topic 21 Cloud Map / 服务发现
核心正确：Public DNS namespace=public HZ+DNS/API；Private DNS=PHZ+DNS/API；HTTP namespace 不建 HZ 只 API discovery。修正：
1. WEIGHTED 补 fail-open（无健康实例时按全部实例处理）；Alias 必须 WEIGHTED；CNAME 必须 WEIGHTED 且不能配 HealthCheckConfig。
2. "标准 R53 HC 仅适用 public namespace" 错误 → HealthCheckConfig 支持 Public DNS 和 HTTP namespace，不支持 Private DNS；custom health 不是"仅限 VPC 资源"；二者不能同时配。
3. "awsvpc→A" 过度简化 → ECS service discovery awsvpc 支持 A 或 SRV；bridge/host 才只能 SRV。
4. "Service Connect 用 HTTP namespace 并自动增删 DNS 记录" 错误 → 新建时创 HTTP 类型但可引用任何现有 namespace；Service Connect 用 Cloud Map API 注册表 + 托管代理，不靠 DNS 记录增删。

## topic 22 迁移与批量变更
核心正确：ChangeResourceRecordSets 整批原子成功/失败；INSYNC = 全部 R53 权威已更新，不代表递归缓存过期。修正：
1. "Zone import 仅适合空 zone" 过绝对 → 控制台原生导入最多 1000 条；非空 zone 可导入，但文件含已存在记录则整次导入失败。
2. **"单请求最多 1000 个变更" 错误 → 上限是 1000 个 ResourceRecord 元素（Alias 也计入）+ 所有 Value 共 32000 字符**，非按 Changes[] 数量。
3. UPSERT 双层双倍 → 请求大小计算时每个 RR 元素及 Value 字符计两次；change-throughput 每个 UPSERT 消耗 2 token，桶 burst 1500/持续 100 changes/s。
4. NS 切换 → 旧服务与新 zone 先降 NS TTL 至 60-900s 等旧 TTL 过期，复制验证后改注册商委派；旧权威至少保留 48h，父区缓存仍可能持续两天。
5. "每批必须等 INSYNC 才提交下一批" 非硬要求 → 是安全串行策略；并发未处理完会收 PriorRequestNotComplete。

## topic 23 企业跨区跨账号架构
（Codex 校验被截断。修正 subagent 请按官方核对：hub-spoke 是 RAM 共享 Resolver **rule** 非 endpoint 本身、消费账号关联自己 VPC；跨账号 PHZ 用 CreateVPCAssociationAuthorization + AssociateVPCWithHostedZone；Profiles vs 逐 VPC vs Resolver rule 选型边界；混合云 outbound endpoint 条件转发。有不准处一并改。）

# Route 53 SME 模拟题库 · Wave4 下半（Topics 08–13）

> 覆盖：08 子域接管/悬空委派、09 域名注册与生命周期、10 Profiles、11 ARC Routing Controls、12 服务集成+配额限流、13 通用排查纪律。
> 题型：场景单选（单选）/ 多选 / 少量问答。每题含题干 + 选项 A–E + 【答案】 + 【解析】。
> 合计 46 题（08:8 · 09:8 · 10:7 · 11:8 · 12:8 · 13:7）。

---

## 第 08 章 · 子域接管 / dangling delegation / StopZoneSniping（8 题）

### 08-1（单选）
某客户发现子域 `sub.example.com` 被他人接管。调查发现：父域仍保留该子域的 4 个 awsdns NS 委派记录，但对应的 child hosted zone 早已被删除。这属于哪个 Scenario，Route 53 的 StopZoneSniping 是否**设计上**会防护？

- A. Scenario 1，会防护
- B. Scenario 5，会防护
- C. Scenario 1，不防护
- D. Scenario 5，不防护
- E. Scenario 3，会防护

【答案】A
【解析】"child zone 曾存在→被删→父域仍留委派" 正是 Scenario 1，是 5 个场景中 Route 53 **唯一**提供防护（对被删 zone 的 NS 组加 hold）的场景。Scenario 2–5 一律不防护。注意题目问的是"设计上是否防护"，与"这次实际是否被拦住"是两回事（后者取决于 hold 当时是否在效）。

### 08-2（单选）
关于 subdomain takeover 的成功条件，下列哪项**最准确**？

- A. 攻击者必须让新建 zone 的全部 4 个 NS 与悬空 NS 完全重叠
- B. 攻击者只需让新建 zone 的 NS 组与悬空 NS 组重叠 ≥1 个即可，重叠越多接管越稳定
- C. 攻击者必须在删除该 zone 的同一账号内重建
- D. 只要父域存在任意 NS 记录即可接管，无需重叠
- E. 必须先拿到 EPP auth code 才能接管

【答案】B
【解析】接管只需命中 ≥1 个重叠 NS（递归解析器在多 NS 间选择/重试，命中攻击者掌控的那个即拿到伪造权威应答）；重叠越多越稳定。"必须整组重叠"是错误认知。接管可在**任意**账号进行（跨账号），与 EPP code 无关（那是域名转移概念）。

### 08-3（多选）
关于 StopZoneSniping 保护特性，以下哪些描述正确？（多选）

- A. 保护是跨账号全局的，阻止任何账号被分配到重叠 NS
- B. 保护仅在删除该 zone 的账号内部生效
- C. 只要新 zone 重叠 1 个或多个 NS 即被阻止（per-NS）
- D. hold 是永久的，删过 zone 的 NS 组永远被锁定
- E. hold 靠"父域仍被观测到委派"续命，委派从父域消失后会被 purge、NS 回池

【答案】A、C、E
【解析】保护是跨账号全局（A 对，B 错）；per-NS 生效，重叠任一即拦（C 对）；hold 非永久（D 错），靠周期性 DNS 重评估续命，父域不再委派则 purge 回池（E 对）。此外保护 backfill 之前就已 dangling 的老委派可能不覆盖。

### 08-4（单选）
退役一个子域时，消除悬空委派的**正确删除顺序**是？

- A. 先删 child hosted zone，再删父域的 NS 委派记录
- B. 先删父域的 NS 委派记录 → 等 TTL 过期 → 再删 child hosted zone
- C. 同时删除父域 NS 记录和 child zone
- D. 只删 child zone，父域委派保留以便日后复用
- E. 先启用 DNSSEC，再任意顺序删除

【答案】B
【解析】文档原则：先删父域 NS 记录并等 TTL 过期（确保 resolver 缓存清空），再删 child zone，"This ensures that no one can hijack the child hosted zone"。反过来（先删 zone 留委派）正是制造 Scenario 1 悬空的错误操作。

### 08-5（单选）
运维做只读巡检时，判断一个子域委派**悬空**的典型 dig 签名是？

- A. `dig sub NS +short` 返回空，且 `dig SOA @NS` 返回 aa
- B. `dig sub NS +short` 仍返回那组 NS，但 `dig SOA @那组NS` 返回 REFUSED/SERVFAIL
- C. `dig sub A @8.8.8.8` 返回 NOERROR + 有 A 记录
- D. `dig sub SOA` 返回 serial=1
- E. `dig sub NS` 返回 NXDOMAIN

【答案】B
【解析】悬空签名 = 父域仍返回 NS 委派（委派还在），但那组 NS 对该域已不再权威（直查 SOA 得 REFUSED/SERVFAIL，NS 上无权威 zone）。选项 D 的 serial=1 是**修复指纹**（新建占位空 zone），不是悬空签名。

### 08-6（单选）
Thales case（`kycshowcase.d1.thalescloud.io`）首轮据"报告时点 SERVFAIL、无权威 zone"推断为 Scenario 5，客户澄清后翻案为 Scenario 1。这个反转给 SME 的**排查纪律**教训是？

- A. dig 的 SERVFAIL 永远意味着 Scenario 5
- B. Scenario 归类必须以父域/删除历史的第一手信息为准，不能只凭报告时点的 dig 签名反推
- C. 只要看到 SERVFAIL 就可对客下 defect 定性
- D. 客户澄清不可信，应以 dig 为准
- E. Scenario 1 和 5 在防护上等价，归类无所谓

【答案】B
【解析】报告时点的 dig 签名只反映"此刻无权威 zone"，无法区分"从未建 zone（Scenario 5）"还是"曾建后删（Scenario 1）"。必须以删除/委派历史的第一手信息定性。归类直接决定"设计上是否本应防护"，绝非无所谓。

### 08-7（多选）
关于 subdomain takeover 的责任归属与处置流程，正确的有？（多选）

- A. 它利用的是父域侧的悬空 DNS 记录，属共享责任模型的客户侧，不是 AWS 服务漏洞
- B. AWS 可以直接读取并删除接管者第三方账号里的 hosted zone
- C. 研究员报告此类漏洞应走 AWS abuse form（report-abuse），而非普通 support case 直接触发对接管者账号的动作
- D. 若服务团队确认属保护缺陷，对外披露前应走 MAPS 并同步 SecOps
- E. NS 向量的修复只能由父域持有方在父域侧完成

【答案】A、C、D、E
【解析】takeover 属客户侧（A 对）；AWS 无法读/删第三方账号 zone（B 错）；研究员漏洞走 abuse form/T&S（C 对）；确认缺陷走 MAPS+SecOps（D 对）；NS 向量修复只能父域持有方做（E 对）。

### 08-8（单选）
关于 DNSSEC 作为对 dangling delegation 风险的防护，下列哪项正确？

- A. DNSSEC 可以替代"正确的删除顺序"，启用后无需再关心删除顺序
- B. DNSSEC signing 让应答需权威源签名，伪造 zone 无法通过验真，是纵深防御；但受 TTL 强制 1 周、PHZ 不支持、需父域 DS 等约束
- C. PHZ（私有区）也完全支持 DNSSEC signing
- D. 启用 DNSSEC 后 TTL 可任意设置
- E. DNSSEC 能阻止攻击者建立重叠 NS 的 zone

【答案】B
【解析】DNSSEC 是密码学纵深防御——伪造 zone 无正确签名/DS 信任链断裂，验证型 resolver 会拒绝；但它不替代正确删除顺序（A 错），且 PHZ 不支持（C 错）、启用后 TTL 强制 1 周（D 错）、需父域支持 DS。它不阻止别人建 zone（E 错），只让伪造应答无法验真。

---

## 第 09 章 · 域名注册 / 生命周期 / TLD 差异（8 题）

### 09-1（单选）
客户 `gateio.jp` 反映：Route 53 控制台显示到期 2027/6/29，而 WHOIS（whois.jprs.jp）显示 2026/06/30，且状态码显示 "-"，怀疑异常。SME 的正确判读是？

- A. WHOIS 到期日权威，客户域名即将过期需立即续期
- B. 两个到期日都对——R53/Gandi 的 2027/6/29 是有效到期日，JPRS WHOIS 按"到期月月末"呈现旧年份且更新滞后；状态 "-" 因 .jp 不支持 transfer lock，均属正常
- C. 状态 "-" 说明域名被锁定，需解锁
- D. 需立即向 JPRS 提工单纠正 WHOIS bug
- E. R53 到期日错误，应以 JPRS 为准修正

【答案】B
【解析】.jp（JPRS）三特性：① WHOIS 到期日恒为到期月月末（6/29→显示 6/30）；② 旧到期月过完才更新新年份（约 7/1 更新）；③ 不支持 transfer lock，无锁状态显示 "-"。有效期以 Gandi/Route 53 记录为准，客户无需操作（保持 auto-renew）。

### 09-2（多选）
关于 Route 53 的"注册商侧"与"DNS 托管侧"的边界，正确的有？（多选）

- A. 删除 hosted zone 会自动注销域名注册
- B. 注销域名注册不会自动删除 hosted zone
- C. 域名被 suspend（clientHold）时，hosted zone 里的记录仍在，但公网查不到，因为注册局停止委派
- D. 改了 hosted zone 的 NS 后，必须在 Registered domains 侧同步更新注册局 NS 委派，否则解析走旧 NS
- E. 注册（registration）与解析（resolution）是同一套生命周期

【答案】B、C、D
【解析】注册 ≠ 解析，两套独立生命周期（E 错）。删 hosted zone 不注销域名（A 错）；注销域名不删 hosted zone（B 对）；suspend/clientHold 断的是注册局委派、记录仍在（C 对）；改 hosted zone NS 必须两侧同步（D 对）。

### 09-3（单选）
关于 .jp 域名的续期与转移特性，下列哪项**错误**？

- A. .jp 续期窗口很窄，仅到期前 30 天到 6 天（D-30 ~ D-6）
- B. .jp 不支持 late renewal
- C. .jp 不支持 transfer lock，状态码显示 "-" 属正常
- D. .jp 由 Amazon Registrar（AMAZON_KS）直接注册
- E. .jp 由 Gandi 代理注册

【答案】D
【解析】.jp 是 ccTLD，由 Gandi（注册商 ID 81）代理（E 对，D 错）。续期窗 D-30~D-6（A 对）、无 late renewal（B 对）、无 transfer lock 显示 "-"（C 对）。Amazon Registrar 主要负责通用 gTLD（.com/.net/.org 等）。

### 09-4（单选）
客户在域名转移**完成前**关闭了源账号，三个 Amazon Registrar 域名被 suspend 进入 clientHold、公网 DNS 中断。要恢复并完成转移，正确路径是？

- A. 直接从目标账号发起转移即可
- B. 重开源账号 → AES 事件驱动自动 unsuspend → 再走标准跨账号转移；转移必须由源账号发起
- C. 联系 JPRS 解除 clientHold
- D. 等域名进入 redemption 后从池中重新注册
- E. 修改目标账号的 NS 委派即可恢复解析

【答案】B
【解析】账号一关，自助转移路径被切断（转移必须由源账号发起）。恢复路径：重开源账号 → AES 事件驱动自动 unsuspend（文档恢复窗口最长 24h，非合同 SLA）→ 标准跨账号转移。这些是 Amazon Registrar 域名，与 JPRS 无关。

### 09-5（单选）
关于账号关闭触发的域名生命周期时限，下列哪项正确？

- A. 关闭后立即删除域名，无任何窗口
- B. 关闭 → 每日 WILL_SUSPEND 通知 5 天 → SUSPEND_DOMAIN(clientHold) → suspend 约 30 天后进入删除流程 → 90 天 post-closure 永久关闭
- C. suspend 后 7 天即永久删除，不可恢复
- D. suspend 等同于 delete，域名立即回到公开池
- E. 90 天内 hosted zone 会自动恢复解析

【答案】B
【解析】标准时限：每日通知 5 天 → suspend(clientHold) → +30 天进入删除 → 90 天 post-closure 永久。suspend ≠ delete（D 错），clientHold 后仍有约 30 天窗口。域名 unsuspend 后 hosted zone 可能仍处 isolation（NS REFUSED），DNS 恢复是另一条独立恢复链（E 错）。

### 09-6（多选）
关于域名转移（transfer out）的前提条件，正确的有？（多选）

- A. 域名注册满 60 天（新注册/刚转入有 60 天锁）
- B. 解除 transfer lock（若该 TLD 支持）
- C. 取得 EPP auth code（转移授权码）
- D. admin/registrant 邮箱可达（接收转移确认邮件）
- E. 必须先删除 hosted zone

【答案】A、B、C、D
【解析】转移前提：60 天锁（A）、解锁（B，部分 TLD 如 .jp 本就不支持锁）、EPP auth code（C）、联系人邮箱可达（D）。删除 hosted zone 与转移域名无关（E 错，且注册≠解析）。变更 registrant 也常触发 60 天锁。

### 09-7（单选）
关于赎回期（Redemption）与删除，下列哪项正确？

- A. 域名过期后随时可免费找回
- B. 进入 redemption 后 restore 通常收费且不保证成功；进入 pending delete 后不可赎回
- C. redemption 期内域名仍正常解析
- D. pending delete 阶段仍可免费赎回
- E. released 阶段域名自动回到原账号

【答案】B
【解析】赎回期 restore 收费且不保证成功；pending delete 后不可赎回（D 错）；released 后回到公开可注册池，需重新抢注（E 错）。redemption 阶段域名已暂停、不正常解析（C 错）。"过期随时免费找回"是常见错误认知（A 错）。

### 09-8（问答）
简述在排查"客户改了 NS 却发现解析仍走旧值"时，SME 应首先确认的关键点，以及 WHOIS 与 RDAP 的关系。

【答案】
- **关键点**：`update-domain-nameservers` 改的是**注册局侧委派**；只改 hosted zone 的 NS 而不在 Registered domains 侧同步更新注册局 NS 委派，注册局仍指向旧 NS，解析走旧 NS——这是"改了 NS 却不生效"的根因。传播还受父区(TLD)NS 记录 TTL 影响（数分钟到数十分钟）。
- **WHOIS vs RDAP**：WHOIS 是传统文本协议、各注册局格式各异（如 .jp 走 whois.jprs.jp 返回日文字段）；RDAP 是其现代 JSON/HTTP 结构化替代，支持权限分级，ICANN 正逐步以 RDAP 取代 gTLD 的 WHOIS。
【解析】呼应 §1.7 注册侧↔解析侧接缝与 §1.6 目录服务。SME 排查转移/续期/解析类问题还应先查联系人邮箱可达性与续期是否成功。

---

## 第 10 章 · Route 53 Profiles（7 题）

### 10-1（单选）
关于 Route 53 Profile 的本质，下列哪项**最准确**？

- A. Profile 是一种全新的 DNS 资源类型，用来取代 PHZ
- B. Profile 是把 PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging 配置成组打包、批量关联到多个 VPC 的分发机制
- C. Profile 只能打包 PHZ，不含其它资源
- D. 用了 Profile 之后就不再需要创建 PHZ
- E. Profile 是一种 Resolver endpoint 的高可用版本

【答案】B
【解析】Profile 是**打包分发机制**，不是新资源类型、不取代 PHZ（A、D 错）。它能装四类资源：PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging 配置（C 错，不止 PHZ）。仍需先单独创建这些资源再放进 Profile。

### 10-2（单选）
一个 VPC 需要下发多组 DNS 治理策略，下列做法正确的是？

- A. 给该 VPC 同时关联 3 个 Profile 分层下发
- B. 把这些策略合并进同一个 Profile，因为一个 VPC 同时只能关联 1 个 Profile
- C. 一个 VPC 最多可关联 5 个 Profile
- D. VPC 无法关联 Profile，只能逐条配置
- E. 一个 Profile 只能关联到 1 个 VPC

【答案】B
【解析】每个 VPC 同时只能关联 1 个 Profile，要下发多组策略必须合并进同一个 Profile（不能叠加）。反向：1 个 Profile 可关联到很多 VPC（E 错，这正是它规模化的意义）。

### 10-3（单选）
某 VPC 本地直接关联了一个 PHZ，同时又通过 Profile 下发了一个同命名空间的 PHZ。查询该命名空间时，Route 53 采用哪个？

- A. Profile 下发的 PHZ 优先
- B. VPC 本地（local）关联的 PHZ 优先于 Profile 下发的同名配置
- C. 随机选择
- D. 报冲突错误，两者都不生效
- E. 合并两者的记录一起返回

【答案】B
【解析】优先级铁律：**local > Profile**。本地是"就近覆盖"，Profile 是"集中默认"。在都属 local 或都属 Profile 的范围内仍遵循最具体匹配。

### 10-4（单选）
跨账号用 Profile 做集中式 DNS 治理，标准分发路径是？

- A. 对每个 PHZ 逐个做 VpcAssociationAuthorization 跨账号授权
- B. 中心账号创建 Profile → 通过 AWS RAM 共享给成员账号/Organization → 成员账号接受后关联到自身 VPC
- C. 把 Profile 复制到每个成员账号
- D. 通过 CloudFormation StackSets 手工同步配置
- E. 跨账号无法使用 Profile

【答案】B
【解析】Profile 通过 AWS RAM 共享给成员账号或整个 Organization，成员账号接受后关联到自身 VPC。这**免去了逐 PHZ 的 VpcAssociationAuthorization** 跨账号授权（A 是被替代的旧繁琐做法）。

### 10-5（多选）
以下哪些资源可以被打包进一个 Route 53 Profile？（多选）

- A. Private Hosted Zones（PHZ）
- B. Resolver rules（转发/系统规则）
- C. DNS Firewall rule groups（含优先级与 fail-open/closed 行为）
- D. Resolver query logging 配置
- E. EC2 安全组

【答案】A、B、C、D
【解析】Profile 可打包四类 DNS 配置：PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging 配置。EC2 安全组不是 DNS 治理资源，不在其列（E 错）。

### 10-6（单选）
关于 Profile 变更的影响范围，下列哪项正确？

- A. 改 Profile 内配置只影响中心账号自己的 VPC
- B. 改 Profile 内配置会作用于所有关联该 Profile 的 VPC，集中一致但一次误改的爆炸半径覆盖全部关联 VPC
- C. 改 Profile 后需逐个 VPC 手工重新关联才生效
- D. Profile 一旦创建即不可修改
- E. 改 Profile 只影响新关联的 VPC，已关联的不受影响

【答案】B
【解析】集中定义→自动传播到所有关联 VPC 是 Profile 的优点，但也意味着误改的爆炸半径覆盖全部关联 VPC，变更需谨慎评审。无需逐个重关联（C 错），Profile 可修改（D 错）。

### 10-7（单选）
何时应把逐 VPC 手工配置切换为 Route 53 Profiles？

- A. 只有单个 VPC 时
- B. 当 PHZ-VPC 关联逼近每 PHZ 300 VPC 上限、或几十上百 VPC 逐个配置不可维护时
- C. 仅当需要 DNSSEC 时
- D. 仅当使用公网 hosted zone 时
- E. Profiles 只适用于跨 Region 场景

【答案】B
【解析】Profiles 定位于治理规模化：当每 PHZ 300 VPC 上限逼近、或几十上百 VPC 逐个配置运维爆炸时，是标准治理方案。单 VPC（A）用不上；与 DNSSEC/公网 zone/跨 Region 无必然绑定。

---

## 第 11 章 · Application Recovery Controller (ARC) Routing Controls（8 题）

### 11-1（单选）
ARC Routing Control 与普通 Route 53 Health Check 的**根本区别**是？

- A. Routing control 主动探测端点，探测失败自动切流
- B. Routing control 是人工/编程拨动的确定性开关，背后改一个 R53 health check 的状态来切流，不依赖对应用的探测
- C. 两者完全等价，只是 ARC 更贵
- D. Routing control 只能用于单 Region
- E. 普通 health check 无法用于 failover 记录

【答案】B
【解析】ARC routing control 是"开关"不是"探针"——由人/自动化确定性拨动，背后驱动一个 health check 状态翻转，进而切 failover 记录。规避了灰色故障下探测不准或探测本身故障导致无法可靠切流的问题。

### 11-2（单选）
灾难发生时，切换 routing control 状态应使用哪条路径？

- A. Control plane（route53-recovery-control-config）
- B. Cluster 的 data plane endpoint（route53-recovery-cluster，5 个 Region endpoint，轮询直到成功）
- C. 直接改 Route 53 记录
- D. 修改 hosted zone 的 NS 委派
- E. 通过 Service Quotas 控制台

【答案】B
【解析】考点铁律：平时用 control plane 配置，**救灾切流必须用 cluster 的 5 个 data plane endpoint**（轮询直到一个成功）。control plane 在大区域性灾难中可能不可达。

### 11-3（单选）
ARC Cluster 的高可用设计是？

- A. 单 Region 部署
- B. 由 5 个 AWS Region 组成，读写 routing control 状态需至少 3 个（3/5 quorum）一致，即使 2 个 Region 不可用仍可切换
- C. 由 3 个 Region 组成，需全部在线
- D. 由 5 个 Region 组成，需 5 个全在线才能切
- E. 由 2 个可用区组成

【答案】B
【解析】Cluster 跨 5 个 Region，3/5 quorum；即使 2 个 Region 挂掉仍可靠切换。这保证"救灾工具本身不和被救系统同挂"。需全部在线（C、D）是错误认知。

### 11-4（多选）
关于 Safety Rules，正确的有？（多选）

- A. 核心目的是防止一次误操作把所有 Region 同时关掉（防"全关"）
- B. Assertion rule 约束一组 routing control 必须满足某条件才允许改变（如至少 1 个为 On）
- C. Gating rule 用一个"门"control 允许/禁止对另一组 control 的更改
- D. Safety rule 会主动探测应用健康
- E. 有了 safety rule 就不再需要 data plane endpoint

【答案】A、B、C
【解析】Safety rule 是护栏，防"全关"与防误触（A、B、C 对）。它不探测应用（D 错，那是普通 health check 的事）；切换仍必须走 data plane endpoint（E 错）。

### 11-5（单选）
Routing control 到 DNS 切流的绑定链条，正确顺序是？

- A. routing control → failover 记录 → health check → DNS
- B. routing control → 驱动 R53 health check(Type=RECOVERY_CONTROL) → 关联的 failover 记录(Primary/Secondary) → DNS 应答切换
- C. health check → routing control → cluster → DNS
- D. failover 记录 → cluster → routing control → DNS
- E. routing control 直接改 A 记录的 IP

【答案】B
【解析】链条：拨 routing control → 改其驱动的 health check(Type=RECOVERY_CONTROL)状态 → 关联的 failover(Primary/Secondary)记录按 health check 判定切换 → DNS 完成切流。routing control 不直接改记录 IP（E 错）。

### 11-6（单选）
在 Active/Standby 双 Region DR 场景中（rc-primary 对 us-east-1、rc-secondary 对 us-west-2），下列哪个 safety rule 能防止运维一次误操作导致全站无端点？

- A. 允许 rc-primary 与 rc-secondary 同时为 Off
- B. Assertion rule：约束 [rc-primary, rc-secondary] 中为 On 的数量必须 ≥1（ATLEAST 1），禁止同时全 Off
- C. 把两个 control 合并成一个
- D. 关闭 safety rule 以加快切换
- E. 只对 rc-primary 设 gating rule

【答案】B
【解析】ATLEAST 1 On 的 assertion rule 会在试图把最后一个 On 也关掉时拒绝切换，防止"两边都没流量"的自陷式全局中断。这正是 Lab D 演示的护栏。

### 11-7（单选）
为 routing control 建的 Route 53 health check，其 Type 与关键属性应是？

- A. Type=HTTP，带探测 URL
- B. Type=RECOVERY_CONTROL，用 RoutingControlArn 关联（由 routing control 驱动，非探测型）
- C. Type=CALCULATED，聚合多个子 health check
- D. Type=CLOUDWATCH_METRIC，绑定告警
- E. Type=TCP，探测端口

【答案】B
【解析】ARC 的 health check 是 `Type=RECOVERY_CONTROL`，通过 `RoutingControlArn` 关联，状态由 routing control 直接驱动而非主动探测。其它类型都是探测/计算型 health check。

### 11-8（问答）
在 DR 演练中，团队通过一个 data plane endpoint 把 rc-secondary 切为 On 并观察到一次 `dig` 成功返回 us-west-2 端点，就宣布"切换路径完全健康"。请指出这个结论的纪律缺陷。

【答案】
一次查询成功不足以证明整条切换路径健康：① cluster 有 5 个 data plane endpoint，仅验证了其中一个可达，未证明灾难时其余 endpoint 的可用性（生产脚本应轮询 5 个直到成功）；② 一次 `dig` 成功只反映当前解析结果，不能证明 failover 记录/health check 在各种故障组合下都会正确切换；③ 应结合 safety rule 验证（如尝试全关被拒）以确认护栏在效。宁可说"已验证经该 endpoint 可切换"，不下"整条路径完全健康"的充分性结论。
【解析】呼应"单点成功 ≠ 全局健康"与"必要非充分"纪律（与 topic 13 一致）。

---

## 第 12 章 · 服务集成 + 配额与限流（8 题）

### 12-1（单选）
客户问"为什么在根域 `example.com` 上配 CNAME 报错"，SME 的正确回答是？

- A. 根域 CNAME 需要额外付费才能启用
- B. 标准 DNS 禁止在 zone apex 放 CNAME，应改用 Alias 记录（Alias 可用于 apex）
- C. 根域只能用 TXT 记录
- D. 需要先启用 DNSSEC
- E. CNAME 在 apex 需要设置 TTL=0

【答案】B
【解析】标准 DNS 禁止 apex 放 CNAME；Route 53 的 Alias 记录没有此限制，可用于 apex，且指向 AWS 资源不额外收费、AWS 自动维护目标 IP。

### 12-2（多选）
关于 Alias 到 S3 静态网站的硬约束，正确的有？（多选）

- A. 目标必须是"网站托管"endpoint（s3-website-<region>），不是普通 REST endpoint
- B. bucket 名必须与记录名完全一致
- C. region 要选对
- D. Alias 到 S3 网站支持 Evaluate Target Health
- E. 可以直接 Alias 到普通 S3 REST endpoint

【答案】A、B、C
【解析】S3 网站 Alias 三硬约束：网站 endpoint（A）、bucket 名 == 记录名（B）、region 选对（C）。S3 网站 Alias **不支持** Evaluate Target Health（D 错）；不能用普通 REST endpoint（E 错）。

### 12-3（单选）
关于 Evaluate Target Health 的支持面，下列哪项正确？

- A. CloudFront、S3 网站、ELB 都支持
- B. ELB 支持；CloudFront 与 S3 网站不支持
- C. 只有 CloudFront 支持
- D. 所有 Alias 目标都强制开启
- E. 只有 API Gateway 支持

【答案】B
【解析】ELB 支持 Evaluate Target Health（Route 53 看目标组是否有健康目标）；CloudFront（全球边缘无"目标"概念）与 S3 网站不支持。别承诺 CloudFront Alias 能做目标健康评估。

### 12-4（单选）
下列关于 Route 53 数据面 vs 控制面限流的说法，哪项正确？

- A. 公网权威 DNS 查询有严格的每账号 QPS 配额
- B. 公网权威查询几乎无限、不计账号配额；被限流的是控制面 API（约 5 请求/秒/账号）和 Resolver endpoint（per-ENI ~10,000 QPS）
- C. 控制面 API 无任何限流
- D. Resolver endpoint 无 QPS 上限
- E. 所有查询都计入统一的账号级 QPS 限流

【答案】B
【解析】公网权威查询由 AWS anycast 车队承载，属数据面、不计账号配额；能被限流的是控制面 API（~5 req/s，如 ChangeResourceRecordSets）与 Resolver endpoint（per-ENI ~10k QPS，加 IP 线性扩）。混答是高频扣分点。

### 12-5（单选）
需要一次性修改一个 hosted zone 里的上百条记录，正确做法是？

- A. 写脚本循环调用 change-resource-record-sets，每条一次，每秒 >5 次
- B. 用单次 ChangeResourceRecordSets 请求打包多个变更，避免触发 Throttling/PriorRequestNotComplete
- C. 先提额把 hosted zone 上限调到 10 万
- D. 分账号并发调用绕过限流
- E. 逐条调用但加 sleep 到每秒恰好 5 次

【答案】B
【解析】控制面 ~5 req/s，循环单条调用会秒级触发 `Throttling`/`PriorRequestNotComplete`。正解是用单次 ChangeResourceRecordSets **打包多条 Changes**。

### 12-6（多选）
关于 `ip-ranges.json` 中 Route 53 相关 service 的三分层（呼应 NBC 案例），对应正确的有？（多选）

- A. ROUTE53 = 公网权威 NS 的 IP 范围
- B. ROUTE53_RESOLVER = VPC 内递归解析器（有 per-ENI QPS 限流的那层）
- C. ROUTE53_HEALTHCHECKS = 健康检查探测车队
- D. ROUTE53 = VPC 内递归解析器
- E. 三者对应同一条数据路径

【答案】A、B、C
【解析】三分层分别对应权威/递归/探测三条完全不同的数据路径：ROUTE53=权威 NS、ROUTE53_RESOLVER=递归（有 QPS 限流）、ROUTE53_HEALTHCHECKS=探测。D、E 混淆了路径。

### 12-7（单选）
NBC（National Bank of Canada）case 中，客户想在防火墙放行 AWS 公共 DNS 服务器 IP 以实现 zone delegation。SME 的关键判读**不含**下列哪项？

- A. 要放行的是 ROUTE53（权威 NS）的 IP，不是 ROUTE53_RESOLVER
- B. 公网权威查询由 anycast 承载、不计账号限流，客户无需为 QPS 提额
- C. NS IP 是静态的但仍可能新增前缀，应全量收录并订阅 SNS 变更监控
- D. NS delegation 本身需要在防火墙放行入站 53，且必须逐个 region 过滤 IP
- E. 需放行的是客户递归解析器 outbound 到权威 NS（目的端口 53）的查询流量

【答案】D
【解析】题问"不含"（即错误项）。NS delegation 本身不需要防火墙改动；需放行的是客户递归 outbound→权威 NS（UDP/TCP 目的 53）。放行应**全量收录、不按 region 过滤**（实测含 8 种 region 字段）并订阅 SNS（AmazonIpSpaceChanged）兜底。D 两处都错。A/B/C/E 均为正确判读。

### 12-8（单选）
关于 Global Accelerator (GA) 与 Route 53 选路的分工，下列哪项最准确？

- A. GA 和 Route 53 二选一，不能叠加
- B. GA 提供两个静态 anycast IP，在网络层做最优接入（客户端到入口的路径）；Route 53 在 DNS 层决定把哪个 IP 返给客户端；二者可叠加
- C. GA 在 DNS 层选路，Route 53 在网络层选路
- D. GA 是 Route 53 延迟路由的替代品，功能完全等价
- E. GA 只能用普通 A 记录、不能用 Alias 指向

【答案】B
【解析】GA 解决"客户端到 AWS 入口的网络路径"（静态 anycast IP、走骨干网），Route 53 解决"把哪个 IP 返给客户端"（DNS 层选路），分工不同、可叠加。Route 53 可用 A 记录指向两个静态 IP，或用 Alias 指向 accelerator DNS 名（E 错）。

---

## 第 13 章 · 通用故障排查纪律（横切，7 题）

### 13-1（单选）
一台 EC2 解析某域名失败。判断故障范围时，SME 首先应做的是？

- A. 立即断定 Route 53 服务整体故障
- B. 先界定 blast radius——是所有 client 还是这一台？所有域名还是这一个？所有查询还是偶发？再归因
- C. 直接建议客户提额
- D. 假定是记录被删并重建记录
- E. 直接对客下单一根因结论

【答案】B
【解析】单点失败 ≠ 服务故障，一次成功 ≠ 路径整体健康。纪律：永远先界定故障范围再归因。确定性全失败指向"所有路径共有的一环"，概率性失败指向"多路径中某一条"。

### 13-2（单选）
客户报告 EC2 `nslookup jcrew.com 10.201.244.2` 三次全部 timeout（VPC CIDR 为 10.201.244.0/22）。AI 初稿建议"检查 EC2 到 .2 的 SG/NACL/路由"。SME 的正确纠正是？

- A. 初稿正确，按建议检查 SG/NACL
- B. 10.201.244.2 = VPC CIDR base + 2 = AmazonProvidedDNS，EC2→.2 这段不经 SG/NACL/路由；真正阻断点在下游（Resolver Outbound Endpoint 的 ENI 子网 NACL、转发目标路由）
- C. timeout 说明记录不存在，应检查记录配置
- D. 应先重启 EC2
- E. 直接判定为限流，建议提额

【答案】B
【解析】AmazonProvidedDNS = VPC CIDR base+2，EC2→该地址不过 SG/NACL/路由（AWS 底层实现）。方向应指向下游 Resolver Endpoint 的 ENI 子网 NACL/转发目标路由。且 timeout 是网络层信号，不是"记录没配"（C 错），也不能直接当限流（E 错）。

### 13-3（单选）
排查中确认了一个 NACL 拦截了 DNS 流量。关于是否可承诺"修这个 NACL 就恢复"，正确的纪律是？

- A. 可以承诺，找到一个阻断点即可结案
- B. 修它是恢复的必要条件但不一定充分——可能同时存在第二个问题（如 TGW 路由不可达、目标 DNS 不响应）；除非已证明是唯一阻断点，否则不承诺"修完即恢复"
- C. 必须先修完所有可能问题再回复
- D. 阻断点越多越应该承诺一次修好
- E. 只要是 DIRECTLY_OBSERVED 的阻断就等于充分条件

【答案】B
【解析】必要非充分：多 ENI/多路径下常有第二处问题。措辞用"这是一处需修复的阻断；同时请确认 A/B/C"，不做充分性承诺。DIRECTLY_OBSERVED 证明"这处确实阻断"，不等于"唯一阻断"（E 错）。

### 13-4（多选）
关于 DNS 响应码/无响应的排查方向，正确的对应有？（多选）

- A. timeout（无响应）→ 网络层：SG/NACL/路由阻断、目标 DNS 宕、UDP 分片丢失
- B. NXDOMAIN → 权威明确回答"此名不存在"，是数据问题（记录缺失/拼写/未创建），不是网络问题
- C. SERVFAIL → 递归/权威处理失败：DNSSEC 验证失败、转发目标不响应、上游超时
- D. REFUSED → 服务器拒绝应答：权限/ACL、非授权区、递归被关
- E. NXDOMAIN → 一定是网络阻断导致

【答案】A、B、C、D
【解析】timeout=网络层（A）、NXDOMAIN=数据问题（B，E 错）、SERVFAIL=处理失败（C）、REFUSED=拒绝应答（D）。把 timeout 当"记录没配"、把 NXDOMAIN 当网络问题都是走错方向。

### 13-5（单选）
客户三个域名"昨天正常、今早全挂"。SME 的首要归因方向与标准取证序列是？

- A. 逐条记录单独排查，先看第一个域名的某条 A 记录
- B. 多资源同时失效 → 找公共因子（同账户/同 Hosted Zone/注册商 NS 被改）；标准序列：whois → dig <domain> NS → 控制台查 Hosted Zone/NS → CloudTrail 查 24-48h 变更事件
- C. 直接判定为 DDoS 攻击
- D. 建议客户重新注册这三个域名
- E. 先启用 DNSSEC 再观察

【答案】B
【解析】三域名同时失效指向"三者共有的一环"，而非单条记录。标准"注册/委派链"取证序列：whois→dig NS→控制台→CloudTrail（ChangeResourceRecordSets/DeleteHostedZone/UpdateDomainNameservers）。逐一给验证命令、不预先断言单一根因。

### 13-6（单选）
客户改完记录后说"还是不通"。SME 应先做什么？

- A. 立即判定记录改错了并回滚
- B. 先问"等了多久？用了哪个递归器？"，再直查权威（dig @权威NS）确认改动已生效——递归失败但权威成功 = 负缓存/TTL 滞后，不是配置错
- C. 直接重建整个 hosted zone
- D. 判定为限流并提额
- E. 关闭 DNSSEC

【答案】B
【解析】负缓存（SOA minimum/negative TTL）会缓存 NXDOMAIN，TTL 也会缓存旧值。递归失败但直查权威成功 = 缓存滞后而非配置错。用 SOA minimum 估算等待时间。

### 13-7（问答）
简述 SME 排查中的"证据分级（四级）"及其在回复措辞上的纪律。

【答案】
四级证据强度：
- **DIRECTLY_OBSERVED**：从客户真实导出/日志/工具输出直接读到 → 措辞"已确认/observed"。
- **DOCUMENTED_FACT**：官方文档明确规定的行为（如 VPC DNS = CIDR base+2）→ 措辞"根据文档"。
- **INFERENCE**：由观测+文档推出、存在反例可能 → 措辞"suggests/很可能"，不用"is/确认"。
- **UNKNOWN**：未验证、需客户提供 → 列入索取清单，绝不当事实写进结论或承诺。

纪律：回复中每个断言都要能对应到一个级别；证据不足时不为了给"确定答案"而把 INFERENCE 说成根因（不做唱因归因）。宁可回复"这是一处确认的阻断，另有 A/B 需确认"，也不唱一个未经证实的单一根因。
【解析】呼应 §1.2 证据分级与 §1.8 不做唱因归因，是横切所有 R53 case 的核心方法论。

---

> 题库结束。合计 46 题（08:8 · 09:8 · 10:7 · 11:8 · 12:8 · 13:7）。

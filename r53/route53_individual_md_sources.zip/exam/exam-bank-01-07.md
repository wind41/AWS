# Route 53 SME 模拟题库 — Topics 01–07（上半）

> 覆盖：01 Hosted Zones / 02 记录与 Alias / 03 路由策略 / 04 健康检查 / 05 Resolver 与混合 DNS / 06 DNS Firewall / 07 DNSSEC。
> 题型：场景单选 / 多选（真实 SME 风格，给客户场景问最佳方案）为主，少量问答题。每题含【答案】【解析】。
> 总题数：52 题（Ch01 8 · Ch02 7 · Ch03 8 · Ch04 8 · Ch05 8 · Ch06 7 · Ch07 6）。

---

## 第 1 章 · Hosted Zones（8 题）

### 1-1（单选）
客户在同一账号下同时持有 public zone `habitat-energy.au`（父）与 `prod.habitat-energy.au`（子），父 zone 里有一条指向子 zone 的 NS 委派记录。客户想把子域记录合并进父 zone、随后删除子 zone，要求切换零停机。最安全的操作顺序是？

- A. 先删父 zone 里的 NS 委派记录，再在父 zone 建全子域记录
- B. 先在父 zone 建全所有子域记录并验证，再删父 zone 里的 NS 委派记录，最后删子 zone
- C. 直接删除子 zone，Route 53 会自动把记录并入父 zone
- D. 同时删 NS 委派记录和子 zone，再补建父 zone 记录
- E. 把子 zone 的 NS 记录复制到父 zone 即可

【答案】B

【解析】只要父 zone 里的 NS 委派记录还在，Route 53 就始终把 `*.prod.habitat-energy.au` 的查询引向子 zone，父 zone 内同名记录在删委派前不会被查询——这正好允许"先建全记录再切换"的无缝迁移。A/D 顺序颠倒会在记录未建全前造成解析失败；C 错在合并不是自动的；E 把委派 NS 复制到父 zone 并不改变委派优先行为。（Topic 01 §1.6 / case 178118102100384）

### 1-2（多选，选两项）
关于 Private Hosted Zone（PHZ）的启用与解析边界，正确的有哪些？

- A. 使用 PHZ 要求关联 VPC 的 `enableDnsHostnames` 与 `enableDnsSupport` 都为 true
- B. PHZ 记录可被公共递归 DNS（如 8.8.8.8）解析
- C. VPC 若用 DHCP Option Set 指向自定义 DNS，PHZ 记录会返回 NXDOMAIN
- D. PHZ 支持 DNSSEC signing
- E. PHZ 支持 IP-based 路由策略

【答案】A、C

【解析】PHZ 只能经 VPC Resolver（VPC+2/.2）解析，公共 DNS 解析不到（B 错，正是 case 178239640400861 的 resolv.conf fallback 根因）；DHCP Option Set 指向自定义 DNS 会绕过 VPC Resolver 导致 NXDOMAIN（C 对）。PHZ 不支持 DNSSEC（仅 public zone，D 错），也不支持 IP-based（E 错）。启用前提是两个 DNS 属性都为 true（A 对）。（Topic 01 §1.2 / §1.4）

### 1-3（单选）
客户裸域 `example.com`（zone apex）要指向一个 ALB。应如何配置？

- A. 建一条 apex 的 CNAME 指向 ALB DNS 名
- B. 建一条 apex 的 A (Alias) 指向 ALB
- C. 建一条 apex 的 NS 记录指向 ALB
- D. 建一条 apex 的 TXT 记录写入 ALB 名
- E. apex 无法指向 ALB，必须换用 www 子域

【答案】B

【解析】zone apex 已强制带 NS+SOA 记录，而 DNS RFC 规定 CNAME 不能与同名其他类型共存，所以 apex 不能建 CNAME（A/排除）。指向 ALB 这类 AWS 资源用 A-Alias 即可（B 对），Alias 免费、少一跳、可开 Evaluate Target Health。（Topic 01 §1.3 / Topic 02）

### 1-4（单选）
一个 VPC 内查询 `seattle.accounting.example.com`，该 VPC 同时关联了 `accounting.example.com` 和 `example.com` 两个 PHZ。Route 53 会用哪个 PHZ 应答？

- A. `example.com`（更早创建的）
- B. `accounting.example.com`（最具体匹配）
- C. 随机选一个
- D. 两个都查，合并结果
- E. 返回 NXDOMAIN，因为命名空间重叠冲突

【答案】B

【解析】重叠命名空间取最长/最具体匹配（most-specific-match）：`accounting.example.com` 是请求域名更具体的父级，胜过 `example.com`。不是按创建时间或随机（A/C 错）。（Topic 01 §1.5）

### 1-5（单选）
客户跨账号把一个 PHZ 关联到另一账号的 VPC，希望免去逐个授权的繁琐。以下哪种做法可省去 `VpcAssociationAuthorization` 步骤？

- A. 用 VPC Peering 替代
- B. 使用 Route 53 Profiles
- C. 打开 `enableDnsHostnames`
- D. 把 PHZ 改成 public zone
- E. 用 RAM 共享该 PHZ

【答案】B

【解析】跨账号关联 PHZ 到别账号 VPC 通常需先做 `VpcAssociationAuthorization`；改用 Route 53 Profiles 可免此步，且适合 >300 VPC-PHZ 关联的大规模治理。（Topic 01 §1.2 / E27）

### 1-6（单选）
客户删除一个已启用 DNSSEC signing 的 hosted zone 时报 `HostedZoneNotEmpty`。最可能的原因与正确处理是？

- A. zone 内还有普通记录，删掉即可
- B. 需先 deactivate/delete 该 zone 的 KSK
- C. 该 zone 被 RAM 共享，需先取消共享
- D. NS/SOA 记录不能删，导致 zone 非空
- E. 需先关闭 VPC 关联

【答案】B

【解析】带 KSK 的 zone 删除会报 `HostedZoneNotEmpty`，需先停用/删除 KSK 再删 zone。NS/SOA 是每个 zone 自带的、不计入"非空"判断（D 错）。（Topic 01 §4 QA-325）

### 1-7（多选，选两项）
关于 hosted zone 的计费与迁移行为，正确的有哪些？

- A. 每个 hosted zone 前 25 个按 $0.50/月 计费
- B. 同一 zone 在 12 小时内删除会重复收费
- C. 迁移记录到新 zone 时，apex 的 NS 与 SOA 需要一并复制过去
- D. 新建 zone 的 apex NS+SOA 由 Route 53 自动生成
- E. 每个 PHZ 默认可关联无限个 VPC

【答案】A、D

【解析】hosted zone $0.50/月（前 25 个，A 对）；同 zone 12 小时内删除不重复收费（B 错）；迁移不复制 NS 与 SOA，新 zone apex 的 NS+SOA 由 Route 53 自动生成（C 错、D 对）；单 PHZ 默认关联上限 300 VPC（E 错）。（Topic 01 §1.6 / §4）

### 1-8（问答）
客户用 Kubernetes ExternalDNS 管理 `prod.example.com` 子 zone，现在想把子域合并进父 zone `example.com` 并删除旧子 zone。除了 DNS 记录迁移本身，还有哪两个真实的坑必须处理？

【答案】(1) ACM 证书验证用的 CNAME 记录必须精确复制到父 zone，否则证书续期失败；(2) 删旧 zone 前必须把 ExternalDNS 的 `--zone-id-filter`/`--domain-filter` 改指新 zone ID，否则它会继续往已删除的旧 zone 写记录。

【解析】这两点是 case 178118102100384 reply3 明确的合并真实坑：ExternalDNS 的 TXT 记录含 `heritage=external-dns`，若不改 filter，它会对着已删除的旧 zone 反复写入，造成记录漂移/失败。（Topic 01 §2 核心案例补充）

---

## 第 2 章 · 记录类型与 Alias（7 题）

### 2-1（单选）
客户要把子域 `www.example.com` 指向一个**第三方（非 AWS 托管）**的域名 `cdn.partner.net`。应使用哪种记录？

- A. A-Alias
- B. AAAA-Alias
- C. CNAME
- D. A 记录直接填 partner 域名
- E. Alias 指向同 zone 记录

【答案】C

【解析】Alias 的目标只能是选定 AWS 资源或同 zone 同类型记录，指不了外部/非 R53 托管域名；要指向任意外部 DNS 名只能用 CNAME。（Topic 02 §1.3 A4）

### 2-2（多选，选三项）
关于 Alias 相对 CNAME 的特性，正确的有哪些？

- A. Alias 可以建在 zone apex，CNAME 不行
- B. Alias 指向 AWS 资源的查询免费
- C. Alias 指向 AWS 资源时可以单独设置 TTL
- D. Alias 支持 Evaluate Target Health，CNAME 不支持
- E. Alias 的目标可以再是另一条 Alias 或 CNAME

【答案】A、B、D

【解析】Alias 能建在 apex（A 对）、指向 AWS 资源查询免费（B 对）、有 ETH（D 对）。Alias 指向 AWS 资源不能设 TTL，用资源默认 TTL（C 错）；Alias 的 target 不能再是 Alias/CNAME（E 错）。（Topic 02 §1.3 / A1–A5）

### 2-3（单选）
客户做 failover，主备记录都指向 ELB（可建 Alias 的资源）。以下哪种做法最规范？

- A. 给每条 alias 记录另外建一个独立 endpoint 健康检查
- B. alias 记录设 Evaluate Target Health = Yes，不再单独建健康检查
- C. 把 alias 改成 CNAME 再挂健康检查
- D. 用 simple 路由 + 健康检查
- E. 关闭健康检查，靠 TTL 过期切换

【答案】B

【解析】指向可建 alias 的 AWS 资源做 failover 时，用 ETH=Yes 让 Alias 自动感知目标健康，不要再单独建 HC（否则多余且可能冲突）。CNAME 无 ETH（C 错），simple 不能关联 HC（D 错）。（Topic 02 §1.3 A5 / Topic 04 C14）

### 2-4（单选）
客户用 simple 路由在一条记录里配了 12 个 A 值，观察到每次 dig 只返回一部分且顺序变化。关于这一行为，正确的解释是？

- A. 配置错误，simple 只能配 1 个值
- B. Simple 的一条 RRset 会返回**全部**值并随机排序；每次 dig 只看到一部分是 UDP 应答体积/客户端截断所致，不是 Route 53 的"8 值上限"
- C. 健康检查剔除了不健康的值
- D. TTL 过期导致部分值丢失
- E. Route 53 在做真正的负载均衡

【答案】B

【解析】Simple 路由的一条 RRset 内可含多个值（单 RRset 配额 400 条），权威 NS **返回该 RRset 的全部值并随机排序**——这是粗粒度分散，不是负载均衡（E 错），也不涉及健康检查（simple 不能关联 HC）。**"每次最多返回 8 个值"是 Multivalue Answer 路由的特性，不是 Simple**；simple 下看到"只回一部分"通常是 UDP 应答大小限制/解析器或客户端截断的表现，而非 Route 53 主动截到 8 条。（Topic 02 §1.2 / Topic 03 §1.1）

### 2-5（单选）
关于 TTL，以下哪项正确？

- A. Route 53 记录有 300 秒的默认 TTL
- B. Alias 指向 AWS 资源时可自设 TTL
- C. 记录 TTL 无默认值，需自行设定；SOA 缩短 TTL 无副作用
- D. TTL 只能设整分钟
- E. CNAME 不能设 TTL

【答案】C

【解析】Route 53 不为记录设默认 TTL，需自设（建议 60–172800 秒）；SOA 也可缩短 TTL 无副作用。Alias 指向 AWS 资源不能设 TTL（B 错），CNAME 可设 TTL（E 错）。（Topic 02 §1.2 / §4）

### 2-6（单选）
客户把 apex 子域配成 A (Alias) 指向 Kong NLB，配置本身 100% 正确，但 VPC 内 dig 却返回旧的 Apigee ELB IP。最可能的根因层次是？

- A. Alias 记录类型选错了
- B. apex 不该用 Alias
- C. VPC 内解析被 Resolver Forward Rule 拦截，查询没到达公网 zone
- D. NLB 未开启健康检查
- E. ELB canonical hosted zone id 填错

【答案】C

【解析】记录/Alias 配置层完全正确，"解析结果不对"的真实根因在解析优先级层：VPC 内的 Forward Rule 优先于 PHZ 优先于公网，查询被转发到企业 DNS（返回旧记录），根本没到达公网 zone。这正是 case 178602594200640——A-Alias→NLB 是本 topic 正面范例，失效根因归 Resolver（Topic 05）。（Topic 02 §2）

### 2-7（问答）
简述"Alias 指向 AWS 资源"相对"CNAME"在**性能**与**计费**上的两点优势。

【答案】(1) 性能：Alias 由 Route 53 在权威侧直接返回目标 IP，少一次 DNS 往返；CNAME 需 resolver 额外一次 lookup 去解析别名目标。(2) 计费：Alias 指向 AWS 资源的查询免费；CNAME 按查询正常计费。

【解析】能用 Alias 指 AWS 资源就别用 CNAME——成本 + 性能双优。（Topic 02 §1.3 A3 / §4）

---

## 第 3 章 · 路由策略（8 题）

### 3-1（单选）
客户在多个 AWS Region 部署了相同应用，希望终端用户被路由到"网络延迟最低"的 Region。应选哪种路由策略？

- A. Weighted
- B. Latency
- C. Geolocation
- D. Geoproximity
- E. Simple

【答案】B

【解析】Latency 路由按 AWS 长期实测的网络延迟把用户导向延迟最低 Region 的资源，目标须在 AWS Region。Weighted 是按你设的比例分（灰度/负载），不是延迟（A 错）；geolocation/geoproximity 按地理位置而非网络延迟。注意 latency 数据非实时、会漂移。（Topic 03 §1.1 / B6）

### 3-2（单选）
客户用 geolocation 路由，为 CN、US 各配了记录，但没有配 default。一个来自无法映射到任何地理位置的 IP 的查询会得到什么？

- A. 随机返回 CN 或 US 记录
- B. 返回离得最近的记录
- C. "no answer"
- D. NXDOMAIN
- E. 返回全部记录

【答案】C

【解析】geolocation 对未映射/未覆盖的来源，若没有 default 记录（`CountryCode:"*"`）就返回 "no answer"，不会兜底挑一个。必须显式建 default。（Topic 03 §1.1 / B8 / case 178246722300140）

### 3-3（多选，选两项）
关于 geolocation 与 geoproximity 的区别，正确的有哪些？

- A. geolocation 只看用户位置；geoproximity 看资源+用户位置
- B. geoproximity 可用 bias（±1..±99）扩张/收缩某资源的吸引范围
- C. geolocation 也能用 bias 调整吸引范围
- D. geoproximity 不需要 Traffic Flow
- E. geolocation 需要 Traffic Flow

【答案】A、B

【解析】geolocation 仅按用户位置（大洲/国家/州）、重叠取最小区、可设 default；geoproximity 看资源+用户位置、用 bias 移动边界、通常需 Traffic Flow、同名同类型上限仅 30。bias 是 geoproximity 独有（C 错）。（Topic 03 §1.1 / B7）

### 3-4（单选）
一条 failover 记录，Primary 和 Secondary 的健康检查同时都是 unhealthy。Route 53 会返回什么？

- A. 返回 Secondary
- B. 返回 Primary（fail open）
- C. 返回 "no answer"
- D. NXDOMAIN
- E. 随机返回一个

【答案】B

【解析】failover 的 fail-open 行为：Primary+Secondary 都不健康时返回 Primary，此行为不可配置。（Topic 03 §1.1 / Topic 04 §1 / QA-337）

### 3-5（单选）
客户在一组 weighted 记录里把某条记录的 weight 设为 0，其余记录权重非 0。什么情况下这条 0 权重记录会被返回？

- A. 永远不会被返回
- B. 每次都会被返回一小部分
- C. 仅当组内所有非 0 权重记录都不健康时
- D. 当它自身的健康检查通过时
- E. 当组内权重之和为 0 时

【答案】C

【解析】单条设 weight 0 = 停止该记录流量；但仅当组内所有非 0 权重记录都不健康时才会启用 0 权重记录（组内全 0 时才对 0 权重记录平均分）。所以"永远不返回"是错的（A）。（Topic 03 §1.1 / B12）

### 3-6（单选）
客户在一个 Private Hosted Zone 里想按客户端源 IP 段做 IP-based 路由。会发生什么？

- A. 正常生效
- B. PHZ 不支持 IP-based 路由策略
- C. 需要先开 Traffic Flow
- D. 需要 outbound endpoint
- E. 仅 IPv6 支持

【答案】B

【解析】PHZ 只支持 simple/failover/multivalue/weighted/latency/geolocation/geoproximity；IP-based 只能在 public zone。（Topic 03 §1.1 / B11 / Topic 01 §1.4）

### 3-7（多选，选两项）
关于 EDNS0 / edns-client-subnet (ECS) 对地理/延迟类路由准确性的影响，正确的有哪些？

- A. resolver 支持 ECS 时，Route 53 能用用户 IP 的截断前缀更准确定位
- B. VPC 的 .2 resolver 支持 EDNS0 但不支持 ECS
- C. PHZ 使用 EDNS0 来做路由决策
- D. 不支持 ECS 时，用 resolver 自身源 IP 近似定位，可能偏差
- E. ECS 会加密 DNS 查询内容

【答案】A、D（B 也正确，但本题按"两项最直接描述定位机制"取 A、D；若允许三项则 A、B、D）

【解析】ECS 让权威 NS 拿到用户 IP 截断前缀，定位更准（A）；不支持时退回 resolver 源 IP 近似（D）。VPC .2 resolver 支持 EDNS0 但不支持 ECS（B 也是正确知识点）；PHZ 不使用 EDNS0，改用所在 Region 的 VPC Resolver 数据（C 错）；ECS 与加密无关（E 错）。（Topic 03 §1.2）

> 说明：本题若判分按三选，正确项为 A、B、D。

### 3-8（问答）
客户咨询 Route 53 geolocation 用的是什么 IP 地理库、多久更新一次。作为 SME，你应如何答复？

【答案】答复要点：使用业界领先的第三方商业 IP 地理定位数据库，因商业协议限制不便披露具体供应商名；该类库会定期更新，AWS 在其发布后自动摄取并持续跟进，但 AWS 对具体传播/更新周期不作公开承诺。同时提醒客户务必配置 Default 记录兜底无法映射的来源（否则返回 "no answer"），国家级映射准确率约 99.8%（粒度越细准确率越低）。

【解析】内部指引是 MaxMind（约每周更新），但"不对客户披露供应商名"、"不给具体周期"。case 178246722300140 的三大 SME 落点：GeoIP 库不披露、必配 default 否则 no answer、EDNS0/ECS 决定精度。（Topic 03 §2 / B8）

---

## 第 4 章 · 健康检查（8 题）

### 4-1（单选）
客户要监控一个**内部 ALB**（私有、不可路由 IP）的健康。哪种健康检查类型最合适？

- A. Endpoint HTTP 检查，直接填内部 ALB 私有 IP
- B. Endpoint TCP 检查内部 IP
- C. CloudWatch alarm-based（或 Calculated）健康检查
- D. Simple 路由自带的健康检查
- E. 无法监控内部资源

【答案】C

【解析】不能对 private/不可路由/multicast IP 建 endpoint 健康检查（A/B 排除）；内部 ALB 应改用 CloudWatch alarm-based 或 calculated HC（EC2 场景可配 EIP 固定公网 IP）。simple 路由不能关联 HC（D 错）。（Topic 04 §1 / C19）

### 4-2（单选）
客户的 HTTPS endpoint 健康检查突然变红，同时发现站点证书刚过期。证书过期是否是健康检查失败的原因？

- A. 是，HTTPS 健康检查会校验证书
- B. 否，HTTPS 健康检查不校验证书，证书过期不会导致失败
- C. 是，但只在开启 string matching 时
- D. 否，但会触发 INSUFFICIENT_DATA
- E. 是，需要更新根 CA

【答案】B

【解析】HTTPS 健康检查不校验证书，证书过期/无效不会导致检查失败——这是经典陷阱题。健康检查变红的原因要另找（连接超时、状态码非 2xx/3xx、string 未匹配等）。（Topic 04 §1 / C17）

### 4-3（单选）
关于 Route 53 健康检查的聚合判定（多地 checker），正确的是？

- A. 需超过 50% 的 checker 报健康才判健康
- B. 需超过 18% 的 checker 报健康才判健康
- C. 全部 checker 都健康才判健康
- D. 任一 checker 健康即判健康
- E. 由客户配置阈值百分比

【答案】B

【解析】聚合规则：> 18% 的 checker 报健康即判健康，≤ 18% 判不健康。18% 门槛用于防止某处网络隔离造成的误判，不是多数决（A 错）。（Topic 04 §1 / C15）

### 4-4（多选，选两项）
关于健康检查的响应时间阈值，正确的有哪些？

- A. HTTP/HTTPS：4s 内建 TCP 连接 + 连接后 2s 内回 2xx/3xx
- B. TCP：10s 内建连
- C. string matching 的匹配串必须落在 body 的前 5,120 字节内
- D. HTTP 需 10s 内回 2xx
- E. TCP 需 2s 内建连

【答案】A、B（C 也是正确知识点）

【解析】HTTP/HTTPS 是 4s 建连 + 2s 回 2xx/3xx（A 对）；TCP 是 10s 建连（B 对）；string match 匹配串须在 body 前 5120 字节内（C 也对）。D/E 把阈值记混。（Topic 04 §1 / C16）

> 说明：若判分允许三项，正确项为 A、B、C。

### 4-5（单选）
一个 CloudWatch alarm-based 健康检查，其 alarm 进入 `INSUFFICIENT_DATA` 状态。健康检查会如何判定？

- A. 一律判健康
- B. 按 HC 的 `InsufficientDataHealthState` 配置（默认 Unhealthy）
- C. 一律判不健康，不可改
- D. 保持上次状态，不可改
- E. 触发 fail open

【答案】B

【解析】CloudWatch HC 监控 alarm 的数据流；INSUFFICIENT_DATA 走 `InsufficientDataHealthState`，三态为 Unhealthy（默认）/ Healthy / LastKnownStatus。case P460958645 的缓解就是改成 LastKnownStatus。（Topic 04 §1 / §2 / C18）

### 4-6（单选）
一个 CloudWatch alarm-based HC 关联的 alarm 已恢复 OK，但 HC 长时间（数十分钟）仍停留 Unhealthy。作为紧急恢复手段，哪种操作能触发 HC 重新评估？

- A. 删除并重建 hosted zone
- B. 对该 HC 执行 `UpdateHealthCheck`（如改一个无害字段）
- C. 重启关联的 EC2 实例
- D. 删除 CloudWatch alarm
- E. 只能等待，无法干预

【答案】B

【解析】`UpdateHealthCheck` 会触发 HC 重新评估，可作紧急恢复手段（case P460958645 中客户正是手动 UpdateHealthCheck 后恢复）。正常 R53 对 alarm 状态变化应在 1–2 分钟内响应，数十分钟属异常。（Topic 04 §1 / §2）

### 4-7（单选）
受害账户在 ALB access log 里发现持续的探测，User-Agent 为 `Amazon-Route53-Health-Check-Service (ref 28e27f8c-...)`，但自己并未创建该健康检查。这属于什么问题、如何处理？

- A. 正常流量，无需处理
- B. Unwanted HC abuse——由 Support Ops 走标准流程（确认 HC → 联系 offending 账户 → 等 7 天 → Mechanic 禁用，需 2PR）
- C. DDoS 攻击，走 Shield 流程
- D. 直接在自己账户里删除该 HC
- E. 修改 SG 屏蔽即可，无需上报

【答案】B

【解析】任意账户都能建指向不属于自己 IP 的 endpoint HC 造成滋扰。User-Agent 与 `ref=<HC ID>` 是识别关键。处理是 Support Ops 专属：确认 HC → 联系 offending → 等 7 天无回复 → 用 Mechanic `controlapi disable-health-check` 禁用（需 2PR），禁用非删除（`Disabled=true`）。受害方无法删别人账户里的 HC（D 错）。（Topic 04 §1 / §2 / case V2254930641）

### 4-8（问答）
简述 failover 的两种"fail-open"表现。

【答案】(1) 单条 failover 记录视角：Primary + Secondary 的健康检查都 unhealthy 时，Route 53 返回 Primary（fail open 到 primary），不可配置。(2) 整个 Hosted Zone 视角：该 zone 所有健康检查都 unhealthy 时，Route 53 fail open（当作全部通过来应答）。

【解析】fail-open 的设计意图是"宁可返回一个可能不健康的答案，也不返回空"，避免因健康检查系统性故障导致整站不可解析。（Topic 04 §1）

---

## 第 5 章 · Resolver 与混合 DNS（8 题）

### 5-1（单选）
VPC 的主 CIDR 是 `10.201.244.0/22`。VPC Resolver（.2 resolver）的地址是？

- A. 10.201.244.1
- B. 10.201.244.2
- C. 10.201.247.253
- D. 169.254.169.253
- E. 10.201.244.253

【答案】B

【解析】VPC Resolver 接入地址 = VPC 主 CIDR 基地址 +2，即 10.201.244.2（经典 .2 / VPC+2）。注意 169.254.169.253 是 link-local 别名，但按题目"VPC+2"算法答案是 10.201.244.2。（Topic 05 §1.1）

### 5-2（单选）
EC2 无法用 `nslookup ... 10.x.x.2`（VPC DNS）解析。工程师第一反应去检查 EC2 到 VPC DNS 之间的 Security Group / NACL / 路由表。这个排查方向对吗？

- A. 对，SG/NACL 常常拦住到 .2 的流量
- B. 不对，EC2 到 VPC DNS(.2) 的流量不经过 SG/NACL/路由表
- C. 对，但只需检查 NACL
- D. 不对，应改用公共 DNS
- E. 对，需要放行 UDP 53

【答案】B

【解析】EC2 → VPC DNS(.2) 的流量不经过 SG/NACL/路由表，这是排障最大的方向性坑（case 178767531400698 中 Genie 初稿即犯此错）。真正的阻断点在 Outbound Endpoint 的 ENI 子网 NACL。（Topic 05 §1.1 / D20）

### 5-3（单选）
某域名在 VPC 内既有一个 PHZ 记录、又有一条 Resolver Forward Rule 指向企业 DNS。VPC 内查询该域名时会怎样？

- A. 用 PHZ 记录应答
- B. 查询被 Forward Rule 转发到企业 DNS（Forward Rule 优先于 PHZ）
- C. 报冲突错误
- D. 随机选一个
- E. 先查 PHZ，未命中再转发

【答案】B

【解析】VPC 内解析优先级链：Forward Rule > PHZ > System Rule > 公网递归。同域名冲突时 Forward Rule 胜，查询被转发出去而不用 PHZ 记录。（Topic 05 §1.4 / D22 / case 178602594200640）

### 5-4（单选）
关于 Inbound / Outbound Resolver Endpoint 的方向，正确的是？

- A. Inbound = AWS→on-prem 查询；Outbound = on-prem→AWS 查询
- B. Inbound = on-prem→AWS 查询；Outbound = AWS→on-prem 查询
- C. 两者方向相同，只是冗余
- D. Inbound 用于公网，Outbound 用于私网
- E. Outbound endpoint 使用公网 IP

【答案】B

【解析】Inbound 让本地/其他网络进来查 AWS 内部名/PHZ；Outbound 让 VPC 的查询出去转发到本地 DNS。记忆：In=别人进来查我，Out=我出去查别人。Outbound endpoint 是私有 IP，出公网需 NAT Gateway（E 错）。（Topic 05 §1.2 / D21）

### 5-5（单选）
客户想把 VPC 内**所有**域名查询都转发到企业 DNS，让 VPC 内查询永远不到达公网 Route 53。应如何配置 Resolver Rule？

- A. 为每个域名各建一条 FORWARD 规则
- B. 建一条域名为 `.`（dot）的 FORWARD 规则，关联 outbound endpoint
- C. 删除所有 System Rule
- D. 建一条 SYSTEM 规则指向企业 DNS
- E. 关闭 VPC 的 enableDnsSupport

【答案】B

【解析】域名为 `.` 的 FORWARD 规则覆盖除 PHZ/AWS 内部名以外的所有域名，把 VPC 内查询全部转出（case 178602594200640 里的 `RULE-INFOBLX`）。Rule 必须关联 outbound endpoint 才生效。（Topic 05 §1.3 / §1.4）

### 5-6（多选，选两项）
关于 Resolver 的 QPS / 吞吐边界，正确的有哪些？

- A. 每个 Outbound Endpoint 最多 6 个 ENI，聚合可达约 60,000 请求/秒
- B. 每个 ENI 约 10K QPS，但经 NLB 或 SG 因 connection tracking 会降到约 1.5–1.7K QPS
- C. 每 ENI 固定 1024 QPS 不可调
- D. Resolver 是全球服务，非 Regional
- E. Rule 不关联 outbound endpoint 也能生效

【答案】A、B

【解析】每 Outbound Endpoint ≤6 ENI、聚合 ~60K req/s（A）；每 ENI ~10K QPS，经 NLB/SG 因强制 connection tracking 降到 ~1.5–1.7K（约 6 倍，B）。1024 是实例侧 VPC+2 link-local 的 PPS 限制（不是 endpoint QPS，C 混淆）；Resolver 是 Regional（D 错）；Rule 必须关联 outbound endpoint（E 错）。（Topic 05 §1.5）

### 5-7（单选）
Outbound Endpoint 有两个 ENI，分属不同子网/NACL。工程师排查发现其中一个 ENI 子网的 NACL 阻断了 DNS。为让转发可靠，NACL 上应双向放行哪些？

- A. 只放行入站 TCP 53
- B. 出站 UDP/TCP 53 + 入站 UDP/TCP ephemeral(1024-65535)，且每个 ENI 子网都要一致
- C. 只放行出站 UDP 53
- D. 放行所有 ICMP
- E. 只在一个 ENI 子网放行即可

【答案】B

【解析】Outbound Endpoint 每个 ENI 子网都要在 NACL 双向放行 DNS：出站 UDP/TCP 53 + 入站 UDP/TCP ephemeral。多 ENI 跨不同子网/NACL 时配置必须一致，否则部分查询超时、表现为间歇故障；且单条 ENI 通不代表全通。（Topic 05 §1.4 / §2 case 二 / D 速记）

### 5-8（问答）
客户跨账号用 AWS RAM 共享一条 Resolver Forward Rule。关于共享范围、outbound endpoint 与成员账号权限，有哪三点关键结论？

【答案】(1) 共享限**同一 Region**，无需额外 VPC peering；(2) 父账号的 outbound endpoint 会随 rule 一起共享，成员账号不需另建 endpoint；(3) 成员账号只能使用共享 rule，不能修改或删除它。

【解析】这是考点 D24。常见错误是以为跨账号共享 rule 还要单独建 outbound endpoint。（Topic 05 §1.3 / D24）

---

## 第 6 章 · DNS Firewall / Global Resolver（7 题）

### 6-1（单选）
DNS Firewall 的核心用途和过滤维度是？

- A. 加密所有 DNS 流量
- B. 对出站 DNS 查询做域名层过滤，主要防 DNS 数据渗漏（exfiltration）
- C. 按 IP/端口做网络层过滤
- D. 校验 DNSSEC 签名
- E. 对入站 DNS 查询做应用层过滤

【答案】B

【解析】DNS Firewall 对经 VPC Resolver 的出站 DNS 查询做域名字符串层过滤，在解析成 IP 之前拦截命中恶意/黑名单域名的查询，主要防 exfiltration。它不加密、不看 IP/端口/应用层协议。（Topic 06 §1 / E25）

### 6-2（单选）
一个 VPC 关联了多个 rule group，rule group 内又有多条 rule。它们的处理顺序是？

- A. priority 数字越大越先处理
- B. priority 数字越小越先处理（rule group 与 rule 都是）
- C. 按创建时间倒序
- D. 随机
- E. 只处理 priority 最大的一条

【答案】B

【解析】rule group 之间按关联 priority 数字从小到大处理，rule group 内部每条 rule 也按组内 priority 从小到大处理（lowest numeric priority first）。（Topic 06 §1 / E25）

### 6-3（多选，选两项）
关于 DNS Firewall 规则的动作（Action），正确的有哪些？

- A. 含 domain list 的规则可选 ALLOW / BLOCK / ALERT
- B. 不含 domain list 的规则（Advanced 保护）只能 BLOCK / ALERT
- C. 任何规则都能设 ALLOW
- D. BLOCK 只能返回 NXDOMAIN
- E. Advanced 保护可以设 ALLOW

【答案】A、B

【解析】含 domain list 才能 ALLOW（A）；Advanced（DGA/tunneling 等）只能 BLOCK/ALERT，不能 ALLOW（B 对、C/E 错）。BLOCK 响应有三种：NXDOMAIN / NODATA / OVERRIDE(CNAME 重定向)（D 错）。（Topic 06 §1 / E25）

### 6-4（单选）
客户用 allowlist（只放行白名单）方式，把入口域名 `svc.example.com` 加入了 ALLOW 列表，但它的 CNAME target 指向未列入白名单的 `backend.other.net`，结果查询被 BLOCK。根因是？

- A. ALLOW 规则失效
- B. 重定向链上的后续域名未显式加入 domain list（默认检查整条 CNAME 链，trust 仅在单次查询事务内有效）
- C. domain list 不支持 CNAME
- D. 白名单必须用通配符
- E. AWS 托管列表拦截了它

【答案】B

【解析】默认会检查整条重定向链，被 ALLOW 域名的 CNAME target 若未列入 domain list，其 A+AAAA 相当于未被 ALLOW 命中而被 BLOCK。allowlist 要把整条 CNAME 链域名都覆盖，或正确配置 Trust Redirection Domains。（Topic 06 §1 / §2 内部 QA-497）

### 6-5（单选）
客户配了一条 ALERT 规则和一条 DGA Advanced 规则，想确认某次查询是否命中了 DGA 检测。仅凭 dig 返回 NXDOMAIN 可以判定吗？应看哪里？

- A. 可以，NXDOMAIN 就代表 DGA 命中
- B. 不能，必须查 OCSF 日志的 `firewall_rule_id`；ALERT 命中流量的 `action_name` 仍是 `Allowed`
- C. 可以，看 dig 的 flags 即可
- D. 不能，只能看 CloudTrail
- E. 可以，看响应的 TTL

【答案】B

【解析】ALERT 命中的流量被放行，OCSF 日志里 `action_name` 仍是 `Allowed`；DGA 是否命中不能凭 dig 的 NXDOMAIN 判断，必须查日志的 `firewall_rule_id`（OCSF 动作值是 Allowed/Denied，不是 ALLOW/BLOCK）。这是"用户可见形态 ≠ 中间判据"的典型。（Topic 06 §2 / §4）

### 6-6（多选，选两项）
关于 Global Resolver 与 VPC Resolver 上 DNS Firewall 的区别，正确的有哪些？

- A. Global Resolver 的 Firewall 规则绑定到 DNS View，而非 VPC
- B. Global Resolver 控制面 API 固定在 us-east-2（Ohio）
- C. Global Resolver 只能保护 VPC 内部工作负载
- D. VPC Resolver 的 Firewall 规则绑定 DNS View
- E. Global Resolver 需要 VPN 才能被客户端访问

【答案】A、B

【解析】Global Resolver 的 Firewall 规则绑 DNS View（A），控制面固定 us-east-2（B）；Global Resolver 保护 VPC 外部客户端、VPC Resolver 保护内部（C 错），VPC Resolver 的 Firewall 绑 VPC（D 错）；Global Resolver 提供全球 Anycast IP，无需 VPN（E 错）。（Topic 06 §1）

### 6-7（问答）
简述 DNS Firewall 与 Network Firewall 在"看得到什么流量"上的区别，以及二者关系。

【答案】DNS Firewall 只看经 VPC Resolver 的出站 DNS 查询（域名层）；Network Firewall 过滤网络/应用层流量，但看不到 Resolver 发起的 DNS 查询。二者是互补关系，不是替代——Network Firewall 拦不住经 Resolver 的 DNS exfiltration，需 DNS Firewall 补位。

【解析】考点 E26 的核心：不要以为 Network Firewall 能拦住 DNS 查询，也不要以为二者二选一。（Topic 06 §1 / E26）

---

## 第 7 章 · DNSSEC（6 题）

### 7-1（单选）
客户要禁用某 public zone 的 DNSSEC signing，直接在 Route 53 点禁用时报 `Please remove DS records in the parent zone first`。正确的禁用顺序是？

- A. 直接强制禁用 signing，再删 DS
- B. 先删父区/注册商的 DS 记录、等传播完成，再关闭 signing
- C. 先删子区 DNSKEY，再关 signing
- D. 先删 KSK，再删 DS
- E. 同时删 DS 和 DNSKEY

【答案】B

【解析】禁用必须先解除信任链：先删父区 DS → 等 DS TTL 过期/传播 → 再关 signing，Route 53 才允许。顺序不能颠倒。（Topic 07 §一/§四 考点 1）

### 7-2（单选）
关于 DS 记录与 DNSKEY 的放置位置，正确的是？

- A. DS 在子区，DNSKEY 在父区
- B. DS 在父区（子区 KSK 对应 DNSKEY 的摘要 + 算法元数据，不含完整公钥），DNSKEY 在子区
- C. 两者都在子区
- D. 两者都在父区
- E. DS 在根区，DNSKEY 在 TLD

【答案】B

【解析】DS（Delegation Signer）放在父区，内容是**子区 KSK 对应 DNSKEY 的摘要（digest）加上算法元数据**（Key Tag / Algorithm / Digest Type / Digest），**不包含完整的 KSK 公钥**，是"父指子"的信任指针；DNSKEY（KSK flag 257 / ZSK flag 256）在子区自身。方向别搞反。（Topic 07 §一 考点 4）

### 7-3（单选）
一个 zone 已经 signing（有 DNSKEY、记录带 RRSIG），但父区 `.com` 里查不到对应 DS 记录。这是什么状态、对解析有何影响？

- A. 信任链完整，解析器会验证
- B. island of trust（信任孤岛）：有签名无信任链，解析器不验证、按普通 DNS 正常返回，不影响可用性
- C. zone 不可解析，返回 SERVFAIL
- D. 配置错误，必须立刻修复否则宕机
- E. DNSSEC 未启用

【答案】B

【解析】zone 自己 signing 但父区无 DS = island of trust，支持 DNSSEC 的解析器不会验证（因为父区没告诉它该 zone 签名了），解析仍正常、不影响可用性。常见于刚启用 signing 还没建 DS，或禁用过程先删了 DS 还没关 signing。（Topic 07 §一/§四 考点 3 / case 178970323600938）

### 7-4（单选）
客户启用 DNSSEC 时报 `<key ARN> could not be used by Route 53 DNSSEC`。KSK 绑定的 KMS CMK 必须满足哪些要求？

- A. 对称密钥、任意规格即可
- B. 位于 us-east-1、asymmetric（非对称）、ECC_NIST_P256，且 key policy 授权 Route 53 DNSSEC 服务
- C. RSA_2048、对称用途
- D. 只要在 us-east-1 即可
- E. 必须是多区域密钥

【答案】B

【解析】KSK 的 CMK 必须**位于 us-east-1**、是 **asymmetric**、规格 **ECC_NIST_P256**（SIGN_VERIFY 用途），且 key policy 授权 `dnssec-route53.amazonaws.com`；任一不满足即报 "could not be used by Route 53 DNSSEC"。D 错在"只要在 us-east-1"——区域正确只是必要条件之一，非对称/规格/授权也都要满足。（Topic 07 §一/§四 考点 2 / case 卡点 2）

### 7-5（单选）
客户 `dig pd-market.com @<recursive>` 得到 SERVFAIL，第一反应怀疑 DNSSEC 验证失败。用什么命令能快速区分"是不是 DNSSEC 验证问题"？

- A. `dig pd-market.com +short`
- B. `dig pd-market.com @<recursive> +cd`——变 NOERROR 则是 DNSSEC 验证失败；仍 SERVFAIL 则与 DNSSEC 无关
- C. `dig DNSKEY pd-market.com`
- D. `dig +trace`
- E. `nslookup pd-market.com`

【答案】B

【解析】`+cd`（Checking Disabled）关闭解析器的 DNSSEC 验证：加了后变 NOERROR，说明原 SERVFAIL 是 DNSSEC 验证失败；仍 SERVFAIL 则与 DNSSEC 无关（case 178970323600938 真正根因是 stale NS 委派）。（Topic 07 §三/§四 考点 5）

### 7-6（问答）
简述轮换 KSK 时为何要走"DS 双记录过渡"，不这样做会有什么风险？

【答案】轮换 KSK 时新旧 DS 需并存一段时间：因为父区 DS、注册商侧变更有传播延迟，且旧 DS 可能仍在解析器缓存中。若直接撤旧 DS/换新，缓存里旧 DS 与 zone 新签名不匹配，中途会出现 DNSSEC 验证失败（SERVFAIL）。等旧 DS 在解析器缓存中过期后再撤旧，可避免验证中断。

【解析】DS/注册商变更受父区 TTL 与注册商处理影响，双记录过渡是平滑轮换的标准做法。（Topic 07 §一 传播与轮换）

---

## 附：答案速查表

| 题号 | 答案 | 题号 | 答案 | 题号 | 答案 |
|---|---|---|---|---|---|
| 1-1 | B | 3-1 | B | 5-1 | B |
| 1-2 | A,C | 3-2 | C | 5-2 | B |
| 1-3 | B | 3-3 | A,B | 5-3 | B |
| 1-4 | B | 3-4 | B | 5-4 | B |
| 1-5 | B | 3-5 | C | 5-5 | B |
| 1-6 | B | 3-6 | B | 5-6 | A,B |
| 1-7 | A,D | 3-7 | A,D(,B) | 5-7 | B |
| 1-8 | 问答 | 3-8 | 问答 | 5-8 | 问答 |
| 2-1 | C | 4-1 | C | 6-1 | B |
| 2-2 | A,B,D | 4-2 | B | 6-2 | B |
| 2-3 | B | 4-3 | B | 6-3 | A,B |
| 2-4 | B | 4-4 | A,B(,C) | 6-4 | B |
| 2-5 | C | 4-5 | B | 6-5 | B |
| 2-6 | C | 4-6 | B | 6-6 | A,B |
| 2-7 | 问答 | 4-7 | B | 6-7 | 问答 |
|  |  | 4-8 | 问答 | 7-1 | B |
|  |  |  |  | 7-2 | B |
|  |  |  |  | 7-3 | B |
|  |  |  |  | 7-4 | B |
|  |  |  |  | 7-5 | B |
|  |  |  |  | 7-6 | 问答 |

# Codex 技术审校 findings（cx ask 咨询式，2026-09-20）

审了 topic 03 路由策略 + topic 07 DNSSEC。以下为需修正项，每条已带正确说法。其余核心表述 Codex 确认成立。

## Topic 03 — 路由策略（11 项）
1. **Simple 不是"最多返回 8 个值"**：8 值上限属 Multivalue。Simple 返回 RRset 全部值并随机排序；单 RRset 配额 400 条。删掉正文表/速记/Mermaid 里的"Simple ≤8"。
2. **Latency 目标不是"必须在 AWS Region"**：可指向 AWS 外资源，但记录仍须指定一个 AWS Region；延迟依据是用户到 AWS 数据中心，故对外部资源可能不准。
3. **Failover Primary 不是"无健康检查就无法创建"**：无 HC 的记录被视为始终健康，故 Primary 不会切到 Secondary。Alias Primary 可用 EvaluateTargetHealth。改为"要有效故障转移，Primary 需 HC 或 ETH"。
4. **Failover fail-open 条件不全**："两者均不健康返回 Primary"仅当 Primary 和 Secondary 都真正参与健康评估；Secondary 无 HC 时始终健康，不存在"两者均不健康"。
5. **Weighted 0 权重过度简化**：仅当所有非零权重记录不健康时才考虑零权重记录；零权重记录本身仍受 HC 影响；全部不健康时 fail-open 后仍按权重选，零权重不自动成唯一兜底。
6. **Geoproximity 不再"必须用 Traffic Flow"**：2024 起支持普通记录/API/CLI/SDK 创建；仅地图可视化仍限 Traffic Flow。
7. **Bias 范围应含 0**：有效 -99~99；0=无偏移，正值扩大区域，负值缩小。
8. **Multivalue 不是"只返回健康记录"**：正常最多返回 8 条健康记录；全部不健康时 fail-open 返回最多 8 条不健康记录。
9. **IP-based 掩码**：普通条目 IPv4 /1-/24、IPv6 /1-/48；默认位置 * 可表示 /0（::/0）。
10. **ECS 检测域名占位符写错**：应为正确的 knowledge-center route-53 ECS 支持链接（占位符 `<domain>` 需替换真实域名）。
11. **实验里"必须直查权威 NS、并发约 10K 次"是编造**：非 AWS 要求；weighted 是概率分布，样本量按统计目标定；shell 顺序循环≠并发。删除此绝对化表述。

## Topic 07 — DNSSEC（核心正确，8 项精度修正）
核心确认正确：KSK/ZSK 分工、DS 在父区、禁用前先删父区 DS、KSK 的 KMS 密钥须 asymmetric ECC_NIST_P256、island of trust。
1. "KSK 签署 ZSK"→ KSK 签署包含 KSK/ZSK 的整个 DNSKEY RRset；ZSK 签署其余 RRset。
2. "DS 包含 KSK 公钥"→ DS 是子区 DNSKEY 的摘要+算法元数据，不含完整公钥。
3. "DNSSEC 加密 DNS 流量"→ 只提供来源认证与完整性，不加密（无机密性）。
4. "权威 DNS 执行 DNSSEC 验证"→ 权威服务器提供签名数据，验证通常由递归解析器完成。
5. "RRSIG 对单条记录签名"→ RRSIG 对同名同类型的整个 RRset 签名。
6. "签名有效期等同 TTL"→ TTL 控缓存；RRSIG inception/expiration 独立控签名有效期。
7. "NSEC3 彻底阻止区域枚举"→ NSEC3 仅提高枚举成本，不能保证阻止离线破解。
8. **补充关键考点**：Route 53 DNSSEC KSK 所用的 KMS 密钥**必须位于 us-east-1**（且 asymmetric ECC_NIST_P256）。

## 第二批抽查（topics 02/04/05，2026-09-20）

### Topic 02 — records-and-alias
1. **删除"Simple RRSET 每次最多返回 8 值"**（1.2 节）：Simple 返回全部值随机排序；8 值上限是 Multivalue；单 RRset 配额 400。→ 这是从 research 文件传导来的同一错误，需连根改。
2. **Alias 可以指向另一条 Alias（Alias 链受支持）**：不要写"target 不能是另一条 Alias"。同 zone 目标通常要求同类型；zone apex 不能最终指向 CNAME。整条 Alias 链若末端是合格 AWS 资源仍免费。
3. **"只有 Alias 能建在 apex"表述纠正**：apex 可有普通 A/AAAA/MX/TXT；准确说法=**CNAME 不能位于 apex，Alias 可以**。
4. **不要泛化"所有 AWS 目标都用 A/AAAA-Alias"**：类型取决于目标（CloudFront 启用 IPv6 才加 AAAA；API Gateway/接口端点通常 A）。
5. **Alias 目标列表不完整**：现还含 VPC Lattice 等；表注明"示例"或补全。

### Topic 04 — health-checks
1. **间隔/失败阈值补全**：Endpoint HC 间隔仅 10s/30s，默认 30s 且创建后不可改；FailureThreshold 连续 1–10 次，默认 3。
2. **18% 规则限定范围**：>18% checker 判健康才算健康，仅适用于全球 checker 的 Endpoint HC，不适用于 Calculated/CloudWatch。
3. **响应时间限定**：HTTP(S) 4s 建连 + 连接后 2s 内收 2xx/3xx；TCP 10s 建连；字符串检查还须状态码后 2s 内收 body。
4. **字符串匹配/SNI**：搜索串区分大小写，须完整位于 body 前 5,120 bytes；HTTPS 开 SNI 把 FQDN 放进 TLS ClientHello，首次证书名不匹配会重试且省略 SNI。
5. **"只有三类 HC"已过时**：还有 ARC RECOVERY_CONTROL；应分述 Endpoint / Calculated / CloudWatch / Recovery Control。
6. **Calculated/CloudWatch 修正**：Calculated 按健康子检查数与 HealthThreshold 比较；CloudWatch 读 alarm 数据流而非强制 alarm state，字段是 InsufficientDataHealthStatus，不支持跨账号 alarm。

### Topic 05 — resolver（沿用重点核对项，按官方文档修正转发规则优先于 PHZ、.2/VPC+2、inbound/outbound、split-horizon、autodefined rules 的任何不准确表述）

## 第三批抽查（topics 08-13，2026-09-20）

### Topic 08 — subdomain-takeover
- 核心正确：Route 53 仅保护 Scenario 1；正确退役顺序=先删父区 NS→等 TTL→再删 child zone。
- CNAME 向量不要把 ELB 列为可抢注目标；当前典型可利用目标=S3、Elastic Beanstalk、AWS 重分配域名时的 CloudFront。
- StopZoneSniping 内部实现（DaasPurgeDelegations/周期重评估/backfill）不是公开契约，删掉；公开结论只到 Scenario1 阻止重叠 NS 分配、删父区委派后 hold 移除、Scenario2-5 不保护。
- "SOA serial=1 是修复指纹"不可靠（默认示例值1，不自动递增、可改）；改为核对父区委派与目标 NS 是否真权威。
- "DNSSEC 启用后 TTL 强制一周"过宽 → 一周是签名 zone 的最大有效 TTL；原 TTL<一周的记录不受影响。
- Lab A 是破坏性实验（真造 dangling delegation）→ 标注仅在严格隔离、完全掌控的测试域执行并立即修复。

### Topic 09 — domain-registration
- 核心正确：注册与 DNS 托管生命周期独立；transfer lock/auth code/恢复受 TLD 规则约束。
- "gTLD 多 Amazon Registrar、ccTLD 多 Gandi"过度概括 → 按 GetDomainDetail/TLD 官方表确认实际 registrar。
- "转移必需解锁+一次性 auth code+60 天"过绝对 → 部分 TLD 不支持锁/不要求 auth code；60 天按 TLD/注册商规则确认。
- "90 天后域名永久删除、RDAP 正逐步取代 WHOIS"错误/过时 → 90 天是 AWS 账号重开期限，域名处置依 registrar；RDAP 自 2025-01-28 已是 gTLD 权威来源。

### Topic 10 — Profiles
- 核心正确：每 VPC 最多一个 Profile，可 RAM 跨账号共享。
- "只打包四类资源"不完整 → 还支持 Interface VPC endpoints，及 DNSSEC validation/反向 DNS/DNS Firewall failure mode 等设置。
- "local 永远优先于 Profile"易误导 → 先按最具体域名匹配；仅相同域名冲突时 local 优先。
- 补边界：Profile/资源/VPC 必须同 Region；Organizations 共享可自动接受，RAM 权限不一定只读。

### Topic 11 — ARC
- 核心正确：routing control 是人工/API 开关；cluster 五个区域数据面端点，≥3/5 quorum。
- "每 routing control 自动对应 health check"错误 → 必须显式创建 RECOVERY_CONTROL health check 并关联 RoutingControlArn。
- "客户端需访问三个端点形成 quorum"易误导 → 客户端只调用一个数据面端点；3/5 是 ARC 后端复制一致性；控制平面在 us-west-2。
- "确定性切换/安全规则绝对阻止"过强 → 状态切换确定，但实际流量受 DNS TTL/缓存影响；紧急可 SafetyRulesToOverride 覆盖。

### Topic 12 — 集成与配额
- 核心正确：默认 500 hosted zones/账号、10000 records/zone 可提；合格 AWS Alias 查询免费。
- **"Route 53 API 统一 5 RPS"已过时** → 公共 Route 53 API 账号桶=持续 10 RPS/突发 50；DNS changes=持续 100/s/突发 1500；5 RPS 主要是 Resolver API。
- Alias 目标列表不完整 + ETH 实验错误 → 还含 Elastic Beanstalk/App Runner/AppSync/OpenSearch/Lightsail/VPC Lattice；单条 simple Alias 即使目标不健康仍可能 fail-open，需多记录组验证 ETH。
- "GA 永远两个 IP/Resolver 约 10K QPS/ENI"不精确 → 按官方现行数字核对。

### Topic 13 — 排查纪律
- 方法论 topic，核对其中引用的具体数字/响应码语义与官方一致即可（尤其 VPC .2/+2、SERVFAIL/REFUSED/NXDOMAIN 含义）。

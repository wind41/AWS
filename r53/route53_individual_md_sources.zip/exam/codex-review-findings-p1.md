# Codex 校验 findings — P1 新域 00a/15/16（2026-09-20）

## topic 00a DNS 协议基础
核心正确：glue/in-domain、NXDOMAIN vs NODATA、负缓存公式、AA≠AD。修正：
1. **SOA MINIMUM 默认 86400 秒（不是 900）**；SOA 记录 TTL 默认 900；有效负缓存 = min(SOA MINIMUM, SOA TTL) = min(86400,900)=900 秒。改正文里"SOA MINIMUM 常见 900"的说法。
2. "stub 必发 RD=1 / recursive 对上游必发 RD=0"过绝对 → RD 只表达是否请求递归，不标识角色；forwarder 转发可带 RD=1，迭代查询通常 RD=0。
3. RFC 9471 措辞 → 要求返回所有 available in-domain glue，放不下则 TC=1；不新增"registry/zone 必须预先配置全部 glue"的要求。
4. in-domain vs sibling → RFC 9471 正式区分二者；sibling 不等同任意域外 NS；bailiwick 取决查询上下文。
5. TC=1 后 → 改用"另一种 transport"（经典客户端必须支持 TCP）。
6. EDNS0 声明值 = requestor 可接收的最大 payload，不是硬截断阈值（还受服务端上限/路径 MTU/分片影响）。
7. CD=1 = 请求递归器不验证，但仍受实现/本地策略/BAD cache 影响，非"保证返回原始数据"。
8. 实验命令：普通 EDNS 查询 flags 不等于 DO；要显式 `+dnssec` 才置 DO 位。改实验里 `flags: do` 的示例。

## topic 15 可观测性
核心正确：HealthCheckStatus/HealthCheckPercentageHealthy/ConnectionTime/TimeToFirstByte/SSLHandshakeTime 真实存在（AWS/Route53）；百分比仅 endpoint HC；InboundQueryVolume/OutboundQueryVolume/OutboundQueryAggregateVolume 存在；query logging 可投 CloudWatch Logs/S3/Firehose 且同 Region。修正：
1. **拼写：`EndpointUnHealthyENICount` → `EndpointUnhealthyENICount`**。
2. 容量判断优先看 `ResolverEndpointCapacityStatus`（ENI Count 指标只表 OPERATIONAL/AUTO_RECOVERING 状态）。
3. query logging 粒度不固定到实例/ENI → 含 srcaddr，srcids 可含 instance/resolver endpoint/RNI，取决查询路径；缓存命中不记录。

## topic 16 成本模型
（Codex 校验被截断，未列出新错误；后续如需再单独校验。核心数字 hosted zone 前 25 个 $0.50/月、health check AWS 内免费外收费、resolver endpoint 按 ENI 小时 方向正确。）

# Route 53 SME 进阶练习题库 —— 真实故障模式诊断 + 底层技术原理

> **素材来源**：`research/internal/r53-tt-failure-patterns.md`（内部 TT/case/COE 故障模式）、`research/internal/r53-sage-qa-supplement.md`（Sage/answers 专家口径）、`topics/14-technical-deep-principles.md`（底层机制深挖）。
> **题型**：场景单选（A-E）/ 多选。每题含 题干 + 选项 + 【答案】+ 【解析】（引回原理/故障模式）。
> **难度定位**：SME 级——侧重"给现象问根因/下一步排查"与"底层为什么这么设计"。
> **共 48 题**，按主题分章。多选题在题干标注"（多选）"。

---

## 第一章 真实故障模式诊断 —— 解析优先级 / PHZ / 转发规则（10 题）

### 1. VPC 内 dig 一条公网记录返回 NXDOMAIN，但指定 8.8.8.8 能正常解析。最可能的根因是？
- A. VPC 的 enableDnsSupport 被关闭
- B. 该域名存在一个覆盖它的 Private Hosted Zone，PHZ 内无此记录且不 fallback 公网
- C. Resolver Endpoint 的 QPS 超限
- D. DNSSEC 验签失败返回了 NXDOMAIN
- E. 公网权威服务器故障

【答案】B
【解析】重叠命名空间经典陷阱。为某域建 PHZ 后会生成 autodefined 规则，查询名落入 PHZ 即在 PHZ 内权威解析；PHZ 里没有该记录时**直接返回 NXDOMAIN，不 fallback 到公网**。8.8.8.8 不受 VPC PHZ 影响故能解析。正解是 split-view DNS。（enableDnsSupport 关了会整体解析失败，不是选择性 NXDOMAIN；DNSSEC 验签失败返回的是 SERVFAIL 而非 NXDOMAIN。）

### 2. 某 VPC 同时关联了 DNS Firewall、一条自定义 forward rule、一个 PHZ。一个查询进来，`.2` Resolver 的评估顺序是？
- A. PHZ → forward rule → DNS Firewall → 公网
- B. forward rule → PHZ → DNS Firewall → 公网
- C. DNS Firewall → Resolver 规则(forward rule) → Private Hosted Zone → 公网
- D. 公网 → PHZ → forward rule → DNS Firewall
- E. 按记录创建时间先后评估

【答案】C
【解析】`.2` Resolver 对每个查询按固定优先级评估：**DNS Firewall → Resolver 规则 → PHZ → 公网**，且 longest match 优先。Firewall BLOCK 的查询不再往下走。

### 3.（多选）关于"同一域名同时存在 PHZ 与自定义 forward rule"，下列正确的是？
- A. custom forward rule 默认压过 autodefined system rule
- B. 更长前缀的子域 PHZ 会赢过父域的 forward rule（longest match 优先于 rule 类型优先）
- C. 等长时 PHZ 永远胜出
- D. 给 example.com 加 outbound forward rule 想 fallback 公网是反模式，会让整域走公网、PHZ 失效
- E. forward rule 与 PHZ 冲突时随机选择

【答案】A、B、D
【解析】custom forward rule 显式定义、优先级最高（压过 autodefined）；但 longest match 优先于 rule 类型——子域 PHZ 前缀更长会赢过父域 forward rule。用 forward rule 给整域做公网 fallback 是反模式（forward rule 压过 autodefined，整域走公网、私区失效、白花 endpoint 费）。C 错在"等长时看类型（custom forward 胜）"，E 错在并非随机。

### 4. ECS 服务报 UnknownHostException，删掉某个 PHZ 后立即恢复。根因与两条修复路径是？
- A. 根因是 QPS 超限；修复是加 ENI 或降 TTL
- B. 根因是一个父域 PHZ 把子服务查询"吸走"返回空（私区最长匹配 + 不 fallback）；修复是删掉该 PHZ，或在该 PHZ 内补齐指向 LB 的镜像 A 记录
- C. 根因是 DNSSEC 信任链断裂；修复是撤父区 DS
- D. 根因是 conntrack；修复是去掉限制性 SG
- E. 根因是委派跳级；修复是逐级委派

【答案】B
【解析】私区与公区不能共享同一根域重叠，私区优先且从最靠近根域的区开始解析。多余的父域 PHZ 把查询吸走返回空。修复两条路：删区，或在该 PHZ 内补镜像记录。

### 5. PrivateLink 端点解析不出私有 IP，CloudAuth token prefetch connect timed out。首先应检查哪两个 VPC 属性？
- A. enableDnsSupport 和 enableDnsHostnames
- B. mapPublicIpOnLaunch 和 assignIpv6
- C. DNS Firewall 状态和 Resolver rule
- D. Flow Logs 和 VPC Peering
- E. NACL 和安全组

【答案】A
【解析】PHZ 解析要求 VPC 同时打开 enableDnsSupport 和 enableDnsHostnames，两者都为 true 才生效。老 VPC / 手工建的 VPC 常默认没开 hostnames。VPCE 私有 DNS、Amazon 提供的 DNS 名解析都依赖它。

### 6. `dev.api.example.com` 间歇性 ERR_NAME_NOT_RESOLVED，偶尔又能解析。最可能的委派配置错误是？
- A. NS 记录 TTL 设得太长
- B. 把 dev.api.example.com 直接从 example.com 委派，而非从直接父区 api.example.com 逐级委派
- C. DNSSEC 未启用
- D. PHZ 未关联 VPC
- E. Resolver endpoint 不足

【答案】B
【解析】多级子域委派必须从直接父区委派，不能跳级。跳级委派（从 example.com 直接委派 dev.api.example.com）会造成间歇失败。核对链 example.com → api.example.com → dev.api.example.com，每级 NS 建在直接父区。

### 7. 客户想在 R53 私有区里用 NS 记录把子区委派给 on-prem BIND，操作失败。原因是？
- A. 私有区 NS 记录需要额外付费
- B. R53 私有区不支持 delegation/NS 记录；纯 R53 场景用"多 PHZ + 重叠命名空间 + Resolver 规则"等效替代
- C. on-prem BIND 版本过旧
- D. 需要先启用 DNSSEC
- E. 私有区 NS 记录 TTL 必须大于 172800

【答案】B
【解析】R53 私有区不支持 NS 委派。纯 R53 一般不需委派（多 PHZ + overlapping namespace + resolver rule 即可等效）；只有子区要委派到非 R53 权威（on-prem）时才撞功能缺口，需用 DNS forwarding 变通。

### 8. 跨账号把 PHZ 关联到另一账号的 VPC，在控制台找不到入口。正确做法是？
- A. 控制台开启跨账号共享开关即可
- B. 用 CLI/SDK/API：先在 PHZ 所有者账号 create-vpc-association-authorization，再在 VPC 所有者账号 associate-vpc-with-hosted-zone；或用 Route 53 Profiles 免授权步骤
- C. 必须先合并两个账号到同一 Organization
- D. 只能通过 Support case 手工关联
- E. 先删除 PHZ 再在目标账号重建

【答案】B
【解析】跨账号关联 PHZ 无法在控制台做，必须 CLI/SDK/API 两步授权；Route 53 Profiles 可免此授权步骤。

### 9. 为什么"按客户端 IP/ISP 做 split-horizon 路由"不可靠？
- A. R53 不支持 A 记录
- B. 无法保证终端用户用的是其 ISP 的 DNS（可能用 8.8.8.8），源 IP 判断会错、返回错记录；此类需求应转为访问控制问题
- C. split-horizon 需要企业级支持合同
- D. 私网 IP 不能放进 public zone
- E. R53 会随机丢弃一半查询

【答案】B
【解析】控制不了终端用户用哪个 resolver，据源 IP 判断会错。专家建议转为访问控制（Lambda@Edge 判 IP 段重定向 + 边缘封锁），而非靠 DNS。（私网 IP 其实可以放进 public zone。）

### 10.（多选）关于 dangling delegation（悬挂委派）的安全风险与正确操作顺序，下列正确的是？
- A. 悬挂委派属安全 Sev2，攻击者可能接管子域
- B. 删除子 zone 的正确顺序：先删父域 NS 委派、再删子 zone
- C. 迁移子 zone 时先更新父域 NS 记录
- D. R53 有防护栏自动阻止悬挂委派
- E. 悬挂委派只影响解析延迟，不涉及安全

【答案】A、B、C
【解析】父域 NS 委派指向的子 zone 被删/迁到别 tenant 后，委派 NS 指向已无权威的 nameserver，攻击者可接管。几乎没有防护栏自动阻止（D 错）。删/迁子 zone 要先处理父域 NS 委派。E 错——这是安全问题。

---

## 第二章 真实故障模式诊断 —— Resolver Endpoint 限流 / QPS / 连接跟踪（8 题）

### 11. 客户问"1024 PPS 和 10,000 QPS 是不是一回事"。正确区分是？
- A. 是同一个限，两个说法而已
- B. `.2` Resolver 每 ENI 硬限 1024 PPS（不可提升，缓存命中/IMDS 查询也算）；Resolver Endpoint 每 ENI/IP 约 10,000 QPS（超 50% 应加 ENI），是两个不同的限
- C. 1024 PPS 可提升，10,000 QPS 不可提升
- D. 两者都可通过 Support 提额
- E. 只有公网权威查询才有这两个限

【答案】B
【解析】两个不同硬限：`.2` 每 ENI 1024 PPS 不可增（缓存命中、IMDS 都吃额度）；Resolver Endpoint 每 ENI 约 10K QPS 可加 ENI。多数 1 查询=1 UDP 包 PPS≈QPS，EDNS0 大包/切 TCP 时不等。

### 12. 某出站 Resolver Endpoint ENI 明明没到 10K QPS 却大量丢包超时，并发布了 `conntrack_allowance_exceeded_delta` 指标。根因是？
- A. 客户超过了 10K QPS 硬限
- B. ENI 使用了限制性安全组规则、或查询经过 NLB，触发 connection tracking，把 UDP QPS 压到低至约 1,500 QPS
- C. 目标 on-prem 名服务器不可达
- D. DNSSEC 验签占用了带宽
- E. IMDS 偷走了额度

【答案】B
【解析】NX 底层用 conntrack。限制性 SG 或经 NLB 强制 conntrack 时，UDP QPS 被压到约 1,500 QPS（约 6 倍降幅）。conntrack 丢包发布 `conntrack_allowance_exceeded_delta`；纯 10K 超限发布 `udp_throttled_count`。修复：去掉限制性 SG / 不走 NLB。

### 13. 内部 runbook 判定：`conntrack_allowance_exceeded_delta` 和 `udp_throttled_count` 两个指标都 NOT OK。如何判定主因？
- A. 一定是 conntrack
- B. 一定是 throttling
- C. 看 ENI 迁移时机——迁移到大实例前已在大实例上则主因是 throttling；迁移中才升到 CONN_TRACK_FLEXI_FLEET 则主因是 conntrack
- D. 两个指标不可能同时 NOT OK
- E. 无法判定，直接加 ENI

【答案】C
【解析】两者都中时看 capacity_level 迁移时机：迁移前已在大实例 → 主因 throttling；迁移中才升到 CONN_TRACK_FLEXI_FLEET → 主因 conntrack。修复：throttling 全 ENI 中招→加 ENI，部分中招→均衡分流；conntrack→去 SG 限制/不走 NLB。

### 14. 出站解析大面积超时/SERVFAIL，但 conntrack 与 throttling 指标都正常。下一步最应怀疑什么、怎么定位？
- A. 客户 SG 配错；抓 SG 规则
- B. 目标 on-prem 名服务器无响应/不可达；用 CloudWatch Insights 按分钟算 timeout%，再对 Athena 表按 destip 聚合 respcode='TIMEOUT' 统计每个目标 NS 的超时数
- C. DNSSEC 信任链断；检查 DS
- D. PHZ 重叠；列出关联 PHZ
- E. VPC DNS 属性未开；检查 enableDnsHostnames

【答案】B
【解析】内部 runbook 明确：出站 endpoint 支持工单最常见根因是目标 NS 不可达。限流指标正常时优先怀疑目标 NS，用 timeout% + 按 destip 聚合超时定位。

### 15. on-prem 发查询到 Inbound Resolver Endpoint，收不到任何响应（连错误都没有），排查极难。底层原因是？
- A. Inbound endpoint 只接受递归查询（RD=1），收到迭代查询会立即静默丢弃、无错误响应
- B. Inbound endpoint 返回了 REFUSED 但被防火墙拦截
- C. 安全组把响应包丢了
- D. 查询触发了 DNS Firewall BLOCK
- E. QPS 超限被静默丢弃

【答案】A
【解析】R53 Resolver endpoint 是递归 resolver，只接受递归查询。发迭代查询给 Inbound endpoint 会被立即丢弃、无错误响应（不是 REFUSED，是无响应），这是 forwarding 的硬性要求。

### 16. 2026-02-04 TRE（税务引擎）DNS 大面积超时约 1 小时，同区 Datapath/OPF 无恙。COE 根因是？
- A. R53 权威 anycast edge 故障
- B. TRE 用共享出站 resolver endpoint，一次 Alexa 变更重启 Redis 使其 VPC 产生 2.76 亿+ 查询把共享 endpoint 打到峰值 821K QPS；Datapath/OPF 因有专用 endpoint 未受影响
- C. DNSSEC 轮换失败
- D. 控制面 API 限流
- E. NLB fail-open

【答案】B
【解析】共享出站 endpoint 的"吵闹邻居"事件。多租户共享 endpoint 无隔离，一个租户的查询洪峰把共享 endpoint 打满，其他共享租户受牵连；专用 endpoint 因隔离未受影响。SME 考点：专用 vs 共享 endpoint 的容量与隔离权衡。

### 17. ChangeResourceRecordSets 报 HTTP 400 `Throttling / Rate exceeded`。正确理解是？
- A. DNS 查询 QPS 超限，需加 ENI
- B. 这是控制面 API 限流（每账户 5 请求/秒），与数据面 DNS 查询限流无关；公网权威 DNS 查询 QPS 无限制
- C. 需要给 hosted zone 提额
- D. `.2` Resolver 的 1024 PPS 超限
- E. conntrack 触发

【答案】B
【解析】Route 53 API 每账户 5 rps（控制面）；DNS 查询是数据面不受此限。不要把 API throttling 与 resolver QPS 混为一谈。

### 18. 为什么"出站 endpoint 的 QPS"与"收到的入站 QPS"不相等？
- A. 因为出站会压缩查询
- B. R53 Resolver 给每个入站请求生成冗余出站查询（并行发到多个 target/cell），故出站 QPS 与入站不等
- C. 出站只处理未缓存的一半
- D. 出站丢弃了迭代查询
- E. NLB 复制了流量

【答案】B
【解析】R53 Resolver 为每个入站请求生成冗余出站查询，所以出站 ENI 的 QPS 与收到的 QPS 不相等（这也是高可用的一部分）。

---

## 第三章 真实故障模式诊断 —— Health Check / Failover（8 题）

### 19. 内部 ALB 后端不健康，但 R53 failover 不切换。根因是？
- A. R53 health check 从全球公网 endpoint 发起，无法探测私有 IP；内部资源要用 CloudWatch alarm 型 HC，或对 ELB 用 Evaluate Target Health(ETH)
- B. ALB 不支持 R53 健康检查
- C. failover 记录 TTL 太长
- D. 缺少 DNSSEC
- E. ETH 只对公网 ELB 有效

【答案】A
【解析】R53 HC 从公网发起，探不了私有 IP。内部资源用 CW-alarm HC 或 ELB 的 ETH。所有 ELB（含内部）自带 R53 health check，指向 ELB 的 Alias 勾选 ETH 即可免费用。

### 20.（多选）关于 Evaluate Target Health (ETH) 的语义，下列正确的是？
- A. ETH 只对 Alias 记录有效；非 Alias 记录用关联的 Health Check
- B. Simple routing 下 ETH 无效（单记录永远按值应答）
- C. Alias + ETH 与显式 HC 同时开时，两者都必须通过才算健康（AND），best practice 是只开一个
- D. ELB（含 internal/私网）已被 R53 健康检查，勾 ETH 即可，无需自建 endpoint HC
- E. ETH 对普通 A 记录 + Weighted 路由同样直接生效

【答案】A、B、C、D
【解析】ETH 仅 Alias；Simple routing 下无效；ETH+HC 同开是 AND 且不推荐；ELB 已被 R53 检查，勾 ETH 即可。E 错——非 Alias 记录用的是"关联的 Health Check"，不是 ETH。

### 21. 某区 NLB 后端 100% 不健康，R53 仍往该区发流量、跨区 failover 不触发。根因是？
- A. ETH 未开
- B. NLB fail-open：目标全部不健康时 NLB 仍放行，于是 ETH 认为"健康"，跨区 failover 不触发
- C. health check 间隔太长
- D. 记录 TTL 过短
- E. DNSSEC 阻断

【答案】B
【解析】NLB fail-open 是"全不健康仍收流量"的根因——ETH 依赖 LB 上报，LB fail-open 就骗过 ETH。方案：改用 failover routing 配合能反映真实后端的 HC（CW 复合指标/应用级 HC）。

### 22. 新建的 HTTPS health check 立刻 unhealthy。哪些是合理根因？（多选）
- A. 探测路径需要鉴权，应用返回 403（403 视为不健康）
- B. HTTPS 探测未开 SNI 或证书不覆盖被探 FQDN
- C. 探测路径返回 5xx
- D. 证书已过期
- E. 记录 TTL 设为 0

【答案】A、B、C
【解析】health check 语义：2xx/3xx 才算健康，403/5xx 算失败；HTTPS 需正确 SNI + 有效证书覆盖被探 FQDN。注意 D 是陷阱——**HTTPS 健康检查不校验证书**，证书过期不会让 HC 失败（见第六章原理题）。E 与 HC 健康判定无关。

### 23. Failover 双记录返回规则，下列哪个是正确的兜底行为？
- A. 主备都不健康 → 不返回任何记录
- B. 主备都不健康 → 返回主（fail-open 到 primary，不可配置）
- C. 主备都不健康 → 返回备
- D. 主备都不健康 → 随机返回
- E. 主备都不健康 → 返回 SERVFAIL

【答案】B
【解析】主健康→只返回主；主不健康备健康→返回备；主备都不健康→返回主（last resort fail-open，不可配置）。

### 24. 基于 CloudWatch alarm 的跨区 failover 配置里，主/备记录的 ETH 应如何设置？
- A. 主备 ETH 都设 True
- B. 主备 ETH 都设 False（健康信号来自 CW alarm 而非 target 本身），否则 failover 不触发
- C. 主 True、备 False
- D. 主 False、备 True
- E. ETH 与 CW alarm 互斥，不能同时用

【答案】B
【解析】CW-alarm 跨区 failover 的 HC 指向目标区自定义 CW 指标/alarm，主备 ETH 都要设 False，否则 failover 不触发（真实 case 卡点）。

### 25. ETH=True 对 NLB 的判定（cross-zone 关闭），下列描述正确的是？
- A. 只看该 AZ 是否有 NLB 节点在监听端口，不看后端 target
- B. 既看该 AZ 是否有健康的 NLB 节点，也看后端 target：某 AZ"至少一个 target group 有健康 target"则该 AZ 的 NLB IP 才进 DNS；>1 个 TG 且任一 UNHEALTHY → FAIL
- C. 只看后端 target，不看 NLB 节点
- D. NLB 跨区开关会直接改变 ETH 判定结果
- E. ETH 对 NLB 永远返回健康

【答案】B
【解析】ETH 对 NLB 两层判断：NLB 侧（cross-zone 关时该 AZ 节点只探同 AZ 目标，至少一个 TG 有健康目标该 AZ IP 才进 DNS）+ target 侧（>1 TG 且有一个 UNHEALTHY 则 FAIL）。NLB 跨区开/关不影响 ETH 判定。

### 26. 单 VPC 内某 service 的 VPC Endpoint 一般是否需要开 ETH？专家口径是？
- A. 必须关闭 ETH，否则会误摘除
- B. 通常不需要（单 VPC 一 service 只能建一个 endpoint，无第二个可切）；且 Alias 到 VPCE 时无论 ETH 设什么，AZ 故障时不健康 IP 都会被自动摘除，建议一律设 True（"要么正确要么无害"）
- C. ETH 对 VPCE 完全无效
- D. 需要额外付费才能对 VPCE 用 ETH
- E. VPCE 必须自建 endpoint HC

【答案】B
【解析】VPCE 通常没有第二个 endpoint 可切；Alias 到 VPCE 时 AZ 故障不健康 IP 会被自动摘除，gavinmc 建议一律设 True。

---

## 第四章 真实故障模式诊断 —— 路由策略 / DNSSEC 运营 / 注册（8 题）

### 27. 同 DC 内，经 NAT 的服务器解析到 us-east-1（预期），带公网 IP 的 resolver 却解析到 us-west-1（意外）。latency-based routing 的判定依据是？
- A. 最终客户端的 IP
- B. 发起解析的 resolver 的源 IP（不同 resolver 公网 IP 来自不同 ISP 池 → 判到不同区）；若 resolver 开了 EDNS0/ECS 则用客户端子网判定
- C. VPC 所在区域
- D. 记录 TTL
- E. 权威服务器最近的 edge

【答案】B
【解析】latency/geo 基于发起解析的 resolver IP，非客户端 IP。开 ECS 时用客户端子网判定；不开则用 resolver IP。注意 VPC Resolver 不支持 ECS。

### 28. 一组 weighted 记录部分权重为 0、部分非 0，都健康。R53 如何选择？
- A. 按比例把 0 权重也纳入
- B. 先只考虑非 0 权重记录；只有当所有非 0 权重记录都不健康时，才考虑 0 权重记录
- C. 0 权重记录永远不返回
- D. 随机返回
- E. 0 权重记录优先返回

【答案】B
【解析】R53 先只考虑非 0 权重记录；仅当所有非 0 权重都不健康才考虑 0 权重记录。可用"权重 100/0"做手动 failover。

### 29. 启用 DNSSEC 签名后，验证型 resolver 却不做验签 / 链中断导致 SERVFAIL。根因是？
- A. 算法选错
- B. 只启用签名不够，必须逐级建立 chain of trust：把每级 KSK 的 DS 注册到直接父区（example.com 的 DS 注册到 .com，子域 DS 注册到 example.com）；缺任一级 DS 传播则验签不发生
- C. ZSK 未轮换
- D. resolver 不支持 EDNS0
- E. 记录 TTL 太长

【答案】B
【解析】启签≠验签生效，必须逐级 DS 注册建信任链。缺任一级 DS 则验签不发生（子区签名也白搭）。R53 Resolver 验签失败返回 SERVFAIL。

### 30. 想在 R53 hosted zone 上禁用 DNSSEC，报 `KeySigningKeyInParentDSRecord 400`。正确处理是？
- A. 重试几次即可
- B. 父区仍有指向该 KSK 的 DS 记录，必须先从父区/注册商移除 DS（先解除信任链）才能安全关签；回滚要考虑 resolver 缓存 TTL，分步进行
- C. 先删除所有 A 记录
- D. 联系 Support 强制关闭
- E. 先轮换 KSK

【答案】B
【解析】关 DNSSEC 前必须先撤父区 DS。Slack 事件教训：回滚未考虑 resolver 缓存 TTL 把小故障放大，应分步进行。

### 31.（多选）关于 R53 Resolver（`.2` / AmazonProvidedDNS）的 DNSSEC 校验语义，下列正确的是？
- A. 只有当 resolver 自己在做递归解析时才做 DNSSEC 校验，转发给其他 resolver 的查询由那个 resolver 校验
- B. `.2` 校验失败返回 SERVFAIL，不放行伪造响应
- C. `.2` 忽略 DO/CD 位、不返回 RRSIG、不置 AD 位 → 客户端侧（如 delv）无法自行校验，要客户端级 DNSSEC 须自建递归 DNS
- D. `.2` 对所有转发区也全链路验签
- E. `.2` 会把 RRSIG 原样返回给客户端

【答案】A、B、C
【解析】Resolver 验签范围 = 它自己递归解析的名字，转发区不覆盖；校验失败 SERVFAIL；`.2` 不返回 DNSSEC 记录/AD 位，客户端验签不支持。D、E 与实际相反。

### 32. 4 个 PHZ 复用同一 KMS CMK，客户困惑为何 DS 记录值各不相同。正确解释是？
- A. 是 bug，应各建独立 CMK
- B. 复用 CMK → KSK 相同（同公钥）；但 DS 用 ECDSA P-256 + SHA-256（algo 13），同一消息多次签名值不同，故不同 HZ 的 DS 值可不同，任取一个上报 RIR 即可；建议别跨 fault domain 复用 CMK
- C. DS 值不同说明 KSK 不同
- D. 必须每个 zone 用不同 CMK 才能启用 DNSSEC
- E. DS 值随机生成与密钥无关

【答案】B
【解析】复用 CMK → KSK 同、DS 值可不同（algo 13 签名不确定性）；每 HZ 仍需各自启签；建议 prod/non-prod 等 fault domain 分开。

### 33. 从其他注册商转入 R53，状态卡在 `serverTransferProhibited`。正确排查方向是？
- A. 该状态由注册商设置，客户自己在 R53 控制台解除
- B. 该状态由注册局(Registry, 如 Verisign/PIR)设置，比 clientTransferProhibited 更难解除；对注册局做 WHOIS 看真实状态，多为账单/法务问题，需原注册商转呈注册局
- C. 直接重新发起转入即可
- D. 提交 Support case 由 AWS 强制转入
- E. 等待 60 天自动解除

【答案】B
【解析】server* 状态由注册局设置，比 client* 难解除。对注册局 WHOIS（.com/.net 查 Verisign，.org 查 PIR）看真实状态；多为账单问题，注册商要转呈注册局。

### 34. 安全审计报"Missing EPP configuration，可能被劫持"。正确澄清是？
- A. 需要立即配置 EPP
- B. EPP 是注册商↔注册局的协议，EPP 状态码只是域名状态、不是发变更的通道；R53 Domains 防未授权变更的真正机制是 IAM 角色/策略
- C. R53 Domains 有独立 EPP 配置项需开启
- D. 必须启用 DNSSEC 才能防劫持
- E. EPP 缺失会导致 DNS 解析失败

【答案】B
【解析】R53 Domains 无独立 EPP"配置"，clientTransferProhibited 有助防转移但可被有权限者移除；访问控制正解是 IAM。

---

## 第五章 底层技术原理 —— 递归 vs 权威 / anycast / 委派选择（7 题）

### 35. Route 53 托管 hosted zone 那一侧扮演什么 DNS 角色？
- A. 递归解析器，会替客户端迭代查询根/TLD
- B. 权威 name server，只对发到它、它负责的 zone 作答，从不迭代、从不缓存别人的数据
- C. stub resolver
- D. 转发解析器
- E. 既是权威又是递归

【答案】B
【解析】R53 托管 zone = 权威（authoritative），只按权威身份作答，收到 RD=1 也不递归。VPC Resolver 才是递归层。这是 SME 最常被问混的分界。

### 36. 客户"改了记录为什么没生效"。机制层最准确的解释与首要排查是？
- A. R53 权威侧改动要几小时才生效
- B. R53 权威侧改动是秒级生效的；卡的是下游递归解析器手里旧记录的剩余 TTL。先问客户在哪测、经过哪个递归解析器、旧记录 TTL 多少
- C. 一定是负缓存
- D. 一定是 DNSSEC 未重签
- E. 需要手工刷新 R53 缓存

【答案】B
【解析】只有递归解析器缓存，权威(R53)不缓存。R53 侧秒级生效，感知延迟取决于下游递归缓存的 TTL 剩余。

### 37.（多选）关于 R53 权威的四组委派 NS（stripe）与 shuffle sharding，下列正确的是？
- A. 每个 hosted zone 的 4 条委派 NS 从 .com/.net/.org/.co.uk 四个 stripe 各取一条
- B. 多 TLD 意义在于 TLD 层容灾（某 TLD 自身故障时还有其他 stripe 可用）
- C. shuffle sharding 强制"任意两个 hosted zone 的 4 条 NS 重叠不超过 2 条"，切碎故障爆炸半径
- D. 四个 stripe 全由 Verisign 运营
- E. 每个 zone 的 4 条 NS 都指向同一个 edge

【答案】A、B、C
【解析】4 条 NS 横跨四个 TLD stripe（各取一条）；多 TLD 为 TLD 层容灾；shuffle sharding 保证任两 zone NS 重叠≤2。D 错——.com/.net 是 Verisign，.org/.co.uk 是不同运营方。E 错——见下题。

### 38. 为什么 R53 选择"每个 edge 一般只宣告一个 stripe"，而非在每个 edge 宣告全部四条 NS？
- A. 节省 anycast 地址
- B. 若每 edge 宣告全部四条，解析器无论选哪条都落到同一最近 edge，该 edge 一旦不可达则四条 NS 全军覆没无处可退；每 edge 一个 stripe 使 4 条 NS 分布在 4 个不同 edge，任一 edge/路径故障仍有 3 条可退 + 获得 Internet 路径多样性
- C. 因为 anycast 不支持多 stripe
- D. 为了降低成本
- E. 因为解析器不支持多 NS

【答案】B
【解析】延迟 vs 可用性取舍：牺牲少许延迟换 edge/路径多样性容灾。代价是某些 NS 从较远 edge 应答，但约 80% 解析器靠 SRTT 自动收敛到最快 NS，对最小 RTT 影响很小。

### 39. 客户抱怨"控制台显示的 4 条 NS 和我 dig NS 拿到的不一致"。最可能原因与正确处置？
- A. R53 出 bug，应重建 zone
- B. 多半是父区(注册商/上级 zone)委派没同步、或存在旧 delegation set 残留；不要动 R53 侧那条自动生成的 NS 记录
- C. 应手工修改 R53 自动生成的 NS 记录使其匹配
- D. DNSSEC 未启用导致
- E. anycast 导致每次 dig 结果本就不同

【答案】B
【解析】NS 不一致多为父区委派未同步或旧 delegation set 残留。"Except in rare circumstances, don't change it"——别动 R53 自动生成的 NS 记录。

### 40. 递归解析路径中，stub→recursive 与 recursive→权威 两段查询的 RD（Recursion Desired）标志分别是？
- A. 都是 RD=1
- B. stub→recursive 带 RD=1（请替我跑全程）；recursive→权威 带 RD=0（权威不递归），R53 收到 RD=1 也不递归、只按权威作答
- C. 都是 RD=0
- D. stub→recursive RD=0，recursive→权威 RD=1
- E. RD 标志由 TTL 决定

【答案】B
【解析】stub→recursive RD=1，recursive→权威 RD=0；R53 权威即使收到 RD=1 也不递归。委派靠 NS 记录 + glue（避免"要解析 NS 又要先解析 NS"死循环），权威应答置 AA=1。

### 41. 若某上游被 `.` rule 指到 Cisco Umbrella，而该上游全部挂掉，R53 Resolver 会怎样？
- A. 自动回落到公网根做递归解析（forward-first）
- B. 不会自动回落到公网根——R53 不提供 BIND 的 forward-first 语义；要回落只能删除该 dot rule（控制面 API 操作）
- C. 返回负缓存
- D. 切到备用上游
- E. 直接返回 8.8.8.8 的结果

【答案】B
【解析】R53 无 BIND forward-first。所有查询转发到某上游，上游全挂不会自动回落公网根。gavinmc 明确"这通常是好事，forward-first 结果不可预期"。要回落只能删 dot rule。（另：Resolver rule 无内建 failover，多 target IP 时逐个试、顺序≈随机。）

---

## 第六章 底层技术原理 —— 缓存/负缓存 / health checker 18% / DNSSEC 信任链（7 题）

### 42. 客户"新建了记录，但一直 NXDOMAIN"。若之前查过这个当时不存在的名字，最可能的机制是？
- A. 正缓存过久
- B. 负缓存：递归解析器缓存了 NXDOMAIN，时长 = min(SOA.MINIMUM, SOA.TTL)（R53 默认 MINIMUM 约 900s），新建后仍要等负缓存过期
- C. DNSSEC 验签失败
- D. R53 权威未生效
- E. anycast 路由错误

【答案】B
【解析】负缓存（RFC 2308/9077）：缓存 NXDOMAIN/NODATA 否定应答，时长取 min(SOA.MINIMUM, SOA.TTL)。"记录明明建了却还 NXDOMAIN"十有八九是负缓存。

### 43. 关于 SOA 记录的 MINIMUM 字段，下列哪个是它在现代 DNS 里的真正用途？
- A. 记录的默认 TTL
- B. 负缓存 TTL 的上限（负缓存时长 = min(SOA.MINIMUM, SOA.TTL)，RFC 9077）
- C. zone 传输间隔
- D. SOA 记录本身的 TTL
- E. DNSSEC 签名有效期

【答案】B
【解析】常见误解是"MINIMUM = 默认记录 TTL"，实际它是负缓存 TTL 上限。RFC 9077 修订：负缓存 TTL 取 min(SOA.MINIMUM, SOA.TTL)，避免 SOA TTL 小而 MINIMUM 大时负缓存过久。

### 44. R53 health checker 判定端点"健康"的全球共识阈值是？其设计意图是？
- A. 50%；简单多数
- B. 可用 checker 中报告健康的比例 > 18% → 判健康，≤18% → 不健康；低阈值意在防止端点仅因被少数检查点的网络路径隔离就被误判为不健康（抗局部隔离误报，偏 fail-toward-available），且不可调
- C. 100%；所有 checker 必须一致
- D. 18%；但客户可在控制台调整
- E. 取决于 HC 类型

【答案】B
【解析】>18% checker 报健康即判健康，抗局部网络隔离误报，不可调（文档明示可能未来变更但用户不能设）。这是"能被多少比例全球检查点看到"的共识，不是端点自身业务健康。

### 45.（多选）关于 R53 health check 的底层机制，下列正确的是？
- A. 各检查点互不协调，即使配 30s 间隔端点也会在某几秒收到多次、又有几秒完全没有，平均约每 2 秒一次
- B. HTTPS 健康检查不校验证书——证书过期/无效不会让 HC 失败
- C. HTTP/HTTPS：4s 内建 TCP 连接 + 连上后 2s 内返回 2xx/3xx；带字符串匹配时需在响应体前 5120 字节内出现指定字符串
- D. TCP 健康检查需 10s 内建立 TCP 连接
- E. 健康结论是同步瞬时传播到所有 DNS 数据面的

【答案】A、B、C、D
【解析】checker 独立全球数据面、互不协调；HTTPS 不校验证书；各类型阈值如题；TCP 10s 建连。E 错——健康结论跨数据面是异步、秒级但非瞬时。

### 46. 客户问"故障发生后为什么没立刻切"。failover 感知总耗时由哪几段串联构成？
- A. 只有 HC 检测一段
- B. ① HC 达到失败阈值（间隔×连续失败，最快约 10s）+ ② 健康结论跨数据面异步传播（秒级非瞬时）+ ③ 递归解析器缓存中旧记录 TTL 过期（取决于 record TTL），三段串联
- C. 只有 TTL 过期一段
- D. HC 检测 + DNSSEC 重签
- E. 控制面 API 传播 + anycast 收敛

【答案】B
【解析】切换总耗时 = 检测(≥10s) + 跨数据面异步传播(秒级) + 递归缓存 TTL 过期。别简化成"HC 一失败就切"。failover 记录 TTL 要设小（如 60s）就是压第三段。

### 47. DNSSEC 验证链四步的正确顺序是？
- A. ZSK 验业务记录 → KSK 验 ZSK → 父区 DS 验 KSK → 根信任锚
- B. 父区 DS 按 Digest Type 哈希子区 KSK 并比对（信任 KSK）→ KSK 验签 DNSKEY RRset（信任其中的 ZSK）→ 信任 ZSK → ZSK 的 RRSIG 验业务记录（全过则置 AD 位）
- C. 根 → ZSK → KSK → DS → 业务记录
- D. DNSKEY 验 DS → DS 验 RRSIG → RRSIG 验记录
- E. KSK 直接签业务记录

【答案】B
【解析】四步：父区 DS→子 KSK（按 Digest Type，2=SHA-256 主流）；KSK 签 DNSKEY RRset→信任 ZSK；ZSK 的 RRSIG 验业务记录。DS 在父区、DNSKEY 在子区，方向别反；DS 只是子 KSK 的摘要指纹不含完整公钥；R53 用 algo 13(ECDSAP256SHA256)。

### 48. 支持验证的递归解析器返回 SERVFAIL，下列哪些是可能断点？（多选）
- A. 换过 KSK 但父区 DS 未更新，DS digest 与子 KSK 对不上
- B. RRSIG 已过期（即使 TTL 未到也失败，多见于手工/外部签名 zone）
- C. 中间盒子裁掉大 DNSSEC 应答或不支持 EDNS0 大报文，DNSKEY 缺失
- D. 父区无 DS（这是 island of trust 半启用态，不验证做普通解析，不 SERVFAIL）
- E. DS Digest Type 填错

【答案】A、B、C、E
【解析】DS 与 KSK 对不上、RRSIG 过期（RRSIG 有效期≠TTL，过期即使 TTL 未到也 SERVFAIL）、DNSKEY 被裁/EDNS0 不支持、Digest Type 填错都会 SERVFAIL。D 是陷阱——父区无 DS 是 island of trust，不验证走普通解析，不 SERVFAIL。

---

*（题库结束，共 48 题）*

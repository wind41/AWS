# Route 53 SME 计分模拟卷（Mock Exam · Scored）

> 65 题 · 覆盖 13 个知识域 · 按考试比重加权（路由策略 / 健康检查 / Resolver / Alias 加重）
> 题源：exam-bank-01-07.md（52 题）+ exam-bank-08-13.md（46 题），已 Codex 校正。

---

## 考试须知（Instructions）

- **建议用时**：90 分钟
- **总分**：100 分
- **及格线**：≥ 70 分（Pass）
- **题量**：65 题
- **题型与分值**：
  - 单选题 51 题，每题 **1.4 分**（合计 71.4 分）
  - 多选题 11 题，每题 **2.0 分**（合计 22.0 分，**多选须选全且不多选才得分，不倒扣、无部分分**）
  - 问答题 3 题，每题 **2.2 分**（合计 6.6 分，按要点覆盖度给分）
  - 合计 71.4 + 22.0 + 6.6 = **100 分**
- **域分布（按考试比重加权）**：

  | 域 | 主题 | 题数 |
  |---|---|---|
  | 01 | Hosted Zones | 4 |
  | 02 | 记录与 Alias ⭐ | 6 |
  | 03 | 路由策略 ⭐ | 8 |
  | 04 | 健康检查 ⭐ | 7 |
  | 05 | Resolver 与混合 DNS ⭐ | 8 |
  | 06 | DNS Firewall / Global Resolver | 5 |
  | 07 | DNSSEC | 5 |
  | 08 | 子域接管 / dangling delegation | 4 |
  | 09 | 域名注册 / 生命周期 | 4 |
  | 10 | Route 53 Profiles | 3 |
  | 11 | ARC Routing Controls | 4 |
  | 12 | 服务集成 + 配额限流 | 4 |
  | 13 | 通用故障排查纪律 | 3 |
  | | **合计** | **65** |

  ⭐ = 考试重点加权域。

> 答题时把每题答案填入**第二部分答题卡**；交卷后对照**第三部分**评分。

---

# 第一部分 · 题卷（Questions）

> 只含题干与选项，不含答案。多选题已在题干标注"多选"。

---

## 域 01 · Hosted Zones（4 题）

### Q1（单选，1.4 分）
客户在同一账号下同时持有 public zone `habitat-energy.au`（父）与 `prod.habitat-energy.au`（子），父 zone 里有一条指向子 zone 的 NS 委派记录。客户想把子域记录合并进父 zone、随后删除子 zone，要求切换零停机。最安全的操作顺序是？

- A. 先删父 zone 里的 NS 委派记录，再在父 zone 建全子域记录
- B. 先在父 zone 建全所有子域记录并验证，再删父 zone 里的 NS 委派记录，最后删子 zone
- C. 直接删除子 zone，Route 53 会自动把记录并入父 zone
- D. 同时删 NS 委派记录和子 zone，再补建父 zone 记录
- E. 把子 zone 的 NS 记录复制到父 zone 即可

### Q2（多选，2.0 分，选两项）
关于 Private Hosted Zone（PHZ）的启用与解析边界，正确的有哪些？

- A. 使用 PHZ 要求关联 VPC 的 `enableDnsHostnames` 与 `enableDnsSupport` 都为 true
- B. PHZ 记录可被公共递归 DNS（如 8.8.8.8）解析
- C. VPC 若用 DHCP Option Set 指向自定义 DNS，PHZ 记录会返回 NXDOMAIN
- D. PHZ 支持 DNSSEC signing
- E. PHZ 支持 IP-based 路由策略

### Q3（单选，1.4 分）
一个 VPC 内查询 `seattle.accounting.example.com`，该 VPC 同时关联了 `accounting.example.com` 和 `example.com` 两个 PHZ。Route 53 会用哪个 PHZ 应答？

- A. `example.com`（更早创建的）
- B. `accounting.example.com`（最具体匹配）
- C. 随机选一个
- D. 两个都查，合并结果
- E. 返回 NXDOMAIN，因为命名空间重叠冲突

### Q4（单选，1.4 分）
客户删除一个已启用 DNSSEC signing 的 hosted zone 时报 `HostedZoneNotEmpty`。最可能的原因与正确处理是？

- A. zone 内还有普通记录，删掉即可
- B. 需先 deactivate/delete 该 zone 的 KSK
- C. 该 zone 被 RAM 共享，需先取消共享
- D. NS/SOA 记录不能删，导致 zone 非空
- E. 需先关闭 VPC 关联

---

## 域 02 · 记录类型与 Alias ⭐（6 题）

### Q5（单选，1.4 分）
客户裸域 `example.com`（zone apex）要指向一个 ALB。应如何配置？

- A. 建一条 apex 的 CNAME 指向 ALB DNS 名
- B. 建一条 apex 的 A (Alias) 指向 ALB
- C. 建一条 apex 的 NS 记录指向 ALB
- D. 建一条 apex 的 TXT 记录写入 ALB 名
- E. apex 无法指向 ALB，必须换用 www 子域

### Q6（单选，1.4 分）
客户要把子域 `www.example.com` 指向一个**第三方（非 AWS 托管）**的域名 `cdn.partner.net`。应使用哪种记录？

- A. A-Alias
- B. AAAA-Alias
- C. CNAME
- D. A 记录直接填 partner 域名
- E. Alias 指向同 zone 记录

### Q7（多选，2.0 分，选三项）
关于 Alias 相对 CNAME 的特性，正确的有哪些？

- A. Alias 可以建在 zone apex，CNAME 不行
- B. Alias 指向 AWS 资源的查询免费
- C. Alias 指向 AWS 资源时可以单独设置 TTL
- D. Alias 支持 Evaluate Target Health，CNAME 不支持
- E. Alias 的目标可以再是另一条 Alias 或 CNAME

### Q8（单选，1.4 分）
客户做 failover，主备记录都指向 ELB（可建 Alias 的资源）。以下哪种做法最规范？

- A. 给每条 alias 记录另外建一个独立 endpoint 健康检查
- B. alias 记录设 Evaluate Target Health = Yes，不再单独建健康检查
- C. 把 alias 改成 CNAME 再挂健康检查
- D. 用 simple 路由 + 健康检查
- E. 关闭健康检查，靠 TTL 过期切换

### Q9（单选，1.4 分）
客户用 simple 路由在一条记录里配了 12 个 A 值，观察到每次 dig 只返回一部分且顺序变化。关于这一行为，正确的解释是？

- A. 配置错误，simple 只能配 1 个值
- B. Simple 的一条 RRset 会返回**全部**值并随机排序；每次 dig 只看到一部分是 UDP 应答体积 / 客户端截断所致，不是 Route 53 的"8 值上限"
- C. 健康检查剔除了不健康的值
- D. TTL 过期导致部分值丢失
- E. Route 53 在做真正的负载均衡

### Q10（单选，1.4 分）
客户把 apex 子域配成 A (Alias) 指向 Kong NLB，配置本身 100% 正确，但 VPC 内 dig 却返回旧的 Apigee ELB IP。最可能的根因层次是？

- A. Alias 记录类型选错了
- B. apex 不该用 Alias
- C. VPC 内解析被 Resolver Forward Rule 拦截，查询没到达公网 zone
- D. NLB 未开启健康检查
- E. ELB canonical hosted zone id 填错

---

## 域 03 · 路由策略 ⭐（8 题）

### Q11（单选，1.4 分）
客户在多个 AWS Region 部署了相同应用，希望终端用户被路由到"网络延迟最低"的 Region。应选哪种路由策略？

- A. Weighted
- B. Latency
- C. Geolocation
- D. Geoproximity
- E. Simple

### Q12（单选，1.4 分）
客户用 geolocation 路由，为 CN、US 各配了记录，但没有配 default。一个来自无法映射到任何地理位置的 IP 的查询会得到什么？

- A. 随机返回 CN 或 US 记录
- B. 返回离得最近的记录
- C. "no answer"
- D. NXDOMAIN
- E. 返回全部记录

### Q13（多选，2.0 分，选两项）
关于 geolocation 与 geoproximity 的区别，正确的有哪些？

- A. geolocation 只看用户位置；geoproximity 看资源+用户位置
- B. geoproximity 可用 bias（±1..±99）扩张/收缩某资源的吸引范围
- C. geolocation 也能用 bias 调整吸引范围
- D. geoproximity 不需要 Traffic Flow
- E. geolocation 需要 Traffic Flow

### Q14（单选，1.4 分）
一条 failover 记录，Primary 和 Secondary 的健康检查同时都是 unhealthy。Route 53 会返回什么？

- A. 返回 Secondary
- B. 返回 Primary（fail open）
- C. 返回 "no answer"
- D. NXDOMAIN
- E. 随机返回一个

### Q15（单选，1.4 分）
客户在一组 weighted 记录里把某条记录的 weight 设为 0，其余记录权重非 0。什么情况下这条 0 权重记录会被返回？

- A. 永远不会被返回
- B. 每次都会被返回一小部分
- C. 仅当组内所有非 0 权重记录都不健康时
- D. 当它自身的健康检查通过时
- E. 当组内权重之和为 0 时

### Q16（单选，1.4 分）
客户在一个 Private Hosted Zone 里想按客户端源 IP 段做 IP-based 路由。会发生什么？

- A. 正常生效
- B. PHZ 不支持 IP-based 路由策略
- C. 需要先开 Traffic Flow
- D. 需要 outbound endpoint
- E. 仅 IPv6 支持

### Q17（多选，2.0 分，选两项）
关于 EDNS0 / edns-client-subnet (ECS) 对地理 / 延迟类路由准确性的影响，选出**最直接描述定位机制**的两项？

- A. resolver 支持 ECS 时，Route 53 能用用户 IP 的截断前缀更准确定位
- B. VPC 的 .2 resolver 支持 EDNS0 但不支持 ECS
- C. PHZ 使用 EDNS0 来做路由决策
- D. 不支持 ECS 时，用 resolver 自身源 IP 近似定位，可能偏差
- E. ECS 会加密 DNS 查询内容

### Q18（单选，1.4 分）
Route 53 的 latency 路由所依据的延迟数据，下列描述正确的是？

- A. 是客户端到资源的实时 ping 延迟
- B. 是 AWS 长期实测的网络延迟，非实时、会漂移，目标须在 AWS Region
- C. 按客户端地理国家静态映射
- D. 由客户在控制台手工填写延迟值
- E. 等同于 geoproximity 的 bias 计算

---

## 域 04 · 健康检查 ⭐（7 题）

### Q19（单选，1.4 分）
客户要监控一个**内部 ALB**（私有、不可路由 IP）的健康。哪种健康检查类型最合适？

- A. Endpoint HTTP 检查，直接填内部 ALB 私有 IP
- B. Endpoint TCP 检查内部 IP
- C. CloudWatch alarm-based（或 Calculated）健康检查
- D. Simple 路由自带的健康检查
- E. 无法监控内部资源

### Q20（单选，1.4 分）
客户的 HTTPS endpoint 健康检查突然变红，同时发现站点证书刚过期。证书过期是否是健康检查失败的原因？

- A. 是，HTTPS 健康检查会校验证书
- B. 否，HTTPS 健康检查不校验证书，证书过期不会导致失败
- C. 是，但只在开启 string matching 时
- D. 否，但会触发 INSUFFICIENT_DATA
- E. 是，需要更新根 CA

### Q21（单选，1.4 分）
关于 Route 53 健康检查的聚合判定（多地 checker），正确的是？

- A. 需超过 50% 的 checker 报健康才判健康
- B. 需超过 18% 的 checker 报健康才判健康
- C. 全部 checker 都健康才判健康
- D. 任一 checker 健康即判健康
- E. 由客户配置阈值百分比

### Q22（多选，2.0 分，选三项）
关于健康检查的响应时间与匹配阈值，正确的有哪些？

- A. HTTP/HTTPS：4s 内建 TCP 连接 + 连接后 2s 内回 2xx/3xx
- B. TCP：10s 内建连
- C. string matching 的匹配串必须落在 body 的前 5,120 字节内
- D. HTTP 需 10s 内回 2xx
- E. TCP 需 2s 内建连

### Q23（单选，1.4 分）
一个 CloudWatch alarm-based 健康检查，其 alarm 进入 `INSUFFICIENT_DATA` 状态。健康检查会如何判定？

- A. 一律判健康
- B. 按 HC 的 `InsufficientDataHealthState` 配置（默认 Unhealthy）
- C. 一律判不健康，不可改
- D. 保持上次状态，不可改
- E. 触发 fail open

### Q24（单选，1.4 分）
一个 CloudWatch alarm-based HC 关联的 alarm 已恢复 OK，但 HC 长时间（数十分钟）仍停留 Unhealthy。作为紧急恢复手段，哪种操作能触发 HC 重新评估？

- A. 删除并重建 hosted zone
- B. 对该 HC 执行 `UpdateHealthCheck`（如改一个无害字段）
- C. 重启关联的 EC2 实例
- D. 删除 CloudWatch alarm
- E. 只能等待，无法干预

### Q25（单选，1.4 分）
受害账户在 ALB access log 里发现持续的探测，User-Agent 为 `Amazon-Route53-Health-Check-Service (ref 28e27f8c-...)`，但自己并未创建该健康检查。这属于什么问题、如何处理？

- A. 正常流量，无需处理
- B. Unwanted HC abuse——由 Support Ops 走标准流程（确认 HC → 联系 offending 账户 → 等 7 天 → Mechanic 禁用，需 2PR）
- C. DDoS 攻击，走 Shield 流程
- D. 直接在自己账户里删除该 HC
- E. 修改 SG 屏蔽即可，无需上报

---

## 域 05 · Resolver 与混合 DNS ⭐（8 题）

### Q26（单选，1.4 分）
VPC 的主 CIDR 是 `10.201.244.0/22`。VPC Resolver（.2 resolver）的地址是？

- A. 10.201.244.1
- B. 10.201.244.2
- C. 10.201.247.253
- D. 169.254.169.253
- E. 10.201.244.253

### Q27（单选，1.4 分）
EC2 无法用 `nslookup ... 10.x.x.2`（VPC DNS）解析。工程师第一反应去检查 EC2 到 VPC DNS 之间的 Security Group / NACL / 路由表。这个排查方向对吗？

- A. 对，SG/NACL 常常拦住到 .2 的流量
- B. 不对，EC2 到 VPC DNS(.2) 的流量不经过 SG/NACL/路由表
- C. 对，但只需检查 NACL
- D. 不对，应改用公共 DNS
- E. 对，需要放行 UDP 53

### Q28（单选，1.4 分）
某域名在 VPC 内既有一个 PHZ 记录、又有一条 Resolver Forward Rule 指向企业 DNS。VPC 内查询该域名时会怎样？

- A. 用 PHZ 记录应答
- B. 查询被 Forward Rule 转发到企业 DNS（Forward Rule 优先于 PHZ）
- C. 报冲突错误
- D. 随机选一个
- E. 先查 PHZ，未命中再转发

### Q29（单选，1.4 分）
关于 Inbound / Outbound Resolver Endpoint 的方向，正确的是？

- A. Inbound = AWS→on-prem 查询；Outbound = on-prem→AWS 查询
- B. Inbound = on-prem→AWS 查询；Outbound = AWS→on-prem 查询
- C. 两者方向相同，只是冗余
- D. Inbound 用于公网，Outbound 用于私网
- E. Outbound endpoint 使用公网 IP

### Q30（单选，1.4 分）
客户想把 VPC 内**所有**域名查询都转发到企业 DNS，让 VPC 内查询永远不到达公网 Route 53。应如何配置 Resolver Rule？

- A. 为每个域名各建一条 FORWARD 规则
- B. 建一条域名为 `.`（dot）的 FORWARD 规则，关联 outbound endpoint
- C. 删除所有 System Rule
- D. 建一条 SYSTEM 规则指向企业 DNS
- E. 关闭 VPC 的 enableDnsSupport

### Q31（多选，2.0 分，选两项）
关于 Resolver 的 QPS / 吞吐边界，正确的有哪些？

- A. 每个 Outbound Endpoint 最多 6 个 ENI，聚合可达约 60,000 请求/秒
- B. 每个 ENI 约 10K QPS，但经 NLB 或 SG 因 connection tracking 会降到约 1.5–1.7K QPS
- C. 每 ENI 固定 1024 QPS 不可调
- D. Resolver 是全球服务，非 Regional
- E. Rule 不关联 outbound endpoint 也能生效

### Q32（单选，1.4 分）
Outbound Endpoint 有两个 ENI，分属不同子网/NACL。工程师排查发现其中一个 ENI 子网的 NACL 阻断了 DNS。为让转发可靠，NACL 上应双向放行哪些？

- A. 只放行入站 TCP 53
- B. 出站 UDP/TCP 53 + 入站 UDP/TCP ephemeral(1024-65535)，且每个 ENI 子网都要一致
- C. 只放行出站 UDP 53
- D. 放行所有 ICMP
- E. 只在一个 ENI 子网放行即可

### Q33（问答，2.2 分）
客户跨账号用 AWS RAM 共享一条 Resolver Forward Rule。关于共享范围、outbound endpoint 与成员账号权限，请写出三点关键结论。

---

## 域 06 · DNS Firewall / Global Resolver（5 题）

### Q34（单选，1.4 分）
DNS Firewall 的核心用途和过滤维度是？

- A. 加密所有 DNS 流量
- B. 对出站 DNS 查询做域名层过滤，主要防 DNS 数据渗漏（exfiltration）
- C. 按 IP/端口做网络层过滤
- D. 校验 DNSSEC 签名
- E. 对入站 DNS 查询做应用层过滤

### Q35（单选，1.4 分）
一个 VPC 关联了多个 rule group，rule group 内又有多条 rule。它们的处理顺序是？

- A. priority 数字越大越先处理
- B. priority 数字越小越先处理（rule group 与 rule 都是）
- C. 按创建时间倒序
- D. 随机
- E. 只处理 priority 最大的一条

### Q36（多选，2.0 分，选两项）
关于 DNS Firewall 规则的动作（Action），正确的有哪些？

- A. 含 domain list 的规则可选 ALLOW / BLOCK / ALERT
- B. 不含 domain list 的规则（Advanced 保护）只能 BLOCK / ALERT
- C. 任何规则都能设 ALLOW
- D. BLOCK 只能返回 NXDOMAIN
- E. Advanced 保护可以设 ALLOW

### Q37（单选，1.4 分）
客户用 allowlist（只放行白名单）方式，把入口域名 `svc.example.com` 加入了 ALLOW 列表，但它的 CNAME target 指向未列入白名单的 `backend.other.net`，结果查询被 BLOCK。根因是？

- A. ALLOW 规则失效
- B. 重定向链上的后续域名未显式加入 domain list（默认检查整条 CNAME 链，trust 仅在单次查询事务内有效）
- C. domain list 不支持 CNAME
- D. 白名单必须用通配符
- E. AWS 托管列表拦截了它

### Q38（单选，1.4 分）
客户配了一条 ALERT 规则和一条 DGA Advanced 规则，想确认某次查询是否命中了 DGA 检测。仅凭 dig 返回 NXDOMAIN 可以判定吗？应看哪里？

- A. 可以，NXDOMAIN 就代表 DGA 命中
- B. 不能，必须查 OCSF 日志的 `firewall_rule_id`；ALERT 命中流量的 `action_name` 仍是 `Allowed`
- C. 可以，看 dig 的 flags 即可
- D. 不能，只能看 CloudTrail
- E. 可以，看响应的 TTL

---

## 域 07 · DNSSEC（5 题）

### Q39（单选，1.4 分）
客户要禁用某 public zone 的 DNSSEC signing，直接在 Route 53 点禁用时报 `Please remove DS records in the parent zone first`。正确的禁用顺序是？

- A. 直接强制禁用 signing，再删 DS
- B. 先删父区/注册商的 DS 记录、等传播完成，再关闭 signing
- C. 先删子区 DNSKEY，再关 signing
- D. 先删 KSK，再删 DS
- E. 同时删 DS 和 DNSKEY

### Q40（单选，1.4 分）
关于 DS 记录与 DNSKEY 的放置位置，正确的是？

- A. DS 在子区，DNSKEY 在父区
- B. DS 在父区（子区 KSK 对应 DNSKEY 的摘要 + 算法元数据，不含完整公钥），DNSKEY 在子区
- C. 两者都在子区
- D. 两者都在父区
- E. DS 在根区，DNSKEY 在 TLD

### Q41（单选，1.4 分）
一个 zone 已经 signing（有 DNSKEY、记录带 RRSIG），但父区 `.com` 里查不到对应 DS 记录。这是什么状态、对解析有何影响？

- A. 信任链完整，解析器会验证
- B. island of trust（信任孤岛）：有签名无信任链，解析器不验证、按普通 DNS 正常返回，不影响可用性
- C. zone 不可解析，返回 SERVFAIL
- D. 配置错误，必须立刻修复否则宕机
- E. DNSSEC 未启用

### Q42（单选，1.4 分）
客户启用 DNSSEC 时报 `<key ARN> could not be used by Route 53 DNSSEC`。KSK 绑定的 KMS CMK 必须满足哪些要求？

- A. 对称密钥、任意规格即可
- B. 位于 us-east-1、asymmetric（非对称）、ECC_NIST_P256，且 key policy 授权 Route 53 DNSSEC 服务
- C. RSA_2048、对称用途
- D. 只要在 us-east-1 即可
- E. 必须是多区域密钥

### Q43（单选，1.4 分）
客户 `dig pd-market.com @<recursive>` 得到 SERVFAIL，第一反应怀疑 DNSSEC 验证失败。用什么命令能快速区分"是不是 DNSSEC 验证问题"？

- A. `dig pd-market.com +short`
- B. `dig pd-market.com @<recursive> +cd`——变 NOERROR 则是 DNSSEC 验证失败；仍 SERVFAIL 则与 DNSSEC 无关
- C. `dig DNSKEY pd-market.com`
- D. `dig +trace`
- E. `nslookup pd-market.com`

---

## 域 08 · 子域接管 / dangling delegation（4 题）

### Q44（单选，1.4 分）
某客户发现子域 `sub.example.com` 被他人接管。调查发现：父域仍保留该子域的 4 个 awsdns NS 委派记录，但对应的 child hosted zone 早已被删除。这属于哪个 Scenario，Route 53 的 StopZoneSniping 是否**设计上**会防护？

- A. Scenario 1，会防护
- B. Scenario 5，会防护
- C. Scenario 1，不防护
- D. Scenario 5，不防护
- E. Scenario 3，会防护

### Q45（单选，1.4 分）
关于 subdomain takeover 的成功条件，下列哪项**最准确**？

- A. 攻击者必须让新建 zone 的全部 4 个 NS 与悬空 NS 完全重叠
- B. 攻击者只需让新建 zone 的 NS 组与悬空 NS 组重叠 ≥1 个即可，重叠越多接管越稳定
- C. 攻击者必须在删除该 zone 的同一账号内重建
- D. 只要父域存在任意 NS 记录即可接管，无需重叠
- E. 必须先拿到 EPP auth code 才能接管

### Q46（单选，1.4 分）
退役一个子域时，消除悬空委派的**正确删除顺序**是？

- A. 先删 child hosted zone，再删父域的 NS 委派记录
- B. 先删父域的 NS 委派记录 → 等 TTL 过期 → 再删 child hosted zone
- C. 同时删除父域 NS 记录和 child zone
- D. 只删 child zone，父域委派保留以便日后复用
- E. 先启用 DNSSEC，再任意顺序删除

### Q47（多选，2.0 分，选三项）
关于 StopZoneSniping 保护特性，以下哪些描述正确？

- A. 保护是跨账号全局的，阻止任何账号被分配到重叠 NS
- B. 保护仅在删除该 zone 的账号内部生效
- C. 只要新 zone 重叠 1 个或多个 NS 即被阻止（per-NS）
- D. hold 是永久的，删过 zone 的 NS 组永远被锁定
- E. hold 靠"父域仍被观测到委派"续命，委派从父域消失后会被 purge、NS 回池

---

## 域 09 · 域名注册 / 生命周期（4 题）

### Q48（单选，1.4 分）
客户 `gateio.jp` 反映：Route 53 控制台显示到期 2027/6/29，而 WHOIS（whois.jprs.jp）显示 2026/06/30，且状态码显示 "-"，怀疑异常。SME 的正确判读是？

- A. WHOIS 到期日权威，客户域名即将过期需立即续期
- B. 两个到期日都对——R53/Gandi 的 2027/6/29 是有效到期日，JPRS WHOIS 按"到期月月末"呈现旧年份且更新滞后；状态 "-" 因 .jp 不支持 transfer lock，均属正常
- C. 状态 "-" 说明域名被锁定，需解锁
- D. 需立即向 JPRS 提工单纠正 WHOIS bug
- E. R53 到期日错误，应以 JPRS 为准修正

### Q49（多选，2.0 分，选三项）
关于 Route 53 的"注册商侧"与"DNS 托管侧"的边界，正确的有哪些？

- A. 删除 hosted zone 会自动注销域名注册
- B. 注销域名注册不会自动删除 hosted zone
- C. 域名被 suspend（clientHold）时，hosted zone 里的记录仍在，但公网查不到，因为注册局停止委派
- D. 改了 hosted zone 的 NS 后，必须在 Registered domains 侧同步更新注册局 NS 委派，否则解析走旧 NS
- E. 注册（registration）与解析（resolution）是同一套生命周期

### Q50（单选，1.4 分）
客户在域名转移**完成前**关闭了源账号，三个 Amazon Registrar 域名被 suspend 进入 clientHold、公网 DNS 中断。要恢复并完成转移，正确路径是？

- A. 直接从目标账号发起转移即可
- B. 重开源账号 → AES 事件驱动自动 unsuspend → 再走标准跨账号转移；转移必须由源账号发起
- C. 联系 JPRS 解除 clientHold
- D. 等域名进入 redemption 后从池中重新注册
- E. 修改目标账号的 NS 委派即可恢复解析

### Q51（单选，1.4 分）
关于赎回期（Redemption）与删除，下列哪项正确？

- A. 域名过期后随时可免费找回
- B. 进入 redemption 后 restore 通常收费且不保证成功；进入 pending delete 后不可赎回
- C. redemption 期内域名仍正常解析
- D. pending delete 阶段仍可免费赎回
- E. released 阶段域名自动回到原账号

---

## 域 10 · Route 53 Profiles（3 题）

### Q52（单选，1.4 分）
关于 Route 53 Profile 的本质，下列哪项**最准确**？

- A. Profile 是一种全新的 DNS 资源类型，用来取代 PHZ
- B. Profile 是把 PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging 配置成组打包、批量关联到多个 VPC 的分发机制
- C. Profile 只能打包 PHZ，不含其它资源
- D. 用了 Profile 之后就不再需要创建 PHZ
- E. Profile 是一种 Resolver endpoint 的高可用版本

### Q53（单选，1.4 分）
某 VPC 本地直接关联了一个 PHZ，同时又通过 Profile 下发了一个同命名空间的 PHZ。查询该命名空间时，Route 53 采用哪个？

- A. Profile 下发的 PHZ 优先
- B. VPC 本地（local）关联的 PHZ 优先于 Profile 下发的同名配置
- C. 随机选择
- D. 报冲突错误，两者都不生效
- E. 合并两者的记录一起返回

### Q54（多选，2.0 分，选四项）
以下哪些资源可以被打包进一个 Route 53 Profile？

- A. Private Hosted Zones（PHZ）
- B. Resolver rules（转发/系统规则）
- C. DNS Firewall rule groups（含优先级与 fail-open/closed 行为）
- D. Resolver query logging 配置
- E. EC2 安全组

---

## 域 11 · ARC Routing Controls（4 题）

### Q55（单选，1.4 分）
ARC Routing Control 与普通 Route 53 Health Check 的**根本区别**是？

- A. Routing control 主动探测端点，探测失败自动切流
- B. Routing control 是人工/编程拨动的确定性开关，背后改一个 R53 health check 的状态来切流，不依赖对应用的探测
- C. 两者完全等价，只是 ARC 更贵
- D. Routing control 只能用于单 Region
- E. 普通 health check 无法用于 failover 记录

### Q56（单选，1.4 分）
灾难发生时，切换 routing control 状态应使用哪条路径？

- A. Control plane（route53-recovery-control-config）
- B. Cluster 的 data plane endpoint（route53-recovery-cluster，5 个 Region endpoint，轮询直到成功）
- C. 直接改 Route 53 记录
- D. 修改 hosted zone 的 NS 委派
- E. 通过 Service Quotas 控制台

### Q57（单选，1.4 分）
ARC Cluster 的高可用设计是？

- A. 单 Region 部署
- B. 由 5 个 AWS Region 组成，读写 routing control 状态需至少 3 个（3/5 quorum）一致，即使 2 个 Region 不可用仍可切换
- C. 由 3 个 Region 组成，需全部在线
- D. 由 5 个 Region 组成，需 5 个全在线才能切
- E. 由 2 个可用区组成

### Q58（多选，2.0 分，选三项）
关于 Safety Rules，正确的有哪些？

- A. 核心目的是防止一次误操作把所有 Region 同时关掉（防"全关"）
- B. Assertion rule 约束一组 routing control 必须满足某条件才允许改变（如至少 1 个为 On）
- C. Gating rule 用一个"门"control 允许/禁止对另一组 control 的更改
- D. Safety rule 会主动探测应用健康
- E. 有了 safety rule 就不再需要 data plane endpoint

---

## 域 12 · 服务集成 + 配额与限流（4 题）

### Q59（单选，1.4 分）
客户问"为什么在根域 `example.com` 上配 CNAME 报错"，SME 的正确回答是？

- A. 根域 CNAME 需要额外付费才能启用
- B. 标准 DNS 禁止在 zone apex 放 CNAME，应改用 Alias 记录（Alias 可用于 apex）
- C. 根域只能用 TXT 记录
- D. 需要先启用 DNSSEC
- E. CNAME 在 apex 需要设置 TTL=0

### Q60（单选，1.4 分）
下列关于 Route 53 数据面 vs 控制面限流的说法，哪项正确？

- A. 公网权威 DNS 查询有严格的每账号 QPS 配额
- B. 公网权威查询几乎无限、不计账号配额；被限流的是控制面 API（约 5 请求/秒/账号）和 Resolver endpoint（per-ENI ~10,000 QPS）
- C. 控制面 API 无任何限流
- D. Resolver endpoint 无 QPS 上限
- E. 所有查询都计入统一的账号级 QPS 限流

### Q61（单选，1.4 分）
需要一次性修改一个 hosted zone 里的上百条记录，正确做法是？

- A. 写脚本循环调用 change-resource-record-sets，每条一次，每秒 >5 次
- B. 用单次 ChangeResourceRecordSets 请求打包多个变更，避免触发 Throttling/PriorRequestNotComplete
- C. 先提额把 hosted zone 上限调到 10 万
- D. 分账号并发调用绕过限流
- E. 逐条调用但加 sleep 到每秒恰好 5 次

### Q62（多选，2.0 分，选三项）
关于 `ip-ranges.json` 中 Route 53 相关 service 的三分层（呼应 NBC 案例），对应正确的有哪些？

- A. ROUTE53 = 公网权威 NS 的 IP 范围
- B. ROUTE53_RESOLVER = VPC 内递归解析器（有 per-ENI QPS 限流的那层）
- C. ROUTE53_HEALTHCHECKS = 健康检查探测车队
- D. ROUTE53 = VPC 内递归解析器
- E. 三者对应同一条数据路径

---

## 域 13 · 通用故障排查纪律（3 题）

### Q63（单选，1.4 分）
一台 EC2 解析某域名失败。判断故障范围时，SME 首先应做的是？

- A. 立即断定 Route 53 服务整体故障
- B. 先界定 blast radius——是所有 client 还是这一台？所有域名还是这一个？所有查询还是偶发？再归因
- C. 直接建议客户提额
- D. 假定是记录被删并重建记录
- E. 直接对客下单一根因结论

### Q64（多选，2.0 分，选四项）
关于 DNS 响应码/无响应的排查方向，正确的对应有哪些？

- A. timeout（无响应）→ 网络层：SG/NACL/路由阻断、目标 DNS 宕、UDP 分片丢失
- B. NXDOMAIN → 权威明确回答"此名不存在"，是数据问题（记录缺失/拼写/未创建），不是网络问题
- C. SERVFAIL → 递归/权威处理失败：DNSSEC 验证失败、转发目标不响应、上游超时
- D. REFUSED → 服务器拒绝应答：权限/ACL、非授权区、递归被关
- E. NXDOMAIN → 一定是网络阻断导致

### Q65（问答，2.2 分）
简述 SME 排查中的"证据分级（四级）"及其在回复措辞上的纪律。

---

> 题卷结束。请把答案填入下方**第二部分答题卡**。

---

# 第二部分 · 答题卡（Answer Sheet）

> 单选填一个字母（A–E）；多选填多个字母（如 `A,C`）；问答简述要点。

| 题号 | 类型 | 你的答案 | 题号 | 类型 | 你的答案 |
|---|---|---|---|---|---|
| Q1 | 单选 | ______ | Q34 | 单选 | ______ |
| Q2 | 多选(2) | ______ | Q35 | 单选 | ______ |
| Q3 | 单选 | ______ | Q36 | 多选(2) | ______ |
| Q4 | 单选 | ______ | Q37 | 单选 | ______ |
| Q5 | 单选 | ______ | Q38 | 单选 | ______ |
| Q6 | 单选 | ______ | Q39 | 单选 | ______ |
| Q7 | 多选(3) | ______ | Q40 | 单选 | ______ |
| Q8 | 单选 | ______ | Q41 | 单选 | ______ |
| Q9 | 单选 | ______ | Q42 | 单选 | ______ |
| Q10 | 单选 | ______ | Q43 | 单选 | ______ |
| Q11 | 单选 | ______ | Q44 | 单选 | ______ |
| Q12 | 单选 | ______ | Q45 | 单选 | ______ |
| Q13 | 多选(2) | ______ | Q46 | 单选 | ______ |
| Q14 | 单选 | ______ | Q47 | 多选(3) | ______ |
| Q15 | 单选 | ______ | Q48 | 单选 | ______ |
| Q16 | 单选 | ______ | Q49 | 多选(3) | ______ |
| Q17 | 多选(2) | ______ | Q50 | 单选 | ______ |
| Q18 | 单选 | ______ | Q51 | 单选 | ______ |
| Q19 | 单选 | ______ | Q52 | 单选 | ______ |
| Q20 | 单选 | ______ | Q53 | 单选 | ______ |
| Q21 | 单选 | ______ | Q54 | 多选(4) | ______ |
| Q22 | 多选(3) | ______ | Q55 | 单选 | ______ |
| Q23 | 单选 | ______ | Q56 | 单选 | ______ |
| Q24 | 单选 | ______ | Q57 | 单选 | ______ |
| Q25 | 单选 | ______ | Q58 | 多选(3) | ______ |
| Q26 | 单选 | ______ | Q59 | 单选 | ______ |
| Q27 | 单选 | ______ | Q60 | 单选 | ______ |
| Q28 | 单选 | ______ | Q61 | 单选 | ______ |
| Q29 | 单选 | ______ | Q62 | 多选(3) | ______ |
| Q30 | 单选 | ______ | Q63 | 单选 | ______ |
| Q31 | 多选(2) | ______ | Q64 | 多选(4) | ______ |
| Q32 | 单选 | ______ | Q65 | 问答 | ______ |
| Q33 | 问答 | ______ | | | |

---

# 第三部分 · 答案 + 解析 + 评分（Answer Key）

> 逐题：答案 / 分值 / 解析。多选须选全且不多选才得该题满分（无部分分、不倒扣）。

---

## 域 01 · Hosted Zones

**Q1（1.4 分）答案：B**
只要父 zone 的 NS 委派记录还在，查询就始终引向子 zone；先建全记录再删委派可无缝迁移。A/D 顺序颠倒会造成解析失败；C 合并非自动；E 复制委派 NS 不改变委派优先。

**Q2（2.0 分）答案：A、C**
PHZ 只能经 VPC Resolver 解析，公共 DNS 解析不到（B 错）；DHCP Option Set 指向自定义 DNS 绕过 VPC Resolver 导致 NXDOMAIN（C 对）；PHZ 不支持 DNSSEC（D 错）、不支持 IP-based（E 错）；启用前提两个 DNS 属性都为 true（A 对）。

**Q3（1.4 分）答案：B**
重叠命名空间取最长/最具体匹配，`accounting.example.com` 胜过 `example.com`，非按创建时间或随机。

**Q4（1.4 分）答案：B**
带 KSK 的 zone 删除报 `HostedZoneNotEmpty`，需先停用/删除 KSK 再删 zone。NS/SOA 是自带记录，不计入"非空"。

## 域 02 · 记录类型与 Alias ⭐

**Q5（1.4 分）答案：B**
apex 已强制带 NS+SOA，CNAME 不能与同名其他类型共存，故 apex 不能用 CNAME；指向 AWS 资源用 A-Alias，免费、少一跳、可开 ETH。

**Q6（1.4 分）答案：C**
Alias 目标只能是选定 AWS 资源或同 zone 同类型记录，指不了外部/非 R53 托管域名；要指向任意外部 DNS 名只能用 CNAME。

**Q7（2.0 分）答案：A、B、D**
Alias 能建在 apex（A）、指 AWS 资源查询免费（B）、有 ETH（D）；Alias 指 AWS 资源不能设 TTL（C 错）；target 不能再是 Alias/CNAME（E 错）。

**Q8（1.4 分）答案：B**
指向可建 alias 的 AWS 资源做 failover，用 ETH=Yes 让 Alias 自动感知目标健康，不再单独建 HC。CNAME 无 ETH（C 错），simple 不能关联 HC（D 错）。

**Q9（1.4 分）答案：B**
Simple 一条 RRset 可含多值，权威 NS 返回全部值并随机排序——粗粒度分散非负载均衡（E 错），不涉及健康检查。"每次最多 8 值"是 Multivalue Answer 的特性，不是 Simple；simple 看到只回一部分通常是 UDP 应答大小/客户端截断。

**Q10（1.4 分）答案：C**
记录/Alias 配置层正确，"解析结果不对"的根因在解析优先级层：VPC 内 Forward Rule 优先于 PHZ 优先于公网，查询被转发到企业 DNS（返回旧记录），没到达公网 zone。

## 域 03 · 路由策略 ⭐

**Q11（1.4 分）答案：B**
Latency 按 AWS 长期实测网络延迟导向延迟最低 Region，目标须在 AWS Region。Weighted 是按比例分（A 错）；geo 类按地理而非网络延迟。

**Q12（1.4 分）答案：C**
geolocation 对未映射来源，若无 default 记录（`CountryCode:"*"`）返回 "no answer"，不会兜底挑一个。必须显式建 default。

**Q13（2.0 分）答案：A、B**
geolocation 仅按用户位置、可设 default；geoproximity 看资源+用户位置、用 bias 移边界、通常需 Traffic Flow。bias 是 geoproximity 独有（C 错）。

**Q14（1.4 分）答案：B**
failover 的 fail-open：Primary+Secondary 都不健康时返回 Primary，不可配置。

**Q15（1.4 分）答案：C**
单条 weight 0 = 停止该记录流量；仅当组内所有非 0 权重记录都不健康时才启用 0 权重记录。"永远不返回"是错的。

**Q16（1.4 分）答案：B**
PHZ 只支持 simple/failover/multivalue/weighted/latency/geolocation/geoproximity；IP-based 只能在 public zone。

**Q17（2.0 分）答案：A、D**
ECS 让权威 NS 拿到用户 IP 截断前缀，定位更准（A）；不支持时退回 resolver 源 IP 近似（D）。（B 也是正确知识点，但本题取最直接描述定位机制的 A、D；C/E 错。）

**Q18（1.4 分）答案：B**
latency 依据 AWS 长期实测网络延迟，非实时、会漂移，目标须在 AWS Region；不是实时 ping、非静态国家映射、非手工填写。

## 域 04 · 健康检查 ⭐

**Q19（1.4 分）答案：C**
不能对 private/不可路由 IP 建 endpoint HC（A/B 排除）；内部 ALB 用 CloudWatch alarm-based 或 calculated HC。simple 路由不能关联 HC（D 错）。

**Q20（1.4 分）答案：B**
HTTPS 健康检查不校验证书，证书过期/无效不会导致失败——经典陷阱。变红原因另找（超时、状态码非 2xx/3xx、string 未匹配）。

**Q21（1.4 分）答案：B**
聚合规则：> 18% 的 checker 报健康即判健康，≤ 18% 判不健康。不是多数决（A 错）。

**Q22（2.0 分）答案：A、B、C**
HTTP/HTTPS 4s 建连 + 2s 回 2xx/3xx（A）；TCP 10s 建连（B）；string match 须在 body 前 5120 字节内（C）。D/E 把阈值记混。

**Q23（1.4 分）答案：B**
INSUFFICIENT_DATA 走 `InsufficientDataHealthState`，三态 Unhealthy（默认）/ Healthy / LastKnownStatus。

**Q24（1.4 分）答案：B**
`UpdateHealthCheck` 触发 HC 重新评估，可作紧急恢复手段。正常 R53 对 alarm 状态变化应在 1–2 分钟内响应，数十分钟属异常。

**Q25（1.4 分）答案：B**
任意账户能建指向不属于自己 IP 的 endpoint HC 造成滋扰。User-Agent 与 `ref=<HC ID>` 是识别关键。处理是 Support Ops 专属流程；受害方无法删别人账户里的 HC（D 错）。

## 域 05 · Resolver 与混合 DNS ⭐

**Q26（1.4 分）答案：B**
VPC Resolver 接入地址 = VPC 主 CIDR 基地址 +2 = 10.201.244.2。169.254.169.253 是 link-local 别名，但按 "VPC+2" 算法答案是 10.201.244.2。

**Q27（1.4 分）答案：B**
EC2 → VPC DNS(.2) 的流量不经过 SG/NACL/路由表——最大的方向性坑。真正阻断点在 Outbound Endpoint 的 ENI 子网 NACL。

**Q28（1.4 分）答案：B**
VPC 内解析优先级：Forward Rule > PHZ > System Rule > 公网递归。同域名冲突时 Forward Rule 胜，查询被转发出去。

**Q29（1.4 分）答案：B**
In = 别人进来查我（on-prem→AWS）；Out = 我出去查别人（AWS→on-prem）。Outbound endpoint 是私有 IP，出公网需 NAT（E 错）。

**Q30（1.4 分）答案：B**
域名为 `.`（dot）的 FORWARD 规则覆盖除 PHZ/AWS 内部名以外的所有域名，把 VPC 内查询全部转出。Rule 必须关联 outbound endpoint 才生效。

**Q31（2.0 分）答案：A、B**
每 Outbound Endpoint ≤6 ENI、聚合 ~60K req/s（A）；每 ENI ~10K QPS，经 NLB/SG 因 connection tracking 降到 ~1.5–1.7K（B）。1024 是实例侧 link-local PPS 限制（C 混淆）；Resolver 是 Regional（D 错）；Rule 必须关联 endpoint（E 错）。

**Q32（1.4 分）答案：B**
每个 ENI 子网都要在 NACL 双向放行：出站 UDP/TCP 53 + 入站 UDP/TCP ephemeral，且多 ENI 跨子网配置须一致，否则间歇故障。

**Q33（问答，2.2 分）答案要点（三点全中给满分，缺一点按比例）**
(1) 共享限**同一 Region**，无需额外 VPC peering；
(2) 父账号的 outbound endpoint 会随 rule 一起共享，成员账号**不需另建 endpoint**；
(3) 成员账号只能**使用**共享 rule，不能修改或删除它。
（常见错误：以为跨账号共享 rule 还要单独建 outbound endpoint。）

## 域 06 · DNS Firewall / Global Resolver

**Q34（1.4 分）答案：B**
对经 VPC Resolver 的出站 DNS 查询做域名字符串层过滤，解析成 IP 之前拦截命中黑名单的查询，主防 exfiltration；不加密、不看 IP/端口/应用层。

**Q35（1.4 分）答案：B**
rule group 之间与组内每条 rule 都按 priority 数字从小到大处理（lowest numeric priority first）。

**Q36（2.0 分）答案：A、B**
含 domain list 才能 ALLOW（A）；Advanced 只能 BLOCK/ALERT，不能 ALLOW（B 对，C/E 错）。BLOCK 响应有 NXDOMAIN/NODATA/OVERRIDE 三种（D 错）。

**Q37（1.4 分）答案：B**
默认检查整条重定向链，被 ALLOW 域名的 CNAME target 若未列入 domain list，其 A+AAAA 相当于未被 ALLOW 命中而被 BLOCK。allowlist 要覆盖整条 CNAME 链或配 Trust Redirection Domains。

**Q38（1.4 分）答案：B**
ALERT 命中流量被放行，OCSF 日志里 `action_name` 仍是 `Allowed`；DGA 是否命中不能凭 dig 的 NXDOMAIN 判断，必须查日志 `firewall_rule_id`。

## 域 07 · DNSSEC

**Q39（1.4 分）答案：B**
禁用必须先解除信任链：先删父区 DS → 等传播 → 再关 signing。顺序不能颠倒。

**Q40（1.4 分）答案：B**
DS（父区）= 子区 KSK 对应 DNSKEY 的摘要 + 算法元数据，不含完整公钥；DNSKEY（KSK 257 / ZSK 256）在子区。方向别反。

**Q41（1.4 分）答案：B**
zone 自己 signing 但父区无 DS = island of trust，验证型解析器不验证、解析仍正常、不影响可用性。常见于刚启用未建 DS 或禁用过程已删 DS 未关 signing。

**Q42（1.4 分）答案：B**
KSK 的 CMK 必须位于 us-east-1、asymmetric、ECC_NIST_P256（SIGN_VERIFY），且 key policy 授权 `dnssec-route53.amazonaws.com`。D 错在"只要在 us-east-1"是必要非充分。

**Q43（1.4 分）答案：B**
`+cd`（Checking Disabled）关闭解析器 DNSSEC 验证：加后变 NOERROR = DNSSEC 验证失败；仍 SERVFAIL 则与 DNSSEC 无关。

## 域 08 · 子域接管 / dangling delegation

**Q44（1.4 分）答案：A**
"child zone 曾存在→被删→父域仍留委派" 是 Scenario 1，是 5 个场景中 Route 53 **唯一**提供防护的场景。题问"设计上是否防护"，与"这次实际是否被拦"两回事。

**Q45（1.4 分）答案：B**
接管只需命中 ≥1 个重叠 NS，重叠越多越稳定；可跨账号进行，与 EPP code 无关。"必须整组重叠"是错误认知。

**Q46（1.4 分）答案：B**
先删父域 NS 记录并等 TTL 过期（清空 resolver 缓存），再删 child zone。反过来正是制造 Scenario 1 悬空的错误操作。

**Q47（2.0 分）答案：A、C、E**
保护跨账号全局（A，B 错）；per-NS 生效，重叠任一即拦（C）；hold 非永久（D 错），靠父域仍被观测到委派续命，委派消失则 purge 回池（E）。

## 域 09 · 域名注册 / 生命周期

**Q48（1.4 分）答案：B**
.jp 三特性：WHOIS 到期日恒为到期月月末、旧到期月过完才更新新年份、不支持 transfer lock 状态显示 "-"。有效期以 Gandi/Route 53 为准，保持 auto-renew。

**Q49（2.0 分）答案：B、C、D**
注册 ≠ 解析（E 错）。删 hosted zone 不注销域名（A 错）；注销域名不删 hosted zone（B 对）；suspend/clientHold 断的是注册局委派、记录仍在（C 对）；改 hosted zone NS 必须两侧同步（D 对）。

**Q50（1.4 分）答案：B**
账号一关自助转移被切断（转移必须由源账号发起）。恢复：重开源账号 → AES 事件驱动自动 unsuspend → 标准跨账号转移。这些是 Amazon Registrar 域名，与 JPRS 无关。

**Q51（1.4 分）答案：B**
赎回期 restore 收费且不保证成功；pending delete 后不可赎回（D 错）；released 后回公开池需重新抢注（E 错）；redemption 阶段已暂停、不正常解析（C 错）；"过期随时免费找回"错（A）。

## 域 10 · Route 53 Profiles

**Q52（1.4 分）答案：B**
Profile 是打包分发机制，不是新资源类型、不取代 PHZ；能装 PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging 四类。

**Q53（1.4 分）答案：B**
优先级铁律：**local > Profile**。本地就近覆盖，Profile 集中默认。

**Q54（2.0 分）答案：A、B、C、D**
Profile 可打包四类 DNS 配置：PHZ、Resolver rules、DNS Firewall rule groups、Resolver query logging。EC2 安全组不在其列（E 错）。

## 域 11 · ARC Routing Controls

**Q55（1.4 分）答案：B**
ARC routing control 是"开关"不是"探针"——人/自动化确定性拨动，背后驱动 health check 状态翻转切 failover 记录，规避灰色故障下探测不准。

**Q56（1.4 分）答案：B**
平时用 control plane 配置；救灾切流必须用 cluster 的 5 个 data plane endpoint（轮询直到成功）。control plane 在大区域灾难中可能不可达。

**Q57（1.4 分）答案：B**
Cluster 跨 5 个 Region，3/5 quorum；即使 2 个 Region 挂掉仍可靠切换。需全部在线（C、D）错。

**Q58（2.0 分）答案：A、B、C**
Safety rule 是护栏，防"全关"与防误触（A、B、C）。它不探测应用（D 错）；切换仍必须走 data plane endpoint（E 错）。

## 域 12 · 服务集成 + 配额与限流

**Q59（1.4 分）答案：B**
标准 DNS 禁止 apex 放 CNAME；Route 53 Alias 无此限制，可用于 apex，指向 AWS 资源不额外收费、AWS 自动维护目标 IP。

**Q60（1.4 分）答案：B**
公网权威查询由 anycast 车队承载、不计账号配额；能被限流的是控制面 API（~5 req/s）与 Resolver endpoint（per-ENI ~10k QPS）。

**Q61（1.4 分）答案：B**
控制面 ~5 req/s，循环单条调用会秒级触发 `Throttling`/`PriorRequestNotComplete`。正解是用单次 ChangeResourceRecordSets 打包多条 Changes。

**Q62（2.0 分）答案：A、B、C**
三分层对应三条不同数据路径：ROUTE53=权威 NS、ROUTE53_RESOLVER=递归（有 QPS 限流）、ROUTE53_HEALTHCHECKS=探测。D、E 混淆路径。

## 域 13 · 通用故障排查纪律

**Q63（1.4 分）答案：B**
单点失败 ≠ 服务故障，一次成功 ≠ 路径整体健康。永远先界定 blast radius 再归因：确定性全失败指向公共环节，概率性失败指向多路径中某一条。

**Q64（2.0 分）答案：A、B、C、D**
timeout=网络层（A）、NXDOMAIN=数据问题（B，E 错）、SERVFAIL=处理失败（C）、REFUSED=拒绝应答（D）。把 timeout 当"记录没配"、把 NXDOMAIN 当网络问题都是走错方向。

**Q65（问答，2.2 分）答案要点（四级 + 措辞纪律，全中给满分）**
四级证据强度：
- **DIRECTLY_OBSERVED**：从客户真实导出/日志/工具输出直接读到 → 措辞"已确认/observed"。
- **DOCUMENTED_FACT**：官方文档明确规定的行为（如 VPC DNS = CIDR base+2）→ 措辞"根据文档"。
- **INFERENCE**：由观测+文档推出、存在反例可能 → 措辞"suggests/很可能"，不用"is/确认"。
- **UNKNOWN**：未验证、需客户提供 → 列入索取清单，绝不当事实写进结论或承诺。
纪律：每个断言对应一个级别；证据不足时不把 INFERENCE 说成根因（不做唱因归因），宁可回"这是一处确认的阻断，另有 A/B 需确认"，也不唱一个未经证实的单一根因。

---

## 评分与段位对照表（Scoring & Weakness Map）

### 一、总分段位

| 分数段 | 段位 | 说明 |
|---|---|---|
| 90–100 | **SME 精通（Expert）** | 可独立主导 R53 复杂 case，覆盖全域 |
| 80–89 | **熟练（Proficient）** | 重点域扎实，个别边缘知识点需补 |
| 70–79 | **及格（Pass）** | 达到 SME 基线，建议对错题域专项复习 |
| 60–69 | **待提升（Below Bar）** | 未达线，重点域存在系统性缺口 |
| < 60 | **需重训（Retrain）** | 建议通读题库 + 手册后重考 |

### 二、各知识域得分占比 → 薄弱域提示

> 算法：某域得分率 = 该域实得分 ÷ 该域满分。**得分率 < 70% 即列为薄弱域**，按下表定位补强方向。

| 域 | 题号范围 | 该域满分 | 薄弱时优先复习 |
|---|---|---|---|
| 01 Hosted Zones | Q1–Q4 | 5.8 | zone 合并顺序、PHZ 解析边界、最具体匹配、KSK 删除 |
| 02 记录与 Alias ⭐ | Q5–Q10 | 9.0 | apex 用 Alias、Alias vs CNAME、simple RRset、解析优先级 |
| 03 路由策略 ⭐ | Q11–Q18 | 12.2 | latency vs geo、default 兜底、weight=0、fail-open、ECS |
| 04 健康检查 ⭐ | Q19–Q25 | 11.0 | 内部资源用 CW HC、HTTPS 不校验证书、18% 聚合、阈值、abuse 流程 |
| 05 Resolver ⭐ | Q26–Q33 | 13.0 | VPC+2、.2 不过 SG/NACL、Forward>PHZ、In/Out 方向、`.`规则、QPS |
| 06 DNS Firewall | Q34–Q38 | 8.2 | 域名层过滤、priority 小优先、Action 面、CNAME 链、ALERT 日志 |
| 07 DNSSEC | Q39–Q43 | 7.0 | 禁用顺序、DS/DNSKEY 位置、island of trust、KMS CMK、+cd 判别 |
| 08 子域接管 | Q44–Q47 | 6.2 | Scenario 1 防护、≥1 NS 重叠、删除顺序、hold 续命 |
| 09 域名注册 | Q48–Q51 | 6.2 | .jp 特性、注册≠解析、账号关闭恢复、赎回期 |
| 10 Profiles | Q52–Q54 | 4.8 | 打包分发本质、local>Profile、四类可打包资源 |
| 11 ARC | Q55–Q58 | 6.2 | 开关非探针、data plane 5 endpoint、3/5 quorum、safety rule |
| 12 服务集成/配额 | Q59–Q62 | 6.2 | apex CNAME、数据面 vs 控制面限流、批量打包、ip-ranges 三分层 |
| 13 排查纪律 | Q63–Q65 | 6.6 | blast radius、响应码方向、四级证据分级 |
| | **合计** | **100** | |

### 三、薄弱域行动建议

- **重点加权域（02/03/04/05）任一 < 70%**：这些是考试主力域，优先回读对应章节的题库 + 手册对应 Topic，并把错题对应的真实 case 通读一遍。
- **DNSSEC（07）/ ARC（11）< 70%**：多为"顺序/位置/机制"记忆点，建议做流程图（如 DNSSEC 启用/禁用顺序、ARC 切流链条）强化。
- **排查纪律（13）< 70%**：这是横切方法论，薄弱会影响所有域答题措辞——重点掌握"blast radius 先界定""响应码方向""四级证据分级 + 不唱因归因"。
- **多选题失分集中**：注意多选须选全且不多选，复习时对每个选项逐一判断对错，而非只记正确项。

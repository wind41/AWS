# Codex 审校 findings — topic 14 技术原理深挖（2026-09-20）

核心确认正确：stub/recursive/authoritative 分层、Route53 anycast+四 stripe、VPC Resolver 不发 ECS、18% 聚合规则、DS→DNSKEY→RRSIG 信任链方向正确。以下需修正：

### 递归解析路径
1. "TLD 委派必须附带四个 awsdns glue，否则死循环"错误 → glue 只对 in-bailiwick（委派域内）NS 必需；awsdns-* 是委派域外名称，可独立解析，不依赖该 child delegation 的 glue（RFC 9471）。
2. "AA=1 表示应答可信"易误导 → AA 只表示该服务器对此答案有权威性，不提供密码学真实性；只有 DNSSEC 验证成功 + AD 标志才表示 authenticated data（RFC 4035）。
3. "只有递归解析器缓存，stub 不缓存"过绝对 → OS/本地代理/应用都可能缓存；VPC Resolver(Nitro) 也维护本地短期缓存，上游故障时甚至可能提供超 TTL 缓存答案。
4. "Route53 权威侧改动秒级生效/几乎总已更新"过强 → 变更通常 60 秒内传播到全部 R53 NS，应以 GetChange=INSYNC 确认，不能只归因递归 TTL。
5. "Public/Private hosted zone 都直接对应权威 NS"需区分 → PHZ 数据经 VPC Resolver 私有连接访问；直接查其公开 awsdns 地址不会返回 PHZ 数据。

### Anycast 与四组 NS
6. "全球 50+ edge / 约 80% resolver 选最低 RTT" 是 2014 架构博客测量 → 只能作设计背景，不能当权威现行数字断言。

（其余 VPC Resolver/health checker/DNSSEC 密码学部分 Codex 未列出新错误，视为方向正确。）

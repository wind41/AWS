# Codex 校验 findings — P2 新域 18/19/20（2026-09-20）

## topic 18 Traffic Flow
核心正确：policy=版本化配置树、policy record=API policy instance、仅 public zone、隐藏底层记录、未关联 policy 免费、instance $50/月按部分月折算、默认 50 policies/账号 + 1000 versions/policy + 5 instances/账号（policies/instances 可提额）。修正：
1. "复杂 alias 树"过窄 → Traffic Flow 编排的是同一 DNS 类型的路由记录树，节点可为规则或 endpoint，不要求都是 Alias。
2. "秒回滚"易误导 → UpdateTrafficPolicyInstance 有控制面处理时间，应轮询 instance state；递归缓存仍使客户端看到旧答案至 TTL 到期。
3. "Alias 指向根 policy record 只付一份 $50"不完整 → 只产生一条 policy-record 月费，但这些 Alias/CNAME 查询仍按 DNS query 计费。
4. Geoproximity：2024-01 起可直接在 public/PHZ 创建；不要说交互地图是 Traffic Flow "唯一剩余价值"（还有版本化/嵌套/跨 zone 复用）。

## topic 19 IAM 治理
核心正确：route53:* / route53resolver:* / route53profiles:* action 命名空间不可混写；DNSSEC KMS key policy 授权 dnssec-route53.amazonaws.com 执行 DescribeKey/GetPublicKey/Sign + 带 kms:GrantIsForAWSResource=true 的 CreateGrant，可加 SourceAccount/SourceArn；RAM 可共享 Resolver rule/Route53 Profile/DNS Firewall rule group（共享配置对象非 endpoint 本身，消费账号仍需关联自己 VPC）。修正：
1. "List/Get 都只能 Resource:*" 错误 → 逐 action 判断；ListHostedZones 用 *，但 GetHostedZone/ListResourceRecordSets/GetDNSSEC 等支持 hosted-zone ARN。

## topic 20 Resolver 高级
（Codex 校验被截断未列新错误。修正 subagent 请按官方现行文档核对以下点的准确性：Resolver delegation rules 2024 新增、autodefined/system rules、DoH/DoH-FIPS、IPv6 dual-stack endpoint、DNS64 需搭 NAT Gateway、Resolver on Outposts、outbound endpoint 每 ENI 约 10K QPS 且建议 ≥2 AZ。有不准处一并改。）

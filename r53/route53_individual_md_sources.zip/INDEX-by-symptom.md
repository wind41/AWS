# Route 53 SME —— 多维检索入口索引（INDEX-by-symptom）

> **用途**：接到 case / 考题时，先在本索引按「症状 / 响应码 / API·CLI / 硬数字 / 选型信号词」定位，直达对应 topic 与小节，再去读正文。硬数字冲突一律以 `framework/00b-canonical-facts.md` 为权威。
> **topic 目录**：`/Users/leichenz/case-knowledge-base/route53-sme-versions/snapshots/route53-sme/topics/`
> topic 文件全清单：`00a` DNS协议基础、`01` Hosted Zones、`02` 记录与Alias、`03` 路由策略、`03b` 路由×HC×Failover深挖、`04` 健康检查、`05` Resolver混合DNS、`06` DNS Firewall、`07` DNSSEC、`08` subdomain takeover、`09` 域名注册生命周期、`10` Profiles、`11` ARC、`12` 集成与配额、`13` 排查纪律、`14` 技术原理深挖、`15` 可观测性、`16` 成本模型、`17` 同症状异根因对照库。

---

## 维度一：按症状（Symptom → Topic）

### SERVFAIL（服务器返回失败）
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| 全域突然全部 SERVFAIL | stale delegation（父区委派 NS 指向已删/失效 zone）、DNSSEC 信任链断 | `17`§类别一SERVFAIL；`07` DNSSEC 信任链/island of trust；`08`§1 悬空委派 |
| 启用 DNSSEC 后 SERVFAIL | DS 记录未在父区/算法不匹配、island of trust、resolver 验签失败 | `07`§信任链·DS·island of trust；`14` 底层机制 |
| 仅混合 DNS 环境 SERVFAIL | 转发规则目标不可达、outbound endpoint 故障、on-prem DNS 拒答 | `05`§Resolver Rule / Inbound·Outbound；`17`§SERVFAIL |
| 排查方法论（SERVFAIL 定位树） | 证据分级 + dig 逐层 | `13`§证据分级·dig；`17`§使用方法 |

### NXDOMAIN（域名不存在）
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| PHZ 记录存在却返回 NXDOMAIN | resolv.conf fallback 到公共 DNS 未命中 PHZ、VPC 未关联 PHZ、DNS hostnames/support 未开 | `05`§resolv.conf fallback / .2 resolver；`01`§1.2 PHZ 启用前提与关联 |
| DNS Firewall 命中后 NXDOMAIN | BLOCK 动作响应 NXDOMAIN；allowlist 里 CNAME 目标未列被拦 | `06`§ALLOW·BLOCK·ALERT / BLOCK 响应；`06`§Domain redirection |
| 重叠命名空间解析到错 zone | 最长匹配未命中预期 zone | `01`§split-horizon / 重叠命名空间最长匹配 |

### NODATA（域名存在但该类型无记录）
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| CloudFront/AWS 资源间歇 NODATA | resolver identity 间歇、目标资源类型无该记录 | `12`§服务集成 Alias·CloudFront NODATA；`17`§间歇超时 |
| DNS Firewall ALERT 命中难区分 | ALERT action=Allowed，只能靠日志区分 | `06`§ALERT / OCSF query log；`15`§Query Logging |

### 解析不一致（同名不同答案 / 时对时错）
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| 同名内外网不同答案 | split-view / split-horizon 设计 | `01`§split-horizon；`17`§类别二解析不一致 |
| 加权/延迟策略返回值飘 | 策略本就返回不同值、latency 非实时、weight 分配 | `03`§路由策略；`03b`§各策略+HC 行为 |
| resolver 缓存 vs 权威不一致 | TTL 未过期、负缓存 | `14` 底层机制；`00a` DNS 基础 |

### failover 不切换 / 切换异常
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| 主挂了不切备 | HC 判定未 Unhealthy、18% checker、Evaluate Target Health 配置、fail-open | `04`§判定机制·18% checker·fail-open；`03b`§Failover+HC |
| CALCULATED HC 一直 Unhealthy | 父子 HC 阈值、子 HC 健康数不足 | `04`§四类HC·Calculated 父255子 |
| Alias 目标健康但不切 | Evaluate Target Health 二选一未开、Alias 与 HC 冲突 | `12`§Evaluate Target Health；`02`§Alias |
| 多 Region/AZ 灾备切换 | ARC Routing Control / Zonal Shift / 手改 failover 记录 | `11`§Routing Control·Zonal Shift；`03b`§Failover |

### 间歇超时（时好时坏 timeout）
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| VPC 内解析间歇超时 | 触顶 1024 PPS/ENI、endpoint ENI QPS、NACL 双向 | `12`§1024 PPS；`05`§ENI QPS·多ENI+NACL；`17`§间歇超时 |
| 混合 DNS 间歇超时 | outbound endpoint 过载、NAT 出公网、UDP vs TCP | `05`§ENI/NLB 降速·outbound NAT；`13`§dig +tcp |

### subdomain takeover / 安全类
| 症状细分 | 最可能根因方向 | 直达 topic·小节 |
|---|---|---|
| 删 zone 后子域被他人接管风险 | dangling delegation、NS hold 失效 | `08`§1.3 StopZoneSniping·5 Scenario；`08`§删 zone 正确顺序 |
| DNS 数据外泄怀疑 | 需 DNS Firewall 出站过滤、DGA/隧道检测 | `06`§防 exfiltration·DGA·DNS tunneling |

---

## 维度二：按错误码 / 响应码 / 状态（Code → 落点）

| 码 / 状态 | 含义 | 直达 topic·小节 |
|---|---|---|
| SERVFAIL | 递归器无法完成解析（委派断、DNSSEC 验签失败、转发目标不可达） | `17`§SERVFAIL；`07` DNSSEC；`05` Resolver Rule |
| NXDOMAIN | 权威明确「无此名」（或 Firewall BLOCK） | `01` 最长匹配；`05` resolv.conf fallback；`06` BLOCK |
| NODATA（NOERROR + 空 answer） | 名存在但无该类型记录 | `12` CloudFront NODATA；`17` |
| REFUSED | 服务器拒答（非权威、ACL 拒绝） | `13`§故障签名；`14` 权威定位 |
| InsufficientDataHealthState | HC 三态之一，数据不足 | `04`§判定机制·三态 |
| Healthy / Unhealthy（HC） | 18% checker 多数判定 | `04`§18% checker |
| GetChange = PENDING / INSYNC | 变更未/已全球同步（INSYNC=全球生效） | `12`§DNS changes 同步；`13` |
| clientHold（域名 EPP 状态） | 账号关闭/欠费导致解析停 | `09`§生命周期·clientHold |
| DNSKEY / DS / RRSIG | DNSSEC 记录（新 ZSK 出现属正常轮换） | `07`§KSK·ZSK·RRSIG·DS |

---

## 维度三：按 API / CLI（命令 → 落点）

| API / CLI / 工具 | 场景 | 直达 topic·小节 |
|---|---|---|
| `dig` `+short` `+trace` `+tcp` `CNAME` 类型 | 逐层解析定位、UDP/TCP 区分 | `13`§dig 用法；`17`§使用方法；`00a` |
| `dig @169.254.169.253` / `.2 resolver` | 直验 VPC DNS 命中 PHZ | `05`§.2 resolver；`01` |
| `dig TXT o-o.myaddr.google.com` | 检测 resolver 是否支持 ECS | `03`§EDNS0/ECS |
| `nslookup` UDP vs TCP | 出站/入站/路由/目标故障区分 | `05`§差分诊断；`17` |
| `UpdateHealthCheck`（CLI/API） | 触发 HC 重评估 | `04`§CloudWatch alarm-based HC lab |
| `VpcAssociationAuthorization` / `AssociateVPCWithHostedZone` | 跨账号 PHZ 关联 | `01`§1.2 跨账号关联 |
| `get-contact-reachability-status` | 域名联系人可达性 | `09`§reachability |
| `GetChange` | 判断变更是否 INSYNC 全球同步 | `12`；`13` |
| `jq` 解析 `ip-ranges.json`（ROUTE53 分类） | 提取权威 NS CIDR + 订阅 SNS | `12`§ip-ranges·AmazonIpSpaceChanged |
| CloudWatch Logs Insights 查 OCSF `firewall_rule_id` | 区分 ALERT/ALLOW 命中 | `06`§OCSF query log；`15`§Query Logging |
| `kubectl exec` 看 `/etc/resolv.conf` / CoreDNS dnsPolicy | Pod 解析路径 | `05`§resolv.conf fallback |
| 内部工具 Info Search / Customer Info Search / Dexter / K2 / lse.amazon.com | 排查起点 | `13`§内部工具 |

---

## 维度四：按硬数字 / 边界（Number → 落点）

> 权威源：`framework/00b-canonical-facts.md`。以下为「见到这个数字/限制该翻哪」。

| 硬数字 / 边界 | 结论要点 | 直达 topic·小节 |
|---|---|---|
| **1024 PPS / ENI 不可调** | VPC DNS 每弹性网卡查询上限，触顶即间歇失败 | `12`§配额·1024 PPS；`05` |
| 每 zone 10,000 记录（超收费） | Hosted Zone 记录上限 | `12`§配额 |
| 单 RRset 400 值 | 记录集值上限 | `02`§RRSET；`12` |
| weight ≤ 255；权重 0 | 加权路由上限与 0 行为 | `03`§Weighted；`03b`§1.1 |
| geoproximity bias −99..99（含0）；上限 30（同名同类型），其他 100 | 地理近邻偏置与配额 | `03`§Geoproximity；`12` |
| multivalue ≤ 8 | 多值应答上限 | `03`§Multivalue |
| 18% checker | 健康检查多数判定阈值 | `04`§18% checker |
| HTTP 4s+2s / TCP 10s / string match 5120 字节 | HC 超时与匹配限制 | `04`§判定机制 |
| KSK / zone ≤ 2；ZSK 轮换 7–30 天 | DNSSEC 密钥限制 | `07`§KSK·ZSK；`12` |
| 签名 zone 记录最大有效 TTL 一周（原 TTL<一周不受影响） | DNSSEC TTL 强制 | `07`§TTL |
| 每 PHZ 300 VPC 关联（>300 建议改 Profiles） | PHZ 关联上限 | `01`；`10`§何时用 Profiles；`12` |
| 1 VPC 只能 1 Profile | Profile 关联约束 | `10`§1.3 |
| 公共 API 账号桶：持续 10 RPS / 突发 50 | Route 53 API 限流 | `12`§配额限流 |
| DNS changes：持续 100/s / 突发 1500 | 变更限流 | `12`§配额限流 |
| Resolver API 约 5 RPS（另算） | Resolver 独立限流 | `12`§配额限流 |
| endpoint ≤ 6 ENI、~10K QPS/ENI（经 NLB/SG 降至 ~1.5–1.7K） | Resolver endpoint 吞吐 | `05`§ENI QPS |
| Zonal Shift 最长 72h | ARC 时限 | `11`§Zonal Shift |
| ARC 指标在 us-west-2；DNSSEC/配额管理走 us-east-1 | 区域约束 | `11`；`07`；`12` |
| GetChange = INSYNC 表示全球已同步 | 变更同步判据 | `12`；`13` |
| 成本档位（HZ 月费 / query 分档 / HC 计费） | 计费模型 | `16`§Hosted Zone 月费·Query 分档 |

---

## 维度五：按选型信号词（客户说 X → 看哪个 topic）

| 客户 / 题干说的话（信号词） | 指向能力 / 结论 | 直达 topic·小节 |
|---|---|---|
| "顶点/根域名要指向 ELB/CloudFront/S3" | 只能用 A/AAAA Alias（CNAME 不能在 apex），Alias 免费+可开 ETH | `02`§1.3 Alias vs CNAME；`12`§集成 Alias |
| "按比例/灰度/金丝雀分流" | Weighted 路由（weight≤255，权重0=不参与） | `03`§Weighted；`03b`§1.1 |
| "就近/最低延迟访问" | Latency 路由（非实时，基于 AWS 测量） | `03`§Latency |
| "主备/自动灾备切换" | Failover 路由 + HC（+可选 ARC） | `03`§Failover；`03b`；`11` |
| "按国家/地区返回不同内容/合规" | Geolocation（配 default 兜底，最小区优先） | `03`§Geolocation |
| "按地理距离并想手动偏置流量" | Geoproximity（bias±99，2024 起支持普通记录） | `03`§Geoproximity |
| "返回多个健康 IP 让客户端自选" | Multivalue（≤8，带 HC） | `03`§Multivalue |
| "按客户端 IP 段路由" | IP-based（CIDR；PHZ 不支持） | `03`§IP-based |
| "内网私有域名解析 / 内外网不同答案" | Private Hosted Zone / split-view | `01`§PHZ·split-horizon |
| "on-prem 与 AWS 互相解析 / 混合云 DNS" | Resolver Inbound/Outbound + 转发规则（Rule>PHZ>公网） | `05` 全篇 |
| "统一给多账号多 VPC 下发 DNS 配置" | Route 53 Profiles（RAM 同 Region，1 VPC 1 Profile） | `10` 全篇 |
| "阻止 DNS 出站到恶意域 / 防数据外泄 / 防隧道" | DNS Firewall（出站按域名，DGA/tunneling 检测） | `06` 全篇 |
| "要让解析结果可被验真 / 防篡改" | DNSSEC signing（KSK 用户 KMS，DS 在父区） | `07` 全篇 |
| "删了子域担心被别人接管" | dangling delegation / subdomain takeover 防护 | `08` 全篇 |
| ".jp / .pay 域名 / 到期日对不上 / 转移锁" | TLD 特性与生命周期 | `09`§TLD·到期日·转移 |
| "AZ 级/Region 级快速隔离故障" | ARC Zonal Shift / Autoshift / Routing Control | `11` 全篇 |
| "要看 DNS 查询日志 / 谁改了记录 / 趋势告警" | Query Logging + CloudTrail + CloudWatch 指标 | `15` 全篇 |
| "这套 DNS 方案要花多少钱 / 怎么省" | 成本模型（HZ 月费 + query 分档 + HC） | `16` 全篇 |
| "解析全挂了帮我查" / "先从哪查" | 通用排查树 + 证据纪律 | `13` 全篇；`17` |
| "同样报错但原因好像不一样" | 同症状异根因对照库 | `17` 全篇 |
| "想搞懂 DNS 底层怎么走的 / 递归迭代 / anycast" | 协议基础 + 技术原理深挖 | `00a`；`14` |

---

> 检索建议：先用「维度五选型信号词」或「维度一症状」锁定 1–2 个 topic，再用「维度四硬数字」核对边界结论，最后回 `00b-canonical-facts.md` 确认权威数字。

# Route 53 SME 全局复习思维导图（Mermaid Mindmap）

> 用途：一张图串起 13 个知识域的全局复习地图。根 = Route53 SME；一级 = 13 个知识域；二级 = 每域关键子点；三级 = 每子点下 SME 高频考点/易错点（一句词，可条件反射）。
> 来源：`framework/00-knowledge-framework.md` 驱动表 + `topics/01-13` 各域「SME 考点/易错点」节。
> 可 git 版本化；可直接粘贴进支持 Mermaid 的编辑器；下附「如何用 Oracle Studio 生成交互式 mind map」。

---

## 全局复习 Mindmap

```mermaid
mindmap
  root((Route53 SME))
    01 Hosted Zones
      Public vs Private HZ
        PHZ需enableDnsHostnames/Support
        PHZ只经VPC DNS解析
      VPC关联
        跨账号需VpcAssociationAuthorization
        每PHZ上限300 VPC
      Split-horizon
        同名PHZ按最长匹配胜出
        重叠命名空间最具体域胜
      合并vs分离
        零停机合并降TTL先建全记录再切委派
        apex必含NS+SOA
    02 记录与Alias
      支持的记录类型
        A AAAA CNAME MX TXT SRV CAA NS SOA DS
        CNAME不能与他类型共存
      Alias vs CNAME
        apex只能Alias不能CNAME
        Alias免费不能设TTL支持ETH
        Alias链不可再指Alias
      TTL与RRSET
        Simple单RRset返回全部值随机排序
        8值上限属MVA非Simple
    03 路由策略八种
      Simple
        无健康检查
      Weighted
        权重上限255
        权重0仅在全不健康时按权重参与
      Latency
        非实时基于测量表
      Failover主备
        fail-open两者都不健康返回Primary不可配
      Geolocation
        default兜底无default返回no answer
        最小地理区优先
      Geoproximity
        bias正负1到99上限30需Traffic Flow
      Multivalue
        最多8条需健康检查
      IP-based
        CIDR匹配PHZ不支持
      EDNS0/ECS
        点2支持EDNS0不支持ECS
    04 健康检查
      四类HC
        Endpoint/Calculated/CloudWatch/Recovery
        Calculated父255子
        新建HC默认健康
      判定与阈值
        18% checker多数判定
        HTTP4s加2s TCP10s string5120字节
        HTTPS不校验证书为高频陷阱
      与Failover绑定
        Evaluate Target Health二选一
        fail-open全不健康返Primary
      滥用与源
        HC源IP走prefix list
        Unwanted HC abuse禁用需2PR
    05 Resolver混合DNS
      VPC Resolver点2
        VPC+2地址不过SG/NACL
      Inbound/Outbound
        Inbound on-prem到AWS
        Outbound AWS到on-prem出公网需NAT
      Forward Rule优先级
        Forward Rule大于PHZ大于公网为核心
        dot点为全局兜底rule
        RAM跨账号共享同Region成员不可改
      容量与陷阱
        每endpoint至多6 ENI约1万QPS
        经NLB/SG降至约1500到1700
        resolv.conf fallback公共DNS致PHZ NXDOMAIN
    06 DNS Firewall
      出站域名过滤
        防数据外泄exfiltration
      规则优先级
        priority数字从小到大
        ALLOW需domain list Advanced只BLOCK/ALERT
      BLOCK响应
        NXDOMAIN/NODATA/OVERRIDE
        Domain redirection检查整条CNAME链
        白名单未覆盖CNAME target被BLOCK
      高级与治理
        DGA/DNS隧道高级检测
        Global Resolver加DNS View加OCSF日志
        ALERT命中靠日志区分
    07 DNSSEC
      角色分工
        signing让resolver验真非validation
        RRSIG对整个RRset签名
      KSK vs ZSK
        KSK用户KMS非对称CMK用户轮换每zone2把
        ZSK由R53自动预发布轮换双ZSK并存正常
      信任链
        需父zone支持DS
        island of trust有DNSKEY无父DS
        禁用先解信任链可跳删DS
      硬限制
        启用后TTL强制1周
        PHZ不支持不支持vanity NS
    08 子域接管/悬空委派
      dangling委派
        CNAME向量指向已释放S3/EB/CloudFront
        不把ELB DNS名列为典型可抢注目标
      subdomain takeover原理
        释放资源后委派仍在被他人抢注
      Route53防护
        StopZoneSniping与5个Scenario
        删zone先解委派/先删NS记录
        DNSSEC作为纵深防护
    09 域名注册/生命周期
      注册商vs托管
        Registrar到Registry到WHOIS
        不支持注册的TLD不影响建zone
      生命周期
        续期到赎回redemption不保证
        账号关闭suspend约30天删clientHold
      到期日
        注册商到期日vs注册局到期日
        jp月末更新差异为高频易错
      转移
        跨账号须源账号发起EPP auth code
        转移锁jp2025/10起不支持
    10 Route53 Profiles
      打包分发
        分发机制非取代PHZ
        可含PHZ/Resolver rule/Firewall/endpoint
      关联约束
        每VPC只能关联1个Profile
        Profile资源VPC必须同Region靠RAM共享
      优先级
        最具体匹配优先同名冲突时local优先
        大于300 VPC-PHZ关联建议改用
    11 ARC应用恢复控制
      两大能力
        Multi-AZ Zonal Shift最长72h fail-open
        Multi-Region Routing Control加Readiness
      Routing Control
        是确定性开关非探测
        灾难用cluster data plane非control plane
        5-Region cluster三取五quorum
        safety rule防同时关两区
      指标位置
        Readiness指标在us-west-2
        ARC非必须failover记录也能切
    12 集成与配额
      Alias目标
        ELB/CloudFront/S3/API GW/GA/VPC endpoint
        apex必A-Alias ACM DNS验证走CNAME
        CloudFront间歇NODATA
      边界数字
        1024 PPS每ENI不可调
        每zone一万记录超收费单RRset400值
        geoproximity同名同类型30其他100
        KSK每zone2 API令牌桶容量40补5每秒
      管理位置
        配额管理在us-east-1
        ip-ranges.json ROUTE53分类订SNS变更
    13 排查纪律横切
      证据分级
        DIRECTLY_OBSERVED/DOCUMENTED/INFERENCE/UNKNOWN
      范围判定
        单点失败vs全局失败
        必要非充分条件不可倒推
      故障签名
        SERVFAIL/NXDOMAIN/NODATA/REFUSED区分
      dig判读
        short/trace/tcp逐层定位
        标准树whois到NS到HZ到CloudTrail收敛
      工具
        Info Search/Dexter/K2 先看lse
```

---

## 高频必考速记（配合上图条件反射）

- **Alias**：只能建 apex（CNAME 不能）/免费/不能设 TTL/支持 Evaluate Target Health/不可链指另一 Alias。
- **路由策略**：weight≤255、权重 0 行为；geolocation 有 default 兜底、无则 no answer；geoproximity bias±99 + 上限 30 + 需 Traffic Flow；multivalue≤8；Simple 无 HC；IP-based PHZ 不支持。
- **健康检查**：18% checker 多数判定；HTTPS 不校验证书；Evaluate Target Health 二选一；fail-open 全不健康返 Primary。
- **Resolver**：`Forward Rule > PHZ > 公网`；VPC DNS 不过 SG/NACL；outbound 出公网需 NAT；resolv.conf fallback 致 PHZ NXDOMAIN。
- **DNS Firewall**：priority 数字从小到大；ALLOW 需 domain list；Domain redirection 查整条 CNAME 链。
- **DNSSEC**：KSK=用户 KMS / ZSK=R53 自动；启用后 TTL 强制 1 周；PHZ 不支持；signing≠validation；island of trust。
- **Profiles**：每 VPC 只 1 个；同 Region；最具体胜、同名冲突 local 优先。
- **ARC**：Routing Control 是开关非探测；Zonal Shift ≤72h；5-Region cluster；指标在 us-west-2。
- **配额**：1024 PPS/ENI 不可调；每 zone 10000 记录；geoproximity 30；KSK/zone 2；API token bucket 40/5；配额/DNSSEC/Domains 管理走 us-east-1，R53 本身全球服务。

---

## 如何用 Oracle Studio 生成交互式 mind map

上面的 Mermaid mindmap 已可版本化、可粘贴进任何支持 Mermaid 的渲染器。若要一份**可交互展开/折叠、可点击下钻**的 mind map，用内部的 **Oracle Studio**（不要用外部工具处理内部资料）：

1. **访问入口**：通过内部 **Harmony console** 进入 Oracle Studio。该工具为**申请制**，需先申请访问权限;支持渠道为 Slack **#oracle-studio-support**。
2. **准备上传素材**：把本项目的知识资料作为语料上传——
   - `framework/00-knowledge-framework.md`（主框架 / 驱动表 / 总览 mindmap）；
   - `topics/01-*.md` ~ `topics/13-*.md`（13 个知识域全文）。
   这些是内部研究整理的备考资料。
3. **选择输出类型**：在 Oracle Studio 里选择 **MindMap 输出**，让它基于上传语料生成分层、可交互的思维导图（可展开各知识域到子点、考点层级下钻）。
4. **迭代**：以本文件的三级结构（域 → 子点 → 考点一句词）作为组织提示，让生成的 mind map 与本复习地图对齐；再按需精修节点。

> **合规红线（务必遵守）**：内部资料一律走内部工具（Oracle Studio / Harmony console），**不上外部 Google NotebookLM 或任何外部 AI 服务**。framework 与 topics 属内部研究整理内容，只在内部受控环境处理。

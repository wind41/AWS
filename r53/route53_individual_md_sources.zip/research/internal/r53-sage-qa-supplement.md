# Route 53 SME 备考 —— Sage / infosearch case-QA 补充（深化搜索 B）

> 目的：从 **Sage / answers.amazon.com（AWS 内部 Q&A / case 库）** 提炼 SME 高频问答与边界结论，**与已有 `r53-internal-research.md`（wiki/playbook/TFC 骨架）不重复的新内容优先**。
> 说明：这些答复多来自 Route 53 服务团队专家（gavinmc / elsenc / eriknie / devineja / zob / jdamick 等），常带 NDA 级的内部实现细节，是"权威口径"级素材。每条带 Sage/answers 来源链接（需 Midway 登录）。
> 检索工具：InternalSearch（SAGE_HORDE 域）。检索日期：2026-09-20。
> **与第一块的关系**：第一块给的是"知识域 + 边界数字 + wiki 导航"；本块给的是"专家在真实客户 case 里怎么答、坑在哪、为什么"，可直接当口试/情景题答案模板。

---

## A. Evaluate Target Health (ETH) —— SME 最易答错的一组（专家原话）

已有 research 只写了"ALIAS 指 ELB 用 ETH"。以下是团队专家在 case 里澄清的**深层语义**，几乎每条都是常见误区：

- **ETH 只对 ALIAS 记录有效**；非 ALIAS 记录（普通 A/CNAME + Weighted/Latency/Failover）用的是"关联的 Health Check"，两者是不同机制。同一条记录**同时**配 ETH 和 Health Check 是**不推荐**的，会导致不一致/不可预期的结果（gredlerj）。
  来源：https://answers.amazon.com/posts/49136
- **ELB（含 internal / 私网 ALB、NLB）本身已经被 Route 53 健康检查**——ELB 是 R53 的内部客户，R53 对 100% 的 ELB IP（包括客户的）都有健康检查。要利用它，只需在指向 ELB 的 ALIAS/CNAME 记录上勾选 **ETH**，**不需要**再自建 endpoint HC（zob）。这与第一块"内部 ALB 不能用 endpoint HC"的说法互补：**你不需要**对 ELB 自建 HC，用 ETH 即可；只有当目标**不是** ELB（如自建应用、跨服务组合判断）时，才退回 CloudWatch alarm-based / calculated HC。
  来源：https://answers.amazon.com/posts/269205 、https://answers.amazon.com/posts/31821
- **ETH 什么时候"有效"、什么时候"无效"**（gavinmc 的精确表述）：
  - **Simple routing** 下 ETH **无效**（单记录永远按值应答，无论健康与否）。
  - 只有当**同一域名下有多条 ALIAS**（Weighted/Geo/Failover 等）时 ETH 才"有意义"：某条 ALIAS 全部健康检查失败 → 该 ALIAS 整体判为 unhealthy → 流量转到其他 ALIAS。
  - 经典例子：两个 NLB 各挂后端、用 1:1 加权。若对一个 NLB 部署了破坏性变更，想让它退出服务，**必须 ETH=True**；ETH=False 时那条无 HC 的 ALIAS 仍留在 DNS 里、继续吃约一半流量。
  - **VPC Endpoint 通常不需要 ETH**：单 VPC 内一个 service 只能建一个 endpoint，一般没有第二个 endpoint 可切；且 ALIAS 到 VPCE 时**无论 ETH 设什么，AZ 故障时不健康 IP 都会被自动摘除**（gavinmc 建议一律设 True，"要么正确要么无害"）。
  来源：https://answers.amazon.com/posts/225168 、https://answers.amazon.com/posts/102167
- **ETH=True 到底检查了什么（NLB 场景，under the hood）**：不仅看"该 AZ 是否有 NLB 节点在监听端口"，还会看 **NLB 后端 target 是否健康**。判定规则（rupbajaj 整理）：
  - NLB 侧：跨区关闭时，某 AZ 的 NLB 节点只对**本 AZ** target 做 HC；"该 AZ 至少一个 target group 里有健康 target"→ 该 AZ 的 NLB IP 才进 DNS。
  - target 侧：有 >1 个 TG 且任一 UNHEALTHY → FAIL；都非空且都不 UNHEALTHY → PASS。
  - **ETH 与 HC 同时开时：两者都必须通过**，才算 target 健康。
  - NLB 跨区开/关**不影响 ETH 判定**。
  来源：https://answers.amazon.com/posts/302118

## B. Failover 路由的确切判定逻辑（背下来当口试标准答案）

第一块已写"全 unhealthy 时 fail open 到 Primary"。这里补 Route 53 团队/专家的**逐条精确表述**（可直接复述）：

- Primary 健康 → 只返回 Primary。
- Primary 不健康、Secondary 健康 → 返回 Secondary。
- Primary + Secondary **都不健康 → 返回 Primary**（fail-open 到 primary，不可配置）。
- **验证 failover 的实操**：在目标服务器安全组上移除 NLB VPC IP（或直接 term 主 target、关掉 autoscaling）再查记录，观察 IP 变化。
  来源：https://answers.amazon.com/posts/302118
- **基于 CloudWatch alarm 的跨区 failover 的常见坑**：HC 要指向**目标区自定义 CW 指标/alarm**，且主/备记录的 **ETH 都要设 False**（因为健康信号来自 CW alarm 而非 target 本身），否则 failover 不触发。这是一个真实 case 里客户卡住的点。
  来源：https://answers.amazon.com/posts/302118

## C. Resolver —— NDA 级实现细节（第一块没有的"为什么高可用"）

- **一次 EC2 查询是"双路并行 + droplet 缓存"**（gavinmc，标注 NDA、可能变化）：EC2 发起查询时，会**并行**发到**同 AZ 内两个独立 resolver cell**；每个 cell（若未命中缓存）各自经 outbound endpoint 转发。故障时查询仍有很高概率被解析。**Nitro 实例**在 droplet 层还有**stale caching（陈旧缓存）**。→ 这解释了为什么"Resolver rule 没有 failover 也能高可用"。
  来源：https://answers.amazon.com/posts/298092
- **Resolver rule 没有内建 failover**：多个 target IP 时**逐个尝试**（顺序≈随机，不按填写顺序），拿到有效响应即返回。这不是"发给所有 IP 取最快"（那是 droplet 层的并行）。要"切走某上游"只能**改 rule**（控制面操作，可用性略低但事件期大概率可行）。
  来源：https://answers.amazon.com/posts/298092 、https://answers.amazon.com/posts/308985
- **R53 不提供 BIND 的 `forward-first`**：所有查询转发到某上游（如 `.` rule 指 Cisco Umbrella），若上游全挂**不会**自动回落到公网根做递归解析。gavinmc 明确说"这通常是好事，forward-first 结果不可预期"。要回落只能删除 dot rule（API 操作）。
  来源：https://answers.amazon.com/posts/298092
- **`.2` resolver 会缓存 outbound endpoint 回来的响应**（遵守记录 TTL，不会缓存更久），高查询量时 DNS query log 里看到的请求数会**少于**按 TTL 推算的次数。
  来源：https://answers.amazon.com/posts/148541
- **Outbound endpoint 不给转发查询加 EDNS0/ECS**：经 outbound 转出的查询，源看起来是 R53 outbound resolver（RFC1918 私网 IP），不是发起 EC2。**这是遵守 RFC 7871**（私网客户端子网信息不应被转发），不是缺陷。想在权威侧做"按原始源审计"→ 用 **Resolver Query Logging**（会记录经 `.2` 或 inbound endpoint 的全部查询，无论后续是否经 outbound 转发）。
  来源：https://answers.amazon.com/posts/125893
- **多上游返回不一致时**：R53 逐个查 IP、返回第一个有效响应，顺序≈随机。若主/备权威未同步（zone 未传输完），可能拿到旧数据。正解是配好 primary/secondary + 每次改 zone 强制重传，或降低 TTL / 上 DDNS——**R53 无法察觉上游是否是权威误配**（可能是 DNS 劫持征兆）。
  来源：https://answers.amazon.com/posts/308985
- **Inbound 会经 Outbound（同 VPC）**：查 Inbound endpoint 的域名若匹配某条引用 Outbound 的 resolver rule，链路是 `Client → Inbound → Resolver → Outbound → Target IP`——即 inbound 查询也会被 outbound 规则捕获转出去。
  来源：https://answers.amazon.com/posts/250042
- **Resolver endpoint 是 Regional，不能放到 Outposts 子网**：Outposts 上的 resolver ENI 走 LGW 到 on-prem 是**不支持配置**；区域内资源无法经 LGW 连 on-prem，转发流量必须走 VPN/DX。EC2 上 nslookup 直连 on-prem DNS 能通、但经 resolver endpoint 就失败，就是这个原因。
  来源：https://answers.amazon.com/posts/324249

## D. DNSSEC —— 专家口径与深层限制（补第一块的 KSK/ZSK）

- **KSK 只签 ZSK，不签记录；记录由 ZSK 签**。KSK 是 KMS 里的**非对称**客户密钥，**用得极少**（启用 DNSSEC 时、R53 轮换 ZSK 时才用，一年可能就几次）。ZSK 由 R53 托管、不按查询签（只在增删记录或签名过期时签），客户**不为 ZSK/查询付费**。DNSSEC 本身免费，成本≈KMS 存 key（$1/月/key）+ 极少量 KSK 签名请求（非对称 $0.15/万次）。
  来源：https://answers.amazon.com/posts/295706
- **同一 CMK 复用到多个 zone → KSK 相同**：4 个 zone 用同一 CMK，公钥（KSK）相同，但**DS 记录值会不同**（ECDSA P-256 每次签名值不同），任取一个 zone 的 DS 上报 RIR 即可。**注意**：KSK 虽相同但是**不同资源、各有独立状态**（zone1-3 可 ACTIVE、zone4 可 INACTIVE）。最佳实践：**不要跨故障域共用 CMK**（如 prod / non-prod 分开）。
  来源：https://answers.amazon.com/posts/361110
- **R53 DNSSEC 签名算法固定为 ECDSA Curve P-256 with SHA-256（algorithm 13）**，目前不支持选其他算法。
  来源：https://answers.amazon.com/posts/237074
- **不支持 multi-signer / 多厂商 active-active DNSSEC**：多厂商需协调共同的 DNSKEY recordset（共同 KSK/ZSK 并同步轮换），R53 **不实现** RFC 8901。多厂商无 DNSSEC 尚可（限极简 vanilla 记录、无 HC/alias/加权/MVA/geo，同 zone 双发布），加 DNSSEC 就做不到。
  来源：https://answers.amazon.com/posts/193786
- **Resolver（AmazonProvidedDNS / `.2`）的 DNSSEC 校验语义**（gavinmc 澄清文档歧义）：
  - "只对 R53 public signed name 校验、不校验 forwarded zone"的真意是：**只有当 resolver 自己在做递归解析时才做 DNSSEC 校验**，与域名托管在哪无关；转发给其他 resolver 时由那个 resolver 校验。
  - `.2` resolver **会**做 DNSSEC 校验（校验失败返回 **SERVFAIL**，不放行伪造响应），但**忽略 DO/CD bit、不返回 RRSIG、不置 AD bit** → 客户端侧（如 `delv`）无法自行校验。要客户端级 DNSSEC 必须自建递归 DNS。
  来源：https://answers.amazon.com/posts/363292
- **GovCloud DNSSEC**：public zone 当时不在 GovCloud，用商业区（us-east-1）public zone + **us-east-1 的 KMS** 做 DNSSEC 签名指向 GovCloud 资源；这不影响 FedRAMP-high 合规（DNSSEC 继承父服务授权，无附加认证）。DNSSEC **validation** 在所有有 Resolver 的区（含 GovCloud）可用。内部页：`w.amazon.com/bin/view/Route53/GovCloud/UsingIADRoute53FromGovCloud`。
  来源：https://answers.amazon.com/posts/185073
- **该不该开 DNSSEC（客户沟通话术，gavinmc 长文）**：最明确收益是**满足合规要求**（近年需求上升多因监管）；否则收益有限——目前只有少数 resolver 做校验，且校验只在 resolver↔权威之间、client↔resolver 仍可被欺骗；DNSSEC **不加密、不提供隐私**（隐私靠 DoH/DoT）。DNSSEC 复杂、"锋利边缘"多（举 Slack 因 R53 一个 bug + 回滚太快没算 resolver 缓存而放大故障为例）。风险主要在**DS 记录设置/委派**与**KSK 轮换**（仍是手动操作）。建议合规无硬要求的客户"wait and see"。
  来源：https://answers.amazon.com/posts/315038

## E. Public/Private Hosted Zone 解析优先级与"重叠命名"（补第一块）

- **PHZ 优先且"最靠近根的 zone 先匹配"**：真实踩坑——同一 VPC 里若存在覆盖某域名根的 PHZ，会**优先于 public zone**接管解析，即使 public zone 才有想要的记录。公私 zone **不能重叠**（不只是"不能同名"，是不能共享同一根域）。解法：在 PHZ 里补一条镜像记录（如指向 LB 的 A 记录），或删掉不该有的 PHZ。多个用户在同一帖里印证。
  来源：https://sage.amazon.dev/posts/1631425
- **PHZ 不支持委派（NS 记录）**：想在 AWS 内切分命名空间，不必委派——把"父" PHZ（example.com）与"子" PHZ（team1.example.com）**都关联到同一 VPC**，R53 视为"重叠命名空间"，效果≈委派；on-prem 侧再配 outbound endpoint 即可同样解析。只有当子域要委派给/来自**非 R53 权威 NS（如 on-prem）**时才撞上"PHZ 不支持委派"的功能缺口，此时用 DNS 转发绕过。
  来源：https://answers.amazon.com/posts/158095
- **Split-horizon（split-brain）是受支持但不推荐的架构**：公私 zone 同名各维护一份，最大风险是"改了一边忘了另一边"导致解析行为不一致、难排查。专家（girvenj）反复劝退：能用 outbound resolver 指向对方 DNS 就别做 split-brain。
  来源：https://answers.amazon.com/posts/152924 、https://answers.amazon.com/posts/275057
- **跨账号关联 PHZ 到别账号 VPC 无法在控制台做**，必须用 CLI/SDK/API：先 `create-vpc-association-authorization`（在 PHZ 所有者账号）再 `associate-vpc-with-hosted-zone`（在 VPC 所有者账号）。（用 Route 53 Profiles 可免此授权步骤，见第一块第 8 节。）
  来源：https://answers.amazon.com/posts/362257
- **Split-horizon 按"客户端 IP/ISP"路由不可靠**：因无法保证终端用户用的是 ISP 的 DNS（可能用 8.8.8.8），源 IP 判断会错、返回错记录。此类需求应转为**访问控制问题**（Lambda@Edge 判 IP 段重定向 + 网络边缘封锁 IP 段），而非靠 DNS。私网 IP 可以放进 public zone，但仍受"控制不了用哪个 resolver"限制。
  来源：https://answers.amazon.com/posts/327005

## F. 委派 / 子域 / Dangling delegation（补第一块的故障签名）

- **子域不解析 = 父域缺 NS 委派记录**：最常见根因是"在父 zone 忘了建指向子 zone NS 的委派记录"，或**父/子 NS 不匹配**。子域 zone 名与父域里那条委派记录名必须一致，否则报"record not found"（内部会开 Sev2）。
  来源：https://sage.amazon.dev/posts/1169026 、https://sage.amazon.dev/posts/1075333
- **Dangling delegation（悬挂委派）= 安全 Sev2**：父域有 NS 委派指向的子 zone 被删除/迁移到别 tenant 后，委派 NS 指向已无权威的 nameserver，攻击者可能接管子域。**删/迁子 zone 的正确顺序**：删除时先删父域 NS 委派、再删子 zone；迁移时先更新父域 NS 记录。几乎没有防护栏自动阻止（rja）。这解释了 Palisade/AWS Security 的 Dangling Delegation Sev2 来源。
  来源：https://sage.amazon.dev/posts/1341655
- **"两个同名 hosted zone"陷阱**：R53 里存在两个同名 zone、把 apex ALIAS 加到了**没有被委派**的那个 → 解析不到。排查要确认记录建在**被委派的那个 zone ID / 账号**里。CDK/SuperStar 自动化里尤其常见。
  来源：https://sage.amazon.dev/posts/1169026

## G. 域名注册（Route 53 Domains）—— 内部账号的实操口径

- **内部（Isengard/Internal-flagged）账号不能通过 R53 registrar 购买公网域名**（报 "account not authorized"），但**可以正常建 hosted zone**（无特殊限制）。
- **内部测试/项目要域名的正确路径**（重要更新，别再教旧法）：
  - 用 **SuperNova** 自助申请 `aws.dev` / `amazon.dev` 子域（推荐，现代做法）。
  - 或 **Nova** 申请 `a2z.com` 子域（内部/个人用途，免费）。
  - 真实业务域名走 **Hostmaster**（Mark Monitor 是 Amazon 官方 registrar）。
  - ⚠️ **不要**再教"用个人账号买域名再委派到公司账号"——已有专家在帖里指出这是**安全策略违规、会被 flag**；也**不要**把这类请求发给 Route 53 Domains team（会被拒），该走 Hostmaster。
  来源：https://answers.amazon.com/posts/1224

## H. 其他零散 SME 边界结论（Sage 印证，快速记）

- **AZ-specific answer 不支持跨 AZ failover**：需用 az-specific answer + alias + failover primary/secondary + 其他 AZ 的 WRR + HC 组合来实现"先本 AZ、挂了转其他 AZ、全挂 fail-open 回本 AZ"。
  来源：https://sage.amazon.dev/posts/527430
- **同一 ELB 可被多条加权记录引用**（用于比 weight 上限更细的分配）——印证第一块第 3 节。
- **R53 无跨 DNS 厂商 failover**：所有 NS 记录被客户端随机使用，切换 DNS 厂商本身要数小时~数天。AWS 自身仅对**遗留** zone 用多厂商，新 zone 全靠 R53 的四数据面模型（2022/08 起 **100% data plane 可用性 SLA**，唯一 100% SLA 的 AWS 服务）。多厂商同步靠自建 API，风险高（缺原子性、丢 HC/加权等特性、排查难）。
  来源：https://answers.amazon.com/posts/349694
- **Route 53 是"一族服务"**（elsenc 常用澄清）：权威 NS（外部/内部）、递归 Resolver（含转发 endpoint）、DNS Registrar、DNS Firewall——回答 IPv6/功能问题前先问清客户指哪一个。R53 支持 **AAAA 记录 + 端到端 IPv6 解析**；但**指定域名的 health check 默认走 IPv4**，要 IPv6 健康检查须直接填 IPv6 地址。
  来源：https://answers.amazon.com/posts/308256
- **`*.amazonaws.com` 经 R53 Resolver 解析**：R53 Resolver 是递归 resolver，正常**不会**把查询发给 8.8.8.8（除非客户显式配转发规则）；amazonaws.com 域大多已在 R53 Public DNS（权威），Resolver→Public DNS 走 AWS backbone（~95% 命中本 AZ），基本不出网。但**不承诺"零互联网查询"**（递归时可能要问根/com 等外部权威）。
  来源：https://answers.amazon.com/posts/311720
- **PHZ Geolocation 用 VPC 源区域判定**：私网源 IP 无地理元数据，PHZ 里的 geolocation 用"发起查询的 VPC 所在区域"判定。客户担心 R53 公网侧被"画像"时的正解：继续在 AWS 里跑自建 resolver（R53 是托管多租户服务，出网查询混在其他租户里难被单独画像）。
  来源：https://answers.amazon.com/posts/314027

---

## 附：本块可直接背诵的"专家口径速记"

- ETH 只对 ALIAS 有效；Simple 路由下 ETH 无效；同一记录别同时配 ETH + HC。
- ELB（含 internal/私网）已被 R53 健康检查——勾 ETH 即可，别自建 endpoint HC；非 ELB 目标才用 CW alarm/calculated HC。
- Failover：Primary 健康→Primary；Primary 挂 Secondary 健康→Secondary；都挂→Primary（fail-open）。CW-alarm 跨区 failover 时主备 ETH 都设 False。
- EC2 查询双 resolver cell 并行 + Nitro droplet stale cache（NDA）；Resolver rule 无内建 failover、逐个试 target；R53 无 BIND forward-first。
- `.2` 会缓存 outbound 响应（守 TTL）；outbound 不加 EDNS0/ECS（守 RFC 7871）；要按源审计用 Query Logging。
- KSK 只签 ZSK、极少用、客户 KMS 非对称 key；ZSK R53 托管自动轮换、免费；算法固定 ECDSA P-256/SHA-256；不支持 multi-signer；`.2` 校验失败返回 SERVFAIL 但不返回 RRSIG/不置 AD bit。
- 公私 zone 不能重叠；PHZ 优先且最靠近根的先匹配；PHZ 不支持 NS 委派（用同 VPC 挂父+子 PHZ 替代）；跨账号关联 PHZ 只能 CLI/API。
- 悬挂委派 = 安全 Sev2；删/迁子 zone 先处理父域 NS 委派。
- 内部账号不能买公网域名（能建 zone）；测试域名走 SuperNova(aws.dev/amazon.dev) / Nova(a2z.com)，业务域名走 Hostmaster；别用个人账号买了委派（违规）。
- Split-horizon 受支持但不推荐；按 ISP/客户端 IP 路由不可靠（控制不了 resolver），应转为访问控制。
- R53 100% data plane SLA（2022/08，唯一）；无跨厂商 DNS failover。

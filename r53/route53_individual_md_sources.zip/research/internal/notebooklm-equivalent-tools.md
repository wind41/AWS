# 用户 #7 专项 —— Amazon 内部 NotebookLM 同类工具 / 文档转导图工具调研

> 目的：确定本项目（Route 53 SME 备考）用什么方式从 markdown / 架构描述自动生成"架构逻辑导图（mind map / knowledge graph / auto-diagram）"。
> 检索工具：InternalSearch（ALL / WIKI / BROADCAST 域）。检索日期：2026-09-20。
> 结论先行：**内部有对标 NotebookLM 的工具（Oracle Studio），并且能直接把文档生成 mind map。但"用 API 从 markdown 生成导图"这条路，推荐用内部 Mermaid（文本即导图，可脚本化/版本化），Oracle Studio 作为"一键把整份文档转成可视化 mind map"的补充。**

---

## 一、有没有类似 NotebookLM 的内部工具？—— 有，主力是 Oracle Studio

### 1. Oracle Studio ⭐（首选，Amazon 官方对标 NotebookLM，RED Certified）

- **定位**：Amazon 内部的 NotebookLM 替代品，RED-Certified（可处理关键/机密内部数据，数据不出 Amazon 基础设施）。数千 Amazonian 使用中（2024 底至今）。
- **能生成什么**：把文档（BRD / PRFAQ / 设计文档 / runbook / wiki / spec）转成 **podcast、PowerPoint、infographic、90 秒动画摘要、web app、以及 mind map（思维导图）**。还有 **Study Mode + 3D 可视化**。
- **能否从 markdown/架构描述生成导图**：**能**。官方用例明确写着"**Create interactive mind maps from complex architecture documents**"（从复杂架构文档创建交互式思维导图）、"MindMap visualization — creates structural overviews from wikis and spec documents"。上传/粘贴文档 → 选 mind map 输出即可。
- **入口 / 访问方式**：
  - 通过 **Harmony console** 访问，除 Midway 认证外无需额外 setup。
  - 当前为**申请制**（sign-up sheet / Quip 表单，一分钟注册，早期访问约 4 周，团队在放开长期访问）。
  - Sign-up 入口（从工具目录链出）：TPM AI Builders 页的 "ORACLE-STUDIO-sign-up-sheet"、AI Tools for TPMs 页的 "Oracle Studio [Sign up]"。
  - 支持渠道：Slack **#oracle-studio-support**。
- **是否有可编程 API 从 markdown 生成导图**：**未发现公开的可编程 API**。Oracle Studio 是 web/console 交互式工具（上传文档→选输出格式），目前没有检索到"用 API / CLI 从 markdown 批量生成 mind map"的接口文档。若本项目需要**可脚本化、可版本控制**地生成导图，Oracle Studio 不是理想路径（见第二节 Mermaid）。
- **来源**：
  - All Things AI 2026-02-03（Oracle Studio 专题，列全部输出格式含 MindMap）：https://w.amazon.com/bin/view/AllThingsAI/2026_02_03/
  - FBABlackbird AI Tips 2026-05-06（"Oracle Studio — Amazon's NotebookLM Alternative"，用例含 "Create interactive mind maps from complex architecture documents"，Harmony console 入口）：https://w.amazon.com/bin/view/FBABlackbird/AI/Tips/
  - TPM AI Builders（Oracle Studio 条目 + sign-up sheet 链接）：https://w.amazon.com/bin/view/Tpm-ai-builders/
  - AI Tools for PMs/TPMs/SDMs（工具目录，Knowledge Management 段列 Oracle Studio [Sign up]）：https://w.amazon.com/bin/view/DavidWu/AI-Tools-for-TPMs/
  - Broadcast 演示视频："[AI for All] Document/JIRA Intelligence & Visualization Suite with AI Studio Oracle"（2025-10-10，演示 mind map / PPT / infographic / podcast 生成，作者 Sasha）：https://broadcast.amazon.com/videos/1715924

### 2. LocalNotebookLM（内部自建，可本地/团队部署，路线图含 mind map）

- **定位**：某开发者用内部 AWS 服务自建的 NotebookLM 风格工具。技术栈：**Vectra 向量库 + Titan embeddings + Bedrock LLM + Amazon Polly（音频）**。
- **能力**：文档上传（多格式）、相似度检索、对话式问答、音频摘要（Polly）。**mind maps / quizzes / flashcards 在路线图上（计划中，未必已 GA）**。
- **入口**：内部包 **LocalNotebookLM**（可内部部署）。Kiro PM 已表示兴趣讨论集成。
- **是否有 API 生成导图**：本质是可自建/可改代码的包，理论上可编程，但 mind map 功能"计划中"，当前不成熟。适合想自己控管数据/流程的团队，不适合"开箱即用生成导图"。
- **来源**：All Things AI 2026-01-16（"Amazon Teams Build LocalNotebookLM"）：https://w.amazon.com/bin/view/AllThingsAI/2026_01_16/

### 3. MindCraft（GraphRAG，知识图谱方向）

- **定位**：把 tribal knowledge 做成 **GraphRAG（知识图谱 + RAG）**。宣称 1.6x 生产力、2.6x 更快 CR 审批。
- **与本项目相关性**：偏"知识图谱检索/问答"，不是"从一份文档一键出 mind map 图片"。如果目标是构建 Route 53 知识**图谱**（概念间关系网络）而非流程/思维导图，MindCraft 值得看。
- **入口**：有 UI + Wiki。来源：AI Tools for TPMs 页（Knowledge Management 段）https://w.amazon.com/bin/view/DavidWu/AI-Tools-for-TPMs/

---

## 二、从 markdown / 架构描述"用 API/文本"生成导图 —— 首选内部 Mermaid

### 4. Mermaid（内部版）⭐（最适合"markdown/文本→导图、可版本化"的路线）

- **定位**：文本即图（diagram-as-code）。Mermaid 支持 **mindmap、flowchart、sequence、class、state** 等图类型。任意 LLM（Kiro / Cedric / Q）都能"给我一个这些内容的 mind map，用 mermaid"直接产出 mermaid 代码。
- **内部可用性**：**有内部版 Mermaid**（外部 mermaid.live 非内部；内部有等价渲染服务）。内部 GenAI 分享会明确演示：让 AI 生成 mermaid mind map 代码 → 粘到（内部）Mermaid 渲染即可。
- **能否 API/脚本从 markdown 生成导图**：**能，且这正是它的强项**。mermaid 是纯文本，天然可版本控制（进 git）、可脚本批量渲染、可嵌进 wiki/文档。对本项目"架构逻辑导图 + 要能随知识更新迭代/纳入版本管理"的诉求最契合。
- **相关内部工具**：**AI Draw.io**（AI 驱动的 draw.io 画图，AI Tools for TPMs 页 "Diagramming" 段）也可作为架构图路线，但不是纯文本可版本化。
- **来源**：
  - Broadcast "MMSRO GenAI Knowledge Sharing Series - Existing GenAI tools and how to use them"（演示"give me a good mind map for these ideas in mermaid" → 内部 Mermaid 渲染）：https://broadcast.amazon.com/videos/1525359
  - AI Tools for TPMs（Diagramming 段：Marp / AI Draw.io / Venue / Nova Image Gen）：https://w.amazon.com/bin/view/DavidWu/AI-Tools-for-TPMs/

### 5. DAG — Diagram Architecture Generator（架构图，非思维导图）

- **定位**：Tampermonkey 用户脚本，把 **AWS support case 文本**自动分析成**架构图**（识别 AWS 服务及其关系，10 秒内出图，官方 AWS 图标）。作者 danajid。
- **与本项目相关性**：面向"case 文本→AWS 架构拓扑图"，**不是知识/逻辑思维导图**。若本项目要画的是"Route 53 各组件如何连接"的架构拓扑（如 Resolver endpoint / PHZ / VPC 关系），DAG 思路可参考；但它绑定 support case 场景，不通用于任意 markdown。
- **来源**：https://w.amazon.com/bin/view/Users/danajid/DAG-DiagramArchitectureGenerator/

---

## 三、配套方法：把散乱文档做成"知识库/关系图"的 prompt recipe

### 6. "Build a Complete Knowledge Base"（可复用 prompt recipe，非工具）

- 一个可交给任意 agent（NotebookLM / Kiro / 任意 LLM）的六步 prompt：读全量 → 分类 → **连接知识（建立概念/流程/框架间的显式关系图 relationship graph）** → 设计检索索引 → 找 gap → 汇总产出（map + 文件树 + roadmap）。
- 与本项目相关性：**这正是"生成知识逻辑导图/关系图"的方法论骨架**——先让 agent 建"relationship graph"，再用 Mermaid mindmap/graph 渲染出来，能版本化。
- 来源：https://w.amazon.com/bin/view/Users/trhieung/Kiro_Knowledge_base/

---

## 四、结论与推荐（针对本项目"架构逻辑导图"）

**内部有没有 NotebookLM 同类工具？—— 有。** 主力是 **Oracle Studio**（RED-Certified，能一键把架构文档转 interactive mind map），备选 LocalNotebookLM（自建/可改）、MindCraft（GraphRAG 知识图谱）。

**用哪个生成本项目的导图？分两种诉求：**

1. **要"可版本控制、可随 SME 知识迭代、能进 git/wiki、可脚本生成"的架构逻辑导图** → **首选内部 Mermaid（mindmap/flowchart/graph）**。理由：纯文本、天然版本化、任意 LLM 直接产出 mermaid、内部有渲染。完全契合本项目把产物纳入 route53-sme-versions 版本仓的做法。可先用 "Build a Knowledge Base" recipe 让 agent 输出概念关系，再转 mermaid mindmap。

2. **要"漂亮的交互式 mind map / 一键把整份文档可视化 / 顺带出 PPT/infographic/podcast 复习材料"** → **用 Oracle Studio**（Harmony console，申请制，#oracle-studio-support）。缺点：交互式 web 工具，**未发现可编程 API**，不利于版本化/脚本化，产物难以纳入本地版本仓。

**给本项目的落地建议**：
- **导图产物本体用 Mermaid**（写进 `.md`/`.mmd`，进 route53-sme-versions 快照仓，可随知识更新 diff/版本化）。
- 需要给自己做**沉浸式复习**（podcast/PPT/交互 mind map）时，把 r53-internal-research.md 丢进 **Oracle Studio** 生成一次性复习材料。
- 若后续要做"Route 53 概念**知识图谱**（概念间关系网络）"，评估 **MindCraft (GraphRAG)**。

**关于外部 NotebookLM 本身**：Google NotebookLM 也支持 mind map 输出，且 Canvas 特性在扩展交互可视化；但**Amazon 内部数据不应上传到外部 NotebookLM**（数据合规），这正是 Oracle Studio（RED-Certified）存在的原因。故本项目涉及内部资料时**不要用外部 NotebookLM**。
- 参考（外部 NotebookLM 特性动态）：https://w.amazon.com/bin/view/Users/vencedua/News/tldr-ai/articles/2026-06-02/3-upcoming-notebooklm-features/

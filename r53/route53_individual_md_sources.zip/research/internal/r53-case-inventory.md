# Route 53 SME 备考 — 真实案例清单与主题聚类

> 来源目录：`/Users/leichenz/Case/r53`（只读摄取，未修改任何源文件）
> 生成时间：2026-09-20
> 案例总数：15 个真实案例（含 Support Case 与内部 HaaS TT）+ 3 份 DNS Firewall 教学素材
> 用途：Route 53 SME 备考的真实案例库与知识域索引

本清单基于每个 case 的 `_analysis.md` / `_investigation.md` / `_full_investigation.md` 一手读取。case ID 末位仅取 analysis 主文件，reply/state 为同一 case 的衍生文档，不单列。

---

## 1. 逐 Case 一行摘要表

| Case ID | 问题域 | 客户症状（一句话） | 根因（一句话） | R53 知识点标签 |
|---|---|---|---|---|
| 178970323600938 | DNS解析 / Hosted Zone / DNSSEC | EC2 上 `dig` 某公网域持续 SERVFAIL，同时想禁用 DNSSEC 遇两处报错 | 解析路径事发时取到旧 NS 委派组、旧 NS 已不托管该 zone 返 REFUSED → SERVFAIL（旧 NS 来源层未唯一确定）；DNSSEC 侧为 island of trust | stale delegation, NS 委派变更, SERVFAIL, DNSSEC disable, island of trust, KMS KSK, 负缓存 |
| 178791950000232 | 域名注册 | 客户想注册 `.pay` 域名，问 AWS 能否走注册局公开 LRP 之外的路径预留/注册 | Route 53 当前不支持 `.pay`；注册局只发布一条 LRP 路径，无面向终端注册人的预留/例外流程 | 不支持的 TLD, LRP, registrar vs registry, Salesforce PFR/TLD feature request, TAM advocacy |
| 178782060900806 | 路由策略 / Resolver / PrivateLink | 大客户 split-horizon + PrivateLink 多区 DR，问关闭爱尔兰路径时如何 failover | 现设计把 DNS 解析和 PrivateLink 数据路径都绑死在爱尔兰 Egress VPC；Resolver rule 优先于同名 PHZ；单 failover pair 无法同时表达两个故障维度（非缺陷） | Resolver rule regional, rule 优先 PHZ, PHZ 跨区关联, 私网 failover 健康检查, 跨区 PrivateLink, Route 53 Profiles, DNS 与连通性解耦 |
| 178767531400698 | Resolver / VPC Networking | Linux EC2 无法加入 AD 域，`nslookup` 对 VPC DNS 三次全超时 | Outbound Resolver Endpoint 的 ENI2 子网 NACL 出站命中 DENY 10.0.0.0/8、入站缺 UDP ephemeral 放行；三次全超时提示 ENI1 路径亦可能有问题（NACL 修复是必要非充分） | Outbound Resolver Endpoint, 多 ENI 行为, NACL DNS 放行, VPC DNS 不过 SG/NACL, AmazonProvidedDNS=CIDR+2, 差分诊断 |
| 178715620200407 | Hosted Zone / DNS安全 | 外部研究员报告子域可被 subdomain takeover（dangling delegation） | child zone 曾存在被删、父域委派未同步删（Scenario 1）；接管时点该组 NS 的 hold 为何不在效需服务团队查后端 | dangling DNS delegation, subdomain takeover, StopZoneSniping/NS hold, 删 zone 顺序（先删 NS 记录）, DNSSEC 防护, 共享责任, abuse 报告流程 |
| 178636929200282 | 域名注册 / Hosted Zone | 源账号在域名转移完成前被关闭，三个域名 clientHold、DNS 全断 | 账号关闭触发域名关闭流水线（通知→suspend→约30天删除），同时阻断自助转移（转移须由源账号发起） | 账号关闭域名流水线, clientHold, 跨账号域名转移, 重开自动 unsuspend, hosted zone AES isolation, 跨账号 support 合规边界, 时效性 TT |
| 178602594200640 | 路由策略 / Resolver | 公网 PHZ 中 A(Alias) 指向新 NLB，但 VPC 内解析仍返回旧 Apigee ELB | VPC 内存在 `spglobal.com` Forward Rule 与 dot(.) 全局 Forward Rule 转发到企业 DNS(Infoblox)，Forward Rule 优先级高于 PHZ/公网，查询在 Resolver 层被拦截转发 | VPC DNS 解析优先级, Resolver Forward Rule > PHZ > 公网, dot(.) 全局 rule, hybrid DNS, 企业 DNS 迁移不同步 |
| 178602958500732 | DNS解析 / IP范围 | 客户问 ip-ranges.json 里哪个 service 是 R53 权威 NS、如何取子网、更新频率 | 纯咨询：`ROUTE53`=权威 NS；用 jq 过滤；无固定更新周期，变更走 SNS `AmazonIpSpaceChanged` | ip-ranges.json, ROUTE53 vs ROUTE53_RESOLVER/HEALTHCHECKS, NS IP 静态, SNS 变更通知, 防火墙放行 DNS delegation, Anycast |
| 178246722300140 | 路由策略 | 客户咨询 Geolocation 路由用什么 IP 库、更新频率 | 纯咨询：R53 用第三方（MaxMind）GeoIP 库，AWS 不公开披露供应商；周更新+自动摄取；用 EDNS0 提升定位精度 | Geolocation routing, MaxMind GeoIP（不对客披露）, EDNS0 client-subnet, Default 记录, dns-test 工具 |
| V2254930641 | 健康检查 (HaaS) | 受害客户 ALB 持续收到不需要的 R53 Health Check 探测 | 另一 AWS 账号创建的 HC 指向了不属于它的 IP（受害账号 ALB）；联系冒犯方7天无回复后经 Mechanic 强制禁用 | Unwanted Health Check abuse, HC IP User-Agent 识别, Mechanic controlapi disable-health-check, 2PR review, 禁用≠删除, outbound case 流程 |
| P460958645 | 健康检查 (HaaS) | CloudWatch Alarm 已转 OK，但 R53 CALCULATED Health Check 卡在 Unhealthy 约53分钟 | CW Alarm 恢复 OK 后 HC 状态同步异常延迟（正常应1-2分钟），疑 HC control plane / 状态传播；`UpdateHealthCheck` 触发重评估后恢复 | CloudWatch alarm-based/CALCULATED HC, InsufficientDataHealthState(Unhealthy/Healthy/LastKnownStatus), HC 状态同步延迟, UpdateHealthCheck 触发重评估 |
| 178239640400861 | Resolver / DNS解析 | 多个 `inner.yxaws` PHZ 私有域名间歇性 "Name does not resolve" | K8s Pod 的 `/etc/resolv.conf` 含公共 DNS fallback（223.5.5.5/223.6.6.6，写死在镜像），CoreDNS 慢时 fallback 到公共 DNS，公共 DNS 无法解析 PHZ → NXDOMAIN | Private Hosted Zone, resolv.conf 多 nameserver fallback, ndots, CoreDNS/EKS dnsPolicy, 公共 DNS 无法解析 PHZ, ENI 1024pps DNS 限流 |
| 178238086600080 | 域名注册 | `.jp` 域名 Route 53 控制台到期日与 JPRS WHOIS 到期日不一致，状态码显示 "-" | `.jp` 注册局已知行为：WHOIS 到期日始终显示到期月月末、旧到期月过后才更新到新年份；`.jp` 不支持锁定故状态 "-"；对客户无影响 | .jp TLD 特性, registry vs Gandi 到期日, 续期窗口 D-30~D-6, 不支持 transfer lock, 无 late renewal |
| 178222843600312 | Hosted Zone / DNS解析 | 客户三个域名 DNS 解析昨天正常今天突然全失效（中文，进行中） | 排查方向（whois/NS/HZ/CloudTrail）：域名过期/被暂停 or NS 被改 or 记录被删 or 账户计费问题（未定性收敛） | 域名突然解析失败排查, NS 记录核对, DeleteHostedZone/ChangeResourceRecordSets 审计, CloudTrail 排查 |
| 178118102100384 | Hosted Zone | 客户问是否应把 `prod.habitat-energy.au` 子域 PHZ 合并进父域 `habitat-energy.au` | 咨询/最佳实践：合并技术可行但推荐保持分离（客户面 vs 内部的管理边界、爆炸半径隔离）；给出零停机合并步骤 | Hosted Zone 合并 vs 分离, 子域委派(NS delegation), TTL 降低零停机迁移, IAM 管理边界, 删 zone 前先建全记录 |

---

## 2. 按 R53 知识域聚类（每个知识域下的可教学真实案例）

### 知识域 A：DNS 解析优先级 / Resolver / Hybrid DNS
VPC 内 DNS 解析优先级、Resolver Endpoint（inbound/outbound）、Forward Rule 与 PHZ 的关系。
- **178602594200640**（★核心教学）— Forward Rule 优先于 PHZ/公网；dot(.) 全局 rule；企业 DNS 迁移不同步。最能讲清"公网记录改对了但 VPC 内还是旧值"的完整优先级链。
- **178767531400698**（★核心教学）— Outbound Resolver Endpoint 多 ENI + 子网 NACL 逐条比对；VPC DNS 不过 SG/NACL 的纠错；必要非充分条件的排查纪律。
- **178782060900806** — Resolver rule regional、同名 rule 优先 PHZ 的文档铁律（split-horizon DR 场景）。
- **178239640400861** — resolv.conf 多 nameserver fallback；PHZ 只能经 VPC DNS 解析；EKS/CoreDNS dnsPolicy。

### 知识域 B：Private Hosted Zone
PHZ 关联 VPC、跨区/跨账号关联、PHZ 覆盖公网行为、NXDOMAIN 不回退。
- **178239640400861**（★核心教学）— PHZ 私有域名解析失败的完整排查（配置正常 → 客户端 resolv.conf 才是根因）。
- **178602594200640** — 全局 PHZ 跨账号搜索、PHZ 无相关记录的排除法。
- **178782060900806** — PHZ 跨区/跨账号关联、同名 PHZ 不能同 VPC 双关联、私网 failover 健康检查。
- **178118102100384** — 子域 PHZ 合并进父域 vs 保持分离的权衡。

### 知识域 C：域名注册 / TLD 特性 / 生命周期
Registrar vs registry、TLD 特殊规则、续期窗口、账号关闭对域名的影响、跨账号转移。
- **178238086600080**（★核心教学）— `.jp` registry vs Gandi 到期日机制、月末更新规则、不支持锁定（附 2 个内部先例 V987680859 / P403473906）。
- **178636929200282**（★核心教学）— 账号关闭域名流水线、clientHold、跨账号转移、重开自动 unsuspend、时效性 TT 与合规边界。
- **178152467300391** — 域名注册卡在 registrar(GANDI) 侧（`.jp` "Pending state at Registrar"），升级 CTI 与 TT 模板。
- **178791950000232** — 不支持的 TLD（`.pay`）、LRP、PFR/TLD feature request 流程。
- **177886223300979** — WHOIS/RDAP Registrant Organization 因 ICANN Registration Data Policy 被后端隐去，registrar 侧修复无明确时间线（对客沟通/期望管理教学）。

### 知识域 D：健康检查（Health Check / HaaS）
Endpoint HC、CloudWatch alarm-based/CALCULATED HC、InsufficientDataHealthState、Unwanted HC abuse。
- **P460958645**（★核心教学）— CALCULATED（CloudWatch alarm-based）HC 卡 Unhealthy；InsufficientDataHealthState 三态；UpdateHealthCheck 触发重评估。
- **V2254930641**（★核心教学）— Unwanted Health Check abuse 全流程（识别 HC User-Agent → outbound case → Mechanic 禁用 → 2PR）。

### 知识域 E：DNSSEC
signing、KSK/CMK、信任链、island of trust、禁用顺序。
- **178970323600938**（★核心教学）— DNSSEC 禁用需先解信任链、island of trust（有 DNSKEY 无父域 DS）可跳删 DS、KSK 的 KMS CMK 要求（asymmetric ECC_NIST_P256）。

### 知识域 F：DNS 安全 / dangling delegation / subdomain takeover
- **178715620200407**（★核心教学）— dangling DNS delegation → subdomain takeover；Route 53 的 NS hold（StopZoneSniping）机制、Scenario 1-5、删 zone 正确顺序、DNSSEC 防护、共享责任、abuse 报告入口。

### 知识域 G：Route 53 基础设施 / IP 范围 / Anycast
- **178602958500732**（★核心教学）— ip-ranges.json 中 `ROUTE53`(权威 NS) vs `ROUTE53_RESOLVER` vs `ROUTE53_HEALTHCHECKS`；NS IP 静态；SNS `AmazonIpSpaceChanged` 变更通知；防火墙放行 zone delegation 流量；Anycast（不对客用此词）。

### 知识域 H：路由策略（Routing Policy）
- **178246722300140**（★核心教学）— Geolocation 路由的 IP 库（MaxMind，不对客披露）、EDNS0 client-subnet、Default 记录、dns-test 工具。
- **178782060900806** — failover 路由策略（组内全不健康返 primary）、私网 failover 设计。

### 知识域 I：DNS Firewall / Global Resolver（教学素材，非 case）
- **repost_article_dns_firewall_cn/en.md** — DNS Firewall repost 文章中英双版。
- **repost_draft_global_resolver_dns_firewall.md** / **...lab.md** — Global Resolver + DNS Firewall 架构草稿与可复现实验步骤。
- **dns_firewall_diagram.drawio** — 架构图（要点见第 4 节）。

### 知识域 J：通用故障排查纪律（横切）
- **178222843600312** — 域名突然全部解析失败的标准排查树（whois/NS/HZ/CloudTrail）。
- **178970323600938 / 178767531400698 / 178239640400861** — 证据分级（DIRECTLY_OBSERVED / DOCUMENTED_FACT / INFERENCE / UNKNOWN）、单点失败 vs 全局问题、必要非充分条件。

---

## 3. 案例适用性标注

### 3a. 特别适合做「知识点 + 案例说明」的 case
这些 case 的根因清晰、知识点单一且典型，讲一个概念带一个真实故事最有效：

| Case | 讲解的知识点 |
|---|---|
| 178602594200640 | VPC DNS 解析优先级：Forward Rule > PHZ > 公网（为什么改对了公网记录 VPC 里还是旧值） |
| 178767531400698 | Outbound Resolver Endpoint 多 ENI + NACL 需双向放行 DNS；VPC DNS 不过 SG/NACL |
| 178239640400861 | PHZ 只能经 VPC DNS 解析；resolv.conf fallback 到公共 DNS 导致间歇失败 |
| 178238086600080 | `.jp` registry vs registrar 到期日机制（月末更新，非 bug） |
| 178970323600938 | stale NS delegation → SERVFAIL；DNSSEC island of trust 与禁用顺序 |
| 178715620200407 | dangling delegation / subdomain takeover 与 NS hold 防护机制 |
| P460958645 | CloudWatch alarm-based HC 的 InsufficientDataHealthState 三态 |
| 178602958500732 | ip-ranges.json 的 ROUTE53 service 分类与 SNS 变更通知 |
| 178246722300140 | Geolocation 路由的 GeoIP 库与 EDNS0 |
| 178636929200282 | 账号关闭对域名/hosted zone 的影响与跨账号转移 |

### 3b. 含可复现实验步骤的素材
| 文件 / Case | 可复现内容 |
|---|---|
| **repost_draft_global_resolver_dns_firewall_lab.md** | ★完整分步 lab：建 Global Resolver → DNS View → Access Source → Query Logging → 自定义/托管/DGA Firewall 规则 → `dig` 验证 → CloudWatch Logs Insights 查 OCSF `firewall_rule_id`（30-40 分钟，含清理步骤） |
| 178767531400698（测试方案节） | 差分诊断命令：`nslookup`/`dig` UDP vs TCP（`-vc`/`+tcp`）、SRV 记录，用结果区分出站/入站/路由/目标 DNS 故障 |
| 178239640400861（调查节） | `dig @169.254.169.253` 直验 VPC DNS Resolver；`kubectl exec` 进 Pod 看 `/etc/resolv.conf` |
| 178602958500732（问题2节） | `jq -r '.prefixes[] \| select(.service=="ROUTE53") \| .ip_prefix'` 从 ip-ranges.json 提取 NS CIDR；SNS 订阅 `AmazonIpSpaceChanged` |
| V2254930641（操作步骤节） | Mechanic `controlapi disable-health-check` 禁用 HC 的完整参数（需 2PR review，仅 Support Ops 可执行，非客户可复现） |

---

## 4. DNS Firewall 架构图（dns_firewall_diagram.drawio）要点

图名 "DNS Firewall Architecture"，描绘 **Route 53 Global Resolver + DNS Firewall** 的端到端查询处理链，分三大区：

**左：Clients（客户端接入，三类）**
- Office（固定 IP / Do53）
- Remote User（Token / DoH）
- Branch Office（固定 IP / DoT）
- 三者的 DNS Query 汇聚指向 AWS 侧的 Anycast 入口。

**中/右：AWS Cloud → Route 53 Global Resolver (Anycast) → DNS View**
查询处理流水线（编号步骤）：
1. **Anycast IP** — Global Resolver 的任播入口。
2. **① Auth** — 按 Access Source / Access Token 鉴权（`✓ Authorized` 才放行到下一步）。
3. **② DNS Firewall**（核心大框）内含四类检测：
   - AWS Managed Domain List（托管恶意域名列表）
   - Custom Domain List（自定义域名列表）
   - DGA Detection（域名生成算法检测，Advanced Protection）
   - DNS Tunneling（DNS 隧道检测，Advanced Protection）
   - 结果动作：**BLOCK → NXDOMAIN**，**ALERT → Log**。
4. **③ Resolve**（ALLOW/Pass 路径）— 命中放行后按目标解析：
   - Private Hosted Zone（内部域名）
   - Public DNS（公网域名）
5. **Query Logging** — 以 **OCSF** 格式输出到 CloudWatch / S3（虚线旁路，记录全部查询）。

**关键教学点（与 lab 文档一致）**：
- Firewall 规则绑定到 **DNS View**，不是 VPC（区别于 VPC 型 Route 53 Resolver DNS Firewall）。
- 鉴权（Access Source/Token）在 Firewall 之前，是 Global Resolver 面向 remote/branch/on-prem 客户端的入口控制。
- Advanced Protection（DGA / DNS Tunneling）与域名列表不能放同一条规则。
- BLOCK 响应三选一：NXDOMAIN / NODATA / OVERRIDE(CNAME 重定向)。
- ALERT 命中的流量 `action_name` 仍为 `Allowed`，只能靠日志的 `firewall_rule_id` 区分，不能仅凭 `dig` 响应判断。

---

## 附：聚类出的知识域清单（速查）
A. DNS 解析优先级 / Resolver / Hybrid DNS
B. Private Hosted Zone
C. 域名注册 / TLD 特性 / 生命周期
D. 健康检查（Health Check / HaaS）
E. DNSSEC
F. DNS 安全 / dangling delegation / subdomain takeover
G. Route 53 基础设施 / IP 范围 / Anycast
H. 路由策略（Routing Policy：Geolocation / Failover 等）
I. DNS Firewall / Global Resolver（教学素材）
J. 通用故障排查纪律（证据分级 / 单点 vs 全局 / 必要非充分条件）

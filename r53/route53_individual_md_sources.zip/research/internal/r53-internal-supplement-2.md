# Route 53 SME 备考 —— 内部资料补充（第二块 / Supplement 2）

> 目的：深挖前三块（`r53-internal-research.md` / `r53-sage-qa-supplement.md` / `r53-tt-failure-patterns.md`）**尚未覆盖**的 SME 专题，均为新增点、与已有内容不重复。
> 覆盖面：Reusable Delegation Set / White-label NS、R53↔ACM/CloudFront 证书交互、CAA/SPF/DKIM/DMARC 记录级安全、R53↔Global Accelerator/API Gateway 边界、区域性服务端点、历史故障 COE 教训。
> 检索工具：InternalSearch（SAGE_HORDE / ALL / WIKI 域）。检索日期：2026-09-20。每条带内部来源（需 Midway 登录访问）。

---

## A. Reusable Delegation Set（可复用委派集）—— 大批量域名迁移的 SME 核心

**1. 是什么 / 为什么用**
- 一组**四台权威 NS**，可绑定给**多个** hosted zone。默认 R53 给每个新建 zone 随机分配 NS；迁移大量域名（几百~几千）时，每个 zone 拿到不同的 4 台 NS，要逐个到 registrar 改 NS 记录，是巨大的手工工作量。用 reusable delegation set 后，所有新建 zone 共用同一组 4 台 NS，registrar 侧只需配一次。
  来源：answers 305180（IHAC 700 zones 迁移）https://answers.amazon.com/posts/305180 ；answers 341715（~1k 域名迁移）https://answers.amazon.com/posts/341715
- **仅 API/CLI/SDK 可用，控制台不支持**。且**只能在 zone 首次创建时**关联；**已存在的 zone 无法改绑**到 delegation set（也无法改 NS）。
  ```
  aws route53 create-reusable-delegation-set --caller-reference <ref>
  # 返回固定的 4 台 NS，之后 create-hosted-zone --delegation-set-id 引用它
  ```
  来源：answers 341715（kenkitts 给出完整 CLI）。客户若已建 1000+ zone 才想起要用，就晚了（同帖 ygoel 的实际困境）。

**2. SME 高频边界/权衡（务必背）**
- **默认每个 reusable delegation set 上限 100 个 hosted zone**（软配额，可通过 Service Quotas 提额，硬上限需 TT 到 R53 服务团队确认）。
  来源：answers 139804（25k zones 案例）https://answers.amazon.com/posts/139804
- **NS IP 永不改变**：AWS 为 delegation set 分配的 4 台 NS 的 IP 是**恒定的**（"AWS NS server IP never changes. Its constant."）。
  来源：answers 139804（kbbheemi）。
- **不能索要"指定/相同"的 NS**：删除 delegation set 后，**无法再申请到同一组 NS 值**——所以用 IAM 严格保护 delegation set 的删除/修改权限。
  来源：answers 139804。
- **DDoS blast radius（最重要权衡）**：共用 4 台 NS = 把爆炸半径缩到 4 台 NS。**若其中一个域被 DDoS，可能牵连所有共用该 delegation set 的域**；追求隔离就该拆分。是否可接受要问客户。
  来源：answers 344451（Pros and cons）https://answers.amazon.com/posts/344451 ；answers 139804（andrewjw 警示单账号放数千 zone 的爆炸半径）。
- **命名空间不可重叠限制（gavinmc 补充，极易考）**：同一 reusable delegation set 上的 hosted zone **命名空间不能重叠**——`example.com` 与 `sub.example.com` **不能**共用同一 delegation set。有这种父子委派需求时，此限制会抵消其收益。
  来源：answers 344451（gavinmc 评论）。
- **25k zones 全放一个 delegation set 不推荐**：官方口径是拆分以降低 blast radius，不要把 25000 zone 全绑一个集。
  来源：answers 139804。
- 深入权衡文档（内部）：https://w.amazon.com/bin/view/Route53/ReusableDelegationSets/

---

## B. White-label / Vanity Name Servers（白牌 / 虚名 NS）—— DNS 加固考点

- **是什么**：默认 R53 的 NS 名形如 `ns-2048.awsdns-64.com`（暴露"这是 AWS"）。white-label（又叫 vanity / private name servers）让 NS 名与自己域名一致，如 `ns1.example.com`，**隐藏底层是 Route 53** 的事实（供应商中立 / 品牌 / 安全隐匿）。
  来源：answers 305180（catborsa 引官方 white-label 文档）。
- **配置要点（SME 实操）**：为自定义 NS 名（如 `ns1-b0.warnerbros.com`）建 A 记录，指向 R53 委派集 NS 的**实际 IP**；再在父区/registrar 用这些自定义 NS 名做委派。校验靠**比对 IP**：
  ```
  dig ns1-b0.warnerbros.com +short         -> 205.251.192.167
  dig -x 205.251.192.167 +short            -> ns-167.awsdns-20.com.   # 证明白牌 NS 实为该 AWS NS
  ```
  来源：answers 373952（Trusted Advisor 白牌 NS 案例，含真实 dig 对比）https://answers.amazon.com/posts/373952
- **易错点 / 运营坑（Trusted Advisor 误报）**：TA 检查 **"Amazon Route 53 Name Server Delegations"** 会因白牌 NS **误报 YELLOW**——因为客户 registrar 侧登记的是 `ns1-b0.warnerbros.com`，而 R53 建议值是 `ns-167.awsdns-20.com`，字面不符。这是**已知的 TA 局限**（TA 未做 IP 比对），不是真配置错误；客户可用 TA 的 exclude 功能屏蔽误报，或提 PFR 让 TA 支持白牌 NS 识别。
  来源：answers 373952（msatpat/karakas，附历史 PFR P11448288）。
- **另一个安全类 TA 检查**："Amazon Route 53 MX Resource Record Sets and Sender Policy Framework" 会在 MX 存在但缺 SPF 时报 YELLOW（衔接 C 节 SPF）。
  来源：answers 373952 relevant（chintuj 文章）。

---

## C. R53 ↔ ACM / CloudFront 证书交互 —— 跨账号/跨区/委派断链

**1. CloudFront 备用域名（CNAME/Alternate Domain Name）的证书硬要求**
- CloudFront 的 alternate domain name **必须**绑定由 **ACM 或公共可信 CA** 签发的证书；**内部 CA（Redfort/Infosec 内部证书）不被接受**（不是外部可信）。内部项目要给 CloudFront 配自定义域，正解是走 **Nova/SuperNova 建 R53 zone + ACM 出证**。
  来源：sage 630480 https://sage.amazon.dev/posts/630480
- **CloudFront 的 ACM 证书必须在 us-east-1（N. Virginia）**：edge-optimized / CloudFront 分发引用的证书只认 us-east-1 区的 ACM，跨区 CDK 要用 `DnsValidatedCertificate(region:'us-east-1')` 或 CrossRegion 构造。
  来源：sage 1458273（CloudFront + LambdaRestAPI + CDK，跨区证书报错）https://sage.amazon.dev/posts/1458273

**2. 跨账号：CloudFront/ACM 在 A 账号、Route 53 在 B 账号**
- **可行**，无需把 CloudFront 迁到 R53 账号：
  - B 账号（R53）：建 hosted zone；加 CloudFront 分发的 alias（控制台不会自动提示该目标名，需手填）；**加 A 账号 ACM 给出的 CNAME 验证键值对**（在 A 账号出证时会显示 PENDING_VALIDATION，直到 B 账号落地该 CNAME）。
  - A 账号（CloudFront/ACM）：出证 + 在分发里选该证书 + 加 alternate domain name。
  - 若出证后仍报无法验证，可能需要 **ACM 对 B 账号做 allow-listing**（提 TT）。
  来源：sage 644806（a2z.com 跨账号 CloudFront 证书）https://sage.amazon.dev/posts/644806

**3. `amazonaws.com` / 受限域出证需 AppSec allow-list（易被卡）**
- 给 `amazonaws.com` 或其他**受限域**申请 ACM 证书，账号必须被 **AppSec 显式 allow-list**；否则 CDK 报 `Additional verification required to request certificates` / `describeCertificate did not contain DomainValidationOptions`。控制台手动出证可能"看起来"能建但同样会 Failed。
  来源：sage 1064758 https://sage.amazon.dev/posts/1064758 （含 ACM FAQ 受限域申请链接 `w.amazon.com/bin/view/ACM/FAQ/`）。

**4. 证书长期 PENDING_VALIDATION 的真实根因（补前块）**
- 几乎都是 **DNS 委派/验证 CNAME 未真正解析**，不是 ACM 本身：
  - 子域 hosted zone **未在父区加 NS 委派记录** → 验证 CNAME 解析不到 → 永久 PENDING。加了父区 NS 记录后证书立即激活。
    来源：sage 1951673（beta.pdx.portal-api.csalt.amazon.dev，加父区 NS 后激活）https://sage.amazon.dev/posts/1951673
  - ZHY/BJS 等区域**DNS 验证功能尚未 IA/GA**时，CNAME 建了也不会被验证（历史时点问题）。
    来源：sage 728309 https://sage.amazon.dev/posts/728309
  - 排查：`dig CNAME _<token>.<domain>` 应能解析到 `_<...>.acm-validations.aws`；解析不到就先查委派链。
    来源：sage 903598 https://sage.amazon.dev/posts/903598

---

## D. CAA / SPF / DKIM / DMARC —— 记录级安全（SME 安全考点新增）

**1. CAA（Certificate Authority Authorization）与 ACM 出证**
- CAA 记录限定**哪些 CA 可为该域出证**，防被攻陷的 CA 乱签。**ACM 出证前会检查 CAA**：若 CAA 存在且未包含 `amazon.com`（ACM 的 CA 标识），**ACM 出证会失败**。用 ACM + R53 时若要加 CAA，须把 `amazon.com`（及需要的 `amazontrust.com` 等）列入，否则自锁。
  来源：sage 1323156（Redfort team：ACM+R53+CAA 指南 `docs.aws.amazon.com/acm/latest/userguide/setup-caa.html`）https://sage.amazon.dev/posts/1323110
- **Nova(a2z.com) / SuperNova(amazon.dev/aws.dev) 默认无 CAA 记录**；Amazon 并无统一"必须用某 CA"的策略（如 Twitch 用非 ACM/Redfort 的 CA）。团队若只用 ACM，可自行在 R53 zone 发 CAA 限定只允许 ACM 签发，作为加固——但这并非强制 ORR 项。
  来源：sage 1323156（andrewjw）。

**2. SPF —— 不要用 SPF 记录类型，用 TXT**
- R53 官方口径（承接前块）：**不再推荐建 `Type=SPF` 的记录**（RFC 7208 §14.1 弃用），改用 **TXT** 承载 SPF 内容；SPF 与 TXT 里的内容完全一样，切换无负面影响。
  来源：answers 362247 https://answers.amazon.com/posts/362247
- **超 255 字符的 SPF/TXT**：单个字符串上限 255，长 SPF/TXT 要**拆成多个带引号的字符串**放在同一 RRSET（R53 会拼接）。
  来源：answers 362247 relevant（ajitsury 文章 "How to configure SPF or TXT records that are longer than 255 characters"）。

**3. DMARC / DKIM 的 SME 关键语义**
- **DMARC 保护的是 From header 里的域**，而 `*.amazonaws.com`（ELB/ALB 托管子域）**不是客户可验证的 email identity**——治理 `amazonaws.com` 域下的滥用是 **Amazon 的责任**，客户给 `_dmarc.foo.us-gov-east-1.elb.amazonaws.com` 加记录无法对齐回自己的 `example.com`。正解：把子域**委派到 R53**并在自己域下建 DMARC TXT + alias 到 ALB。
  来源：answers 165344（SPF/DMARC for ELB，含 GovCloud 需在 IAD 调 R53 的提醒）https://answers.amazon.com/posts/165344
- **组织域 DMARC 覆盖子域**：组织域（example.com）的 DMARC 策略（如 `p=reject`）**自动适用于所有无自身 DMARC 策略的子域**——通常不必给每个子域都建 DMARC。但要注意 **`aspf=r`（relaxed，默认）**时，别让某子域有过于宽松的 SPF，否则攻击者可从子域 MAIL FROM 且 DMARC 对齐回可见 From 域。子域策略在收件系统的处理有 "Organizational Domain Discovery" 歧义，别过度假设。
  来源：answers 165344（awszjt EXPERT）。
- **DMARC 不是 SES 前置条件 / 每域仅需一条**：SES 域验证靠**三条 CNAME**（每区独立），**不是 DMARC 记录**；DMARC 每域只需一条，与验证了多少个区无关。多区 CDK 栈都去建 `_dmarc.foo.bar.amazon.com` 会互相冲突——DMARC 应单独一处管理。
  来源：sage 1867542（多 CDK 栈同域 DMARC）https://sage.amazon.dev/posts/1867542
- **SPF pass 但 DMARC fail** 的典型：SPF 对齐的是 MAIL FROM/HELO 域（如 `smtp-fw-6002.amazon.com`），DMARC 看 header From（如 `amazon.sa`）——两者**域不对齐**则 DMARC fail（即使 SPF pass）。自动回复类邮件（Return-Path 为空）尤其常见。
  来源：sage 1397967 https://sage.amazon.dev/posts/1397967
- **"Secure By Default" SPF/DKIM/DMARC 运动**：新注册的**不发邮件的**域会被默认下发**限制性** SPF/DKIM/DMARC（拒绝一切发信），防被冒用发钓鱼。SME 要知道这是企业安全项，不是 R53 自动 DNS 特性。
  来源：sage 1926332（AWS IT Security SPF/DKIM/DMARC Campaign 页）https://sage.amazon.dev/posts/1926332

**4. DS 记录也可编程写（承接 DNSSEC）**
- boto3/CLI 文档一度**漏列 DS** 于合法类型，但 `change-resource-record-sets` **实际支持 DS**（`Type:"DS"`, value 形如 `18380 13 2 <digest>`）——用于把子域 DS 注册到父区建信任链，全程可编程。
  来源：answers 173606 https://answers.amazon.com/posts/173606

---

## E. R53 ↔ API Gateway / Global Accelerator —— 边界与多区 failover

**1. Edge-optimized vs Regional 端点（决定能否做 R53 多区 failover）**
- **Edge-optimized API GW 用 CloudFront**，而 **CloudFront 不允许两个分发共用同一 CNAME** → 因此**同一自定义域名无法在多个区各建一个 edge-optimized 端点** → **不能用 R53 latency/failover 在多区间切换 edge-optimized 域**。
- **要做 R53 多区 failover/latency，必须用 Regional 端点**：在每个区建**同名**的 regional custom domain（在每个区 ACM 各验证一次同域名），再用 R53 failover/latency 策略在区间切换。**ACM 证书必须在该 regional 端点所在区**。
  来源：answers 554732（mdiggins 详解 HOST header / 多区 / edge vs regional）https://sage.amazon.dev/posts/554732 ；answers 332327（API GW Multi-Region Failover，mooretj）https://answers.amazon.com/posts/332327
- **API GW 用 HOST header 判 API**：每个在用的 DNS 名必须在**每个可能被路由到的区**都在 API GW 里配好（否则 Host 不匹配）。
  来源：answers 554732。

**2. R53 failover vs CloudFront Origin Group failover（别叠加）**
- 两条多区 failover 路径：
  - **CloudFront Origin Group / origin failover**（前置 CloudFront + regional API）——每个 regional API 需**不同**的 DNS 端点；支持读类失败切换，PUT/POST/DELETE 需 Lambda@Edge。
  - **R53 failover**——每区建**同名** custom domain（ACM 各区验证），R53 直接在区间切；仅 regional 端点可用。
- **不要把两者叠加使用**（mooretj 明确建议）。
  来源：answers 332327。

**3. Edge→Regional 迁移（零/极小停机，SME 常见操作）**
- 官方顺序（**每步单独部署，切勿合并**，否则可能部署失败需手工回滚）：
  1. 给现有 edge custom domain **追加** regional 端点配置（`endpointConfiguration.types=[EDGE, REGIONAL]` + `regionalCertificateArn`）；
  2. 把 API GW 端点迁为 REGIONAL；
  3. 把 R53 记录指向 regional 目标（alias 用 `attrRegionalDomainName` + `attrRegionalHostedZoneId`，或从 cloudfront.net 改到 execute-api）；
  4.（可选）清理 edge 配置。
  来源：answers 263167 https://answers.amazon.com/posts/263167 ；sage 1655875（CDK 三步迁移，附各步 CR）https://sage.amazon.dev/posts/1168900 、https://sage.amazon.dev/posts/1655875
- 内部已有 `@amzn/apigatewaycustomdomainmanager`（`ApiGatewayDomainMigration` 构造）把 4 步合成**单次部署**（含证书关联、R53 更新、mTLS、冲突重试、DNS 传播等待）。
  来源：sage 1655875 / sage 1168900（2025-09 更新）。

**4. Global Accelerator 边界（承接前块 alias 用法）**
- GA 用**固定 anycast IP**（两个静态 IP），R53 用 alias 指向 accelerator 的 DNS 名；GA 自身在边缘做健康检查与区/端点故障切换，**与 R53 DNS-based failover 是不同层**。做 API GW 跨区 failover 时，GA 是 R53/CloudFront-origin-failover 之外的第三选项（TCP/UDP 层、连接不断）。
  来源：answers 332327 relevant（"Using AWS Global Accelerator for cross-region failover" QUwsSlAelvRtujZcRdJJwAGg）。

---

## F. 区域性服务端点 / 控制面-数据面拓扑（承接前块，新增内部实现细节）

**1. R53 控制面的多区 active-active 前门（内部架构，SME 深读）**
- 公共控制面端点解析链：
  ```
  route53.amazonaws.com → CNAME → ge.r53-mr.amazonaws.com → CNAME →
      route53-direct.us-east-1.amazonaws.com  或  route53-direct.us-west-2.amazonaws.com
  ```
  IAD 为主区、PDX 为次区，DNS-based 路由做多区 active-active。
- 各 partition 区域端点：
  | 区 | 前门 DNS | 说明 |
  |---|---|---|
  | Prod IAD | route53.amazonaws.com | 主 |
  | Prod PDX | route53.amazonaws.com | 次 |
  | ZHY | route53.amazonaws.com.cn | 中国 |
  | NCL | route53.cloud.adc-e.uk | ISO-E |
  | PDT | route53.us-gov.amazonaws.com | GovCloud |
  来源：DaaS Control Plane wiki https://w.amazon.com/bin/view/Route53/ADC-DNS-UK/OK/DaaSControlPlane/

**2. 控制面 vs 数据面区域行为（官方口径 + LSE 印证）**
- **控制面 = Route 53 API + Traffic Flow API**（管理 DNS 记录）。**控制台在 us-east-1**，若 AWS 判定 us-east-1 受损，控制台改由 **us-west-2** 提供。
- **数据面 = 权威 DNS 服务**，跑在 **200+ PoP**，据 hosted zone + health check 应答查询，**独立于控制面**。
- 2025 年一次 LSE 中 us-west-2 控制面是否实际发动"不确定（很可能未发动）"——SME 要能讲清"控制台可切区、但权威解析数据面本就全球独立"。
  来源：JP infosearch Slack QA-117 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Slack/QA-117/

**3. 变更生命周期（内部，理解"控制面改动如何到数据面"）**
- 客户改记录 → DaasCustomerAPIService/Console/SDK → 记入 **JournalDB**（带序号）→ Applier 复制到 SQL 供查询 → Change Propagation 从 Journal 摄取 → Delta Uploader 批量成 delta 推 S3 → 数据面主机（DCD）拉 delta 打进本地 SGF 存储 → ChangeSyncStatusPoller 回查数据面主机确认同步。理解这条链有助解释"改了记录多久生效/为何偶发延迟"。
  来源：DaaS Control Plane wiki（同上）。

---

## G. 历史故障 COE 教训（SME "为什么这样设计"类金矿，全部新增）

> 主源：Gavinmc "DNS Related COEs/Accidents" 内部索引页 https://w.amazon.com/bin/view/Users/Gavinmc/Route53/DNSCustomerCOEs/ ；DaaS Control Plane COE 段 https://w.amazon.com/bin/view/Route53/ADC-DNS-UK/OK/DaaSControlPlane/

**1. IAD 控制面不应触发所有 zonal 数据面（关键设计原则）**
- **COE 86977（DUB2/DUB4/FRA53 EC2 DNS 中断）**：一次 IAD 控制面变更传播把**全球所有** EC2 DNS（后来的 Resolver）主机标记为 "stale"，导致 RI（Resolver Instance）Manager 在**每个 AZ 同时回收主机**；三个 AZ 的 NAT Fleet 暴露 conntrack 上限过低的 bug。**核心教训：绝不让 IAD 控制面触发所有 zonal 数据面的行为**——改为 AZ/cell 内**本地共识**判定 stale（主机彼此比对，而非依赖全局 actor）。
  这解释了为何 R53 强调数据面 zonal 独立、控制面故障不应放大到数据面。

**2. 蜂窝（cell）隔离失效 → 全区数据面受影响**
- **COE 211386（Dexter DNS "Too many open filehandles" in IAD）**：对 IAD6 四个 RI cell 之一的部署触发两个 GI（Gateway Instance）cell 的文件描述符泄漏 bug；**设计缺陷是两个 GI cell 都能用全部四个 RI cell**，于是单 cell 部署重配了两个 GI cell，蜂窝模型失效。教训：把 GI 隔离到**不重叠**的 RI cell 组，单 cell 部署不能影响整个 zonal 数据面。
- **COE 217173 / IAD7 查询超时**：resolver 移除某 cell 10% 的 RI，但很多恰好在同一 "slot"（sub-cell），导致该 slot 不可用——**移除要跨 slot 均匀**。

**3. Quilt/主机替换活动误杀数据面容量**
- **COE 207131（DCA：加新主机反而把公共 DNS 容量砍掉 93%）**：一次 Quilt 主机替换活动给 15/16 bastion 环境各配新主机准备替换，15 个替换各自拆掉对应 EC2 fleet → 杀掉 15/16 的 EC2 DaaS fleet，3/4 stripe 死亡。且 RM&A 网络因**错误地把递归查询转发到 DaaS 权威 NS**而连带中断（权威 NS 不该收递归查询——承接前块 forwarding vs delegation）。

**4. DynamoDB 端点 DNS 全球中断（2025-10-20，最新最重要 COE）**
- **现象**：06:48 UTC 一次针对 DynamoDB 端点（`dynamodb...amazonaws.com` / `api...` / `ddb...`）的 **DNS 控制面更新**与一次**边界网络传播故障**重叠，导致 DNS 传播不完整、resolver 看到**陈旧或缺失**的 A/AAAA → **全球 DynamoDB 端点解析失败**、流量掉到平时约 1/3；**DynamoDB 数据面本身健康**（IPv6 端点全程可解析，证明是 DNS 而非服务故障）。
- **控制面机制（SME 要点）**：控制面**构建新的 DNS record tree 并原子翻转 alias**；此过程被打断，留下混合/陈旧记录对 resolver 可见。
- **缓解**：回滚到上一个稳定的 DNS record tree（alias 重指）；生产网临时部署 **RPZ（Response Policy Zone）**恢复内部解析，公共 DNS 修好后移除 RPZ；**刷新内部与公共 resolver 缓存**（含 Cloudflare / Google / OpenDNS）。查询量正常后系统自恢复，Tiny / Lambda Streams 等下游随 backlog 清空而恢复。
- **SME 教训**：① DNS 数据面健康 ≠ 服务健康，反之亦然，要用 IPv6 vs IPv4 差异等切分；② 大规模端点用 **WRR + 每 IP 健康检查 + 手动 weigh-out（weight=0）**做 AZ 隔离缓解；③ alias 原子翻转 + resolver 缓存 TTL 是控制面变更的风险点，回滚要考虑缓存刷新。
  来源：Oncall Notes 10/20–10/27/2025 https://w.amazon.com/bin/view/AmazonLive/ThirdPartyTools/OnCall/OncallNotes/10-20-2025_to_10-27-2025/ ；DynamoDB DNS Management System（BigBird，DNS 计划执行/BBDNS PE 架构）https://w.amazon.com/bin/view/BigBird/BorderServices/Architecture/DNSManagement/

**5. DynamoDB DNS 管理系统（BigBird）—— 大规模 WRR 的内部实现（SME 深读）**
- 闭环：VipDB 收集端点元数据 → WeightWatcher 算最优权重 → WeightLifter 安全施加权重 → BBDNS 存权威 DNS plan → **BigBirdDNSPlanExecutor 发布 Route53 记录**供客户解析。
- 客户 SDK 解析 `dynamodb.us-east-1.amazonaws.com` 时，R53 用 **Weighted Round Robin** 按权重（1–255，相对值）返回众多 IP 之一；每 IP 属某 NLB（或待退役的 LBIR）。**每区维护 6 个 DNS 域**（主 IPv4、dual-stack、FIPS IPv4、FIPS dual-stack、两个 cells 域）。
- R53 **健康检查持续监控每个端点 IP，不健康自动摘除**；运维可**手动置 weight=0（"weigh out"）**移除间歇可达端点——这是 **AZ 受损/容量事件的首选缓解工具**。
  来源：DynamoDB DNS Management System wiki（同上）。

**6. DaaS 控制面自身 COE（承接 F 节变更链）**
- **COE 390561**：JDWL 中断 → 100% API 失败（复制节点部署引发 leadership 争用）。教训：JDWL 失败会让**所有** ControlAPI 主机同时深健康检查失败 → VIP 摘除全部后端；排查失败要检查**所有共用 journal 的服务**（ControlAPI、ReplicationNode）的部署。
- **COE 330266**：控制面输入校验放松导致 **"poison pill"** → 可传播到 Change Propagation 并**阻塞整个 partition**。
- **COE 370751**：分片控制面冲突的 HZ 查询。
  来源：DaaS Control Plane wiki COE Examples 段。

**7. 其它历史 DNS 基础设施 COE（索引，SME 背景）**
- COE 5260（公司级 DNS 中断）；COE 67741（us-east-1/eu-west-1 amazonaws.com 未 dual-home，针对 Dyn 的 DDoS）；COE 222945（PDX/Prod 误加空 /24 masking zone 遮蔽 /16 内 PTR，致 Kinesis/ALF 因无法解析自身 PTR 而失败，回滚又阻塞 ACC 主机 provisioning）；COE 108337（R53 丢失部分 VPC 关联）；COE 213400（FC 用 CloudFlare/OpenDNS，第三方 resolver 故障时受影响——印证用托管 resolver 的取舍）。
  来源：Gavinmc DNS COEs 索引页（同上）。

---

## 附：本块可直接背诵的"新增考点速记"

1. Reusable delegation set：**仅 API/CLI**、**仅建 zone 时**关联、已存在 zone 不能改绑；默认 **100 zone/set**（可提额）；**NS IP 恒定、删后拿不回同一组**；共用 = 缩 blast radius 但**一域被 DDoS 牵连全体**；**同 set 内命名空间不能重叠**（example.com 与 sub.example.com 不行）。
2. White-label/vanity NS：自定义 NS 名 A 记录指向 AWS NS 的**真实 IP**；**Trusted Advisor 会误报 YELLOW**（未做 IP 比对），用 exclude 或提 PFR。
3. CloudFront alternate domain 只认 **ACM/公共 CA**（拒内部 CA）；CloudFront/edge 证书**必须 us-east-1**；跨账号出证可能需 **AppSec/ACM allow-list**。
4. 证书 PENDING 多为**委派/验证 CNAME 未解析**（子域缺父区 NS 记录最常见）。
5. **CAA 若不含 amazon.com 会让 ACM 出证失败**；Nova/SuperNova 默认无 CAA。
6. **别用 SPF 记录类型，用 TXT**；长 SPF/TXT 拆多段带引号字符串。
7. DMARC 保护 From 域；组织域 DMARC 覆盖无自身策略的子域；**SES 验证靠 3 条 CNAME 不是 DMARC**；DMARC 每域一条；**SPF pass 可 DMARC fail**（域不对齐）。
8. R53 多区 API GW failover **必须用 Regional 端点**（edge-optimized 因 CloudFront CNAME 唯一性做不到）；证书须在端点所在区；**别把 R53 failover 与 CloudFront origin failover 叠加**。
9. Edge→Regional 迁移**分步单独部署，切勿合并**。
10. 控制面 = R53 API（控制台 us-east-1，受损切 us-west-2）；数据面 = 200+ PoP 权威服务、独立。变更链：Journal → Propagation → Delta/S3 → 数据面拉取。
11. **核心设计教训**：IAD 控制面不触发全球 zonal 数据面（COE 86977）；蜂窝隔离（COE 211386）；移除要跨 slot 均匀（COE 217173）。
12. **DynamoDB 端点 2025-10-20 全球 DNS 中断**：控制面 alias 原子翻转被边界网络故障打断 → 陈旧/缺失记录；数据面健康（IPv6 先恢复）；缓解 = 回滚 record tree + 临时 RPZ + 刷 resolver 缓存 + weigh-out。大规模端点用 WRR + 每 IP HC + weight=0 手动摘除。

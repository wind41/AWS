# Route 53 真实故障模式 —— 内部 TT / Case / 已解决问题提炼（SME 备考）

> 来源：内部检索（InternalSearch — Sage/answers.amazon.com、Broadcast 培训、w.amazon.com wiki、内部 runbook、2026 DNS COE）。
> 每条模式格式：现象 → 根因 → 排查手法 → SME 考点。内部来源 ID 逐条标注。
> 说明：这些来自内部 SA/TAM 问答与支持 runbook，反映的是 R53 数据面/控制面真实工作机制与运营口径，可直接用于 SME 面试/认证的“为什么”类问题。

---

## 一、解析优先级 & PHZ / 转发规则冲突（最高频考点）

### 1.1 VPC .2 Resolver 的解析优先级顺序（必背）
- **现象**：客户抱怨“我建了转发规则/私有区，但解析结果不是我预期的”。
- **根因**：VPC .2 Resolver 对每个查询按固定优先级评估，长匹配（most specific）优先；`.2` 每收到查询都重新按序评估所有关联规则。
- **权威顺序（内部 runbook 与培训一致）**：
  1. **DNS Firewall**（若 VPC 关联了 firewall rule group，先评估；BLOCK 的查询不再往下走）
  2. **Route 53 Resolver Forwarding/Resolver 规则**（含 autodefined system rule）
  3. **Private Hosted Zone**（VPC 关联的 PHZ，最长匹配优先）
  4. **Public DNS**（前面都不匹配才走公网）
  - 关键陷阱：**同一域名同时存在 PHZ 与自定义 forward rule 时，custom forward rule 胜出**（因为客户显式定义的规则要拿到最高优先级，通常是要把流量送到 on-prem）。但**更长前缀的 PHZ（子域）会赢过父域的 forward rule** —— 即“longest match wins”优先于“rule 类型优先”。
- **排查手法**：画出该 VPC 关联的所有 rule + PHZ，按域名前缀长度排序，逐条对照查询名判断命中哪条；用 Resolver Query Log 抓精确时间戳 + 域名确认分类。
- **SME 考点**：能背出四层顺序；能解释“PHZ 子域 vs 父域 forward rule”谁赢（子域 PHZ，longest match）；能解释 custom rule 为何默认压过 autodefined system rule。
- **来源**：Broadcast 360549 “Route53 session 1”；Broadcast 1154819 “Route53Resolver-Concepts-Endpoints-Day4”；wiki `GFSPrincipalTechnologistOffice/.../Architecture`；wiki `AmazonWebServices/.../VPC/Runbooks/DNSAndDHCP` (DNS/DHCP Runbook)；wiki `EC2/Networking/DNS/Support_Overview` (Route53 Resolver Support Overview)。

### 1.2 PHZ 与公网区“重叠命名空间”→ 意外 NXDOMAIN（经典陷阱）
- **现象**：VPC 内 dig 公网记录（如 `publicsb.example.com`）返回 NXDOMAIN，指定 8.8.8.8 却能解析；客户以为 R53 会自动 failover 到公网。
- **根因**：为 `example.com` 建 PHZ 后会生成一条 autodefined 规则；只要查询名落入该 PHZ，就**在 PHZ 内权威解析**。若 PHZ 里没有该记录，Resolver **不会 failover 到公网**，直接返回 NXDOMAIN。这是 documented “Public and private hosted zones that have overlapping namespaces” 行为。
- **排查手法**：确认是否存在覆盖该查询名的 PHZ；解决靠 split-view DNS（公私区记录保持同步，Lambda/EventBridge 或定期导出同步），或把 PHZ 收窄到更具体子域。
- **反模式**：给 `example.com` 建 outbound forward rule 想 fallback 公网 —— 会让整域走公网、PHZ 私有解析失效（forward rule 压过 autodefined），等于白花 endpoint ENI 费用。
- **SME 考点**：解释 R53 为何不做“私区 NXDOMAIN → 公网 fallback”；split-view/split-horizon 是唯一正解；能识别“加 forward rule 解决重叠”是反模式。
- **来源**：answers 367030（Public DNS Resolution fails with NXDOMAIN）；answers 351787（无 fallback 的 workaround）；answers 238767（重叠命名空间转发）；sage 1631425（Hydra UnknownHostException — 私区不能与公网区 overlap，私区优先，靠近 root 的区先解析）。

### 1.3 私区“同根域即冲突”导致服务解析失败
- **现象**：ECS/服务调用报 UnknownHostException / 连不到；删掉某 PHZ 后立即恢复。
- **根因**：客户误以为“私区与公区只要不完全同名即可”，实际**私区与公区不能共享同一根域重叠**；私区优先、且从最靠近根域的区开始解析。多余的父域 PHZ 把子服务查询“吸走”返回空。
- **排查手法**：列出 VPC 关联的全部 PHZ，找到把查询“吸走”的最近父域 PHZ；要么删掉，要么在该 PHZ 内补齐 A/别名记录（社区反复验证：在私区加一条指向 LB 的镜像记录即可修复）。
- **SME 考点**：私区“最长匹配 + 不 fallback”的双重效应；修复两条路（删区 / 补记录）。
- **来源**：sage 1631425。

### 1.4 VPC DNS 属性未开 → PHZ 完全不解析
- **现象**：PrivateLink/PHZ 记录解析不出私有 IP；CloudAuth token prefetch connect timed out。
- **根因**：PHZ 解析要求 VPC 同时打开 **enableDnsSupport** 和 **enableDnsHostnames**；老 VPC / 手工建的 VPC 常默认没开 hostnames。
- **排查手法**：检查 VPC 两个 DNS 属性；两者都为 true 才生效。VPCE(PrivateLink) 私有 DNS、Amazon 提供的 DNS 名解析都依赖它。
- **SME 考点**：能立刻点名这两个 VPC 属性是 PHZ 生效前提。
- **来源**：sage 1177563（CloudAuth token prefetch failed）；wiki DNS/DHCP Runbook。

### 1.5 委派层级错误 → 间歇性 ERR_NAME_NOT_RESOLVED
- **现象**：`dev.api.example.com` 间歇解析失败（ERR_NAME_NOT_RESOLVED）。
- **根因**：多级子域委派必须**从直接父区委派**，不能跳级。把 `dev.api.example.com` 直接从 `example.com` 委派（而非从 `api.example.com`）会造成间歇失败。
- **排查手法**：核对委派链 `example.com → api.example.com → dev.api.example.com`，每级 NS 记录建在直接父区。
- **SME 考点**：委派必须逐级；跳级委派是间歇 DNS 故障的隐蔽根因。
- **来源**：sage 1946115（accepted answer，引 Route53 DNS Best Practices）。

### 1.6 私区不支持 NS 委派 → 混合架构解析缺口
- **现象**：客户想在私区里用 NS 记录把子区委派给 on-prem BIND，失败。
- **根因**：R53 **私有区不支持 delegation/NS 记录**。纯 R53 场景一般不需要委派（用多个 PHZ + 重叠命名空间 + Resolver 规则即可等效）；只有当子区要委派到非 R53 权威（on-prem）时才撞到功能缺口，需用 DNS forwarding 变通。
- **SME 考点**：私区无 NS 委派；纯 R53 用“多 PHZ + overlapping namespace + resolver rule”替代委派。
- **来源**：answers 158095（Route53 Private Zones support delegation）。

---

## 二、Resolver Endpoint 限流 / QPS / 连接跟踪（运营核心考点）

### 2.1 两个不同的硬限：1024 PPS（.2）vs 10,000 QPS（endpoint ENI）
- **现象**：客户 DNS 查询被丢/超时，问“PPS 和 QPS 是不是一回事”。
- **根因/事实**：
  - **VPC .2 Resolver（169.254.169.253 / VPC+2）：每 ENI 硬限 1024 PPS，不可提升**。超限直接 reject。该限制作用在 ENI 上，**droplet 上的缓存命中也算**。IMDS 查询也走这条 ENI、会吃额度。
  - **Resolver Endpoint：每个 ENI/IP 约 10,000 QPS**。超过 50% 容量就应加 ENI。
  - 多数情况下 1 查询 = 1 UDP 包，PPS≈QPS；例外：EDNS0 大包、切 TCP（>4096B）时不等。
- **排查手法**：看 CloudWatch `InboundQueryVolume` / `OutboundQueryAggregateVolume`，确认是否逼近 `10,000 × ENI 数`；`.2` 侧超限查 IMDS 是否在偷额度、应用是否缓存过差、TTL 是否设太低。
- **SME 考点**：能分清两个限、两个数（1024 PPS 不可增 vs 10K QPS 可加 ENI）；能说出 R53 Resolver 给每个入站请求生成**冗余出站查询**，所以出站 ENI 的 QPS 与收到的 QPS 不相等。
- **来源**：answers 340209（PPS Vs QPS）；answers 74644（Throttling）；answers 224004（API limit vs DNS query）；wiki `AWS/Teams/.../Route53`（NetTFC）。

### 2.2 连接跟踪把 10K QPS 打到 ~1,500 QPS（最隐蔽的限流）
- **现象**：endpoint ENI 明明没到 10K QPS 却大量丢包/超时。
- **根因**：NX(AWS 底层)用 connection tracking。当 ENI 用了**限制性安全组规则**，或查询**经过 NLB**（强制 conntrack）时，UDP QPS 被压到低至 **~1,500 QPS**（约 6 倍降幅）。丢包发布 `conntrack_allowance_exceeded_delta` 指标；纯 10K 超限发布 `udp_throttled_count`。两指标都在 Proxy Instance 账户的 `ProxyInstance/ContributorInsightsLog` 日志组（区域级）。
- **服务侧机制**：ENI 进入 conntrack 后，服务会把它**迁到更大实例类型**（capacity_level `CONN_TRACK_FLEXI_FLEET`）以支撑带 conntrack 的 10K QPS；迁移期间流量重分布可能瞬时 throttle（出站 endpoint 属正常，不建议给客户额外建议）。
- **排查手法（内部 runbook 顺序）**：
  1. 查 `conntrack_allowance_exceeded_delta` 状态；NOT OK → conntrack 根因，逐 ENI 看 capacity_level 是否已升到 `CONN_TRACK_FLEXI_FLEET`。
  2. 查 `udp_throttled_count`；NOT OK → 客户超 10K QPS 根因，逐 ENI 看 `IPTableUDPThrottlesStatus`。
  3. 两者都中：迁移前已在大实例 → 主因 throttling；迁移中才升 → 主因 conntrack。
  4. 建议：throttling 全 ENI 中招 → 加 ENI；部分中招 → 均衡分流。conntrack → 去掉限制性 SG / 不走 NLB。
- **SME 考点**：能说出“SG 限制或 NLB 触发 conntrack → 10K 降到 ~1.5K”；能点名两个 CloudWatch 指标及其含义；能给出正确修复（去 SG 限制 / 不走 NLB / 加 ENI / 均衡分流）。
- **来源**：wiki `TestResolverEndpointsRunbook`（内部 Resolver Endpoint 排查 runbook，含精确指标名与判定流程）；wiki NetTFC Route53；wiki JP QA-1928（NLB/SG 把入站压到 1,500 QPS）。

### 2.3 出站 endpoint 目标名服务器不可达/无响应 → SERVFAIL/超时
- **现象**：出站解析大面积超时/SERVFAIL，且非 throttling / 非 conntrack。
- **根因**：**目标 on-prem 名服务器无响应或不可达**（内部 runbook 明确：这是出站 endpoint 支持工单最常见根因）。
- **排查手法**：CloudWatch Insights 按分钟算 `sum(timeout_queries)/sum(received_queries)*100`；持续高 → 目标 NS 不可达。再对 `eniloganalysisdb.eniloganalysis_new` 跑 Athena，按 `destip` 聚合 `respcode='TIMEOUT'` 统计每个目标 NS 的超时数，全部列出让客户排查其名服务器。
- **SME 考点**：SERVFAIL/超时且限流指标正常 → 优先怀疑目标 NS；知道用 timeout% 和按目标 NS 聚合超时来定位。
- **来源**：wiki `TestResolverEndpointsRunbook`。

### 2.4 iterative 查询被静默丢弃 → 极难排查的“无响应”
- **现象**：on-prem 发查询到 Inbound endpoint，无任何响应（silent failure），排查困难。
- **根因**：R53 Resolver endpoint 是**递归 resolver，只接受递归查询（RD=1，默认值）**；发**迭代查询**给 Inbound endpoint 会被**立即丢弃、无错误响应**。
- **SME 考点**：inbound endpoint 只吃递归查询；iterative 查询 → 静默丢弃（不是 REFUSED，是无响应），这是“forwarding vs delegation”里 forwarding 的硬性要求。
- **来源**：wiki `GFSPrincipalTechnologistOffice/.../Architecture`（Forwarded queries must be recursive；iterative 立即丢弃）；Broadcast 360549。

### 2.5 共享出站 endpoint 的“吵闹邻居”→ 真实大规模 DNS 事件（2026-02-04）
- **现象**：某 tier-1 服务（TRE 税务引擎）DNS 大面积超时/丢包约 1 小时；同区其他 tier-1（Datapath、OPF）无恙。
- **根因**：TRE 用**共享**出站 resolver endpoint `rslvr-out-3444560625b4fdf97`；一次 Alexa CDK 变更重启 Redis 集群，Alexa 的 VPC 在事件窗口产生 **2.76 亿+ DNS 查询**，把共享 endpoint 打到 4 倍常量（峰值 **821K QPS**）、8.6 万+ 超时。Datapath/OPF 因有**专用 endpoint（各 ~50 ENI）**未受影响。
- **容量事实**：CAN 共享出站 endpoint 区域容量 IAD 630K QPS、PDX 120K、ZAZ 150K、DUB 28.8K；专用 endpoint 容量公式 `((N×0.80×10000)/2)×0.6`（N=ENI 数），50 ENI ≈ 120K QPS。
- **排查/缓解**：识别高用量客户迁到专用/替代 endpoint；tier-1 服务预置专用 endpoint；共享 endpoint 层加限流。查询量正常后系统自恢复。
- **SME 考点**：能讲清多租户出站 endpoint 无隔离 → 吵闹邻居 blast radius；专用 vs 共享 endpoint 的容量与隔离权衡；单实例最多 1024 PPS 也仍能占满一个 ENI 相当份额（cache-busting 攻击可绕过缓存放大）。
- **来源**：wiki `Viksingh/Operations/2026/.../2026-02-04-dns-resolver-architecture-incident-analysis`（COE 385154，Ticket V2097404680）；wiki `CAN/LimitsInCAN`；wiki `Users/Gavinmc/Route53/ResolverForManagedAD`（noisy neighbour 风险与 SERVFAIL 讨论）。

### 2.6 Route 53 控制面 API 限流 ≠ DNS 查询限流
- **现象**：ChangeResourceRecordSets 报 HTTP 400 `Throttling / Rate exceeded`。
- **根因**：**Route 53 API 每账户 5 请求/秒**（控制面）；DNS 查询是数据面，不受此限。公网权威 DNS 查询 QPS 无限制（不含 DDoS 处理），无需申请提额。
- **SME 考点**：分清控制面 API 限流（5 rps/account）与数据面查询无限；不要把“API throttling”与“resolver QPS”混为一谈。
- **来源**：answers 224004；answers 340209（gavinmc 评论）。

---

## 三、DNSSEC 签名 / DS 传播 / 信任链（安全类考点）

### 3.1 信任链未建立 → 验签不生效 / SERVFAIL
- **现象**：子区已启用 DNSSEC 签名，但验证型 resolver 不做验签；或链中断导致 SERVFAIL。
- **根因**：只启用签名不够，**必须建立 chain of trust**：`example.com` 启签并把 DS 注册到 `.com`；`123.example.com` 把 DS 注册到 `example.com`。DS 是 KSK 的哈希，缺任一级 DS 传播，验签不发生（子区签名也白搭）。
- **关键行为**：VPC 上启用 DNSSEC 验证后，**验签失败会返回 SERVFAIL**（拒绝返回伪造应答）。
- **SME 考点**：能画出逐级 DS 注册链；能解释“启签 ≠ 验签生效”；能解释 R53 Resolver 验签失败 → SERVFAIL 而非放行。
- **来源**：answers 173606（DS 记录支持）；answers 340988（子域委派 DNSSEC 注册链）；answers 374223（有/无委派的子域 DNSSEC）；answers 363292（Resolver 验签失败返回 servfail）。

### 3.2 R53 Resolver 的 DNSSEC 只对“自己递归解析的名字”验签，不覆盖转发区
- **现象**：客户以为开了 Resolver DNSSEC 验证就全链路验签。
- **根因**：R53 Resolver 只在**自己执行递归解析时**做 DNSSEC 验证；**转发给其他 resolver 的查询由那个 resolver 负责验签**。且 `.2` Resolver **忽略 DO/CD 位、不回 AD 位与 RRSIG** → 客户端自己做验签（delv）会失败，需自建递归 resolver。
- **SME 考点**：Resolver 验签范围 = “它自己递归解析的”，转发区不覆盖；`.2` 不返回 DNSSEC 记录/AD 位，客户端验签不支持。
- **来源**：answers 363292（DNSSEC support for AmazonProvidedDNS/Route 53 Resolver）。

### 3.3 复用同一 KMS CMK → 多区 KSK 相同但 DS 值不同
- **现象**：多个 PHZ 复用同一 CMK，客户困惑 DS 记录各异。
- **根因**：复用 CMK → KSK 相同（同一公钥/key id）；但 DS 用 ECDSA P-256 + SHA-256（algo 13），**同一消息多次签名值不同**，故不同 HZ 显示不同 DS 值——任取其一上传给 RIR 即可。ZSK 各区独立（R53 管理）。注意别跨 fault domain 复用 CMK（prod/non-prod 应分开）。
- **SME 考点**：CMK 复用 → KSK 同、DS 值可不同；每个 HZ 仍需各自启用签名；fault domain 隔离建议。
- **来源**：answers 361110（Route 53 reuse DNSSEC CMK）。

### 3.4 禁用 DNSSEC 时 `KeySigningKeyInParentDSRecord 400`
- **现象**：想在 R53 HZ 上禁用 DNSSEC 报 `KeySigningKeyInParentDSRecord 400`。
- **根因**：父区仍有指向该 KSK 的 DS 记录，必须**先从父区/注册商移除 DS**（先解除信任链）才能安全关签。这也是防“回滚太快”类 DNSSEC 事故的关键（Slack 事件：回滚未考虑 resolver 缓存把小故障放大）。
- **SME 考点**：关 DNSSEC 前必须先撤父区 DS；回滚要考虑 resolver 缓存 TTL，分步进行。
- **来源**：answers（SUPPORT ENGINEER 文章 `troubleshoot-keysigningkeyinparentdsrecord-400-error...`，见 answers 340988/374223 relevant content）；answers 315038（Slack DNSSEC rollout 事故引用）。

---

## 四、Health Check 误判 / Failover 不触发（高频运营考点）

### 4.1 Health check 无法探测私有/内部资源 → failover 不动
- **现象**：内部 ALB/私有应用不健康，但 R53 failover 不切换。
- **根因**：R53 health check 从**全球公网 endpoint**发起，**无法探测私有 IP**。内部资源要么用 **CloudWatch alarm 型 health check**（探自定义指标），要么对 ELB 用 **Evaluate Target Health(ETH)**。
- **关键澄清**：**所有 ELB（含内部 ELB）自带 R53 health check**；只要在指向 ELB 的 Alias 记录勾选 **Evaluate Target Health** 即可免费用，不需自建 IP health check。
- **SME 考点**：R53 HC 探不了私有 IP；内部资源用 CW-alarm HC 或 ELB 的 ETH；不要对 ELB IP 自建 HC（用 ETH）。
- **来源**：answers 269205（internal ALB failover）；answers 297811（公网 LB 健康但私有应用不健康）。

### 4.2 ETH vs 显式 Health Check：语义不同、别同时开
- **现象**：客户同时给 Alias 记录开 ETH 和自定义 HC，行为不可预期。
- **根因/事实**：
  - **ETH 只对 Alias 记录有效**；从被指向资源（如 ELB/子记录集）拿健康状态。
  - 非 Alias 记录只能用显式 health check。
  - **Simple routing 下 ETH 无效**（只有一条同名同类型记录时，无论健康与否都返回）。
  - Alias + ETH 与显式 HC **同时开** → 两者都必须通过才算健康（AND），易产生“不一致/不想要”的结果，best practice 是**只开一个**。
- **NLB/ETH 判定细节**：ETH 对 NLB 做两层判断——(1) NLB 是否健康：cross-zone 关时，某 AZ 的 NLB 节点只探同 AZ 目标，“该 AZ 每个目标组至少一个健康目标”则该 AZ IP 进 DNS；(2) 目标是否健康：>1 目标组且有一个 UNHEALTHY → FAIL。
- **SME 考点**：ETH 仅 Alias；Simple routing ETH 无效；ETH+HC 同开是 AND 且不推荐；能讲 NLB 的 AZ 级 ETH 判定。
- **来源**：answers 49136（R53 traffic policies ETH vs HC）；answers 225168（VPCE ETH）；answers 302118（CW alarm failover，含 NLB ETH 判定细节）；answers 278648（Alias 自定义 HC）。

### 4.3 NLB “fail open” → 100% 不健康仍收流量，跨区 failover 不发生
- **现象**：某区 NLB 后端 100% 不健康，R53 仍往该区发流量。
- **根因**：**NLB fail-open**：当目标全部不健康时 NLB 仍放行（fail open），于是 ETH 认为“健康”，跨区 failover 不触发。
- **排查/方案**：改用 failover routing（只能选两个资源）配合能反映真实后端的 health check（如 CW 复合指标 / 应用级 HC）。
- **SME 考点**：NLB fail-open 是“全不健康仍收流量”的根因；ETH 依赖 LB 上报，LB fail-open 就骗过 ETH。
- **来源**：answers 328101（cross-region routing away from 100% unhealthy NLB）。

### 4.4 Health check 403/证书/SNI 导致“假不健康”
- **现象**：新建 health check 立刻 unhealthy（HTTP 403 / HTTPS 探测失败）。
- **根因**：探测被应用鉴权拦（403 Forbidden 即视为不健康）；HTTPS 探测需正确 SNI + 有效证书，子域证书没配好、路径需要鉴权都会误判。
- **排查手法**：确认探测路径返回 2xx/3xx；HTTPS 开 SNI；证书覆盖被探 FQDN；用 `describe-target-health` 拿不到细节时看应用侧日志/SG。
- **SME 考点**：health check 语义——2xx/3xx 才算健康，403 算失败；HTTPS 需 SNI + 证书匹配。
- **来源**：sage 670834（HTTP 403 → unhealthy）；sage 1540208（新域 HTTPS health check 持续 unhealthy，SNI/证书）。

### 4.5 Failover “双记录”返回规则（必背）
- **事实**：主健康 → 只返回主；主不健康、备健康 → 返回备；**主备都不健康 → 返回主**（last resort，不是不返回）。
- **验证手法**：在目标 SG 上移除 NLB VPC IP 制造不健康，观察 DNS 结果变化。
- **SME 考点**：能背“都不健康返回主”的兜底行为。
- **来源**：answers 302118（rupbajaj “How Route 53 works”）。

---

## 五、路由策略意外行为（latency / weighted / geo）

### 5.1 Latency-based routing 结果“反直觉”（按 resolver IP 而非客户端）
- **现象**：同一 DC 内，经 NAT 的服务器解析到 us-east-1（预期），但用带公网 IP 的 resolver 解析却到 us-west-1（意外）。
- **根因**：R53 按**发起解析的 resolver 的源 IP**（不是最终客户端）估算地理/延迟；不同 resolver 的公网 IP 来自不同 ISP 池 → 判到不同区。若 resolver 开了 **EDNS0 (ECS)**，会把客户端子网转给权威，用客户端 IP 判定；不开则用 resolver IP。
- **排查手法**：查两条查询实际用的源 IP（ipinfo.io 看归属）；确认 resolver 是否启用 EDNS0/ECS。
- **注意**：VPC Resolver **不支持 ECS**（RFC7871 建议权威忽略 RFC1918/RFC4193 私网地址，而 VPC 用私网）。
- **SME 考点**：latency/geo 基于 resolver IP，非客户端 IP；ECS 是否启用改变判定源；VPC resolver 不支持 ECS。
- **来源**：answers 350874（unexpected latency-based routing）；wiki NetTFC Route53（VPC Resolver 不支持 ECS）。

### 5.2 Weighted 记录中权重为 0 + health check 的交互
- **现象**：一组 weighted 记录部分权重 0 部分非 0，健康时行为“意外”。
- **根因/事实**：R53 **先只考虑非 0 权重记录**；只有当所有非 0 权重记录都不健康时，才考虑 0 权重记录。可用于“权重 100/0”做手动 failover（换权重触发切换）。
- **SME 考点**：weighted+HC 的 0 权重兜底语义。
- **来源**：answers 52579（引 health-checks-how-route-53-chooses-records，weight 0 行为）。

### 5.3 多 API Gateway / 自定义域 weighted 路由 → 403 / HTTPS 失败
- **现象**：weighted 路由本身通，但 HTTPS 调用 403 或握手失败。
- **根因**：Alias/CNAME 指向的证书与被请求 Host 不匹配（host mismatch）；API Gateway 自定义域 + ACM 未配好会 403。
- **SME 考点**：路由通 ≠ TLS 通；weighted 到多 APIGW 要每个自定义域配好 ACM 证书 & Host 匹配。
- **来源**：sage 1715612（Weighted Routing with Multiple API Gateways）；answers 225168（giupeter 评论 host mismatch 证书错误）。

---

## 六、域名注册 / 转移卡点（Registrar 类考点）

### 6.1 转入卡在 `serverTransferProhibited`
- **现象**：从其他注册商转入 R53，状态卡 `serverTransferProhibited`，域名在原注册商已不可见。
- **根因**：该状态由**注册局(Registry)**设置（Verisign/PIR 等），常因法务/账单/域名状态在注册商侧不同步。`serverTransferProhibited` 比 `clientTransferProhibited` 更难解除（注册商要转呈注册局）。
- **排查手法**：对注册局做 WHOIS（.com/.net 查 Verisign，.org 查 PIR）看真实状态；若局侧显示 OK 则让注册商同步下发；仍是 serverTransferProhibited 多为账单问题；必要时联系原注册商。
- **SME 考点**：client* vs server* 状态码的区别与解除难度；WHOIS 查注册局而非注册商。
- **来源**：answers 11429（ServerTransferProhibited）；answers 203703（EPP 状态码含义）。

### 6.2 EPP 状态码 ≠ 变更请求通道；R53 的防劫持真正靠 IAM
- **现象**：安全审计报“Missing EPP configuration，可能被劫持”。
- **根因/澄清**：EPP 是**注册商↔注册局**的协议（Amazon Registrar ↔ Verisign），命令只接受 allow-list IP + 内部凭证。EPP 状态码（如 clientTransferProhibited）只是**域名状态**，不是发变更的通道。在 R53 Domains，防未授权变更的**真正机制是 IAM 角色/策略**——攻击者只有拿到有相应权限的 AWS 凭证才能改域。
- **SME 考点**：R53 Domains 无独立 EPP“配置”，clientTransferProhibited 有助防转移但可被有权限者移除；访问控制正解是 IAM。
- **来源**：answers 203703（Missing EPP configuration）。

### 6.3 转入卡在 step 5 / step 7；防御性注册(defensive registration)不支持
- **现象**：转入流程卡在第 5 或第 7 步；`.name` 防御性注册转入报 `2303 Object does not exist`。
- **根因**：step 卡住多为 auth code / 授权确认 / 原注册商未放行；**防御性注册**（域名是“blocked”而非真正“registered”）**R53 不支持转入**（2024 起明确）。
- **SME 考点**：能区分转入卡点的常见位置与含义；defensive/blocked registration 不支持。
- **来源**：answers 11429 relevant（Why is my domain transfer stuck at step 5 or 7）；answers 254848（defensive domain 不支持）。

### 6.4 NS 记录集配置错误 → 子域被接管（subdomain takeover）
- **现象**：NS RecordSet 误配导致子域可被第三方接管。
- **根因**：悬空/错误 NS 委派（指向已释放的外部区）→ subdomain takeover 风险。
- **SME 考点**：能识别悬空委派/NS 误配的接管风险，属安全考点。
- **来源**：answers（SUPPORT ENGINEER 文章 `Route 53 - NS RecordSet Misconfiguration - Subdomain takeover`，见 answers 340988 relevant content）。

---

## 七、其他 SME 常考真实点（补充）

### 7.1 ACM DNS 验证 / 委派断链导致证书卡 PENDING_VALIDATION
- **现象**：证书长期 `Pending Validation`；嵌套 CFN stack 因父 stack 失败回滚，把待验证的 DNS stack 删掉（表现为 `User initiated` DELETE，而非正常 rollback）。
- **根因**：ACM 靠 Route53 CNAME 验证记录；委派断链 / 验证 CNAME 未落地 / 嵌套栈父栈失败连带删子栈，都会卡验证。ACM 会周期性轮询 CNAME，DNS 委派完成后一段时间才签发。
- **排查手法**：dig 验证 CNAME 是否解析（`_xxx.domain CNAME _yyy.acm-validations.aws`）；核对委派链；查父 CFN 栈失败。
- **SME 考点**：ACM DNS 验证依赖 R53 记录 + 完整委派；证书卡住常是 DNS/委派问题而非 ACM 本身。
- **来源**：sage 1913139（ACM/嵌套栈回滚）；sage 903598 / sage 1435434 / sage 1093690（证书卡 pending，均为 R53 记录/委派缺失）。

### 7.2 私区“不 fallback”导致 RDS/VPCE 端点解析到公网 IP 或 NXDOMAIN
- **现象**：RDS/VPCE 端点解析到公网 IP（应为私有）或 NXDOMAIN。
- **根因**：VPC DNS 属性未开、PHZ 未关联该 VPC、或重叠命名空间私区无对应记录。
- **SME 考点**：把 1.2/1.4 的机制套到 RDS/PrivateLink 端点解析场景。
- **来源**：sage 1647103（domain NXDOMAIN status）；wiki DNS/DHCP Runbook；answers（RDS 端点解析公网 IP 文章）。

### 7.3 从 on-prem 直接查 VPC `.2`（CIDR+2）不受支持
- **现象**：on-prem 直接把查询转发到 VPC .2 地址，结果不稳定。
- **根因**：**不支持从 on-prem 把私有 DNS 查询转发到任意 VPC CIDR+2**，会不稳定；正解是用 **Inbound Resolver Endpoint**。`.2` 也不应经 DX/VPN 从别处访问（TGW 场景偶发响应某 VPC 的 .2 是 bug）。
- **SME 考点**：on-prem → VPC 私有解析必须走 inbound endpoint，不能直连 .2。
- **来源**：answers 318814（VPC DNS resolving from on-prem without Resolver）；wiki NetTFC Route53。

---

## SME 速记（一句话考点清单）
1. .2 解析优先级：**Firewall → Resolver 规则 → PHZ → 公网**，longest match 优先；同域 PHZ vs forward rule 看长度，等长时 custom forward 胜。
2. PHZ 重叠命名空间**不 fallback 公网** → NXDOMAIN，正解 split-view。
3. PHZ 生效前提：VPC **enableDnsSupport + enableDnsHostnames** 都要开。
4. 两个硬限：`.2` **1024 PPS 不可增**；endpoint ENI **10K QPS 可加 ENI**；R53 生成冗余出站查询。
5. **SG 限制 / 走 NLB → conntrack → 10K 降到 ~1.5K**；指标 `conntrack_allowance_exceeded_delta` / `udp_throttled_count`。
6. 出站超时且限流正常 → 查**目标 NS 不可达**（timeout% + 按 destip 聚合）。
7. inbound endpoint 只吃**递归**查询，iterative **静默丢弃**。
8. 共享出站 endpoint 有**吵闹邻居**风险（2026-02-04 TRE 事件，821K QPS）。
9. DNSSEC：**逐级 DS 注册**建信任链；验签失败 → **SERVFAIL**；`.2` 不返回 DNSSEC 记录/AD 位。
10. 关 DNSSEC 前**先撤父区 DS**（`KeySigningKeyInParentDSRecord 400`）。
11. R53 HC **探不了私有 IP**；ELB 自带 HC，用 **ETH**；Simple routing ETH 无效；ETH 仅 Alias。
12. **NLB fail-open** → 全不健康仍收流量，跨区 failover 不切。
13. latency/geo 基于 **resolver IP**（或 ECS 时客户端子网），非客户端；VPC resolver 不支持 ECS。
14. 域转移 `serverTransferProhibited` 比 client 难解；R53 防劫持靠 **IAM**，EPP 状态码只是状态；防御性注册不支持转入。
15. ACM/证书卡 PENDING 多为 **R53 验证 CNAME / 委派断链**问题。

# Route 53 SME 备考 —— Amazon 内部资料研究（第一块）

> 目的：为 Route 53 SME 考试构建 SME 级深度的内部权威素材。按知识域分节，每条尽量带来源链接。
> 检索工具：InternalSearch（WIKI/ALL/BROADCAST 域）。检索日期：2026-09-20。
> 说明：以下链接均为 Amazon 内部 wiki（w.amazon.com）、Broadcast、command-center 案例库等，需 Midway 登录访问。

---

## 0. 权威源导航（先看这些"总目录"）

这几个页面是内部 Route 53 知识的骨架，几乎所有专题文章都从这里链出，是 SME 备考的第一入口：

- **Route 53 SME Training Page（SME 认证官方备考页）** — 分 Stage 1/2/3，Week 1–13，每周有"Major competencies checklist"，直接对应 SME 考点。
  https://w.amazon.com/bin/view/AWSSupportPortal/CST/GlobalLearning/CE/SME/SESMEHomepage/Current_%26_Upcoming_SME_Accreditations/Route53SMETrainingPage/
- **New-Route53-SME-Journey / Route53-SME-Journey（SME 学习路径，含 Week 5 高级专题清单）**
  https://w.amazon.com/bin/view/New-Route53-SME-Journey/
  https://w.amazon.com/bin/view/Route53-SME-Journey/
- **Route53 PS Engineer Journey — Stage 1（DNS 基础 + Amazon Learn 1XX/2XX/3XX 视频清单）**
  https://w.amazon.com/bin/view/Route53_PS_Engineer_Journey/Stage1/
- **Route 53 PC/CS PlayBook（Support 参考手册 + Knowledge Center 文章总集）** — 内含 DNS/HealthCheck/Resolver/Domains/ARC 各子手册。
  Knowledge Center Articles 总目录：https://w.amazon.com/bin/view/Route53_PC_CS_PlayBook/KnowledgeCentreArticles/
- **TAM Field Guides — Route 53（概念 + Public DNS 深度页，讲 ALIAS/CNAME/路由策略/EDNS0 很清楚）**
  https://w.amazon.com/bin/view/TAM_Field_Guides/Networking/R53/
  Public DNS 深度页：https://w.amazon.com/bin/view/TAM_Field_Guides/Networking/R53/R53PublicDNS/
- **Networking TFC — Amazon Route 53（架构总览 + Draw.io 源图 + 大量 SME 边界结论 + Feature Demo 视频）** —— 强烈推荐，很多"易错点/内部限制"结论集中在这页。
  https://w.amazon.com/bin/view/AWS/Teams/Technical_Feedback_Communities/Networking/Resources/AWS-Services/Route53/
- **CWR-Route53（ADC/DSE Well-Architected 检查清单，逐项列配额、限流、DR 推荐配置）** —— SME 级"配额/限流/DR"速查表。
  https://w.amazon.com/bin/view/AWSSupport/ADC-SE/Support/DSE-CWR-Checklist/CWR-Route53/
- **内部服务架构（Stage 3 深挖，SME OSA board 必读）** —— Route 53 Domains / DNS / Health check / Resolver "Service Internals"，链接从 SME Training Page 的 Stage 3 段落进入。
- **日文 Networking Profile 案例库（infosearch/Route53/Case）** —— 数百条真实案例 QA（AI 匿名化），是"边界条件/易错点"的金矿；本文多处引用其中的 QA-xxxx。
  https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/

---

## 1. Hosted Zones（Public / Private）

**核心概念**
- Public Hosted Zone：在互联网上路由域名流量；Private Hosted Zone（PHZ）：在 VPC 内路由。（TAM Field Guides / Networking TFC）
- **Zone apex（顶点）不能建 CNAME**：RFC 规定 CNAME 不能与其他记录共存，而 apex 至少已有 NS + SOA 记录 → apex 只能用 **ALIAS** 记录指向 AWS 资源（ELB、CloudFront、API GW、S3、另一条本 zone 记录）。
  来源：https://w.amazon.com/bin/view/TAM_Field_Guides/Networking/R53/R53PublicDNS/
- **ALIAS vs CNAME 的 SME 级差异**：
  - CNAME 解析会先返回它指向的记录名，再继续解析到目标 IP；ALIAS **只返回 IP**（隐藏背后的 ELB/CloudFront）。
  - 指向 AWS 资源的常见 ALIAS 查询**免费**；ALIAS 指向的目标记录查询由"被指向资源的所有者"付费；ALIAS 指向本 zone 内其他记录仍由本 zone 所有者付费。
  - 来源同上（R53PublicDNS）。

**PHZ 边界/易错点（来自真实案例）**
- **PHZ 与 VPC Resolver Rule 同域名冲突**：若同一 VPC 既关联了 example.com 的 PHZ，又有一条转发 example.com 到网络的 VPC Resolver Rule，则 **Resolver Rule 优先**，DNS 查询会被转发出去而不是用 PHZ 记录解析。迁移/解关联时要先解 PHZ 关联还是先解 Rule 关联，顺序很关键。
  来源：QA-3982 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Case/QA-3982/
- 使用 PHZ 需要 VPC 属性 `enableDnsHostnames` / `enableDnsSupport`；DHCP Option Set 指定自定义 DNS 时 PHZ 记录会 NXDOMAIN（案例 Index-9 系列多条）。
- 跨账号关联 PHZ 到别账号 VPC：需 `VpcAssociationAuthorization`（或用 Route 53 Profiles 免此步）。
- Split-view / 同 VPC 内不同主机返回不同结果：单纯 R53 无法实现（Index-9 QA）。
- 删除带 KSK 的 zone 会报 `HostedZoneNotEmpty`（Index-4 QA-325）。

---

## 2. 记录类型与 ALIAS

- 支持记录类型：A / AAAA / CNAME / MX / TXT / PTR / SRV / SPF(不推荐) / NAPTR / CAA / NS / SOA。
  来源：https://w.amazon.com/bin/view/AWS-Mandarin-CS-LandingPage/AWS-Mandarin-CS-core/Knowledge/Continuous_Education/Route53/
- **TTL**：系统不为记录设默认 TTL，需自行设定（建议 60–172800 秒）。SOA 也可缩短 TTL，无副作用（案例 Index-9 QA-322）。
- **ALIAS 链**：ALIAS 的 target 不能再是另一条 ALIAS/CNAME；CNAME 的 target 可以是 ALIAS/CNAME（案例 Index-9 QA-317）。
- **Simple routing RRSET 行为**：一个命名空间下 simple 记录只能有一条 RRSET；RRSET 内可含多个值，R53 name server 返回该 RRset 的**全部值并随机排序**（不是"每次最多 8 个"——8 值上限属于 **Multivalue answer** 路由策略）；单 RRset 值的数量受**单 RRset 配额 400 个值**约束。
  来源：R53PublicDNS（同上）。
- **NULL MX / SPF / DKIM / DMARC / CAA** 常见配置与验证方法（案例 Index-4 多条）。

---

## 3. 路由策略（Simple / Weighted / Latency / Failover / Geolocation / Geoproximity / Multivalue / IP-based）

**总览来源**：R53PublicDNS、kyoheibb 个人页（路由策略逐条中文/日文笔记）
https://w.amazon.com/bin/view/Users/kyoheibb/AWS/Route53/

- **Simple**：单资源，无健康检查；PHZ 里可建。
- **Weighted（加权）**：单条记录 weight 上限 **255**；总流量按 weight/总和 分配。**同一 ELB 可被多条记录引用**以实现比 256 分割更细的分配（案例 Index-8 QA-483）。测试加权必须直接 dig zone 的权威 NS 并发约 10K 次才看得出比例（1–2 次看不出）。
  来源：TSR53DNSService https://w.amazon.com/bin/view/Route53_PC_CS_PlayBook/TSR53DNSService/
- **Latency-based (LBR)**：路由到延迟最低的 AWS Region 的资源；所有目标必须在 AWS Region。用多数据源推断延迟（含 geo 数据）。
- **Failover**：Active-Standby；**Primary 记录必须关联 Health Check**（否则无法创建 failover 策略）。**Primary+Secondary 健康检查都异常时 → R53 返回 Primary（fail open 到 primary）**，此行为不可配置（案例 Index-9 QA-337）。
- **Geolocation**：按用户地理位置（大洲/国家/州）路由，可设默认 `*` 记录。
- **Geoproximity**：按地理距离 + **Bias**（可调资源影响范围大小）；2024/01 起可在 Traffic Flow 之外直接创建。
  来源：kyoheibb 页。
- **Multivalue Answer (MVA)**：最多 8 个值随机返回，可各带健康检查（DNS 级简单负载均衡）。
- **IP-based routing**：按客户端 IP CIDR 路由（CIDR collection）。**匹配规则**：R53 把比指定 CIDR 更长的查询 CIDR 匹配到更短的指定 CIDR；若无默认 `*` 且查询源 CIDR 不匹配任何 CIDR → 返回 **NODATA**。
  来源：TSR53DNSService（IP-based Routing Troubleshooting 段）。

**EDNS0 / ECS 的 SME 关键点（路由策略正确性的核心）**
- Geo/Latency/IP 类策略依赖客户端信息。若中间 resolver 支持 **EDNS0 / EDNS-Client-Subnet (ECS)**，R53 name server 能拿到更接近真实客户端的信息 → 路由更准；不支持 ECS 时基于 resolver 的 IP 判断，可能"地理定位错误"。
- **VPC DNS resolver (.2) 支持 EDNS0，但不支持 ECS。**
- 检测 resolver 是否支持 ECS：`host -t txt o-o.myaddr.google.com.`（响应含 `edns0-client-subnet` 即支持）；或 `dig TXT o-o.myaddr.google.com -4`。
  来源：Networking TFC 页 + TSR53DNSService。

**Traffic Flow / Traffic Policy**
- 在控制台图形编辑器里编排路由策略并做成 policy；无法把"已建好的普通记录"反向 GUI 化。用 R53 Information Search Tool 查 Traffic Policy Instance。
  来源：kyoheibb 页 + TSR53DNSService。

**路由策略排障文章（Playbook）**
- Troubleshooting LBR / Geolocation / GeoProximity routing decisions
- Troubleshoot weighted routing DNS resolution
- Troubleshoot Latency Based Routing
- Understand & troubleshoot failover routing policy
- Routing Policies & Health Checks — Edge Cases
  以上均从 SME Training Page → Week 6 "Routing Policies" 链出。

---

## 4. 健康检查（Health Checks）

- 三种类型：**Endpoint-based**（HTTP/HTTPS/TCP）、**Calculated**（组合多个子 HC）、**CloudWatch Alarm-based**。
- **健康检查器源 IP**：2023/09 起以 **AWS managed prefix list** 形式提供，IP 会被 AWS 自动更新；该 prefix list 的 weight（消耗名额）为 25，需注意上限缓解。防火墙放行时**不能只放自己 region 的 CIDR**，健康检查器来自多 region。
  来源：kyoheibb 页 + CWR-Route53。
- **Fail-open 行为**：一个 Hosted Zone 的**所有 HC 都不健康**时，R53 **fail open**（当作全部通过来应答）。这是排障 TSOA runbook 明确指出的坑。
  来源：https://w.amazon.com/bin/view/TrafficShift/SOA/MR_TSOA_Troubleshooting_Runbook/
- **Evaluate Target Health (ETH)**：ALIAS 指向 ELB 时用 ETH 而非单独 HC。
- **内部 ALB（非公网）无法用 endpoint HC**（状态会异常）→ 需用 CloudWatch alarm-based HC 或 calculated HC。
- **String matching HC / Inverted HC / 配 Hostname 的 HC** 是常见排障场景。
- 内部工具：Route53 Customer Information Search（用 HealthCheck ID 查配置/CloudWatch metric/PercentageHealthy）、K2 "HealthCheck Failure Reason" 脚本（查最近失败原因 + 检查器 IP + region + epoch 时间）。
  来源：https://w.amazon.com/bin/view/Route53_PC_CS_PlayBook/TSR53HealthCheckService/
- 排障文章：Route 53 health checks service / Troubleshooting Route 53 health check service / Working of health checks in complex configurations / ETH for Alias to LB（SME Training Page → Week 6 "Health Checks"）。

**易错点**：failover 回切（failback）比预期快——HC 间隔 10s/失败阈值 3/TTL 20s 却约 10s 回切（案例 Index-8 QA-482，涉及 HC 评估与 TTL 交互）。

---

## 5. Route 53 Resolver（Inbound / Outbound Endpoints、Resolver Rules、DNS Firewall）

**基础架构（Resolver 是 Regional 服务，非 global）**
- VPC 通过 **VPC+2** 地址连到 Route 53 Resolver。Resolver 自动应答：EC2 本地 VPC 域名、PHZ 记录；公网域名做递归查询。
  来源：QA-385 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Case/QA-385/
- **Inbound Endpoint**：接受外部（on-prem）→ VPC 的 DNS 查询（解析 PHZ 等）。
- **Outbound Endpoint**：把 VPC 的查询转发到外部 DNS（on-prem / 公网）。Outbound 是私有 IP，要发到公网 DNS（8.8.8.8 等）需 **NAT Gateway**。
  来源：BootCamp 1154827 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/Route_53/BootCamp/1154827/
- **每个 endpoint 最多 6 个 ENI，可承受高达 60,000 请求/秒**（每 ENI 承担一部分）。多 AZ 分布保证高可用。
  来源：Learn108 https://w.amazon.com/bin/view/Users/kitanish/r53/Learn108/

**Resolver Rules（3 种类型）**
- **Conditional forwarding rules（条件转发）**、**System rules**、**Recursive rules**。Rule 必须关联一个 outbound endpoint 才生效。
- **`.`（dot）rule**：默认自动定义，适用于除 PHZ 内部 AWS 域名/记录外的所有域名；无自定义规则匹配时按 dot rule 转发。要把所有查询转发到网络 DNS，就建一条域名为 `.` 的 forward 规则。
  来源：QA-385（同上）。
- **RAM 共享**：一个账号建的 forwarding rule 可用 AWS RAM 共享给同 region 其他账号；共享 rule 的父账号 outbound endpoint 也随之共享，**无需额外 VPC peering**；需 `PutResolverRulePolicy` 权限；成员账号不能改/删共享 rule。
  来源：Learn108 + QA-1466 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Case/QA-1466/

**QPS / 吞吐边界（SME 高频考点）**
- **每 ENI ~10K QPS**（endpoint 每 ENI），但**经 NLB 或 Security Group 会因强制 connection tracking 把每 ENI 有效 QPS 从 ~10K 降到 ~1.5–1.7K（约 6 倍下降）**。高 QPS 场景应避免把流量经 NLB。
  来源：Networking TFC 页（Resolver QPS 段）。
- 见"配额与限流"节的 1024 PPS（这是 VPC+2 link-local 的实例侧限制，与 endpoint QPS 是两回事，别混淆）。

**Resolver 排障文章合集**（PlayBook Knowledge Center）
https://w.amazon.com/bin/view/Route53_PC_CS_PlayBook/KnowledgeCentreArticles/
包含：Resolver Endpoints How-To、reverse DNS、"Action needed" 状态、Outbound target IP fail 行为、避免 DNS loop 的 endpoint 配置、经 NAT 转发到公网、"Action needed"、小 MTU（VPN）下的最佳实践、QPS Quota 检查、intermittent timeout 因 endpoint throttling、OutboundQueryVolume 与 VQL count 的差异等。
- **Understanding Route53 Resolver Outbound Endpoints Behavior When a Target IP Fails**、**Avoid DNS Loops**（endpoint + Profiles）也在此。
- Resolver Service Internals（SME Training Stage 3）为架构级深读。

**DNS Firewall**
- 通过 Resolver（inbound/outbound）过滤 DNS 请求，allow/deny 域名，可结合 threat intelligence 或解析 query log 自动生成 allow/deny list。
- **AWS 托管域名列表不公开具体域名**，每个列表含数千域名，至少每日更新一次。
  来源：Networking TFC 页（DNS Firewall 段）。
- 易错点：**allowlist 方式**下，若允许域名的 CNAME target 指向另一个未在列表中的域名，会因 `A+AAAA 记录缺失` 而被 `firewall_rule_action: BLOCK`（案例 Index-8 QA-497）。→ 参见 "Trust Redirection Domains Setting"。
  来源：PlayBook DNS Firewall 段。
- 排障文章：DNS Firewall blocks a domain added with 'ALLOW' action / How to read DNS Firewall configuration / DNS Firewall Lab（SME Journey Week 5）。

---

## 6. DNSSEC

- **概念**：DNSSEC signing 让 resolver 验证响应确实来自 R53 且未被篡改；每个响应用公钥密码学签名。
- **KSK vs ZSK 责任划分（SME 关键）**：
  - **KSK（Key Signing Key）**：用户负责，用 AWS **KMS** 里的非对称 CMK；KSK 轮换是用户责任/手动。
  - **ZSK（Zone Signing Key）**：**Route 53 自动管理并轮换**，采用 **Pre-Publish Zone Signing Key Rollover**，签名开始后 **7–30 天**启动定期 ZSK 轮换，之后每 7–30 天重复。因此外部工具看到 DNSKEY 里多出一个新 ZSK（临时两个 ZSK 并存）是**正常现象**，不是异常。
  - 来源：QA-2638 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Case/QA-2638/
- **PHZ 不支持 DNSSEC**（仅 public zone）。
- 删除带 KSK 的 zone 会 `HostedZoneNotEmpty`；需先 deactivate/delete KSK（案例 Index-4 QA-325）。
- **信任链**：父 zone 未签名则子 zone 无法建立 DNSSEC 信任链（案例 Index-4 QA-347）。
- 参考：Resilient Route 53 (R253) 页含 "Configuring DNSSEC signing" 摘录 https://w.amazon.com/bin/view/Abnagpal/UIS/R253/
- 排障文章（SME Journey Week 5）：DNSSEC - A walk through approach / How to verify DNSSEC is enabled / Step by step troubleshoot DNSSEC / Broadcast video on DNSSEC。
- Resolver 侧还有 **Resolver DNSSEC validation**（与 zone signing 不同，是校验方向）。

---

## 7. 域名注册与转移（Route 53 Domains）

- Route 53 Domains 是 **global 服务，仅 us-east-1，仅商业 partition**；endpoint `route53domains.us-east-1.amazonaws.com`。
  来源：TAM Field Guides — Route 53（APIs 段）https://w.amazon.com/bin/view/TAM_Field_Guides/Networking/R53/
- 支持一批 gTLD 和地理 TLD，**并非所有 TLD 都支持注册**；缺某 TLD 不影响用该域名建 Hosted Zone（可在别的 registrar 注册后用 R53 建 public zone）。新 TLD 走 "R53 Request New TLD process"。
- **Premium / special-pricing 域名非公开支持**，特定情况下可例外。
- **不能在 AWS 内部 Isengard 账号用 R53 Domain Registration** → 用 SuperNova 拿 AWS 专用子域名。
  来源：Networking TFC 页（Domain Registration 段）。
- **Domain locking（转移锁）**：防止域名被意外转到别的 registrar；2025/10 起 **.JP 域名不支持转移锁**（此前文档误导为支持）。
  来源：kyoheibb 页 Domain locking 段。
- 常见问题：`ClientHold`（suspended）、`We can't finish registering your domain`、`.jp` Whois 联系人必须完全一致、registrant email reachability 验证（`get-contact-reachability-status` 可能未验证却返回 `DONE`）、NS 切换传播时间等（案例 Index-8/Index-9 大量条目）。
- 排障来源：PlayBook Route 53 Domains 段 + SME Training Stage 3 "Route 53 Domains Service Internals"。

---

## 8. Route 53 Profiles

- 2024/04 GA。用途：把 region 内多 VPC 的 DNS 配置**跨账号统一管理并分发**（借 RAM），包括：**PHZ associations、Resolver forwarding rules、DNS Firewall rule groups**。
- 2025/11 起 Profiles 支持把 **Resolver Query Logging 配置**纳入，建 VPC 时分配 Profile 即自动带上 query logging。
  来源：kyoheibb 页 Profile 段。
- 易错/排障：避免与 Resolver endpoints + Profiles 形成 loop 配置；用 Profiles 简化 VPC endpoint 的 Private DNS；跨账号关联 PHZ 免 `VpcAssociationAuthorization`；共享 Profile 无法关联 PHZ 的问题。
  来源：PlayBook Knowledge Center "Route 53 Profile & RAM" 段。

---

## 9. Application Recovery Controller (ARC)

- **2024/08/22 起 ARC 在案例控制台里成为独立服务**（原在 Route 53 伞下），仍属 Networking & Content Delivery 类目；**Route 53 SME 仍是 POC，R53 Support Ops 处理所有 ARC escalation**。
  来源：https://w.amazon.com/bin/view/Route53_PC_CS_Playbook/Route53_Application_Recovery_Control/
- ARC 两大能力：
  1. **Multi-AZ recovery**：Zonal Shift / Zonal Autoshift（把某 AZ 流量移走）。适用于 NLB 和 **关闭跨区负载均衡的 ALB**。原理：ARC 把该 AZ 对应 IP 的 R53 健康检查设为 unhealthy → 流量不再进该 AZ；shift 必须有过期时间，最长 **72 小时（3 天）**，可更新/取消。**fail-open 场景**（target group 无实例或全不健康）时 zonal shift 不会移流量。
  2. **Multi-Region recovery**：Routing Control（"big red button" 式手动/告警切换）+ Readiness Check（每 1 分钟审计容量/配额/限流/配置版本差异）。面向 RTO < 5 分钟 / 可用性 > 99.99% 的极高可用应用。
  来源：R253 页 + PeRC 页 https://w.amazon.com/bin/view/Route53/ADC-DNS-UK/OK/PeRC/
- **ARC 可与任何支持健康检查的路由策略配合**：Weighted / Geolocation / Latency / Failover。
  来源：Networking TFC 页（ARC 段）。
- **监控 region 的坑（SME 易错）**：ARC routing control / readiness check 的 CloudTrail / CloudWatch（`AWS/Route53RecoveryReadiness` 命名空间）/ EventBridge 事件发生在 **us-west-2（俄勒冈）**；在东京等 region `list-metrics` 查不到。Region switch 的部分控制面 API 事件记录在 **us-east-1**。设计告警要以 us-west-2 为准。
  来源：QA-3396 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Case/QA-3396/
- **ARC 非必须**：region 故障切换也可只用 Failover 记录（public zone 是全球资源，单 region 故障不影响 zone 本身）；手动切换可用 (A) 手改 simple 记录、(B) 固定子域名 + 手动改 apex ALIAS、(C) failover 记录 + 禁用并反转 HC 状态。
  来源：QA-2811 https://w.amazon.com/bin/view/AmazonWebServices/SalesSupport/DeveloperSupport-JP/NetworkingProfile/infosearch/Route53/Case/QA-2811/

---

## 10. 与其他服务集成（CloudFront / ELB / S3 / API Gateway / Global Accelerator）

- **ALIAS 指向 AWS 资源**（ELB、CloudFront、S3 website、API GW、Global Accelerator、VPC endpoint、另一条本 zone 记录）；apex 只能 ALIAS 不能 CNAME。
- **ELB (NLB) 用 A-ALIAS 还是 CNAME**：apex 必须 A-ALIAS；子域可 CNAME，但 ALIAS 免费且能配 ETH（案例 Index-4 QA-305）。
- **CloudFront 集成易错**：CloudFront resolver identity 域名有时返回 **NODATA**（因 EDNS Client Subnet 源不同间歇空应答）；排障要切分 R53 HC 指标缺失与 CloudFront 侧请求失败的因果（案例 Index-8 QA-498/499、SME Journey Week 5 "CloudFront resolver identity domain NODATA"）。
- **S3 wildcard ALIAS**：给 `s3-accesspoint.<region>.amazonaws.com` 建 `*` ALIAS 却 dig 不到期望 VPC endpoint IP 的坑（案例 Index-8 QA-484）。
- **API Gateway**：加权路由指向别账号 API GW 自定义域名用哪种记录（案例 Index-4 QA-314）。
- **Global Accelerator**：用 ALIAS 把自定义域名指向 accelerator DNS 名。
  来源：R253 页 AGA 段。
- **ACM 证书 DNS 验证**：CNAME 建在 R53 还是外部 DNS 的判断（案例 Index-8 QA-517）。

---

## 11. 限流与配额（SME 高频，务必记牢边界数字）

来源主要是 **CWR-Route53 检查清单** https://w.amazon.com/bin/view/AWSSupport/ADC-SE/Support/DSE-CWR-Checklist/CWR-Route53/ + Networking TFC + Internal DNS Modernization MBR。

- **VPC DNS / 1024 PPS（最重要）**：每个 EC2 实例的**每个网络接口**向 Route 53 Resolver（VPC+2 link-local）最多 **1024 packets/second**，超出被丢弃，**此限制不可调**。这是 SME 反复考的硬限制。诊断方法（SME Journey Week 5）：
  - How to determine if DNS query PPS reaches 1024 PPS on **Gunpowder** / **Xen**
  - 用 **amzlogs** 查 Gunpowder 实例是否触顶
  - 用 **Interface Analyzer** 一次性判断 Xen 和 Gunpowder 是否触顶（最简便）
  - 来源：https://w.amazon.com/bin/view/New-Route53-SME-Journey/ Week 5
  - 内部实证：Internal DNS 迁移到 R53 时，超 1024 PPS 的客户会受影响，需逐个改造（Internal DNS Modernization MBR：HKG/NRT/IAD 各识别出 5/6/139 个超限客户）。
    https://w.amazon.com/bin/view/Users/aslanova/Quip/InternalDNSBuilds_on_R53/February_2025_Update/
- **Resolver endpoint ENI 吞吐**：每 ENI ~1.5K–10K PPS/QPS；经 NLB/SG 因 connection tracking 降到 ~1.5–1.7K QPS（见第 5 节）。
- **Route 53 API 限流（token bucket）**：in-region 最大容量 **40**、补充 **5/秒**（account 且 per-API）；无 change-throughput 限速可用 → 自动化要指数退避。
- **配额速查**：Hosted zone 数、每 zone 记录数（`MAX_RRSETS_BY_ZONE`，默认 50 可调，案例 Index-8 QA-516）、Health check 数、Resolver endpoint 数、Resolver rule 数 —— 都在 Service Quotas 里，参见 CWR-Route53 "Service quotas & limits" 段与官方 [Route 53 quotas]。
- **加权记录 weight 上限 255**（见第 3 节）。
- 排障文章：How to investigate for Route 53 API throttling in customer account（PlayBook KC "API Throttling"）；AWS:Route 53-303 API Throttling（Amazon Learn 3XX）。

---

## 12. 常见故障模式与排查（内部 runbook / playbook / 案例）

**排障总入口**
- Troubleshooting Route 53 DNS Issues（PlayBook）：https://w.amazon.com/bin/view/Route53_PC_CS_PlayBook/TSR53DNSService/
- Troubleshooting Route 53 Health Check Issues：https://w.amazon.com/bin/view/Route53_PC_CS_PlayBook/TSR53HealthCheckService/
- MR-TSOA Troubleshooting Runbook（dig/NXDOMAIN/fail-open 实战）：https://w.amazon.com/bin/view/TrafficShift/SOA/MR_TSOA_Troubleshooting_Runbook/
- Core Networking PAN Runbooks（PHZ / ALB HC 简明 runbook）：https://w.amazon.com/bin/view/CoreNetworking/PAN/Runbooks/

**高频故障签名（SME 必须能条件反射）**
- **ServFail**：CNAME 指向 PHZ 记录导致 ServFail；DNS servfail 通用排障；Google 8.8.8.8 单独 SERVFAIL 而其他公共 DNS/权威直查正常的切分（案例 Index-9 QA-318）。
- **NODATA / NOERROR**：wildcard 记录却 NODATA；IP-based 无默认 `*` 且不匹配 → NODATA；CloudFront resolver identity 间歇 NODATA。
- **REFUSED**：R53 对 CNAME(ALIAS) 返回 REFUSED。
- **NXDOMAIN**：PHZ 未正确关联 VPC / DHCP option set 指向自定义 DNS；子域委派失败（Lame delegation，删 public zone 后 `internal type for both IPv4 and IPv6 (A+AAAA)` 报错）。
- **Subdomain Delegation Failure**、**NS delegation 错误**。
- **dig works but dig +trace does not**（递归 vs 迭代查询差异）。
- **VPC DNS options 如何影响 PHZ 与 Resolver rules**。
- **Reverse DNS (PTR / in-addr.arpa)**：Resolver rules 与反向解析、outbound endpoint 反向 DNS 排障。
- 工具：**Route53 Information Search Tool**（route53-information-search.amazon.com）、**Route53 Customer Information Search**、**Dexter**（DNS 网络监控 dexter-vpc-ia-iad.amazon.com）、**Command Center K2 script-runner**（HealthCheck Failure Reason）。
  来源：TSR53DNSService / TSR53HealthCheckService。

**dig 用法要点**（TSOA runbook）
- `dig +short name` 会先找 CNAME 再解到 A；`dig cname +short` 指定 CNAME 类型。
- NXDOMAIN 输出示例（status: NXDOMAIN，ANSWER:0，AUTHORITY 段带 SOA）。
- LSE 期间先查 https://lse.amazon.com。

**China / GovCloud、Service Availability、Security**
- AWS:Route 53-301 Service Availability / 304 Security / 305 China & GovCloud（Amazon Learn 3XX，Stage 1 页）。
- ADC/in-region 差异（CWR-Route53）：**geolocation 和 latency routing 在 in-region 不可用**；DR 用 failover/weighted（public zone 上可 IP-based）。Resolver query log group 在 in-region 必须放 east region（us-iso-east-1 / us-isob-east-1）。

---

## 13. 内部服务架构（Stage 3 / OSA board 深读）

从 SME Training Page Stage 3 "Internal Service Architectures" 段落链出（需从该页跳转）：
- Route 53 **Domains** Service Internals
- Route 53 **DNS** Service Internals（DaaS 架构）
- Route 53 **Health check** Service Internals
- Route 53 **Resolver** Service Internals
- Bootcamp 里对应 session：**DaaS（DNS as a Service）架构**、**HAAS（Health check as a Service）架构**、White Label NS、Reverse Zone Lab。
  来源：Route 53 AMER/EMEA Bootcamp 2026 https://w.amazon.com/bin/view/AWSSupportPortal/CST/GlobalLearning/CE/Bootcamps/BootcampWiki2025/Route53_AMER_EMEA_2026/
- **Draw.io 架构源图**（authoritative NS / recursive resolver / registrar / DNS firewall 全景）在 Networking TFC 页可下载。

---

## 14. 视频 / 培训资源（Broadcast + Amazon Learn）

- **Amazon Learn 系列**（1XX 基础 / 2XX 进阶 / 3XX 高级），完整清单见 PS Engineer Journey Stage 1：
  https://w.amazon.com/bin/view/Route53_PS_Engineer_Journey/Stage1/
  关键：201 DNS Deep Dive、202 Health Checks、203 Simple/Weighted/Failover/MVA、204 Geolocation & Latency、205 Geoproximity & Traffic Flow、206 Private Hosted Zones、302 Health Checks & Conditional Routing Tree、303 API Throttling、304 Security、305 China & GovCloud；Resolver 101/201/202/203；Domains 101–205（含 204 DNSSec）。
- **Networking TFC Feature Demo 视频**（Resolver Endpoints、Inbound Resolver、Profiles、Profiles+DNS Firewall priorities、Make R53 the DNS for existing domain、IP-based routing、Public/Resolver Query Logging、DNSSEC、Resolver DNS Firewall、Firewall Domain Redirection、Ransomware protection、ARC、STOP）——链接在 TFC 页。

---

## 附：可直接用作"考点速记"的 SME 边界数字/结论清单

- Zone apex 不能 CNAME，只能 ALIAS。
- Simple RRSET 返回全部值并随机排序（单 RRset 配额 400 值）；"最多 8 值"是 MVA 特性，非 Simple。MVA 最多 8 值随机。
- Weighted weight 上限 255。
- VPC → Resolver **1024 PPS/ENI，不可调**。
- Resolver endpoint 每 ENI ~10K QPS；经 NLB/SG 降到 ~1.5–1.7K QPS；每 endpoint ≤6 ENI，可达 ~60K req/s。
- R53 API token bucket：容量 40，补充 5/s。
- 每 zone 记录默认配额 50（`MAX_RRSETS_BY_ZONE`）。
- Failover：Primary 必须有 HC；Primary+Secondary 都 unhealthy → 返回 Primary。
- 全 zone HC 都 unhealthy → fail open。
- ZSK 由 R53 自动轮换（7–30 天，pre-publish）；KSK 用户负责（KMS CMK）。PHZ 不支持 DNSSEC。
- ARC 指标在 us-west-2；Zonal shift 最长 72h。
- Resolver / Profiles / ARC(routing control+readiness) 是 **Regional**；Public DNS / Domains 是 **Global(us-east-1)**。
- VPC .2 resolver 支持 EDNS0 但**不支持 ECS**。
- PHZ 与同域名 Resolver Rule 冲突 → Rule 优先。

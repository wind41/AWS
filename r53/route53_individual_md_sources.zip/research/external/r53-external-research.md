# Route 53 SME 备考 — 外部权威文档研究（AWS 官方 + 业界）

> 来源：AWS Route 53 Developer Guide / API Reference / ARC Developer Guide / re:Post / 业界深度解读。
> 每条附官方 URL。末尾「SME 高频考点与易错点」为应试速记。
> 采集日期：2026-09-20。

---

## 1. DNS 解析路径原理 / Route 53 定位

**Route 53 是什么**：一个 authoritative DNS 服务 + 域名注册商 + 健康检查/流量管理平台。它把域名映射到 IP。
官方递归解析路径（`www.example.com`）：

1. 用户浏览器 → ISP 的 DNS resolver（递归解析器）。
2. Resolver → DNS root name server。
3. Resolver → `.com` TLD name server；TLD 返回 example.com 的 **4 个 Route 53 name server**。
4. Resolver 缓存这 4 个 NS（**典型缓存 2 天**），选一个 Route 53 NS。
5. Route 53 NS 在 hosted zone 里查 `www.example.com` 记录，返回值（如 IP）。
6. Resolver 按记录 **TTL** 缓存该应答，返回浏览器。

- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/welcome-dns-service.html

**关键角色链**：Registrar（Amazon Registrar 或 associate Gandi）→ Registry（管某 TLD 的公司，如 .com）→ WHOIS。注册域名时 Route 53 自动成为其 DNS 服务、建同名 public hosted zone、分配 4 个 NS 并写回域名。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/welcome-domain-registration.html

---

## 2. Hosted Zones（公有 / 私有）

- **Public hosted zone**：控制 internet 上如何路由域名流量。注册域名时自动创建同名 public zone。
- **Private hosted zone (PHZ)**：与一个或多个 VPC 关联，只在这些 VPC 内经 Route 53 VPC Resolver 解析。使用 PHZ 需 VPC 设 `enableDnsHostnames=true` 且 `enableDnsSupport=true`。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zone-private-considerations.html
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/AboutHZWorkingWith.html

**PHZ 支持的路由策略**（考点：不是全部）：simple、failover、multivalue answer、weighted、latency、geolocation、geoproximity。**不支持** IP-based。
**PHZ 支持的健康检查**：仅可与 failover、multivalue、weighted、latency、geolocation、geoproximity 记录关联。

**Split-view / split-horizon DNS**：同名建 public + private 两个 hosted zone；VPC 内解析走 PHZ（内部内容），internet 解析走 public zone。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zone-private-considerations.html （"Split-view DNS" 段）

**重叠命名空间的解析优先级（most-specific-match / 最长匹配）**：当 public 与 private zone、或多个 PHZ 命名空间重叠（如 `example.com` 与 `accounting.example.com`），VPC Resolver 按**最具体匹配**选中 PHZ；匹配定义 = 完全相同，或 PHZ 名是请求域名的父级（`seattle.accounting.example.com` 命中 `accounting.example.com` 与 `example.com`，取更具体者）。无匹配 PHZ 时转公网递归。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zone-private-considerations.html

---

## 3. 记录类型（Record Types）

支持类型：A、AAAA、CAA、CNAME、DS、HTTPS、MX、NAPTR、NS、PTR、SOA、SPF、SRV、SSHFP、SVCB、TLSA、TXT，外加 Route 53 专有的 **Alias**（DNS 扩展，非标准记录类型）。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/ResourceRecordTypes.html

要点：
- **A** = IPv4；**AAAA** = IPv6。
- **CNAME** 与任何其他类型不能同名共存（DNS 规则）；因此 zone apex 不能建 CNAME。
- **CAA** 限制哪些 CA 可为域名签发证书；不能与同名 CNAME 共存。
- **DS**（Delegation Signer）用于 DNSSEC 信任链。
- 域名尾点可选（`www.example.com` 与 `www.example.com.` 等价）。

---

## 4. Alias vs CNAME（SME 高频对比）

Alias 记录是 Route 53 对 DNS 的专有扩展，把查询路由到选定 AWS 资源或同 zone 内另一记录。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resource-record-sets-choosing-alias-non-alias.html

| 维度 | Alias | CNAME |
|---|---|---|
| 可指向目标 | 仅选定 AWS 资源（CloudFront、S3 静态站点、ELB/ALB/NLB/CLB、API Gateway、VPC 接口端点、Global Accelerator、App Runner、Elastic Beanstalk、OpenSearch、AppSync、**同 zone 同类型的另一记录**） | 任意 DNS 名（可指向非 Route 53 托管域） |
| Zone apex（裸域 example.com） | **可以** | **不可以**（DNS RFC 禁止） |
| TTL | 指向 AWS 资源时**不能设 TTL**，用资源默认 TTL；指向同 zone 记录时用目标记录的 TTL | 可自设 TTL |
| 收费 | Alias 指向 AWS 资源的查询**免费** | 正常按查询计费 |
| 性能 | Route 53 直接回 IP，少一次 DNS 往返 | 需额外一次 DNS lookup 解析别名目标 |
| 目标健康感知 | 可设 **Evaluate Target Health**（自动跟随资源 IP 变化、感知健康） | 无 |
| 记录类型约束 | alias 必须与目标记录同类型；apex 即使 alias 也不支持 CNAME 型 | — |

- 业界佐证（zone apex / 额外 lookup / 性能）：
  - https://jayendrapatil.com/aws-route-53-alias-vs-cname/
  - https://www.repost.aws/questions/QUH6vOhyB6RcCWLbmzRAPLbg/route-53-cname-and-alias-differences
  - https://www.ibm.com/think/topics/alias-vs-cname
  - https://aws.amazon.com/blogs/networking-and-content-delivery/solving-dns-zone-apex-challenges-with-third-party-dns-providers-using-aws/

---

## 5. 路由策略（8 种）

总览 URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy.html

1. **Simple** — 单资源单值。不支持关联健康检查（simple 记录）。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-simple.html
2. **Failover** — active-passive 主备。主健康则回主，主全不健康回备。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-failover.html
3. **Geolocation** — 按**用户所在地**（查询来源地）路由，可按大洲/国家/美国州；重叠时**最小地理区优先**（Canada 优先于 North America）。可建 **default 记录**兜底无法映射的 IP，否则返回 "no answer"。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-geo.html
4. **Geoproximity** — 按**资源位置 + 用户位置**路由到最近资源，且可用 **bias** 扩张/收缩某资源的地理吸引范围（**+1..+99 扩大**，**-1..-99 缩小**，正 bias 缩小相邻区）。**需 Traffic Flow**。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-geoproximity.html
5. **Latency** — 多 Region 部署时路由到延迟最低的 Region。基于 AWS 长期测量的延迟数据（**非实时**），会随网络变化漂移。数据仅覆盖到 AWS 数据中心之间的流量。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-latency.html
6. **IP-based** — 按客户端源 IP（用你上传的 CIDR-to-endpoint 映射）路由。用 CIDR collection / location / block；查询 CIDR 比集合中更长时按较短的匹配，不匹配回 default `*`。IPv4 掩码 1–24，IPv6 掩码 1–48。**PHZ 不支持**。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-ipbased.html
7. **Multivalue answer** — 随机返回**最多 8 个**健康记录，可关联健康检查。是"带健康检查的简单负载分散"，非替代 ELB。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-multivalue.html
8. **Weighted** — 按权重比例分流：某记录流量 = 权重 / 组内权重和。权重 0 = 停止该记录（除非组内全为 0）。
   - https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-weighted.html

**Weighted + 健康检查的 0 权重行为（考点）**：Route 53 先只看非 0 权重记录；仅当所有非 0 权重记录都不健康时，才考虑 0 权重记录。
- https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-weighted.html

**EDNS0 / edns-client-subnet**：geolocation、geoproximity、latency、IP-based 用 EDNS0 拿到用户 IP 的截断前缀来估位。
- https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-edns0.html

---

## 6. 健康检查（Health Checks）

**三种类型**：
1. **Endpoint**（监控 IP/域名+端口，HTTP/HTTPS/TCP，可选 string matching）。
2. **Calculated**（父检查监控多个子检查，1 父可管**最多 255 子**，指定需多少子健康则父健康）。
3. **CloudWatch alarm**（监控 alarm 的**数据流**而非 alarm state；OK→健康，ALARM→不健康，INSUFFICIENT→按配置）。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/health-checks-creating-values.html

**判定机制（考点密集）**：
- 全球多地 health checker，无相互协调；间隔 **10s 或 30s**。
- 聚合规则：**> 18% 的 checker 报健康 → 健康；≤ 18% → 不健康**（18% 防止网络隔离误判）。
- 响应时间阈值：HTTP/HTTPS 需 **4s 内建 TCP 连接** + 连接后 **2s 内**回 2xx/3xx；TCP 检查需 **10s 内**建连；string matching 检查在收到状态码后需再 **2s 内**收到 body，匹配串必须在 body 前 **5,120 字节**内。
- **HTTPS 健康检查不校验证书**（过期/无效证书不会导致失败）。
- 新建健康检查在数据足够前默认视为**健康**（若开启 invert 则默认**不健康**）。
- 不能对 local/private/nonroutable/multicast IP 段建 endpoint 健康检查（建议 EC2 用 EIP 固定 IP）。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-failover-determining-health-of-endpoints.html

**Failover 主备与健康检查绑定（考点）**：
- Active-active：用除 failover 外**任意**路由策略（或组合），所有同名同类型同策略记录都活跃，除非被判不健康。
- Active-passive：用 **failover** 策略，Primary/Secondary。
- **绑定方式二选一**：指向可建 alias 的 AWS 资源时，**别建独立健康检查**，而是把 alias 记录的 **Evaluate Target Health 设 Yes**；指向不能建 alias 的资源时，才关联独立健康检查。
- 多资源主/备记录：只要至少一个关联资源健康，该 failover 记录即视为健康。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-failover-types.html
- 记录选择逻辑：https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/health-checks-how-route-53-chooses-records.html

---

## 7. Route 53 VPC Resolver（.2 / VPC+2 架构）

- VPC Resolver 对 VPC 内资源递归应答 public 记录、VPC 专有 DNS 名、PHZ 记录，**默认在所有 VPC 可用**。
- 接入地址：**VPC+2**（VPC CIDR 基地址 +2，即经典的 ".2 resolver"），连到某 AZ 内的 Resolver。（旧称 Route 53 Resolver，因引入 Global Resolver 而更名 VPC Resolver。）
- **Inbound endpoint**：允许**从**本地/其他 VPC 向本 VPC 发 DNS 查询（on-prem → AWS 解析）。
- **Outbound endpoint**：允许**从**本 VPC 向本地/其他 VPC 发查询（AWS → on-prem 解析）。
- **Resolver rule（conditional forwarding rule）**：每域名一条转发规则，指定把该域名的查询转发到哪；直接作用于 VPC，**可跨账号共享（RAM）**。
- 混合云（VPN / Direct Connect）DNS：outbound endpoint 转发到 on-prem resolver；on-prem 转发到 inbound endpoint 解析 AWS 名。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver.html
- 可用性与扩展：https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-availability-scaling.html

**PHZ vs Resolver forwarding rule 解析优先级（重要考点）**：对同一域名，**Resolver 转发规则优先于 PHZ**（forwarding rule takes priority over the private hosted zone）。
- re:Post 佐证: https://www.repost.aws/questions/QUptcBFQJeQlmWcaB2URmeZA/dns-resolution-with-forwarding-rule-and-phz
- 业界整理: https://dev.classmethod.jp/articles/private-hosted-zone-with-resolver-rule/

---

## 8. DNS Firewall（出站 DNS 过滤）

- 过滤 VPC **出站** DNS 查询（经 VPC Resolver），主用于防 **DNS 数据渗漏（exfiltration）**；也能拦 PHZ / VPC 端点名 / EC2 实例名的解析。是 VPC Resolver 的特性，无需额外部署。
- **只按域名过滤**，不解析成 IP，也不过滤 HTTPS/SSH/TLS/FTP 等应用层协议。
- 组件：rule group（可复用规则集，关联到 VPC）、rule、domain list（自建或 AWS 托管列表）、DNS Firewall Advanced（防 DNS tunneling / DGA）。
- **动作**：含 domain list 的规则可 ALLOW / BLOCK / ALERT；不含 domain list 的（Advanced）只能 BLOCK / ALERT。可自定义 BLOCK 响应。
- **Domain redirection 设置**：默认检查整条重定向链（CNAME/DNAME…），链上后续域名须显式加入 domain list 并设动作；trust 行为仅在单次查询事务内有效。
- **与 Network Firewall 区别**：DNS Firewall 只看经 VPC Resolver 的出站 DNS 查询；Network Firewall 过滤网络/应用层但看不到 Resolver 发起的查询。
- 可用 **AWS Firewall Manager** 跨组织集中管理 DNS Firewall rule group 关联。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-dns-firewall.html
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-dns-firewall-overview.html

**处理顺序（考点）**：
- 一个 VPC 关联多个 rule group 时，按**关联的 priority 数字从小到大**处理（lowest numeric priority first）。
- rule group 内每条 rule 有组内唯一 priority，也是**从小到大**处理。
- Firewall Manager 管的关联占据最低（first）与最高（last）优先级位置。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-dns-firewall-overview.html

---

## 9. DNSSEC signing

- DNSSEC signing 让 resolver 验证应答确来自 Route 53 且未被篡改，用公钥密码对每个应答签名。
- 两类密钥：**KSK（key-signing key）** 基于你自有的 **AWS KMS 非对称 customer managed key**，你负责管理/轮换；**ZSK（zone-signing key）** 由 Route 53 管理。
- 启用 DNSSEC signing 后 hosted zone **TTL 上限强制为 1 周**（设更长不报错但仍按 1 周执行）。
- **不支持 multi-vendor / vanity name server** 配置（须单一 DNS 提供商）。
- 父 zone 的 DNS 提供商必须支持 **DS 记录**，否则子 zone 启 DNSSEC 会变不可解析。
- 强烈建议对 `DNSSECInternalFailure` / `DNSSECKeySigningKeysNeedingAction` 设 CloudWatch 告警，快速处理否则可能整 zone 宕。
- 每 hosted zone **最多 2 个 KSK**。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-configuring-dnssec.html
- Resolver 侧 **DNSSEC validation**（验证，不同于 signing）：https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-dnssec-validation.html

---

## 10. Route 53 Profiles

- 跨多 VPC / 多账号统一管理 Route 53 DNS 配置；改 Profile 会传播到所有关联 VPC；可用 RAM 在同 Region 跨账号共享。
- 可关联资源：PHZ、Resolver rules（转发 + system）、DNS Firewall rule groups、Interface VPC endpoints、VPC Resolver query logging 配置。
- Profile 上直接管理的配置：反向 DNS lookup（Resolver rules）、DNS Firewall failure mode、DNSSEC validation。
- **一个 VPC 只能关联一个 Profile**；>300 个 VPC-PHZ 关联建议改用 Profiles。
- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/profiles.html

**Profile 优先级（考点）**：local VPC 设置 优先于 Profile 设置；域名冲突时**最具体（most specific）者胜**。

| DNS query | Profile rule | VPC (local) rule | 生效 |
|---|---|---|---|
| example.com | example.com | example.com | **Local VPC** |
| test.example.com | test.example.com | example.com | **Profile**（更具体） |
| marketing.example.com | 无 | marketing.example.com | **Local VPC** |

- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/profiles.html

---

## 11. ARC Routing Controls（Application Recovery Controller）

- Routing control 是简单的**开/关开关**，用于在多 Region 副本间切换客户端流量做 failover。
- 通过 **routing control health check**（与 Route 53 DNS failover 记录关联）实现流量重路由。
- 组件：cluster（**5 个 Region 的数据面**，高可用）、control panel、routing control、routing control health check。
- **Safety rules** 防止误操作导致意外恢复副作用（如避免同时把两个 Region 都关掉）。
- 推荐用 **AWS CLI / API**（而非控制台）切换状态，可批量。
- 与普通 Route 53 endpoint 健康检查区别：ARC routing control 是**人为决策的开关**（灾备演练/主动切换），不是被动探测端点健康。
- URL: https://docs.aws.amazon.com/r53recovery/latest/dg/routing-control.html
- 最佳实践: https://docs.aws.amazon.com/r53recovery/latest/dg/route53-arc-best-practices.regional.html

---

## 12. 服务配额（Quotas）

- URL: https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html
- 查看/提额须在 **US East (N. Virginia)** Region（Route 53 是全球服务但配额管理在 us-east-1）；Resolver 配额在对应 Region。

| 实体 | 配额 |
|---|---|
| Domains / 账号 | 20（2021-03 后新客户；老账号可能仍 50） |
| Hosted zones / 账号 | 初始 500（可提额） |
| 同一 reusable delegation set 可用的 hosted zone | 100 |
| 一个 PHZ 可关联的 VPC | 300（更多用 Profiles） |
| Records / hosted zone | 10,000（超出可提额，但**额外收费**） |
| Values / record set | 400 |
| 同名同类型的 geolocation/latency/multivalue/weighted/IP-based 记录 | 100 |
| 同名同类型的 **geoproximity** 记录 | **30** |
| KSK / hosted zone | 2 |
| CIDR collections / 账号 | 5 |
| CIDR blocks / collection | 1000 |
| 跨账号 VPC 关联 authorization | 1000 |

- API 侧可用 `GetAccountLimit` / `GetHostedZoneLimit` / `GetReusableDelegationSetLimit` 查当前配额。

---

## 13. 定价模型要点

- 官方定价页: https://aws.amazon.com/route53/pricing/
- **Hosted zone**：每个 hosted zone 每月按个数收费（前若干个一价，超出更低单价）；同一 zone 12 小时内删除不重复收费。
- **查询（queries）**：按百万次计费，standard / latency-based / geo / geoproximity 分档；**Alias 记录指向 AWS 资源（ELB、CloudFront、S3 站点、API Gateway 等）的查询免费**。
- **Health checks**：AWS endpoint 检查基础价；**非 AWS endpoint、HTTPS、string matching、快速间隔(10s)、延迟测量**等为附加费。
- **Traffic Flow**：按 policy record 每月计费。
- **Resolver endpoint**：按每个 ENI（endpoint IP）每小时计费 + 查询量计费。
- **DNS Firewall**：按 rule group 关联的查询量 + Advanced 规则计费。
- **Domain registration**：按 TLD 年费（转入/续费另计）。
- **DNSSEC**：signing 本身不额外收费，但 KMS KSK 与查询正常计费。
- 备考层面记结构即可（细价随时间变），SME 常考「哪些免费/哪些附加费」而非具体数字。

---

## 14. 业界深度解读（补充视角）

- Route 53 全景架构（routing policies / Resolver / PHZ / hybrid DNS，指出"只会建 A 记录"的心智模型在第二个 Region / 私网 / 第二账号出现时就崩）：
  https://hidekazu-konishi.com/entry/amazon_route_53_dns_architecture_guide.html
- SAA-C03 路由策略与"场景信号词→策略"速查：
  https://sailor.sh/blog/aws-route-53-routing-policies-saa-c03/
- Latency vs Geoproximity vs Geolocation 机制级对比（三者都涉地理但原理不同，混用会导致次优路由）：
  https://www.examcollection.com/blog/comparing-latency-geoproximity-and-geolocation-routing-methods/
- 路由策略完整指南：https://www.bitslovers.com/aws-route53-routing-policies/
- Alias vs CNAME 实务：https://oneuptime.com/blog/post/2026-02-12-route-53-alias-records-vs-cname/view

---

## 15. SME 高频考点与易错点（速记）

### A. Alias vs CNAME
1. **只有 Alias 能建在 zone apex（裸域）**；CNAME 永远不能（DNS RFC）。
2. Alias 指向 AWS 资源**不能设 TTL**（用资源默认）；指向同 zone 记录用目标记录 TTL。
3. Alias 指向 AWS 资源的**查询免费**；CNAME 正常计费且多一次 DNS 往返。
4. Alias 目标限选定 AWS 资源或**同 zone 同类型**记录；CNAME 可指任意 DNS 名（含外部）。
5. Alias 有 **Evaluate Target Health**；CNAME 无。

### B. 路由策略对比 / 边界
6. **Weighted vs Latency**：weighted 按你设的比例分（负载/灰度）；latency 按 AWS 测得的网络延迟（多 Region 性能）。latency 数据非实时、会漂移、只覆盖到 AWS 数据中心。
7. **Geolocation vs Geoproximity**：geolocation 只看**用户位置**、按大洲/国家/州、重叠取最小区、可设 default 兜底；geoproximity 看**资源+用户位置**、可用 **bias(±1..±99)** 移动边界、**需 Traffic Flow**、同名同类型上限仅 **30**。
8. **Geolocation 无 default 记录** → 未映射/未覆盖来源返回 "no answer"（易错：以为会随便返回一个）。
9. **Multivalue answer** 最多返回 **8** 个健康记录、带健康检查，但**不是 ELB 替代**（无真正负载均衡/会话）。
10. **Simple 路由不能关联健康检查**（simple 记录）。
11. **IP-based routing 在 PHZ 不支持**；PHZ 只支持 simple/failover/multivalue/weighted/latency/geolocation/geoproximity。
12. **Weighted 权重 0**：仅当所有非 0 权重记录都不健康时才启用 0 权重记录；单条设 0 = 停流量。

### C. Failover 与健康检查
13. **Active-passive = failover 策略**；**active-active = 除 failover 外任意策略**。
14. 指向可建 alias 的 AWS 资源做 failover 时，用 **Evaluate Target Health=Yes**，**不要**再单独建健康检查（易错点）。
15. **>18% checker 报健康才算健康**（≤18% 判不健康）。
16. HTTP/HTTPS：4s 建连 + 2s 回 2xx/3xx；TCP：10s 建连；string match 串须落在 body 前 **5120 字节**。
17. **HTTPS 健康检查不校验证书**（证书过期/无效不导致失败）——常见陷阱题。
18. **Calculated 健康检查**：1 父最多 255 子；**CloudWatch alarm 健康检查监控 alarm 的数据流**而非直接 alarm 状态；新检查在数据足够前默认健康（除非 invert）。
19. 不能对 private/nonroutable/multicast IP 建 endpoint 健康检查。

### D. Resolver / 混合 DNS / 优先级
20. **VPC+2（.2 resolver）** 是 VPC 内解析入口，默认所有 VPC 可用。
21. **Inbound endpoint = on-prem→AWS 查询**；**Outbound endpoint = AWS→on-prem 查询**（方向易混）。
22. **Resolver 转发规则优先于 PHZ**（同域名冲突时 forwarding rule 胜）。
23. **重叠命名空间取最长/最具体匹配**（`accounting.example.com` 胜过 `example.com`）。
24. Resolver rule **可经 RAM 跨账号共享**。

### E. DNS Firewall / Profiles / DNSSEC / ARC
25. **DNS Firewall 只管出站、只按域名、防 exfiltration**；rule group 与 rule 都按 **priority 数字从小到大** 处理；含 domain list 的规则才能 ALLOW，Advanced 只能 BLOCK/ALERT。
26. **DNS Firewall（域名层）vs Network Firewall（网络/应用层）**：后者看不到 Resolver 发起的 DNS 查询。
27. **Profile 优先级**：local VPC 设置优先于 Profile；冲突取最具体；**1 VPC 只能 1 Profile**。
28. **DNSSEC signing**：KSK=你的 KMS 非对称 CMK（你轮换），ZSK=Route 53 管；**启用后 TTL 强制 1 周**；不支持 multi-vendor / vanity NS；父 zone 提供商须支持 **DS 记录**；每 zone 最多 2 KSK。
29. **DNSSEC validation（Resolver）≠ signing（authoritative）**——两个不同特性别混。
30. **ARC routing control = 人为开/关开关**做多 Region failover（cluster 跨 5 Region），配 safety rules 防误切；不同于被动端点健康检查。

### F. 平台/配额/计费
31. Route 53 是**全球服务**，配额查看/提额、DNSSEC 等管理操作走 **us-east-1**。
32. **每 hosted zone 10,000 记录**（超出收费）；**geoproximity 同名同类型仅 30**（其他分散型策略 100）；**每 PHZ 关联 300 VPC**（更多用 Profiles）。
33. 注册链：**Registrar（Amazon Registrar / Gandi）→ Registry → WHOIS**；注册即自动建 public zone + 分配 4 NS。
34. Resolver 缓存 example.com 的 NS **典型 2 天**；应答缓存按记录 **TTL**。
35. **Alias→AWS 资源查询免费**、非 AWS endpoint / HTTPS / string-match / 10s 快检 / 延迟测量健康检查 **附加费**。

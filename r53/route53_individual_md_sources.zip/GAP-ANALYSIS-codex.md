# Route53 SME 体系缺口分析 — Codex 端（cx ask，2026-09-20）

以现有 22 topic 为基线，从 AWS 官方现行文档 + 2024-2025 新特性找缺失/待更新的 SME 考点：

1. **API 限流模型整体更新**：旧 40/5 或统一 5 RPS 已过时；现行账号级+operation 级双 token bucket，常规 burst 50/持续 10 RPS，DNS 变更 burst 1500/持续 100 changes/s，UPSERT 消耗 2。自动化/IaC 限流题常考。
2. **ARC 缺 Region switch + Readiness Check 定位变化**：补 plan/workflow/execution block/graceful vs ungraceful/cross-account/plan evaluation/恢复时间；Readiness Check 已不向新客户开放，官方推荐 Region switch。
3. **HTTPS/SVCB 需 RFC 9460 深度**：alias mode(priority 0)/service mode/优先级/alpn/port/ipv4hint/ech/ipv6hint/dohpath；R53 不支持 keyNNNNN；HTTPS/SVCB 支持 public/PHZ，SSHFP/TLSA 仅 public。
4. **缺 Cloud Map/ECS DNS 服务发现专题**：Cloud Map namespace/service/instance、DNS vs API discovery、MULTIVALUE/WEIGHTED、A/AAAA/SRV/CNAME、custom health vs R53 HC、ECS task 注册/注销生命周期。
5. **Global Resolver 独立成专题(标 Preview)**：anycast resolver/DNS Views/access source/DNSSEC validation/独立日志；易与 VPC Resolver 混。（What's New 2025-11）
6. **Profiles 2025 扩展**：interface VPC endpoint managed PHZ、Resolver query logging、同 Region/RAM/资源所有权、local-over-profile 冲突。
7. **Alias 目标矩阵刷新**：CloudFront distribution tenant、OpenSearch custom domain、VPC Lattice service custom domain；标 public/PHZ/ETH/计费边界。
8. **DNS Firewall Advanced 深度**：Dictionary DGA、DNS tunneling、LOW/MEDIUM/HIGH confidence threshold、规则互斥、Security Hub findings。
9. **Resolver 管理 API PrivateLink 边界**：2025-10 起可私网访问 Resolver 管理 API；保护控制面、不承载 DNS 查询，≠ authoritative API PrivateLink。
10. **Resolver 容量可观测性更新**：ResolverEndpointCapacityStatus + RNI/目标 DNS 延迟/rcode/timeout 指标；不能只靠 QueryVolume 推算容量。
11. **配额表改「默认/硬限制/可提额」三态**：Resolver endpoints、IP/endpoint、target IP/rule、rules、rule-VPC associations、Profiles、HC 现行配额；别把默认背成硬限。
12. **缺 EKS DNS 集成边界**：CoreDNS→VPC Resolver 数据面、私有 EKS endpoint managed PHZ、ExternalDNS 的 R53 API/IAM/TXT ownership/zone filter/限流；ExternalDNS 非托管 R53 功能。
13. **健康检查依赖删除风险**：删 HC 前需解除对它的引用依赖（route/policy）等。

# Route 53 SME 备考知识体系 —— 独立设计评审（Claude）

> 评审方：Claude（独立评审，批判视角）。范围：framework/00-knowledge-framework.md、topics/01–14（含 03b）、exam/ 全部题库、research/ 概览。**只读评审，未改动任何被评审文件。**
> 评审日期：2026-09-20。
> 评审目标：以「通过 Route 53 SME 考试」为唯一标尺，评估知识域覆盖完整性、四要素结合有效性、题库难度真实性、组织检索动线、技术准确性治理，以及过度/不足。
> 一句话结论：**这是一套完成度很高、以真实 case 为锚、经 Codex 审校的优秀备考体系；主要缺陷不在"错"而在"覆盖偏斜"——高频运维/可观测/成本/IPv6 等成套知识域缺失或单薄，且题库全是"知道答案"的辨识题、缺少真正区分 SME 的多跳诊断题。**

---

## ① 缺陷清单（按严重度）

### 高（会直接导致考场失分或能力盲区）

**H1. CloudWatch 指标 / query logging 作为独立可观测知识域缺失。**
全套 14 个 topic 没有一个系统讲 Route 53 的**监控与可观测面**：Public/PHZ 的 CloudWatch metrics（`DNSQueries`、`HealthCheckStatus`、`HealthCheckPercentageHealthy`、`ConnectionTime`、`TimeToFirstByte`、`SSLHandshakeTime`）、Resolver endpoint 的 `InboundQueryVolume`/`OutboundQueryVolume`/`EndpointHealthyENICount`、以及 **Resolver query logging（不同于 firewall 的 OCSF 日志）** 的配置对象、投递目标（CW Logs / S3 / Firehose）、字段结构。这些散落在 topic 04（HC 的 `get-health-check-status`）、topic 12（几个 CW 指标名）、topic 06（firewall 的 OCSF 日志）里，**没有一处把"如何观测 Route 53"当成独立能力来教**。真实 SME 考试与真实 case 高频考"客户说慢/间歇失败，你看哪个指标"，这是明显盲区。
- 建议落点：**新建 topic 15「监控与可观测（CloudWatch metrics + Query Logging）」**，或至少在 topic 04/12 各补一节；把 topic 14 已提到的 health checker `ConnectionTime/TimeToFirstByte/SSLHandshakeTime` 指标钉进考点。

**H2. 成本 / 计费作为知识域几乎不存在。**
计费信息碎片化散在各 topic 的"边界数字速记"里（hosted zone $0.50/月、Alias 查询免费、query 计费、HC 附加费）。SME 考试与 TAM 场景**必考成本对比与优化**：标准 vs 快速 HC 的价差、string-match/HTTPS/非 AWS endpoint/延迟测量的附加费、query pricing 分档（标准 vs latency/geo/geoproximity 的"特殊查询"更贵）、resolver endpoint 每 ENI 小时费、DNS Firewall 按查询计费、Traffic Flow policy record 月费。没有一处把这些拉通成"给定架构，成本怎么算/怎么省"。
- 建议落点：**在 topic 12（服务集成+配额）内新增「计费与成本优化」大节**，或独立 topic；把散落的计费数字集中成一张对照表 + 2–3 道成本场景题。

**H3. 题库全是"辨识题"，缺少真正区分 SME 的多跳诊断题。**
146 道题（52+46+48）+ 65 题 mock，绝大多数是"给现象/概念 → 选正确结论"的单跳辨识题，且**正确答案高度集中在 B**（exam-bank-01-07 的速查表里 5-1..5-7 全是 B、7-1..7-5 全是 B、4-2..4-7 除一题外全是 B）——这不仅是应试习惯问题，更暴露**题干设计缺乏真正的干扰项工程**：正确选项往往是"最长、最完整、写满限定词"的那条，考生靠"选最详细的"就能蒙对，与真实 SME 考试"每个选项都像对、要靠推理排除"的难度不符。真实 SME 认证/内部测评的难度来自**多跳链式推理**（如 03b 的 Q1–Q8 那种"ALB 挂→ETH→failover→fail-open→恢复"全链判断），而这种题**只在 03b 一处出现**，其余章节几乎没有。
- 建议落点：见 ③ 结构改进。每章至少补 2–3 道"选项等长、需排除法"的场景题，并把答案分布打散。

**H4. Resolver DNS Firewall「Advanced」与托管规则组的深度不足以支撑高频考点。**
topic 06 把 Global Resolver 的**实验流程**写得极详（30–40 分钟分步 lab），但对 **Advanced protections 本身的机制**（DGA / DNS tunneling 检测的置信度阈值 LOW/MEDIUM/HIGH 的语义与误报权衡、Advanced 与 domain-list 不能同规则、confidence threshold 调低的代价）只有寥寥数语；对**托管规则组的类别体系**（AWSManagedDomainsMalwareDomainList / BotnetCommandandControl / AggregateThreatList / AmazonGuardDutyThreatList 等具体列表名与覆盖面）几乎没有。SME 考试会考"选哪个托管列表""Advanced 阈值调高调低的影响"。
- 建议落点：topic 06 §1 补「Advanced protections 阈值语义 + 托管列表清单」小节。

### 中（覆盖偏斜或深度不均，影响得分稳定性）

**M1. Traffic Flow / policy record 作为独立机制缺失。**
Traffic Flow 只在 topic 03（geoproximity 可视化）和 03b（nested failover 的实现载体）里被顺带提到，从未系统讲：policy / policy record / policy version、按 policy record **月费**计费、可视化编排、与手工记录集互引的区别、如何回滚 policy version。ARC 的 nested/多层路由、复杂 geoproximity 都以它为实现载体，SME 会考"怎么搭多层路由"。
- 建议落点：topic 03 或 11 补「Traffic Flow policy record」节，或在 03b nested failover 处补实现细节。

**M2. IPv6 / DNS64 / AAAA 场景单薄。**
AAAA 记录只在 topic 02 记录类型表里一笔带过。没有讲：dual-stack 场景下 A + AAAA 的健康检查独立性、Alias 到 dual-stack 资源时 A/AAAA 记录类型如何随目标而定（topic 02/12 提了一句"类型取决于目标"但没展开）、DNS64/NAT64 与 Route 53 的关系、IPv6-only 客户端解析。SME 考试有 IPv6 相关题。
- 建议落点：topic 02 补 AAAA/dual-stack 节，或在 topic 12 集成处补。

**M3. Outbound endpoint 高可用 / 容量规划散且不成体系。**
关于 endpoint HA 的关键结论散在 topic 05（≤6 ENI、~10K QPS/ENI、NLB 降到 1.5–1.7K）、题库进阶章（conntrack vs throttling 指标区分、共享 vs 专用 endpoint 的吵闹邻居 COE、每 endpoint 至少 2 IP、加 IP 线性扩、迁移时机判主因）。这些**进阶题库里的内容质量很高**，但**没有一个 topic 把它固化成正文**——一旦考生只读 topics 不做进阶题库，就会漏掉"专用 vs 共享 endpoint 隔离""conntrack 6 倍降速""按 destip 聚合 timeout 定位目标 NS"这些真实 SME 核心。**知识存在于题库解析里，但不在教材正文里**，这是结构性隐患。
- 建议落点：把进阶题库第二章的 endpoint HA/限流诊断内容**上提**到 topic 05 正文（新增「endpoint 高可用与容量规划」节）。

**M4. Profiles 缺真实 case 且部分能力边界未覆盖。**
topic 10 明确标注"无绑定真实 case"，用推演场景替代——这在整套"case 为锚"的体系里是**唯一的例外**，削弱了它的说服力。且未覆盖：Profile 与 VPC 级 DNS 设置（reverse DNS、DNSSEC validation、firewall failure mode）的**冲突/覆盖优先级细节**、Profile 关联数量配额、Profile 与 RAM 共享后成员账号能改哪些。
- 建议落点：从内部 case inventory 里找一个真实的多-VPC/多账号治理 case 补进去（178782060900806 只是"提及"，可深挖）；补 Profile 配额与冲突优先级。

**M5. ARC「Zonal Shift / Autoshift」与「Readiness Check」被砍掉。**
framework 驱动表里 topic 11 原本列了「Multi-AZ：Zonal Shift/Autoshift 最长 72h」「Readiness Check 每分钟审计」「指标在 us-west-2」，但**实际 topic 11 正文只写了 Routing Controls**（cluster/safety rule/data plane），**Zonal Shift、Autoshift、Readiness Check 完全没写**。framework 的高频必考清单还写着"Zonal Shift 72h / ARC 指标在 us-west-2"，但正文查不到——**framework 承诺了、topic 没兑现**。这是覆盖与索引不一致的实锤。
- 建议落点：topic 11 补「Zonal Shift / Autoshift（Multi-AZ）」与「Readiness Check」两节，并核对 framework 清单与正文一致。

**M6. CAA / 记录级安全 / SPF-DKIM-DMARC 应用场景单薄。**
CAA 只在记录类型表里定义了"限制哪些 CA 签发"，没有场景题（如"客户证书被非授权 CA 签发怎么用 CAA 防"）。TXT 的 SPF/DKIM/DMARC 邮件安全场景、CAA 与 ACM/CloudFront 的交互也没展开。SME 会考 CAA 场景。
- 建议落点：topic 02 或新增小节补 CAA/邮件安全记录的场景。

**M7. 控制面限流数字在体系内不自洽（治理问题，见 ⑤）。**
topic 12 正文写"公共 API 账号桶 10 RPS 持续/突发 50"，但题库 12-4、12-5、进阶第 17 题都写"控制面 ~5 请求/秒"。两处都在同一体系里、都作为"正确答案"，**考生会困惑到底是 5 还是 10**。这是单一事实源缺位的直接后果。

### 低（打磨项，不影响通过但影响精度/体验）

**L1. 答案分布可预测（B 偏多）**，已在 H3 提及，属可快速修复的打磨项。

**L2. 部分 topic 命名/编号风格不统一**：topic 07/12/13/14 用「# Topic NN —」或「# NN.」混排，topic 01–06/08–11 用「# NN.」，检索时轻微割裂。

**L3. 实验 Lab 大量为"受控/概念演练/需真实资源"，缺少纯离线可练的判读练习。** 例如很多 lab 需要真建 endpoint（有成本）；而 SME 备考更需要"给你一段 dig 输出/一段 flow log/一张 NACL 表，判读结论"这类零成本高频练习。topic 13 的 dig 分层实验方向对，但只有一处。

**L4. framework 的「高频必考清单」是纯文本长句堆叠**，没有做成可勾选的 checklist 或按域分组的速查卡，复习末期"过一遍硬结论"的动线不够顺。

**L5. 时效性数字缺"复核日期"标注机制。** 配额（500 zones、10000 records、300 VPC/PHZ、6 ENI）、边缘规模、TTL 默认值等会变，除 topic 14 对"50+ edge/80% resolver"做了"2014 背景数字非现行值"的免责，其余数字没有"采集/复核日期 + 官方 URL"的统一戳记，未来会悄悄过时（见 ⑤）。

---

## ② 建议补充的具体知识域 / 内容

按你在任务里点名的候选逐一给判定 + 落点：

| 候选知识域 | 现状 | 判定 | 建议落点 |
|---|---|---|---|
| **CloudWatch metrics / query logging** | 碎片化，无独立域 | **必补（H1）** | 新建 topic 15，或 topic 04+12 各补节 |
| **成本 / 计费** | 碎片在各"边界数字" | **必补（H2）** | topic 12 新增「计费与成本优化」大节 + 对照表 |
| **Resolver DNS Firewall Advanced / 托管列表** | 实验详、机制浅 | **补（H4）** | topic 06 §1 补阈值语义 + 托管列表清单 |
| **Traffic Flow policy record** | 顺带提及，无系统讲 | **补（M1）** | topic 03/11 补节 |
| **ARC Zonal Shift / Autoshift / Readiness Check** | framework 列了、topic 没写 | **必补（M5）** | topic 11 补两节 + 对齐 framework |
| **IPv6 / DNS64 / AAAA / dual-stack** | 一笔带过 | **补（M2）** | topic 02 补 dual-stack 节 |
| **Outbound endpoint 高可用 / 容量规划** | 在题库里、不在正文 | **必补（M3）** | 把进阶题库第二章上提到 topic 05 正文 |
| **CAA / 记录级安全 / SPF-DKIM-DMARC** | 定义有、场景无 | **补（M6）** | topic 02 补 CAA/邮件安全场景 |
| **Profiles 跨账号真实 case + 配额/冲突** | 无 case、边界不全 | **补（M4）** | topic 10 补真实 case + 配额 |

**额外发现的、你未点名但同样值得补的域：**

- **N1. `dig` / `dnstools` 判读技能的成套练习**（零成本、高频）——把散在各 topic §3 的 dig 命令与 topic 13 的分层判读，抽成一个「DNS 排障命令速查 + 判读练习集」（可作 topic 13 附录或独立 cheat sheet）。
- **N2. Route 53 与 ACM 证书验证 / CloudFront 的交互**——ACM DNS 验证 CNAME、CloudFront resolver identity 间歇 NODATA（topic 12 提了一句）、证书续期与 DNS 记录的耦合（topic 01 case 合并时提到），值得成节，SME 会考。
- **N3. 私有区 NS 委派缺口的等效替代**（进阶题库第 7 题的"R53 私有区不支持 NS 委派，用多 PHZ + 重叠命名空间 + resolver rule 等效"）——这是真实高频卡点，只在题库里，应上提到 topic 01 或 05 正文。
- **N4. Reusable delegation set / white-label NS**——只在 topic 14 提了一句，SME 会考"多 zone 共用 NS 便于注册商侧配置"，可在 topic 01 补。

---

## ③ 结构 / 流程改进

**S1. 建立"单一事实源"约定，消除数字冲突（对应 H2/M7/⑤）。**
明确规定：**边界数字/配额/计费的权威值只写在 framework 的一张「硬数字总表」里，各 topic 只引用不重复定义**。当前每个 topic 都有自己的"边界数字速记"，导致 5 RPS vs 10 RPS 这类冲突。改为：framework 建「配额与限流总表」（含官方 URL + 复核日期），topic 引用时写"见 framework 总表"或直接同步。这条能根治体系内自相矛盾。

**S2. framework 驱动表 ↔ topic 正文 ↔ 题库，做一次三向一致性核对（对应 M5）。**
现在 framework 承诺了 topic 11 有 Zonal Shift、高频清单写了 Zonal Shift 72h，但 topic 11 正文没有。应建一个轻量核对表：每个 framework 承诺的知识点，标注它在哪个 topic 的哪节兑现、在题库哪几题被考。**任何 framework 列出但正文/题库缺失的，就是覆盖漏洞**。这也顺带发现 M3（endpoint HA 在题库不在正文）这类"正文欠题库"的反向漏洞。

**S3. 题库难度分层 + 干扰项工程（对应 H3/L1）。**
- 把题库显式分三层：**L1 辨识（现有大部分）/ L2 单跳诊断 / L3 多跳链式**。SME 通过靠 L2/L3，现在几乎只有 L1（除 03b）。每章补 2–3 道 L3。
- **干扰项工程**：正确选项不再是"最长最全"那条；每个错误选项都要是"真实世界里有人会犯的具体误解"，且长度与正确项相当。
- **打散答案分布**：当前 B 严重偏多，考生可能形成"选 B/选最长"的应试捷径，这会让 mock 分数虚高、掩盖真实掌握度。
- mock-exam-scored 的加权（03/04/05/02 加重）方向正确，但应确保加重域里 L2/L3 题占比更高，而不是靠堆 L1 题数加权。

**S4. 把"存在于题库解析、缺席于正文"的知识上提为正文（对应 M3/N3）。**
进阶题库（exam-bank-advanced-tt-principles）里含大量正文没有的真实 COE/TT 知识（conntrack vs throttling 指标判主因、共享 endpoint 吵闹邻居、私有区无 NS 委派的等效替代、`.` rule 无 forward-first 回落、跳级委派间歇失败）。这些**质量极高但只有做题才能学到**。应把它们反哺进对应 topic 正文，让"只读 topic"的考生也能覆盖。否则题库解析实际承担了教材职责，结构失衡。

**S5. 新增末期复习动线：一页硬结论 checklist + 零成本判读练习集（对应 L3/L4）。**
- 把 framework 的高频必考长句，重排成**按域分组、可勾选的 checklist 卡**（diagrams/00-review-mindmap.md 已有 mindmap，可配一张纯文字硬结论卡）。
- 建一个「给输出判结论」的零成本练习集（dig 输出 / flow log 片段 / NACL 表 / OCSF 日志行 → 判读），补足现有 lab"需真实资源、有成本"的短板。

**S6. 统一 topic 文件的标题/编号/分节骨架（对应 L2）。**
framework §"每个 topic 文件的统一模板"已定义 5 段结构，但 topic 07/12/13/14 的一级标题风格与 01–06 不一致。做一次格式归一，让检索与自动化处理（如按节抽取考点）更稳。

**S7. 为所有时效性数字加"采集/复核日期 + 官方 URL"戳记，并设复核周期（对应 L5）。**
research/ 已标"采集日期 2026-09-20"，但 topic 正文的硬数字没有逐条戳记。建议每个配额/计费/默认值旁标注来源 URL + 复核日期；配一个"季度复核"提醒。topic 14 对 2014 博客数字做的免责是好范例，应推广。

---

## 评审收尾说明

**这套体系的突出优点**（评审需诚实记录，避免只挑刺）：case-锚定极强、四要素（概念-案例-实验-考点）结构统一且大部分执行到位、Codex 审校发现的技术错误（glue 必需性、AA vs AD、5 Scenario 只防 1、fail-open vs no-answer、DS 不含公钥、weight-0 兜底、negative TTL = min(MINIMUM,TTL) 等）都已订正、topic 03b 和进阶题库的多跳/COE 内容达到了真正的 SME 深度。**缺陷集中在"覆盖偏斜"而非"内容错误"**：可观测/成本/IPv6/Traffic Flow/Zonal Shift 等成套域缺失或单薄，题库难度结构偏辨识、答案可预测，以及少数 framework↔正文↔题库的一致性裂缝和单一事实源缺位导致的数字冲突。按 ① 的高/中优先级补齐 + ③ 的 S1/S2/S3/S4 四条结构改进，即可从"很好的备考材料"提升到"能真实区分并保证通过 SME"的体系。

# Route53 SME 体系设计评估 — Codex 端（cx ask，2026-09-20）

总体：体系已有很强的「案例—原理—实验—考点」闭环，但更像 R53 支持工程知识库，而非按考试蓝图校准的备考产品。最大风险不是覆盖不足，而是少数过时/内部结论被提升为硬考点。

## 设计缺陷
### 严重
1. Master Syllabus 未成为准确性单一事实源——总纲仍残留已在 topic 修正的错误（DNSSEC TTL 强制一周 / API 40-5 限流 / Alias 链不可再指 Alias），总纲错误会覆盖 topic 正文修正。
2. 缺可验证的考试蓝图与权重依据（"前三域占比最大/高频必考"无题目统计支撑；15 个 case 偏异常 support 场景 abuse/账号关闭/.jp 特例，不足以代表真实 SME 分布）。
3. 内部事实 / 公开产品契约 / 个案推断 混为同级硬考点（MaxMind、内部吞吐经验、StopZoneSniping 后端、Support Ops 流程）。应分级：公开且现行 / 内部运营 / case-specific / 推断待验证。
4. 缺内容版本治理（Profiles/Global Resolver/ARC/API 限流变化快；ARC 已增 Region switch，框架仍围绕 routing control/readiness）。
5. 部分实验安全等级与实际动作不符（他账号抢注同名 zone、DNSSEC 禁用、Zonal Shift、建 ALB/endpoint 非只读；应给隔离账户/费用/回滚/禁止执行版本）。
### 较高
6. 四要素模板过度强制（并非每主题都需真实 case/实验/Mermaid，易造低价值或高风险实验）。
7. 题库偏数字背诵（缺"多答案均可行选最佳""条件不足""排除干扰项"真实判断）。
8. 考试知识与 Support 运营混杂（case ID/内部工具/2PR/abuse 应移入独立 Operations 附录）。
9. 主题粒度失衡（DNS Firewall+Global Resolver、集成+配额过宽；Traffic Flow、可观测性无独立主题）。
10. 知识域编号不一致（名义 13 topic，实际有 03b、14；主线/专题/横切缺层级）。
### 中
11. 案例锚定过拟合风险（单 case 偶然配置被误记为通用规则）。
12. 缺反例训练（只给正确路径，无"相似症状不同根因"）。
13. 跨主题重复多（ETH/fail-open/ECS/TTL/优先级 多处重复→版本漂移）。
14. 检索入口单一（只按产品域，缺按症状/错误码/API/硬数字/选型信号词索引）。
15. 题库缺质量指标（难度/区分度/干扰项有效率/错题原因/知识点覆盖率）。
### 低
16. Mermaid 过量；17. 实验命令过长应移入 Lab Manual；18. 学习路线仅线性，缺诊断测验/薄弱域分支/冲刺路线。

## 建议补充知识域
- 00 DNS 协议基础（delegation/glue/bailiwick、UDP 截断 TCP fallback、EDNS0、NXDOMAIN vs NODATA、负缓存）
- Traffic Flow 独立专题（traffic policy/版本/policy instance/复杂 alias tree/回滚/计费）
- 日志与可观测性（Public DNS query logging、Resolver query logging、CloudWatch 指标、CloudTrail、缓存对日志影响）
- Resolver 高级（delegation rules、autodefined/system rules、DoH/DoH-FIPS、IPv6/dual-stack、DNS64、Resolver on Outposts）
- ARC Region switch（与 routing control/readiness/zonal shift 的职责边界）
- IAM 与治理（R53/Resolver 权限、KMS policy、RAM、SCP、防误删、跨账号责任）
- 控制面语义（PENDING/INSYNC、批量变更、幂等、重试、PriorRequestNotComplete、现行限流模型）
- 成本模型（hosted zone/query/health check/resolver endpoint/traffic flow/日志费用）
- 反例库（相似症状不同根因）

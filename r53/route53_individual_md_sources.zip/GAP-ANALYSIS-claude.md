# Route 53 SME —— 独立知识缺口分析（GAP ANALYSIS · Claude 独立评审）

> **评审方**：独立评审 sub-agent（Claude）。**日期**：2026-09-20。
> **评审范围（只读）**：`framework/00-knowledge-framework.md`、`framework/00b-canonical-facts.md`、全部 `topics/*.md`（22 个）标题+考点节、`INDEX-by-symptom.md`、`exam/` 题库标题。
> **方法**：对照真实 Route 53 SME 应覆盖面，只找「缺 / 薄 / 可能过时 / 错配」，不复述已覆盖内容。
> **权威冲突处理**：本文件只提缺口，不改任何硬数字；硬数字仍以 `00b-canonical-facts.md` 为准。

---

## ① 缺口清单（按重要度：高 / 中 / 低）

> 每条 = **缺什么** + **为何该补** + **建议落点**（新建 topic 或塞进现有 topic）。

### 🔴 高优先级（真实 case / 考试大概率命中，现体系几乎空白）

**H1. AWS Cloud Map / ECS Service Connect / 服务发现（整类缺失）**
- **缺什么**：Cloud Map（`servicediscovery`）如何用 Route 53 做服务发现——namespace = PHZ、service = 记录集、SRV/A/AAAA 自动注册注销、`DiscoverInstances` API 路径、Cloud Map 私有 vs 公共 namespace、ECS service discovery 与新的 Service Connect 的区别、Cloud Map 自动建的 PHZ 与手工 PHZ 的关系（删 namespace 会连带删 zone）。
- **为何该补**：这是 R53 在容器/微服务场景最高频的真实集成，SME case 常见「Cloud Map 建的 PHZ 里记录莫名消失/无法手删」「ECS 任务退出后 SRV 记录不清理」。现体系 22 个 topic 对 Cloud Map **零覆盖**，`servicediscovery` 关键字仅出现在 research 文件，从未进 topic。
- **建议落点**：**新建 topic 21 — Cloud Map / 服务发现与 R53 的耦合**，与 topic 01（PHZ）、topic 20（Resolver 高级）交叉引用。

**H2. HTTPS / SVCB 记录（RFC 9460）深度（现仅列表级，深度为零）**
- **缺什么**：topic 02 只把 `HTTPS`/`SVCB` 列在「支持的记录类型」清单里，**无任何 RFC 9460 细节**：SvcPriority（AliasMode=0 vs ServiceMode）、SvcParams（`alpn`、`port`、`ipv4hint`/`ipv6hint`、`ech`）、HTTPS 记录如何让浏览器免一跳直接 HTTP/3/ECH、SVCB 与 CNAME-at-apex 问题的关系（HTTPS 记录可在 apex 表达「等价 CNAME」语义）、R53 对这两类记录的录入格式。
- **为何该补**：HTTPS/SVCB 是近年新增标准记录类型，浏览器（Chrome/Safari/Firefox）已广泛查询，ECH/HTTP3 推广使其考点权重上升；SME 被问「apex 想要 CNAME 效果又想指外部域，能不能用 HTTPS 记录」「客户端在查 type65 是什么」时现体系答不出深度。
- **建议落点**：**加深 topic 02**（新增 §1.4「HTTPS/SVCB 记录与 RFC 9460」），或并入 H1 附近的新记录类型专题。

**H3. Route 53 ↔ PrivateLink / VPC Interface Endpoint 深度（现仅一行 Alias 目标）**
- **缺什么**：topic 12 只有一行「VPC Interface Endpoint（PrivateLink）→ ✅ 可做 Alias 目标」。缺：Private DNS for endpoint 开关（`PrivateDnsEnabled`）如何自动建/劫持 zone、endpoint-specific vs service-wide 的 regional/zonal DNS 名、开 Private DNS 后与自建 PHZ 的**命名空间冲突**、跨 VPC/跨账号消费 endpoint 的 DNS、endpoint DNS 与 Resolver 转发规则的优先级交互。exam-bank-advanced Q5（PrivateLink 端点解析不出私有 IP + CloudAuth token prefetch timeout）已在考、但无 topic 深度支撑。
- **为何该补**：PrivateLink DNS 是企业内网/SaaS 消费最常见的 R53 疑难，且题库已经出题却无对应正文（见④错配 M-mismatch-1）。
- **建议落点**：**加深 topic 05（Resolver）或 topic 12（集成）**，新增「PrivateLink Private DNS 与 PHZ 冲突」专节；与 topic 01 split-horizon 交叉。

**H4. EKS ExternalDNS 作为独立能力（现仅当作「合并 zone 的坑」提了一句）**
- **缺什么**：ExternalDNS 目前只在 topic 01（合并 zone 时改 `--zone-id-filter`）和 topic 19（IAM 拆 `ListHostedZones` Statement）里被顺带提到。缺：ExternalDNS 的工作模型（TXT registry `heritage=external-dns`、owner-id、`txtOwnerId`、sync vs upsert-only policy）、它对 R53 API 的调用节奏（易触发 topic 12 的 100 changes/s 限流）、IRSA 权限最小集、多集群共享一个 zone 的 owner 隔离。
- **为何该补**：EKS + ExternalDNS 是 K8s 上 R53 的事实标准，故障（记录漂移、删不掉、限流）频繁进 case。
- **建议落点**：并入 **H1 新建 topic 21**（服务发现族）或 topic 12 增设「ExternalDNS 运维」节。

### 🟡 中优先级（真实存在、考点中等，现体系薄或缺角）

**M1. 迁移场景：zone 导入 / 大批量记录变更 / 从他方 DNS 迁入 R53（整类偏薄）**
- **缺什么**：BIND zone file 导入（控制台 Import zone file / CLI）、`ChangeResourceRecordSets` 单次打包 vs 循环单条（topic 12 只提了一句限流，无迁移剧本）、`GetHostedZoneCount`/`ListResourceRecordSets` 分页导出、迁移四阶段剧本（降 TTL → 双跑 → 切 NS → 观察 → 拆旧）、跨 registrar 迁移与 DNS 迁移的解耦。topic 00a §有「降 TTL 提前 24h」的锚点，但没有成体系的迁移 topic。
- **为何该补**：「帮我把 DNS 迁到 R53 / 大批量改记录报 Throttling」是高频咨询型 case。
- **建议落点**：**新建 topic 22 — DNS 迁移与批量变更剧本**，聚合 00a 的 TTL 锚点 + 12 的限流 + 01 的 NS 委派切换。

**M2. 私有 DNS 与 on-prem AD / Windows DNS 集成模式（现只有通用 Resolver 转发）**
- **缺什么**：topic 05/20 讲了 Inbound/Outbound/Delegation 通用机制，但缺针对 **Active Directory / Windows DNS** 的具体模式：AD 的 `_msdcs`/SRV 记录如何经 Outbound 转发、条件转发器双向配置、AD 加域主机的 DNS suffix search list、Managed AD（Directory Service）自带的 DNS 与 Resolver 的关系、Simple AD vs AWS Managed Microsoft AD 的 DNS 行为差异。
- **为何该补**：混合云里 on-prem 侧几乎都是 AD/Windows DNS，SME 需要能对着 AD 的 SRV 结构排障，而不只是「转发规则优先级」抽象。
- **建议落点**：**加深 topic 05**（新增「与 on-prem AD/Windows DNS 集成」节）。

**M3. 跨区域 / 跨账号复杂 DNS 架构（散点存在，无统一架构 topic）**
- **缺什么**：现体系把跨区/跨账号碎片散在 01（PHZ 跨账号关联）、05（RAM 共享 rule）、10（Profiles）、19（RAM/partition 边界）。缺一个**架构综合 topic**：多区 active-active/active-passive 的 DNS 分层、跨账号「hub-and-spoke Resolver」中心账号出站 + RAM 分发模式、centralized DNS account 反模式与最佳实践、跨账号 PHZ + Profiles + Resolver rule 三者的选型决策树、跨 Region PHZ 关联的适用边界。
- **为何该补**：SME 常被要求「设计一个多账号多区的企业 DNS」，需要能把碎片拼成架构而非逐点回答。
- **建议落点**：**新建 topic 23 — 企业级跨区/跨账号 DNS 架构（综合选型）**，或在 topic 10 增设「架构模式」节。

**M4. Resolver DNSSEC validation（与 signing 明确区分，现只有一句锚点）**
- **缺什么**：topic 07 反复讲 signing（KSK/ZSK/DS），并点了「validation ≠ signing」，但**没有独立展开 Resolver 端 DNSSEC validation 的开关、行为、故障**：在 VPC Resolver 上启用 validation 后，验签失败返回 SERVFAIL 的现象、如何区分「权威没签 vs 递归验签失败」、启用 validation 对 topic 17 SERVFAIL 差分诊断的影响。
- **为何该补**：客户启用 Resolver DNSSEC validation 后「某些域突然 SERVFAIL」是真实 case，需与 signing 故障切开。
- **建议落点**：**加深 topic 07**（新增「Resolver 端 validation」节）+ topic 17 SERVFAIL 类别补一行。

**M5. DNS over HTTPS/TLS（DoH/DoT）在 topic 20 出现于标题但正文深度存疑**
- **缺什么**：topic 20 标题含 `DoH`，但需确认正文是否讲清 R53 Resolver 对 DoH/DoT 的支持边界、与 DNS Firewall/query logging 的交互、客户端加密 DNS 绕过企业 DNS Firewall 的风险。（本评审只读标题+考点节，正文深度需 owner 自查；列为中优先「疑薄」。）
- **建议落点**：确认 topic 20 正文覆盖，不足则加深。

### 🟢 低优先级（补全度问题，考点较窄或偏冷）

**L1. 反向 DNS（PTR）/ IP → 名称 与 in-addr.arpa 委派**：topic 02 列了 PTR 类型，但无反向区、无 EC2/EIP 反向 DNS 申请流程（邮件发送 IP 声誉相关）、无 `ip6.arpa`。建议 topic 02 或新记录专题补一小节。
- **L2. R53 Resolver on Outposts / 混合边缘**：topic 20 标题提 Outposts，深度需自查；偏冷，低优先。
- **L3. CAA 记录与 ACM/证书签发链路**：topic 02 提了 CAA 不能与 CNAME 共存，但没讲 CAA 如何影响 ACM DNS 验证与第三方 CA 签发失败的排障。低优先补 topic 02。
- **L4. IPAM / ip-ranges 之外的公共 NS IP 生命周期**：topic 12 有 ip-ranges.json + SNS，够用；IPAM 关联极弱，可忽略。

---

## ② 现有 topic 里偏薄、需加深的（结构骨架够但深度不足）

| topic | 现状 | 需加深点 |
|---|---|---|
| **02 记录与 Alias** | HTTPS/SVCB **仅列表级**，PTR 无反向区，CAA 无签发链路 | 见 H2 / L1 / L3 |
| **12 集成与配额** | PrivateLink **仅一行 Alias 目标**；批量变更**仅一句限流** | 见 H3 / M1 |
| **05 Resolver** | 通用 Inbound/Outbound 强，但**无 AD/Windows DNS 具体模式**、**无 PrivateLink Private DNS 冲突** | 见 M2 / H3 |
| **07 DNSSEC** | signing 侧扎实，**validation 侧仅一句** | 见 M4 |
| **10 Profiles / 01 PHZ / 19 IAM** | 跨账号能力散点，**无综合架构视图** | 见 M3 |
| **20 Resolver 高级** | 标题含 DoH/Outposts/DNS64，**正文深度需 owner 自查**（本评审只读标题） | 见 M5 / L2 |
| **11 ARC** | 正文标注 Readiness Check「不再对新客户开放」——**需确认体系其他处（框架/canonical）是否已同步这条时效性变化**，避免过时表述残留 | 时效性核对 |

---

## ③ 题库覆盖 vs topic 覆盖的错配（exam ⟷ topics 对不齐）

- **Mismatch-1（PrivateLink）**：`exam-bank-advanced-tt-principles.md` Q5 已考「PrivateLink 端点解析不出私有 IP，CloudAuth token prefetch timeout，先查哪两个 VPC 属性」，但 topic 侧只有 topic 12 一行 Alias 目标——**考在正文之外**。→ 补 H3 后回填题目落点。
- **Mismatch-2（ECS + PHZ）**：Q4「ECS 服务 UnknownHostException，删某 PHZ 后恢复」实为服务发现/命名空间冲突场景，但无 Cloud Map/服务发现 topic 承接。→ 补 H1。
- **Mismatch-3（conntrack / 共享 endpoint 吵闹邻居）**：advanced 题库 Q12–Q18 大量考 `conntrack_allowance_exceeded_delta`、`udp_throttled_count`、共享 vs 专用 endpoint 隔离、TRE COE——这些**深度在 research/内部素材里**，但对照 framework 驱动表，topic 05/20 的**考点节是否把这些指标名与判别纪律固化进正文**需核对；若只在题库解析里出现而正文缺，属错配。→ 核对 topic 05/20 正文，必要时把 conntrack/throttle 指标判别补进 topic 05 考点节。
- **一致性抽查建议**：对 `exam/` 每道题解析里引用的「（Topic NN §x）」锚点做一次自动化回链校验，确认每个被引小节真实存在——本评审抽样发现 advanced 题库多题只引 research 而不引 topic 小节，存在锚点悬空风险。

---

## ④ framework 承诺但正文可能没有的（驱动表 vs 落地）

- **F1**：框架驱动表 topic 06 承诺「Global Resolver + DNS View + Access Source/Token + OCSF query log」完整 lab；topic 06 标题节可见 lab 骨架，但 **Global Resolver / DNS View 属较新特性，需核对正文是否真讲清 Access Source/Token 与 OCSF 字段**，避免只有 lab 步骤无概念深度。
- **F2**：框架把 topic 00a/14/15/16/17/18/19/20 列为已扩展域，但**驱动表（第「知识域驱动表」表格）只列到 01–13**，14–20 与 00a 未进驱动表 → framework 的「驱动表」与实际 topic 清单**已脱节**（INDEX 全清单列到 17，driver table 列到 13，实际到 20）。建议把驱动表补齐到 20 并纳入 00a，否则新学员按驱动表学会漏掉 7 个 topic。**（这是一条 framework 自身的结构性缺口，优先级等同高。）**
- **F3**：canonical-facts `00b` 覆盖限流/HC/配额/DNSSEC/路由/传播/ARC 七类硬数字，但**未收录**：HTTPS/SVCB 无硬数字条目、Cloud Map/服务发现相关配额（每 namespace 记录数等）、Traffic Flow versioning 默认 1000（散在 topic 18 来源行，未进 00b）、query logging 指标保留期「two weeks」（散在 topic 15）。建议把这些边界数字**上收进 00b** 以维持单一权威源承诺。

---

## ⑤ 优先级建议（补齐顺序）

1. **先补 framework 自身脱节（F2）**——驱动表补齐到 topic 20 + 纳入 00a。这是元层缺口，不补则后续所有「按驱动表备考」都漏 7 个域，**成本最低、影响最大**。
2. **H1 Cloud Map/服务发现 + H4 ExternalDNS**（合并为新 topic 21）——真实 case 最密集的整类空白，且已有题库悬空（Mismatch-2）。
3. **H3 PrivateLink 深度**——题库已考、正文缺（Mismatch-1），加深 topic 05/12 即可，不必新建。
4. **H2 HTTPS/SVCB RFC 9460**——加深 topic 02，工作量小、时效性考点上升快。
5. **M1 迁移剧本（新 topic 22）+ M3 跨区跨账号架构（新 topic 23）**——咨询型 case 高频，但可由现有碎片聚合，非从零。
6. **M2 AD/Windows DNS + M4 Resolver validation + M5 DoH 核对**——加深 topic 05/07/20。
7. **F3 硬数字上收 00b + ③ 题库锚点回链校验**——一致性维护，随上述各项顺带完成。
8. **低优先 L1–L4**——补全 topic 02/20 的窄考点，最后处理。

> **元建议**：③ 的「题库解析锚点回链校验」和 F2 的「驱动表补齐」应做成一次性脚本/清单，纳入项目 versioning 流程，避免 topic 继续扩张时 framework 与 exam 再次脱节。
